﻿Imports MySql.Data.MySqlClient
Public Class Admin_Conceptos

#Region "Load de conceptos"
    Private Sub Admin_Conceptos_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        TabControl_HaberesDescuentos.Dock = DockStyle.Fill
        TabControl_ManageDescuentos.Dock = DockStyle.Fill
        TabControl_MangeHaberes.Dock = DockStyle.Fill
    End Sub
#End Region

#Region "Manejo Haberes"
    'Al clickear en boton "haberes" se despliega la Tab correspondiente
    Private Sub btnHaberes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHaberes.Click
        btnDescuentos.Image = My.Resources.money_down
        btnDescuentos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnHaberes.Image = My.Resources.money_up_red
        btnHaberes.ForeColor = Color.FromArgb(255, 167, 37, 57)
        TabControl_HaberesDescuentos.SelectedTab = TabPage_Haberes
        pnlSelection.Width = btnHaberes.Width
        pnlSelection.Location = New Point(btnHaberes.Location.X, pnlSelection.Location.Y)
        '---------------------------------------------------------------------------------------------
        Dim VerHAB_cnn As New MySqlConnection("data source=localhost;user id=root; password='1234';database=tax")
        Dim VerHAB_adapter As New MySqlDataAdapter("SELECT * FROM haberes ", VerHAB_cnn)
        Dim VerHAB_table As New DataTable()

        VerHAB_adapter.Fill(VerHAB_table)

        VerHAB_cbHaberes.DataSource = VerHAB_table
        VerHAB_cbHaberes.ValueMember = "haber_id"
        VerHAB_cbHaberes.DisplayMember = "nombre"
        '---------------------------------------------------------------------------------------------
        Dim ModHAB_cnn As New MySqlConnection("data source=localhost;user id=root; password='1234';database=tax")
        Dim ModHAB_adapter As New MySqlDataAdapter("SELECT * FROM haberes ", ModHAB_cnn)
        Dim ModHAB_table As New DataTable()

        ModHAB_adapter.Fill(ModHAB_table)

        ModHAB_cbHaberes.DataSource = ModHAB_table
        ModHAB_cbHaberes.ValueMember = "haber_id"
        ModHAB_cbHaberes.DisplayMember = "nombre"
        '---------------------------------------------------------------------------------------------
        Dim ElimHAB_cnn As New MySqlConnection("data source=localhost;user id=root; password='1234';database=tax")
        Dim ElimHAB_adapter As New MySqlDataAdapter("SELECT * FROM haberes ", ElimHAB_cnn)
        Dim ElimHAB_table As New DataTable()

        ElimHAB_adapter.Fill(ElimHAB_table)

        ElimHAB_cbHaberes.DataSource = ElimHAB_table
        ElimHAB_cbHaberes.ValueMember = "haber_id"
        ElimHAB_cbHaberes.DisplayMember = "nombre"
    End Sub

    'Al clickear "ver" dentro de "haberes" se despliega la Tab ver-haberes
    Private Sub HAB_btnVer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HAB_btnVer.Click
        TabControl_MangeHaberes.SelectedTab = HAB_TabPage_Ver
        HAB_pnlSelection.Width = HAB_btnVer.Width
        HAB_pnlSelection.Location = New Point(HAB_btnVer.Location.X, HAB_pnlSelection.Location.Y)
    End Sub

    'Al clickear "agregar" dentro de "haberes" se despliega la Tab agregar-haberes
    Private Sub HAB_btnAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HAB_btnAgregar.Click
        TabControl_MangeHaberes.SelectedTab = HAB_TabPage_Agregar
        HAB_pnlSelection.Width = HAB_btnAgregar.Width
        HAB_pnlSelection.Location = New Point(HAB_btnAgregar.Location.X, HAB_pnlSelection.Location.Y)
    End Sub


    'Al clickear "modificar" dentro de "haberes" se despliega la Tab modificar-haberes
    Private Sub HAB_btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HAB_btnModificar.Click
        TabControl_MangeHaberes.SelectedTab = HAB_TabPage_Modificar
        HAB_pnlSelection.Width = HAB_btnModificar.Width
        HAB_pnlSelection.Location = New Point(HAB_btnModificar.Location.X, HAB_pnlSelection.Location.Y)
    End Sub

    'Al clickear "eliminar" dentro de "haberes" se despliega la Tab eliminar-haberes
    Private Sub HAB_btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HAB_btnEliminar.Click
        TabControl_MangeHaberes.SelectedTab = HAB_TabPage_Eliminar
        HAB_pnlSelection.Width = HAB_btnVer.Width
        HAB_pnlSelection.Location = New Point(HAB_btnEliminar.Location.X, HAB_pnlSelection.Location.Y)
    End Sub

    'Carga nombres de los haberes en el combobox de "Ver haberes"
    Private Sub VerHAB_cbDescuentos_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VerHAB_cbHaberes.SelectedIndexChanged
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM haberes WHERE nombre = '" & VerHAB_cbHaberes.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.VerHAB_txtId.Text = rdr.Item("haber_id").ToString
                Me.VerHAB_txtNombre.Text = rdr.Item("nombre").ToString
                Me.VerHAB_txtValor.Text = rdr.Item("valor").ToString
                Me.VerHAB_txtTipo.Text = rdr.Item("tipo").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    'Agrega nuevos haberes a la tabla "haberes"
    Private Sub AddHAB_btnAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddHAB_btnAgregar.Click
        Dim AddHAB_txtTipo As String
        If AddHAB_rbValorFijo.Checked = True Then
            AddHAB_txtTipo = "Valor Fijo"
        ElseIf AddHAB_rbPorcentaje.Checked = True Then
            AddHAB_txtTipo = "Porcentaje"
        Else
            MsgBox("Debe seleccionar si el haber tiene un Valor fijo o porcentual")
        End If
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")

        Try
            cnn.Open()
            Dim Query As String
            Query = "INSERT INTO haberes (nombre, valor, tipo) VALUES ('" & AddHAB_txtNombre.Text & "', " & AddHAB_txtValor.Text & ", '" & AddHAB_txtTipo & "')"
            Dim cmd As New MySqlCommand(Query, cnn)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Haber guardado")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    'No deja dar aceptar sin especificar si el haber es "%" o "$fijo", tambien hace que se vean las labels de "porcentaje", "Valor fijo" y los signos "%" "$"
    Private Sub AddHAB_rbValorFijo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddHAB_rbValorFijo.CheckedChanged
        If AddHAB_rbValorFijo.Checked Then
            AddHAB_lblPorcentaje.Visible = False
            AddHAB_lblPorciento.Visible = False
            AddHAB_lblValor.Visible = True
            AddHAB_lblPesos.Visible = True
        ElseIf AddHAB_rbPorcentaje.Checked = True Then
            AddHAB_lblValor.Visible = False
            AddHAB_lblPesos.Visible = False
            AddHAB_lblPorcentaje.Visible = True
            AddHAB_lblPorciento.Visible = True

        End If
    End Sub

    'Carga el identificador del haber en modHAB_txtID al seleccionarlo en la combobox
    Private Sub ModHAB_cbHaberes_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModHAB_cbHaberes.SelectedIndexChanged
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM haberes WHERE nombre = '" & ModHAB_cbHaberes.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ModHAB_txtID.Text = rdr.Item("haber_id").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    'Modifica el haber el la BD al dar click en "MODIFICAR"
    Private Sub ModHAB_btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModHAB_btnModificar.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "UPDATE haberes SET nombre = '" & ModHAB_txtNombre.Text & "', valor = '" & ModHAB_txtValor.Text & "', tipo = '" & ModHAB_cbTipo.Text & "'  WHERE haber_id = " & ModHAB_txtID.Text & " "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ModDesc_txtID.Text = rdr.Item("haber_id").ToString
            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    'Carga los datos del haber en "Eliminar Haber" al seleccionarlo en la combobox
    Private Sub ElimHAB_cbHaberes_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ElimHAB_cbHaberes.SelectedIndexChanged
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM haberes WHERE nombre = '" & ElimHAB_cbHaberes.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ElimHAB_txtId.Text = rdr.Item("haber_id").ToString
                Me.ElimHAB_txtNombre.Text = rdr.Item("nombre").ToString
                Me.ElimHAB_txtValor.Text = rdr.Item("valor").ToString
                Me.ElimHAB_txtTipo.Text = rdr.Item("tipo").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    'Elimina el haber de la BD al hacer click en "ELIMINAR"
    Private Sub ElimHAB_btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ElimHAB_btnEliminar.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "DELETE FROM haberes WHERE haber_id = " & ElimHAB_txtId.Text & " "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ModDesc_txtID.Text = rdr.Item("haber_id").ToString
            End While
            cnn.Close()
            MessageBox.Show("Se ha eliminado el haber")

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

#End Region

#Region "Manejo de decuentos"
    'Al clickear en boton "descuentos" se despliega la Tab correspondiente y se abren conexiones
    Private Sub btnDescuentos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDescuentos.Click
        btnDescuentos.Image = My.Resources.money_down_red
        btnDescuentos.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnHaberes.Image = My.Resources.money_up
        btnHaberes.ForeColor = Color.FromArgb(255, 91, 91, 91)
        TabControl_HaberesDescuentos.SelectedTab = TabPage_Descuentos
        pnlSelection.Width = btnDescuentos.Width
        pnlSelection.Location = New Point(btnDescuentos.Location.X, pnlSelection.Location.Y)

        '---------------------------------------------------------------------------------------------
        Dim VerDesc_cnn As New MySqlConnection("data source=localhost;user id=root; password='1234';database=tax")
        Dim VerDesc_adapter As New MySqlDataAdapter("SELECT * FROM descuentos ", VerDesc_cnn)
        Dim VerDesc_table As New DataTable()

        VerDesc_adapter.Fill(VerDesc_table)

        VerDesc_cbDescuentos.DataSource = VerDesc_table
        VerDesc_cbDescuentos.ValueMember = "descuento_id"
        VerDesc_cbDescuentos.DisplayMember = "nombre"
        '---------------------------------------------------------------------------------------------
        Dim ModDesc_cnn As New MySqlConnection("data source=localhost;user id=root; password='1234';database=tax")
        Dim ModDesc_adapter As New MySqlDataAdapter("SELECT * FROM descuentos ", ModDesc_cnn)
        Dim ModDesc_table As New DataTable()

        ModDesc_adapter.Fill(ModDesc_table)

        ModDesc_cbDescuentos.DataSource = ModDesc_table
        ModDesc_cbDescuentos.ValueMember = "descuento_id"
        ModDesc_cbDescuentos.DisplayMember = "nombre"
        '---------------------------------------------------------------------------------------------
        Dim ElimDESC_cnn As New MySqlConnection("data source=localhost;user id=root; password='1234';database=tax")
        Dim ElimDESC_adapter As New MySqlDataAdapter("SELECT * FROM descuentos ", ElimDESC_cnn)
        Dim ElimDESC_table As New DataTable()

        ElimDESC_adapter.Fill(ElimDESC_table)

        ElimDESC_cbDescuentos.DataSource = ElimDESC_table
        ElimDESC_cbDescuentos.ValueMember = "descuento_id"
        ElimDESC_cbDescuentos.DisplayMember = "nombre"

    End Sub

    'No deja dar aceptar sin especificar si el descuento es "%" o "$fijo", tambien hace que se vean las labels de "porcentaje", "Valor fijo" y los signos "%" "$"
    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddDESC_rbValorFijo.CheckedChanged
        If AddDESC_rbValorFijo.Checked Then
            AddDESC_lblPorcentaje.Visible = False
            AddDESC_lblPorciento.Visible = False
            AddDESC_lblValor.Visible = True
            AddDESC_lblPesos.Visible = True
        ElseIf AddDESC_rbPorcentaje.Checked = True Then
            AddDESC_lblValor.Visible = False
            AddDESC_lblPesos.Visible = False
            AddDESC_lblPorcentaje.Visible = True
            AddDESC_lblPorciento.Visible = True

        End If

    End Sub

    Private Sub DESC_btnAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DESC_btnAgregar.Click
        TabControl_ManageDescuentos.SelectedTab = DESC_TabPageAgregar
        DESC_pnlSelection.Width = DESC_btnAgregar.Width
        DESC_pnlSelection.Location = New Point(DESC_btnAgregar.Location.X, HAB_pnlSelection.Location.Y)
    End Sub

    Private Sub DESC_btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DESC_btnModificar.Click
        TabControl_ManageDescuentos.SelectedTab = DESC_TabPageModificar
        DESC_pnlSelection.Width = DESC_btnModificar.Width
        DESC_pnlSelection.Location = New Point(DESC_btnModificar.Location.X, HAB_pnlSelection.Location.Y)
    End Sub

    Private Sub DESC_btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DESC_btnEliminar.Click
        TabControl_ManageDescuentos.SelectedTab = DESC_TabPageEliminar
        DESC_pnlSelection.Width = DESC_btnEliminar.Width
        DESC_pnlSelection.Location = New Point(DESC_btnEliminar.Location.X, HAB_pnlSelection.Location.Y)
    End Sub

    Private Sub DESC_btnVer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DESC_btnVer.Click
        TabControl_ManageDescuentos.SelectedTab = DESC_TabPageVer
        DESC_pnlSelection.Width = DESC_btnVer.Width
        DESC_pnlSelection.Location = New Point(DESC_btnVer.Location.X, HAB_pnlSelection.Location.Y)
    End Sub


    'Carga los datos del descuento seleccionado en la combobox en la pestaña "ver"
    Private Sub VerDesc_cbDescuentos_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VerDesc_cbDescuentos.SelectedIndexChanged
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM descuentos WHERE nombre = '" & VerDesc_cbDescuentos.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.VerDesc_txtID.Text = rdr.Item("descuento_id").ToString
                Me.VerDesc_txtNombre.Text = rdr.Item("nombre").ToString
                Me.VerDesc_txtValor.Text = rdr.Item("valor").ToString
                Me.VerDesc_txtTipo.Text = rdr.Item("tipo").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    'Carga los datos del descuento seleccionado en la combobox en la pestaña "modificar"
    Private Sub ModDesc_cbDescuentos_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModDesc_cbDescuentos.SelectedIndexChanged
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM descuentos WHERE nombre = '" & ModDesc_cbDescuentos.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ModDesc_txtID.Text = rdr.Item("descuento_id").ToString
                Me.ModDesc_txtNombre.Text = rdr.Item("nombre").ToString
                Me.ModDesc_txtValor.Text = rdr.Item("valor").ToString
                Me.ModDesc_cbTipo.Text = rdr.Item("tipo").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    'Modifica los datos del descuento en la BD al hacer click en "MODIFICAR"
    Private Sub ModDesc_btnAceptar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModDesc_btnAceptar.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "UPDATE descuentos SET nombre = '" & ModDesc_txtNombre.Text & "', valor = '" & ModDesc_txtValor.Text & "', tipo = '" & ModDesc_cbTipo.Text & "'  WHERE descuento_id = " & ModDesc_txtID.Text & " "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ModDesc_txtID.Text = rdr.Item("descuento_id").ToString
            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    'Agrega descuentos en la BD al hacer click en "AGREGAR"
    Private Sub AddDESC_btnAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddDESC_btnAgregar.Click
        Dim AddDESC_txtTipo As String
        If AddDESC_rbValorFijo.Checked = True Then
            AddDESC_txtTipo = "Valor Fijo"
        ElseIf AddDESC_rbPorcentaje.Checked = True Then
            AddDESC_txtTipo = "Porcentaje"
        Else
            MsgBox("Debe seleccionar si el descuento tiene un Valor fijo o porcentual")
        End If
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")

        Try
            cnn.Open()
            Dim Query As String
            Query = "INSERT INTO descuentos (nombre, valor, tipo) VALUES ('" & AddDESC_txtNombre.Text & "', " & AddDESC_txtValor.Text & ", '" & AddDESC_txtTipo & "')"
            Dim cmd As New MySqlCommand(Query, cnn)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Descuento guardado")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    'Carga los datos del descuento seleccionado en la combobox en la pestaña "eliminar"
    Private Sub ElimDESC_cbDescuentos_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ElimDESC_cbDescuentos.SelectedIndexChanged
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM descuentos WHERE nombre = '" & ElimDESC_cbDescuentos.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ElimDESC_txtID.Text = rdr.Item("descuento_id").ToString
                Me.ElimDESC_txtNombre.Text = rdr.Item("nombre").ToString
                Me.ElimDESC_txtValor.Text = rdr.Item("valor").ToString
                Me.ElimDESC_txtTipo.Text = rdr.Item("tipo").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    'Elimina el descuento en la BD al hacer click en "ELIMINAR"
    Private Sub ElimDESC_btnEliminar_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ElimDESC_btnEliminar.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "DELETE FROM descuentos WHERE descuento_id = " & ElimDESC_txtID.Text & " "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ModDesc_txtID.Text = rdr.Item("descuento_id").ToString
            End While
            cnn.Close()
            MessageBox.Show("Se ha eliminado el descuento")

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
#End Region

    Private Sub ModDesc_txtNombre_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ModDesc_txtNombre.Click
        ModDesc_txtNombre.Clear()
        ModDesc_txtNombre.ForeColor = Color.Black
    End Sub


    Private Sub ModDesc_txtValor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ModDesc_txtValor.Click
        ModDesc_txtValor.Clear()
        ModDesc_txtValor.ForeColor = Color.Black
    End Sub


    Private Sub ModDesc_cbTipo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ModDesc_cbTipo.Click
        ModDesc_cbTipo.ForeColor = Color.Black
    End Sub

    Private Sub pnlSup_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pnlSup.Paint

    End Sub
End Class