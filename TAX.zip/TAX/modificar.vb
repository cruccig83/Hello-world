﻿Public Class modificar
    Private Sub cmdinicio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdinicio.Click
        inicioadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdficha.Click
        ficharoja.Show()
        Me.Close()

    End Sub

    Private Sub cmdrecibo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdrecibo.Click
        mireciboadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdliquidar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdliquidar.Click
        sueldos.Show()
        Me.Close()

    End Sub

    Private Sub cmdagregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdagregar.Click
        empleados.Show()
        Me.Close()

    End Sub

    Private Sub cmdeliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdeliminar.Click
        eliminar.Show()
        Me.Close()

    End Sub

    Private Sub cmdlistar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdlistar.Click
        listar.Show()
        Me.Close()
    End Sub

    Private Sub cmdayuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdayuda.Click
        MsgBox("En Progreso")
    End Sub

    Private Sub cmdmodificaar2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdmodificaar2.Click

        If Not (IsNumeric(txtcelular.Text)) Then
            MsgBox("Celular: Solo se admiten numeros")
            txtcelular.Text = ""
            txtcelular.Focus()
        End If


        If Not (IsNumeric(txttelefono.Text)) Then
            MsgBox("Telefono: Solo se admiten numeros")
            txttelefono.Text = ""
            txttelefono.Focus()
        End If


        If Not (IsNumeric(txtrut.Text)) Then
            MsgBox("Rut: Solo se admiten numeros")
            txtrut.Text = ""
            txtrut.Focus()
        End If

        If Not (IsNumeric(txttelefonoemp.Text)) Then
            MsgBox("Telefono Empresarial: Solo se admiten numeros")
            txttelefonoemp.Text = ""
            txttelefonoemp.Focus()
        End If

        If Not (IsNumeric(txtgrado.Text)) Then
            MsgBox("Grado: Solo admite letras")
            txtgrado.Text = ""
            txtgrado.Focus()

        End If
        If Not (Char.IsLetter(txtnombre.Text)) Then
            MsgBox("Nombre: Solo admite letras")
            txtnombre.Text = ""
            txtnombre.Focus()

        End If

        If Not (Char.IsLetter(txtapellido.Text)) Then
            MsgBox("Apellido: Solo admite letras")
            txtapellido.Text = ""
            txtapellido.Focus()

        End If

        If Not (Char.IsLetter(txtapellido.Text)) Then
            MsgBox("Apellido: Solo admite letras")
            txtapellido.Text = ""
            txtapellido.Focus()

        End If

        If Not (Char.IsLetter(txtpuesto.Text)) Then
            MsgBox("Puesto: Solo admite letras")
            txtpuesto.Text = ""
            txtpuesto.Focus()

        End If

        If Not (Char.IsLetter(txtcargo.Text)) Then
            MsgBox("Cargo: Solo admite letras")
            txtcargo.Text = ""
            txtcargo.Focus()

        End If


    End Sub
End Class