﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Divisas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlSup = New System.Windows.Forms.Panel
        Me.pnlDer = New System.Windows.Forms.Panel
        Me.pnlInf = New System.Windows.Forms.Panel
        Me.pnlIzq = New System.Windows.Forms.Panel
        Me.pnlCentral = New System.Windows.Forms.Panel
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.pnlCentral.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlSup
        '
        Me.pnlSup.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlSup.Location = New System.Drawing.Point(0, 0)
        Me.pnlSup.Name = "pnlSup"
        Me.pnlSup.Size = New System.Drawing.Size(786, 20)
        Me.pnlSup.TabIndex = 0
        '
        'pnlDer
        '
        Me.pnlDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlDer.Location = New System.Drawing.Point(766, 20)
        Me.pnlDer.Name = "pnlDer"
        Me.pnlDer.Size = New System.Drawing.Size(20, 344)
        Me.pnlDer.TabIndex = 1
        '
        'pnlInf
        '
        Me.pnlInf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlInf.Location = New System.Drawing.Point(0, 344)
        Me.pnlInf.Name = "pnlInf"
        Me.pnlInf.Size = New System.Drawing.Size(766, 20)
        Me.pnlInf.TabIndex = 2
        '
        'pnlIzq
        '
        Me.pnlIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlIzq.Location = New System.Drawing.Point(0, 20)
        Me.pnlIzq.Name = "pnlIzq"
        Me.pnlIzq.Size = New System.Drawing.Size(20, 324)
        Me.pnlIzq.TabIndex = 3
        '
        'pnlCentral
        '
        Me.pnlCentral.BackColor = System.Drawing.Color.White
        Me.pnlCentral.Controls.Add(Me.TextBox1)
        Me.pnlCentral.Controls.Add(Me.Button2)
        Me.pnlCentral.Controls.Add(Me.Button1)
        Me.pnlCentral.Controls.Add(Me.WebBrowser1)
        Me.pnlCentral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlCentral.Location = New System.Drawing.Point(20, 20)
        Me.pnlCentral.Name = "pnlCentral"
        Me.pnlCentral.Size = New System.Drawing.Size(746, 324)
        Me.pnlCentral.TabIndex = 4
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(298, 32)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(250, 250)
        Me.WebBrowser1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(65, 32)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(65, 94)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(83, 151)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 3
        '
        'Admin_Divisas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(786, 364)
        Me.Controls.Add(Me.pnlCentral)
        Me.Controls.Add(Me.pnlIzq)
        Me.Controls.Add(Me.pnlInf)
        Me.Controls.Add(Me.pnlDer)
        Me.Controls.Add(Me.pnlSup)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_Divisas"
        Me.Text = "Admin_Divisas"
        Me.pnlCentral.ResumeLayout(False)
        Me.pnlCentral.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlSup As System.Windows.Forms.Panel
    Friend WithEvents pnlDer As System.Windows.Forms.Panel
    Friend WithEvents pnlInf As System.Windows.Forms.Panel
    Friend WithEvents pnlIzq As System.Windows.Forms.Panel
    Friend WithEvents pnlCentral As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
