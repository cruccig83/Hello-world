﻿Imports MySql.Data.MySqlClient
Public Class Admin_Ficha
    Dim dt As New DataTable
    Dim cnn As New MySqlConnection
    Dim sql As String


    Private Sub btnFicha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFicha.Click
        TabControl_FichaAdmin.SelectedTab = TabPageFicha
        pnlSelection.Width = btnFicha.Width
        pnlSelection.Location = New Point(btnFicha.Location.X, pnlSelection.Location.Y)

        btnOrganizacion.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnOrganizacion.Image = My.Resources.enterprise_gris
        btnHLaboral.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnHLaboral.Image = My.Resources.historia_gris
        btnHRecibos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnHRecibos.Image = My.Resources.historial_gris
        btnFicha.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnFicha.Image = My.Resources.ficha_roja
        
    End Sub


    Private Sub btnOrganizacion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrganizacion.Click
        TabControl_FichaAdmin.SelectedTab = TabPageOrganizacion
        pnlSelection.Width = btnOrganizacion.Width
        pnlSelection.Location = New Point(btnOrganizacion.Location.X, pnlSelection.Location.Y)

        btnOrganizacion.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnOrganizacion.Image = My.Resources.enterprise__1_
        btnHLaboral.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnHLaboral.Image = My.Resources.historia_gris
        btnHRecibos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnHRecibos.Image = My.Resources.historial_gris
        btnFicha.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnFicha.Image = My.Resources.ficha_gris

        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM empresa"
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ORG_txtRUT.Text = rdr.Item("RUT").ToString
            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub btnHLaboral_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHLaboral.Click
        TabControl_FichaAdmin.SelectedTab = TabPageHLaboral
        pnlSelection.Width = btnHLaboral.Width
        pnlSelection.Location = New Point(btnHLaboral.Location.X, pnlSelection.Location.Y)

        btnOrganizacion.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnOrganizacion.Image = My.Resources.enterprise_gris
        btnHLaboral.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnHLaboral.Image = My.Resources.historia_roja
        btnHRecibos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnHRecibos.Image = My.Resources.historial_gris
        btnFicha.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnFicha.Image = My.Resources.ficha_gris

    End Sub

    Private Sub btnHRecibos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHRecibos.Click
        TabControl_FichaAdmin.SelectedTab = TabPageHrecibos
        pnlSelection.Width = btnHRecibos.Width
        pnlSelection.Location = New Point(btnHRecibos.Location.X, pnlSelection.Location.Y)

        btnOrganizacion.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnOrganizacion.Image = My.Resources.enterprise_gris
        btnHLaboral.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnHLaboral.Image = My.Resources.historia_gris
        btnHRecibos.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnHRecibos.Image = My.Resources.historial_rojo
        btnFicha.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnFicha.Image = My.Resources.ficha_gris

    End Sub

    Private Sub pnlBotones_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pnlBotones.Paint

    End Sub

    Private Sub Admin_Ficha_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Dock = DockStyle.Fill
        TabControl_FichaAdmin.Dock = DockStyle.Fill
        FICHA_txtContraseña.UseSystemPasswordChar = True

        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE doc = '" & Module1.document & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.FICHA_txtDocumento.Text = rdr.Item("doc").ToString
                Me.FICHA_txtNombre.Text = rdr.Item("nombre").ToString + " " + rdr.Item("2nombre").ToString
                Me.FICHA_txtApellido.Text = rdr.Item("apellido").ToString + " " + rdr.Item("2apellido").ToString
                Me.FICHA_txtContraseña.Text = rdr.Item("passwd").ToString
                Me.FICHA_txtSexo.Text = rdr.Item("sexo").ToString
                Me.FICHA_txtFNacimiento.Text = rdr.Item("f_nac").ToString
                Me.FICHA_txtCalle.Text = rdr.Item("calle").ToString + " " + rdr.Item("numero").ToString
                Me.FICHA_txtEstCivil.Text = rdr.Item("estado_civil").ToString
                Me.FICHA_txtEmail.Text = rdr.Item("email").ToString
                Me.ORG_txtNRegistro.Text = rdr.Item("persona_id").ToString
                Me.ORG_txtFIngreso.Text = rdr.Item("f_ingreso").ToString
                Me.ORG_txtCargo.Text = rdr.Item("cargo").ToString
                Me.ORG_txtGrado.Text = rdr.Item("grado").ToString
                Me.ORG_txtDepartamento.Text = rdr.Item("dpto").ToString
                Me.ORG_txtTlfEmpresarial.Text = rdr.Item("tlf_empr").ToString
                Me.ORG_txtMailEmpresarial.Text = rdr.Item("email_empr").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FICHA_btnCambiarContraseña.Click
        Admin_CambioContraseña.Show()

    End Sub

End Class