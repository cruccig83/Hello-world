﻿Imports MySql.Data.MySqlClient
Public Class Buscar

    Private Sub Buscar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscarRegistro.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim table As New DataTable()
        Dim adapter As New MySqlDataAdapter("SELECT doc, persona_id, nombre, apellido FROM personal WHERE persona_id = '" & txtBuscarRegistro.Text & "' ", cnn)
        adapter.Fill(table)
        DataGridView1.DataSource = table
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim indice As Integer
        indice = e.RowIndex
        Dim FilaSeleccionada As DataGridViewRow
        FilaSeleccionada = DataGridView1.Rows(indice)
        buscar_usuarios.List_txtBuscar.Text = FilaSeleccionada.Cells(0).Value.ToString()
        buscar_usuarios.List_btnBuscar.PerformClick()
        buscar_usuarios.List_txtBuscar.ForeColor = Color.Black
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

        If ComboBox1.Text = "Buscar por registro" Then
            txtBuscarRegistro.Visible = True
            btnBuscarRegistro.Visible = True
            txtBuscarNombre.Visible = False
            txtBuscarApellido.Visible = False
            btnBuscarNombre.Visible = False
        ElseIf ComboBox1.Text = "Buscar por nombre" Then
            txtBuscarRegistro.Visible = False
            btnBuscarRegistro.Visible = False
            txtBuscarNombre.Visible = True
            txtBuscarApellido.Visible = True
            btnBuscarNombre.Visible = True
        End If

    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscarNombre.Click
        Dim cnn As New MySqlConnection
        Dim table As New DataTable

        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")

        If (txtBuscarNombre.Text = String.Empty And txtBuscarApellido.Text = String.Empty) Or (txtBuscarNombre.Text = "Nombre" And txtBuscarApellido.Text = "Apellido") Then
            MessageBox.Show("Debe completar")
        ElseIf txtBuscarNombre.Text = String.Empty Or txtBuscarNombre.Text = "Nombre" Then
            Dim adapter As New MySqlDataAdapter("SELECT doc, persona_id, nombre, apellido FROM personal WHERE apellido ='" & txtBuscarApellido.Text & "' ", cnn)
            adapter.Fill(table)
            DataGridView1.DataSource = table
            If DataGridView1.RowCount >= 1 Then
                DataGridView1.Visible = True


            Else
                MsgBox("Nombre y/o apellido del usuario incorrectos")
            End If
        ElseIf txtBuscarApellido.Text = String.Empty Or txtBuscarApellido.Text = "Apellido" Then
            Dim adapter As New MySqlDataAdapter("SELECT doc, persona_id, nombre, apellido FROM personal WHERE nombre = '" & txtBuscarNombre.Text & "' OR 2nombre = '" & txtBuscarNombre.Text & "' ", cnn)
            adapter.Fill(table)
            DataGridView1.DataSource = table
            If DataGridView1.RowCount >= 1 Then
                DataGridView1.Visible = True


            Else
                MsgBox("Nombre y/o apellido del usuario incorrectos")
            End If
        Else
            Dim adapter As New MySqlDataAdapter("SELECT doc, persona_id, nombre, apellido FROM personal WHERE (nombre = '" & txtBuscarNombre.Text & "' OR 2nombre = '" & txtBuscarNombre.Text & "') AND apellido ='" & txtBuscarApellido.Text & "' ", cnn)
            adapter.Fill(table)
            DataGridView1.DataSource = table
            If DataGridView1.RowCount >= 1 Then
                DataGridView1.Visible = True


            Else
                MsgBox("Nombre y/o apellido del usuario incorrectos")
            End If
        End If

      
    End Sub

    Private Sub TextBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtBuscarRegistro.Click
        txtBuscarRegistro.ForeColor = Color.Black
        txtBuscarRegistro.Clear()
    End Sub

    Private Sub TextBox2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtBuscarNombre.Click
        txtBuscarNombre.ForeColor = Color.Black
        txtBuscarNombre.Clear()
    End Sub

    Private Sub TextBox3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtBuscarApellido.Click
        txtBuscarApellido.ForeColor = Color.Black
        txtBuscarApellido.Clear()
    End Sub
End Class