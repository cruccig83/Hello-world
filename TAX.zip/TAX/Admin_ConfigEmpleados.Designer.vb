﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_ConfigEmpleados
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_ConfigEmpleados))
        Me.pnlSup = New System.Windows.Forms.Panel
        Me.pnlDer = New System.Windows.Forms.Panel
        Me.pnlInf = New System.Windows.Forms.Panel
        Me.pnlIzq = New System.Windows.Forms.Panel
        Me.pnlCentral = New System.Windows.Forms.Panel
        Me.pnlBotones = New System.Windows.Forms.Panel
        Me.pnlBotonesGris = New System.Windows.Forms.Panel
        Me.pnlSelection = New System.Windows.Forms.Panel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.TabControl_AdministrarEmpleados = New System.Windows.Forms.TabControl
        Me.TabPage_Agregar = New System.Windows.Forms.TabPage
        Me.Button1 = New System.Windows.Forms.Button
        Me.AddUser_cbGrado = New System.Windows.Forms.ComboBox
        Me.ADD_ObligTipoUsuario = New System.Windows.Forms.Label
        Me.ADD_ObligEmailEmpr = New System.Windows.Forms.Label
        Me.ADD_ObligTelfEmpresarial = New System.Windows.Forms.Label
        Me.ADD_ObligDepartamento = New System.Windows.Forms.Label
        Me.ADD_ObligGrado = New System.Windows.Forms.Label
        Me.ADD_ObligCargo = New System.Windows.Forms.Label
        Me.ADD_FIngreso = New System.Windows.Forms.Label
        Me.ADD_ObligEmail = New System.Windows.Forms.Label
        Me.ADD_ObligEstCivil = New System.Windows.Forms.Label
        Me.ADD_ObligDirNumero = New System.Windows.Forms.Label
        Me.ADD_ObligDirCalle = New System.Windows.Forms.Label
        Me.ADD_ObligFNac = New System.Windows.Forms.Label
        Me.ADD_ObligSexo = New System.Windows.Forms.Label
        Me.ADD_ObligApellido = New System.Windows.Forms.Label
        Me.ADD_ObligNombre = New System.Windows.Forms.Label
        Me.ADD_ObligDocumento = New System.Windows.Forms.Label
        Me.AddUser_txt2apellido = New System.Windows.Forms.TextBox
        Me.AddUser_txt2Nombre = New System.Windows.Forms.TextBox
        Me.AddUser_txtDirCalle = New System.Windows.Forms.TextBox
        Me.AddUser_txtDirNumero = New System.Windows.Forms.TextBox
        Me.AddUser_cbEstCivil = New System.Windows.Forms.ComboBox
        Me.AddUser_cbSexo = New System.Windows.Forms.ComboBox
        Me.AddUser_dateFIngreso = New System.Windows.Forms.DateTimePicker
        Me.AddUser_dateFNacimiento = New System.Windows.Forms.DateTimePicker
        Me.AddUser_btnAgregar = New System.Windows.Forms.Button
        Me.AddUser_rbAdmin = New System.Windows.Forms.RadioButton
        Me.AddUser_rbUsuario = New System.Windows.Forms.RadioButton
        Me.AddUser_txtMailEmpresarial = New System.Windows.Forms.TextBox
        Me.AddUser_txtTlfEmpresarial = New System.Windows.Forms.TextBox
        Me.AddUser_txtDepartamento = New System.Windows.Forms.TextBox
        Me.AddUser_txtCargo = New System.Windows.Forms.TextBox
        Me.AddUser_lblEmailEmpresarial = New System.Windows.Forms.Label
        Me.AddUser_lblTelfEmpresarial = New System.Windows.Forms.Label
        Me.AddUser_lblDepartamento = New System.Windows.Forms.Label
        Me.AddUser_lblGrado = New System.Windows.Forms.Label
        Me.AddUser_lblCargo = New System.Windows.Forms.Label
        Me.AddUser_lblFIngreso = New System.Windows.Forms.Label
        Me.AddUser_txtFijo = New System.Windows.Forms.TextBox
        Me.AddUser_txtCelular = New System.Windows.Forms.TextBox
        Me.AddUser_txtHijos = New System.Windows.Forms.TextBox
        Me.AddUser_txtEmail = New System.Windows.Forms.TextBox
        Me.AddUser_txtContraseña = New System.Windows.Forms.TextBox
        Me.AddUser_txtApellido = New System.Windows.Forms.TextBox
        Me.AddUser_txtNombre = New System.Windows.Forms.TextBox
        Me.AddUser_lblFijo = New System.Windows.Forms.Label
        Me.AddUser_lblCelular = New System.Windows.Forms.Label
        Me.AddUser_lblHijos = New System.Windows.Forms.Label
        Me.AddUser_lblEmail = New System.Windows.Forms.Label
        Me.AddUser_lblEstCivil = New System.Windows.Forms.Label
        Me.AddUser_lblDireccion = New System.Windows.Forms.Label
        Me.AddUser_lblFNacimiento = New System.Windows.Forms.Label
        Me.AddUser_lblSexo = New System.Windows.Forms.Label
        Me.AddUser_lblContraseña = New System.Windows.Forms.Label
        Me.AddUser_lblApellido = New System.Windows.Forms.Label
        Me.AddUser_lblNombre = New System.Windows.Forms.Label
        Me.AddUser_txtDocumento = New System.Windows.Forms.TextBox
        Me.AddUser_lblDocumento = New System.Windows.Forms.Label
        Me.TabPage_Modificar = New System.Windows.Forms.TabPage
        Me.TabPage_Eliminar = New System.Windows.Forms.TabPage
        Me.EUsuario_btnEliminar = New System.Windows.Forms.Button
        Me.EUsuario_btnBuscar = New System.Windows.Forms.Button
        Me.EUsuario_lblNumRegistro = New System.Windows.Forms.Label
        Me.EUsuario_lblDocumento = New System.Windows.Forms.Label
        Me.EUsuario_DataGrid = New System.Windows.Forms.DataGridView
        Me.PersonaidDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DocDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.NombreDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ApellidoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.RolDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.CargoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PersonalBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TaxDataSet = New TAX.taxDataSet
        Me.EUsuario_txtNumRegistro = New System.Windows.Forms.TextBox
        Me.EUsuario_txtDocumento = New System.Windows.Forms.TextBox
        Me.TabPage_Listar = New System.Windows.Forms.TabPage
        Me.ListUser_pnlBuscPorRegistro = New System.Windows.Forms.Panel
        Me.ListUser_btnBuscPorRegistro = New System.Windows.Forms.Button
        Me.ListUser_txtBuscPorRegistro = New System.Windows.Forms.TextBox
        Me.ListUser_lblBuscPorRegistro = New System.Windows.Forms.Label
        Me.ListUser_pnlBuscPorNombre = New System.Windows.Forms.Panel
        Me.ListUser_txtBuscPorNombre_Apellido = New System.Windows.Forms.TextBox
        Me.ListUser_btnBuscPorNombre = New System.Windows.Forms.Button
        Me.ListUser_txtBuscPorNombre = New System.Windows.Forms.TextBox
        Me.ListUser_lblBuscPorNombre = New System.Windows.Forms.Label
        Me.ListUser_pnlBuscPorDocumento = New System.Windows.Forms.Panel
        Me.ListUser_btnBuscPorDocumento = New System.Windows.Forms.Button
        Me.ListUser_txtBuscPorDocumento = New System.Windows.Forms.TextBox
        Me.ListUser_lblBuscPorDocumento = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.ListUser_btnVer = New System.Windows.Forms.Button
        Me.ListUser_DataGrid = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ListUser_pnlTitulo = New System.Windows.Forms.Panel
        Me.PersonalBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TaxDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PersonalTableAdapter = New TAX.taxDataSetTableAdapters.personalTableAdapter
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btnListar = New System.Windows.Forms.Button
        Me.btnEliminar = New System.Windows.Forms.Button
        Me.btnAgregar = New System.Windows.Forms.Button
        Me.AddUser_pbFoto = New System.Windows.Forms.PictureBox
        Me.AddUser_picAgregarUsuario = New System.Windows.Forms.Button
        Me.ModUser_picModificarFichas = New System.Windows.Forms.Button
        Me.picEliminarUser = New System.Windows.Forms.Button
        Me.BuscarUser_BuscarEmpleados = New System.Windows.Forms.Button
        Me.pnlCentral.SuspendLayout()
        Me.pnlBotones.SuspendLayout()
        Me.pnlBotonesGris.SuspendLayout()
        Me.TabControl_AdministrarEmpleados.SuspendLayout()
        Me.TabPage_Agregar.SuspendLayout()
        Me.TabPage_Modificar.SuspendLayout()
        Me.TabPage_Eliminar.SuspendLayout()
        CType(Me.EUsuario_DataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PersonalBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TaxDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Listar.SuspendLayout()
        Me.ListUser_pnlBuscPorRegistro.SuspendLayout()
        Me.ListUser_pnlBuscPorNombre.SuspendLayout()
        Me.ListUser_pnlBuscPorDocumento.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.ListUser_DataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ListUser_pnlTitulo.SuspendLayout()
        CType(Me.PersonalBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TaxDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AddUser_pbFoto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlSup
        '
        Me.pnlSup.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlSup.Location = New System.Drawing.Point(0, 0)
        Me.pnlSup.Name = "pnlSup"
        Me.pnlSup.Size = New System.Drawing.Size(818, 20)
        Me.pnlSup.TabIndex = 0
        '
        'pnlDer
        '
        Me.pnlDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlDer.Location = New System.Drawing.Point(798, 20)
        Me.pnlDer.Name = "pnlDer"
        Me.pnlDer.Size = New System.Drawing.Size(20, 423)
        Me.pnlDer.TabIndex = 1
        '
        'pnlInf
        '
        Me.pnlInf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlInf.Location = New System.Drawing.Point(0, 423)
        Me.pnlInf.Name = "pnlInf"
        Me.pnlInf.Size = New System.Drawing.Size(798, 20)
        Me.pnlInf.TabIndex = 2
        '
        'pnlIzq
        '
        Me.pnlIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlIzq.Location = New System.Drawing.Point(0, 20)
        Me.pnlIzq.Name = "pnlIzq"
        Me.pnlIzq.Size = New System.Drawing.Size(20, 403)
        Me.pnlIzq.TabIndex = 3
        '
        'pnlCentral
        '
        Me.pnlCentral.BackColor = System.Drawing.Color.White
        Me.pnlCentral.Controls.Add(Me.pnlBotones)
        Me.pnlCentral.Controls.Add(Me.TabControl_AdministrarEmpleados)
        Me.pnlCentral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlCentral.Location = New System.Drawing.Point(20, 20)
        Me.pnlCentral.Name = "pnlCentral"
        Me.pnlCentral.Size = New System.Drawing.Size(778, 403)
        Me.pnlCentral.TabIndex = 4
        '
        'pnlBotones
        '
        Me.pnlBotones.Controls.Add(Me.pnlBotonesGris)
        Me.pnlBotones.Controls.Add(Me.Panel1)
        Me.pnlBotones.Controls.Add(Me.btnListar)
        Me.pnlBotones.Controls.Add(Me.btnEliminar)
        Me.pnlBotones.Controls.Add(Me.btnAgregar)
        Me.pnlBotones.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBotones.Location = New System.Drawing.Point(0, 0)
        Me.pnlBotones.Name = "pnlBotones"
        Me.pnlBotones.Size = New System.Drawing.Size(778, 60)
        Me.pnlBotones.TabIndex = 1
        '
        'pnlBotonesGris
        '
        Me.pnlBotonesGris.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.pnlBotonesGris.Controls.Add(Me.pnlSelection)
        Me.pnlBotonesGris.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlBotonesGris.Location = New System.Drawing.Point(0, 54)
        Me.pnlBotonesGris.Name = "pnlBotonesGris"
        Me.pnlBotonesGris.Size = New System.Drawing.Size(778, 3)
        Me.pnlBotonesGris.TabIndex = 10
        '
        'pnlSelection
        '
        Me.pnlSelection.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlSelection.Location = New System.Drawing.Point(0, 0)
        Me.pnlSelection.Name = "pnlSelection"
        Me.pnlSelection.Size = New System.Drawing.Size(97, 3)
        Me.pnlSelection.TabIndex = 3
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 57)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(778, 3)
        Me.Panel1.TabIndex = 9
        '
        'TabControl_AdministrarEmpleados
        '
        Me.TabControl_AdministrarEmpleados.Controls.Add(Me.TabPage_Agregar)
        Me.TabControl_AdministrarEmpleados.Controls.Add(Me.TabPage_Modificar)
        Me.TabControl_AdministrarEmpleados.Controls.Add(Me.TabPage_Eliminar)
        Me.TabControl_AdministrarEmpleados.Controls.Add(Me.TabPage_Listar)
        Me.TabControl_AdministrarEmpleados.Location = New System.Drawing.Point(1, 6)
        Me.TabControl_AdministrarEmpleados.Name = "TabControl_AdministrarEmpleados"
        Me.TabControl_AdministrarEmpleados.Padding = New System.Drawing.Point(6, 19)
        Me.TabControl_AdministrarEmpleados.SelectedIndex = 0
        Me.TabControl_AdministrarEmpleados.Size = New System.Drawing.Size(777, 397)
        Me.TabControl_AdministrarEmpleados.TabIndex = 0
        '
        'TabPage_Agregar
        '
        Me.TabPage_Agregar.AutoScroll = True
        Me.TabPage_Agregar.Controls.Add(Me.Button1)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_pbFoto)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_cbGrado)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligTipoUsuario)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligEmailEmpr)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligTelfEmpresarial)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligDepartamento)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligGrado)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligCargo)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_FIngreso)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligEmail)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligEstCivil)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligDirNumero)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligDirCalle)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligFNac)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligSexo)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligApellido)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligNombre)
        Me.TabPage_Agregar.Controls.Add(Me.ADD_ObligDocumento)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txt2apellido)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txt2Nombre)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtDirCalle)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtDirNumero)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_cbEstCivil)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_cbSexo)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_dateFIngreso)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_dateFNacimiento)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_btnAgregar)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_rbAdmin)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_rbUsuario)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_picAgregarUsuario)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtMailEmpresarial)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtTlfEmpresarial)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtDepartamento)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtCargo)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblEmailEmpresarial)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblTelfEmpresarial)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblDepartamento)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblGrado)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblCargo)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblFIngreso)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtFijo)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtCelular)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtHijos)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtEmail)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtContraseña)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtApellido)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtNombre)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblFijo)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblCelular)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblHijos)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblEmail)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblEstCivil)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblDireccion)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblFNacimiento)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblSexo)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblContraseña)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblApellido)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblNombre)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_txtDocumento)
        Me.TabPage_Agregar.Controls.Add(Me.AddUser_lblDocumento)
        Me.TabPage_Agregar.Location = New System.Drawing.Point(4, 54)
        Me.TabPage_Agregar.Name = "TabPage_Agregar"
        Me.TabPage_Agregar.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Agregar.Size = New System.Drawing.Size(769, 339)
        Me.TabPage_Agregar.TabIndex = 0
        Me.TabPage_Agregar.Text = "TabPage1"
        Me.TabPage_Agregar.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(557, 328)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(124, 23)
        Me.Button1.TabIndex = 94
        Me.Button1.Text = "Seleccionar foto"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'AddUser_cbGrado
        '
        Me.AddUser_cbGrado.FormattingEnabled = True
        Me.AddUser_cbGrado.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.AddUser_cbGrado.Location = New System.Drawing.Point(574, 137)
        Me.AddUser_cbGrado.Name = "AddUser_cbGrado"
        Me.AddUser_cbGrado.Size = New System.Drawing.Size(132, 21)
        Me.AddUser_cbGrado.TabIndex = 92
        '
        'ADD_ObligTipoUsuario
        '
        Me.ADD_ObligTipoUsuario.AutoSize = True
        Me.ADD_ObligTipoUsuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligTipoUsuario.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligTipoUsuario.Location = New System.Drawing.Point(421, 270)
        Me.ADD_ObligTipoUsuario.Name = "ADD_ObligTipoUsuario"
        Me.ADD_ObligTipoUsuario.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligTipoUsuario.TabIndex = 91
        Me.ADD_ObligTipoUsuario.Text = "*"
        '
        'ADD_ObligEmailEmpr
        '
        Me.ADD_ObligEmailEmpr.AutoSize = True
        Me.ADD_ObligEmailEmpr.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligEmailEmpr.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligEmailEmpr.Location = New System.Drawing.Point(554, 226)
        Me.ADD_ObligEmailEmpr.Name = "ADD_ObligEmailEmpr"
        Me.ADD_ObligEmailEmpr.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligEmailEmpr.TabIndex = 90
        Me.ADD_ObligEmailEmpr.Text = "*"
        '
        'ADD_ObligTelfEmpresarial
        '
        Me.ADD_ObligTelfEmpresarial.AutoSize = True
        Me.ADD_ObligTelfEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligTelfEmpresarial.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligTelfEmpresarial.Location = New System.Drawing.Point(554, 197)
        Me.ADD_ObligTelfEmpresarial.Name = "ADD_ObligTelfEmpresarial"
        Me.ADD_ObligTelfEmpresarial.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligTelfEmpresarial.TabIndex = 89
        Me.ADD_ObligTelfEmpresarial.Text = "*"
        '
        'ADD_ObligDepartamento
        '
        Me.ADD_ObligDepartamento.AutoSize = True
        Me.ADD_ObligDepartamento.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligDepartamento.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligDepartamento.Location = New System.Drawing.Point(554, 168)
        Me.ADD_ObligDepartamento.Name = "ADD_ObligDepartamento"
        Me.ADD_ObligDepartamento.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligDepartamento.TabIndex = 88
        Me.ADD_ObligDepartamento.Text = "*"
        '
        'ADD_ObligGrado
        '
        Me.ADD_ObligGrado.AutoSize = True
        Me.ADD_ObligGrado.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligGrado.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligGrado.Location = New System.Drawing.Point(554, 139)
        Me.ADD_ObligGrado.Name = "ADD_ObligGrado"
        Me.ADD_ObligGrado.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligGrado.TabIndex = 87
        Me.ADD_ObligGrado.Text = "*"
        '
        'ADD_ObligCargo
        '
        Me.ADD_ObligCargo.AutoSize = True
        Me.ADD_ObligCargo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligCargo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligCargo.Location = New System.Drawing.Point(554, 110)
        Me.ADD_ObligCargo.Name = "ADD_ObligCargo"
        Me.ADD_ObligCargo.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligCargo.TabIndex = 86
        Me.ADD_ObligCargo.Text = "*"
        '
        'ADD_FIngreso
        '
        Me.ADD_FIngreso.AutoSize = True
        Me.ADD_FIngreso.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_FIngreso.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_FIngreso.Location = New System.Drawing.Point(554, 78)
        Me.ADD_FIngreso.Name = "ADD_FIngreso"
        Me.ADD_FIngreso.Size = New System.Drawing.Size(14, 18)
        Me.ADD_FIngreso.TabIndex = 85
        Me.ADD_FIngreso.Text = "*"
        '
        'ADD_ObligEmail
        '
        Me.ADD_ObligEmail.AutoSize = True
        Me.ADD_ObligEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligEmail.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligEmail.Location = New System.Drawing.Point(225, 312)
        Me.ADD_ObligEmail.Name = "ADD_ObligEmail"
        Me.ADD_ObligEmail.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligEmail.TabIndex = 82
        Me.ADD_ObligEmail.Text = "*"
        '
        'ADD_ObligEstCivil
        '
        Me.ADD_ObligEstCivil.AutoSize = True
        Me.ADD_ObligEstCivil.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligEstCivil.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligEstCivil.Location = New System.Drawing.Point(225, 285)
        Me.ADD_ObligEstCivil.Name = "ADD_ObligEstCivil"
        Me.ADD_ObligEstCivil.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligEstCivil.TabIndex = 81
        Me.ADD_ObligEstCivil.Text = "*"
        '
        'ADD_ObligDirNumero
        '
        Me.ADD_ObligDirNumero.AutoSize = True
        Me.ADD_ObligDirNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligDirNumero.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligDirNumero.Location = New System.Drawing.Point(383, 255)
        Me.ADD_ObligDirNumero.Name = "ADD_ObligDirNumero"
        Me.ADD_ObligDirNumero.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligDirNumero.TabIndex = 80
        Me.ADD_ObligDirNumero.Text = "*"
        '
        'ADD_ObligDirCalle
        '
        Me.ADD_ObligDirCalle.AutoSize = True
        Me.ADD_ObligDirCalle.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligDirCalle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligDirCalle.Location = New System.Drawing.Point(225, 255)
        Me.ADD_ObligDirCalle.Name = "ADD_ObligDirCalle"
        Me.ADD_ObligDirCalle.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligDirCalle.TabIndex = 79
        Me.ADD_ObligDirCalle.Text = "*"
        '
        'ADD_ObligFNac
        '
        Me.ADD_ObligFNac.AutoSize = True
        Me.ADD_ObligFNac.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligFNac.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligFNac.Location = New System.Drawing.Point(225, 226)
        Me.ADD_ObligFNac.Name = "ADD_ObligFNac"
        Me.ADD_ObligFNac.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligFNac.TabIndex = 78
        Me.ADD_ObligFNac.Text = "*"
        '
        'ADD_ObligSexo
        '
        Me.ADD_ObligSexo.AutoSize = True
        Me.ADD_ObligSexo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligSexo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligSexo.Location = New System.Drawing.Point(225, 198)
        Me.ADD_ObligSexo.Name = "ADD_ObligSexo"
        Me.ADD_ObligSexo.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligSexo.TabIndex = 77
        Me.ADD_ObligSexo.Text = "*"
        '
        'ADD_ObligApellido
        '
        Me.ADD_ObligApellido.AutoSize = True
        Me.ADD_ObligApellido.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligApellido.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligApellido.Location = New System.Drawing.Point(225, 136)
        Me.ADD_ObligApellido.Name = "ADD_ObligApellido"
        Me.ADD_ObligApellido.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligApellido.TabIndex = 76
        Me.ADD_ObligApellido.Text = "*"
        '
        'ADD_ObligNombre
        '
        Me.ADD_ObligNombre.AutoSize = True
        Me.ADD_ObligNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligNombre.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligNombre.Location = New System.Drawing.Point(225, 110)
        Me.ADD_ObligNombre.Name = "ADD_ObligNombre"
        Me.ADD_ObligNombre.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligNombre.TabIndex = 75
        Me.ADD_ObligNombre.Text = "*"
        '
        'ADD_ObligDocumento
        '
        Me.ADD_ObligDocumento.AutoSize = True
        Me.ADD_ObligDocumento.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligDocumento.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligDocumento.Location = New System.Drawing.Point(225, 78)
        Me.ADD_ObligDocumento.Name = "ADD_ObligDocumento"
        Me.ADD_ObligDocumento.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligDocumento.TabIndex = 74
        Me.ADD_ObligDocumento.Text = "*"
        '
        'AddUser_txt2apellido
        '
        Me.AddUser_txt2apellido.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txt2apellido.ForeColor = System.Drawing.Color.Black
        Me.AddUser_txt2apellido.Location = New System.Drawing.Point(312, 137)
        Me.AddUser_txt2apellido.Name = "AddUser_txt2apellido"
        Me.AddUser_txt2apellido.Size = New System.Drawing.Size(65, 20)
        Me.AddUser_txt2apellido.TabIndex = 4
        '
        'AddUser_txt2Nombre
        '
        Me.AddUser_txt2Nombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txt2Nombre.ForeColor = System.Drawing.Color.Black
        Me.AddUser_txt2Nombre.Location = New System.Drawing.Point(312, 108)
        Me.AddUser_txt2Nombre.Name = "AddUser_txt2Nombre"
        Me.AddUser_txt2Nombre.Size = New System.Drawing.Size(65, 20)
        Me.AddUser_txt2Nombre.TabIndex = 2
        '
        'AddUser_txtDirCalle
        '
        Me.AddUser_txtDirCalle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtDirCalle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtDirCalle.Location = New System.Drawing.Point(245, 253)
        Me.AddUser_txtDirCalle.Name = "AddUser_txtDirCalle"
        Me.AddUser_txtDirCalle.Size = New System.Drawing.Size(65, 20)
        Me.AddUser_txtDirCalle.TabIndex = 7
        '
        'AddUser_txtDirNumero
        '
        Me.AddUser_txtDirNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtDirNumero.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtDirNumero.Location = New System.Drawing.Point(312, 253)
        Me.AddUser_txtDirNumero.Name = "AddUser_txtDirNumero"
        Me.AddUser_txtDirNumero.Size = New System.Drawing.Size(65, 20)
        Me.AddUser_txtDirNumero.TabIndex = 8
        '
        'AddUser_cbEstCivil
        '
        Me.AddUser_cbEstCivil.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_cbEstCivil.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_cbEstCivil.FormattingEnabled = True
        Me.AddUser_cbEstCivil.Items.AddRange(New Object() {"casado/a", "soltero/a", "divorciado/a", "concubinato/a", "viudo/a"})
        Me.AddUser_cbEstCivil.Location = New System.Drawing.Point(245, 282)
        Me.AddUser_cbEstCivil.Name = "AddUser_cbEstCivil"
        Me.AddUser_cbEstCivil.Size = New System.Drawing.Size(132, 21)
        Me.AddUser_cbEstCivil.TabIndex = 9
        '
        'AddUser_cbSexo
        '
        Me.AddUser_cbSexo.BackColor = System.Drawing.Color.White
        Me.AddUser_cbSexo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_cbSexo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_cbSexo.FormattingEnabled = True
        Me.AddUser_cbSexo.Items.AddRange(New Object() {"hombre", "mujer", "otro"})
        Me.AddUser_cbSexo.Location = New System.Drawing.Point(245, 195)
        Me.AddUser_cbSexo.Name = "AddUser_cbSexo"
        Me.AddUser_cbSexo.Size = New System.Drawing.Size(132, 21)
        Me.AddUser_cbSexo.TabIndex = 5
        '
        'AddUser_dateFIngreso
        '
        Me.AddUser_dateFIngreso.CustomFormat = "yyyy-MM-dd"
        Me.AddUser_dateFIngreso.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.AddUser_dateFIngreso.Location = New System.Drawing.Point(574, 76)
        Me.AddUser_dateFIngreso.Name = "AddUser_dateFIngreso"
        Me.AddUser_dateFIngreso.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_dateFIngreso.TabIndex = 14
        '
        'AddUser_dateFNacimiento
        '
        Me.AddUser_dateFNacimiento.CustomFormat = "yyyy-MM-dd"
        Me.AddUser_dateFNacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.AddUser_dateFNacimiento.Location = New System.Drawing.Point(245, 224)
        Me.AddUser_dateFNacimiento.Name = "AddUser_dateFNacimiento"
        Me.AddUser_dateFNacimiento.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_dateFNacimiento.TabIndex = 6
        '
        'AddUser_btnAgregar
        '
        Me.AddUser_btnAgregar.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.AddUser_btnAgregar.FlatAppearance.BorderSize = 0
        Me.AddUser_btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddUser_btnAgregar.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_btnAgregar.ForeColor = System.Drawing.Color.White
        Me.AddUser_btnAgregar.Location = New System.Drawing.Point(346, 472)
        Me.AddUser_btnAgregar.Name = "AddUser_btnAgregar"
        Me.AddUser_btnAgregar.Size = New System.Drawing.Size(87, 23)
        Me.AddUser_btnAgregar.TabIndex = 22
        Me.AddUser_btnAgregar.Text = "AGREGAR"
        Me.AddUser_btnAgregar.UseVisualStyleBackColor = False
        '
        'AddUser_rbAdmin
        '
        Me.AddUser_rbAdmin.AutoSize = True
        Me.AddUser_rbAdmin.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_rbAdmin.Location = New System.Drawing.Point(574, 269)
        Me.AddUser_rbAdmin.Name = "AddUser_rbAdmin"
        Me.AddUser_rbAdmin.Size = New System.Drawing.Size(107, 19)
        Me.AddUser_rbAdmin.TabIndex = 21
        Me.AddUser_rbAdmin.TabStop = True
        Me.AddUser_rbAdmin.Text = "ADMINISTRADOR"
        Me.AddUser_rbAdmin.UseVisualStyleBackColor = True
        '
        'AddUser_rbUsuario
        '
        Me.AddUser_rbUsuario.AutoSize = True
        Me.AddUser_rbUsuario.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_rbUsuario.Location = New System.Drawing.Point(441, 269)
        Me.AddUser_rbUsuario.Name = "AddUser_rbUsuario"
        Me.AddUser_rbUsuario.Size = New System.Drawing.Size(69, 19)
        Me.AddUser_rbUsuario.TabIndex = 20
        Me.AddUser_rbUsuario.TabStop = True
        Me.AddUser_rbUsuario.Text = "USUARIO"
        Me.AddUser_rbUsuario.UseVisualStyleBackColor = True
        '
        'AddUser_txtMailEmpresarial
        '
        Me.AddUser_txtMailEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtMailEmpresarial.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtMailEmpresarial.Location = New System.Drawing.Point(574, 224)
        Me.AddUser_txtMailEmpresarial.Name = "AddUser_txtMailEmpresarial"
        Me.AddUser_txtMailEmpresarial.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_txtMailEmpresarial.TabIndex = 19
        '
        'AddUser_txtTlfEmpresarial
        '
        Me.AddUser_txtTlfEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtTlfEmpresarial.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtTlfEmpresarial.Location = New System.Drawing.Point(574, 195)
        Me.AddUser_txtTlfEmpresarial.MaxLength = 8
        Me.AddUser_txtTlfEmpresarial.Name = "AddUser_txtTlfEmpresarial"
        Me.AddUser_txtTlfEmpresarial.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_txtTlfEmpresarial.TabIndex = 18
        '
        'AddUser_txtDepartamento
        '
        Me.AddUser_txtDepartamento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtDepartamento.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtDepartamento.Location = New System.Drawing.Point(574, 166)
        Me.AddUser_txtDepartamento.Name = "AddUser_txtDepartamento"
        Me.AddUser_txtDepartamento.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_txtDepartamento.TabIndex = 17
        '
        'AddUser_txtCargo
        '
        Me.AddUser_txtCargo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtCargo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtCargo.Location = New System.Drawing.Point(574, 108)
        Me.AddUser_txtCargo.Name = "AddUser_txtCargo"
        Me.AddUser_txtCargo.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_txtCargo.TabIndex = 15
        '
        'AddUser_lblEmailEmpresarial
        '
        Me.AddUser_lblEmailEmpresarial.AutoSize = True
        Me.AddUser_lblEmailEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblEmailEmpresarial.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblEmailEmpresarial.Location = New System.Drawing.Point(413, 226)
        Me.AddUser_lblEmailEmpresarial.Name = "AddUser_lblEmailEmpresarial"
        Me.AddUser_lblEmailEmpresarial.Size = New System.Drawing.Size(111, 17)
        Me.AddUser_lblEmailEmpresarial.TabIndex = 52
        Me.AddUser_lblEmailEmpresarial.Text = "Email empresarial:"
        '
        'AddUser_lblTelfEmpresarial
        '
        Me.AddUser_lblTelfEmpresarial.AutoSize = True
        Me.AddUser_lblTelfEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblTelfEmpresarial.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblTelfEmpresarial.Location = New System.Drawing.Point(413, 197)
        Me.AddUser_lblTelfEmpresarial.Name = "AddUser_lblTelfEmpresarial"
        Me.AddUser_lblTelfEmpresarial.Size = New System.Drawing.Size(128, 17)
        Me.AddUser_lblTelfEmpresarial.TabIndex = 51
        Me.AddUser_lblTelfEmpresarial.Text = "Teléfono empresarial:"
        '
        'AddUser_lblDepartamento
        '
        Me.AddUser_lblDepartamento.AutoSize = True
        Me.AddUser_lblDepartamento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblDepartamento.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblDepartamento.Location = New System.Drawing.Point(412, 168)
        Me.AddUser_lblDepartamento.Name = "AddUser_lblDepartamento"
        Me.AddUser_lblDepartamento.Size = New System.Drawing.Size(92, 17)
        Me.AddUser_lblDepartamento.TabIndex = 50
        Me.AddUser_lblDepartamento.Text = "Departamento:"
        '
        'AddUser_lblGrado
        '
        Me.AddUser_lblGrado.AutoSize = True
        Me.AddUser_lblGrado.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblGrado.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblGrado.Location = New System.Drawing.Point(412, 139)
        Me.AddUser_lblGrado.Name = "AddUser_lblGrado"
        Me.AddUser_lblGrado.Size = New System.Drawing.Size(44, 17)
        Me.AddUser_lblGrado.TabIndex = 49
        Me.AddUser_lblGrado.Text = "Grado:"
        '
        'AddUser_lblCargo
        '
        Me.AddUser_lblCargo.AutoSize = True
        Me.AddUser_lblCargo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblCargo.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblCargo.Location = New System.Drawing.Point(412, 110)
        Me.AddUser_lblCargo.Name = "AddUser_lblCargo"
        Me.AddUser_lblCargo.Size = New System.Drawing.Size(44, 17)
        Me.AddUser_lblCargo.TabIndex = 48
        Me.AddUser_lblCargo.Text = "Cargo:"
        '
        'AddUser_lblFIngreso
        '
        Me.AddUser_lblFIngreso.AutoSize = True
        Me.AddUser_lblFIngreso.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblFIngreso.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblFIngreso.Location = New System.Drawing.Point(412, 78)
        Me.AddUser_lblFIngreso.Name = "AddUser_lblFIngreso"
        Me.AddUser_lblFIngreso.Size = New System.Drawing.Size(106, 17)
        Me.AddUser_lblFIngreso.TabIndex = 46
        Me.AddUser_lblFIngreso.Text = "Fecha de ingreso:"
        '
        'AddUser_txtFijo
        '
        Me.AddUser_txtFijo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtFijo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtFijo.Location = New System.Drawing.Point(245, 404)
        Me.AddUser_txtFijo.MaxLength = 8
        Me.AddUser_txtFijo.Name = "AddUser_txtFijo"
        Me.AddUser_txtFijo.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_txtFijo.TabIndex = 13
        '
        'AddUser_txtCelular
        '
        Me.AddUser_txtCelular.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtCelular.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtCelular.Location = New System.Drawing.Point(245, 369)
        Me.AddUser_txtCelular.MaxLength = 8
        Me.AddUser_txtCelular.Name = "AddUser_txtCelular"
        Me.AddUser_txtCelular.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_txtCelular.TabIndex = 12
        '
        'AddUser_txtHijos
        '
        Me.AddUser_txtHijos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtHijos.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtHijos.Location = New System.Drawing.Point(245, 340)
        Me.AddUser_txtHijos.Name = "AddUser_txtHijos"
        Me.AddUser_txtHijos.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_txtHijos.TabIndex = 11
        '
        'AddUser_txtEmail
        '
        Me.AddUser_txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtEmail.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtEmail.Location = New System.Drawing.Point(245, 311)
        Me.AddUser_txtEmail.Name = "AddUser_txtEmail"
        Me.AddUser_txtEmail.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_txtEmail.TabIndex = 10
        '
        'AddUser_txtContraseña
        '
        Me.AddUser_txtContraseña.BackColor = System.Drawing.Color.White
        Me.AddUser_txtContraseña.Enabled = False
        Me.AddUser_txtContraseña.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtContraseña.Location = New System.Drawing.Point(245, 166)
        Me.AddUser_txtContraseña.Name = "AddUser_txtContraseña"
        Me.AddUser_txtContraseña.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_txtContraseña.TabIndex = 37
        Me.AddUser_txtContraseña.Text = "12345678"
        '
        'AddUser_txtApellido
        '
        Me.AddUser_txtApellido.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtApellido.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtApellido.Location = New System.Drawing.Point(245, 137)
        Me.AddUser_txtApellido.Name = "AddUser_txtApellido"
        Me.AddUser_txtApellido.Size = New System.Drawing.Size(65, 20)
        Me.AddUser_txtApellido.TabIndex = 3
        '
        'AddUser_txtNombre
        '
        Me.AddUser_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtNombre.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtNombre.Location = New System.Drawing.Point(245, 108)
        Me.AddUser_txtNombre.Name = "AddUser_txtNombre"
        Me.AddUser_txtNombre.Size = New System.Drawing.Size(65, 20)
        Me.AddUser_txtNombre.TabIndex = 1
        '
        'AddUser_lblFijo
        '
        Me.AddUser_lblFijo.AutoSize = True
        Me.AddUser_lblFijo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!)
        Me.AddUser_lblFijo.Location = New System.Drawing.Point(84, 406)
        Me.AddUser_lblFijo.Name = "AddUser_lblFijo"
        Me.AddUser_lblFijo.Size = New System.Drawing.Size(79, 17)
        Me.AddUser_lblFijo.TabIndex = 34
        Me.AddUser_lblFijo.Text = "Teléfono fijo:"
        '
        'AddUser_lblCelular
        '
        Me.AddUser_lblCelular.AutoSize = True
        Me.AddUser_lblCelular.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblCelular.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblCelular.Location = New System.Drawing.Point(83, 371)
        Me.AddUser_lblCelular.Name = "AddUser_lblCelular"
        Me.AddUser_lblCelular.Size = New System.Drawing.Size(99, 17)
        Me.AddUser_lblCelular.TabIndex = 33
        Me.AddUser_lblCelular.Text = "Teléfono celular:"
        '
        'AddUser_lblHijos
        '
        Me.AddUser_lblHijos.AutoSize = True
        Me.AddUser_lblHijos.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblHijos.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblHijos.Location = New System.Drawing.Point(83, 342)
        Me.AddUser_lblHijos.Name = "AddUser_lblHijos"
        Me.AddUser_lblHijos.Size = New System.Drawing.Size(38, 17)
        Me.AddUser_lblHijos.TabIndex = 32
        Me.AddUser_lblHijos.Text = "Hijos:"
        '
        'AddUser_lblEmail
        '
        Me.AddUser_lblEmail.AutoSize = True
        Me.AddUser_lblEmail.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblEmail.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblEmail.Location = New System.Drawing.Point(83, 313)
        Me.AddUser_lblEmail.Name = "AddUser_lblEmail"
        Me.AddUser_lblEmail.Size = New System.Drawing.Size(42, 17)
        Me.AddUser_lblEmail.TabIndex = 31
        Me.AddUser_lblEmail.Text = "Email:"
        '
        'AddUser_lblEstCivil
        '
        Me.AddUser_lblEstCivil.AutoSize = True
        Me.AddUser_lblEstCivil.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblEstCivil.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblEstCivil.Location = New System.Drawing.Point(83, 284)
        Me.AddUser_lblEstCivil.Name = "AddUser_lblEstCivil"
        Me.AddUser_lblEstCivil.Size = New System.Drawing.Size(75, 17)
        Me.AddUser_lblEstCivil.TabIndex = 30
        Me.AddUser_lblEstCivil.Text = "Estado Civil:"
        '
        'AddUser_lblDireccion
        '
        Me.AddUser_lblDireccion.AutoSize = True
        Me.AddUser_lblDireccion.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblDireccion.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblDireccion.Location = New System.Drawing.Point(83, 255)
        Me.AddUser_lblDireccion.Name = "AddUser_lblDireccion"
        Me.AddUser_lblDireccion.Size = New System.Drawing.Size(63, 17)
        Me.AddUser_lblDireccion.TabIndex = 29
        Me.AddUser_lblDireccion.Text = "Dirección:"
        '
        'AddUser_lblFNacimiento
        '
        Me.AddUser_lblFNacimiento.AutoSize = True
        Me.AddUser_lblFNacimiento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblFNacimiento.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblFNacimiento.Location = New System.Drawing.Point(83, 226)
        Me.AddUser_lblFNacimiento.Name = "AddUser_lblFNacimiento"
        Me.AddUser_lblFNacimiento.Size = New System.Drawing.Size(127, 17)
        Me.AddUser_lblFNacimiento.TabIndex = 28
        Me.AddUser_lblFNacimiento.Text = "Fecha de nacimiento:"
        '
        'AddUser_lblSexo
        '
        Me.AddUser_lblSexo.AutoSize = True
        Me.AddUser_lblSexo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblSexo.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblSexo.Location = New System.Drawing.Point(84, 197)
        Me.AddUser_lblSexo.Name = "AddUser_lblSexo"
        Me.AddUser_lblSexo.Size = New System.Drawing.Size(37, 17)
        Me.AddUser_lblSexo.TabIndex = 27
        Me.AddUser_lblSexo.Text = "Sexo:"
        '
        'AddUser_lblContraseña
        '
        Me.AddUser_lblContraseña.AutoSize = True
        Me.AddUser_lblContraseña.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblContraseña.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblContraseña.Location = New System.Drawing.Point(83, 168)
        Me.AddUser_lblContraseña.Name = "AddUser_lblContraseña"
        Me.AddUser_lblContraseña.Size = New System.Drawing.Size(75, 17)
        Me.AddUser_lblContraseña.TabIndex = 26
        Me.AddUser_lblContraseña.Text = "Contraseña:"
        '
        'AddUser_lblApellido
        '
        Me.AddUser_lblApellido.AutoSize = True
        Me.AddUser_lblApellido.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblApellido.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblApellido.Location = New System.Drawing.Point(83, 139)
        Me.AddUser_lblApellido.Name = "AddUser_lblApellido"
        Me.AddUser_lblApellido.Size = New System.Drawing.Size(62, 17)
        Me.AddUser_lblApellido.TabIndex = 25
        Me.AddUser_lblApellido.Text = "Apellidos:"
        '
        'AddUser_lblNombre
        '
        Me.AddUser_lblNombre.AutoSize = True
        Me.AddUser_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblNombre.Location = New System.Drawing.Point(83, 110)
        Me.AddUser_lblNombre.Name = "AddUser_lblNombre"
        Me.AddUser_lblNombre.Size = New System.Drawing.Size(61, 17)
        Me.AddUser_lblNombre.TabIndex = 24
        Me.AddUser_lblNombre.Text = "Nombres:"
        '
        'AddUser_txtDocumento
        '
        Me.AddUser_txtDocumento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_txtDocumento.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddUser_txtDocumento.Location = New System.Drawing.Point(245, 76)
        Me.AddUser_txtDocumento.MaxLength = 8
        Me.AddUser_txtDocumento.Name = "AddUser_txtDocumento"
        Me.AddUser_txtDocumento.Size = New System.Drawing.Size(132, 20)
        Me.AddUser_txtDocumento.TabIndex = 0
        '
        'AddUser_lblDocumento
        '
        Me.AddUser_lblDocumento.AutoSize = True
        Me.AddUser_lblDocumento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblDocumento.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblDocumento.Location = New System.Drawing.Point(83, 78)
        Me.AddUser_lblDocumento.Name = "AddUser_lblDocumento"
        Me.AddUser_lblDocumento.Size = New System.Drawing.Size(76, 17)
        Me.AddUser_lblDocumento.TabIndex = 2
        Me.AddUser_lblDocumento.Text = "Documento:"
        '
        'TabPage_Modificar
        '
        Me.TabPage_Modificar.Controls.Add(Me.ModUser_picModificarFichas)
        Me.TabPage_Modificar.Location = New System.Drawing.Point(4, 54)
        Me.TabPage_Modificar.Name = "TabPage_Modificar"
        Me.TabPage_Modificar.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Modificar.Size = New System.Drawing.Size(769, 339)
        Me.TabPage_Modificar.TabIndex = 1
        Me.TabPage_Modificar.Text = "TabPage2"
        Me.TabPage_Modificar.UseVisualStyleBackColor = True
        '
        'TabPage_Eliminar
        '
        Me.TabPage_Eliminar.BackColor = System.Drawing.Color.White
        Me.TabPage_Eliminar.Controls.Add(Me.picEliminarUser)
        Me.TabPage_Eliminar.Controls.Add(Me.EUsuario_btnEliminar)
        Me.TabPage_Eliminar.Controls.Add(Me.EUsuario_btnBuscar)
        Me.TabPage_Eliminar.Controls.Add(Me.EUsuario_lblNumRegistro)
        Me.TabPage_Eliminar.Controls.Add(Me.EUsuario_lblDocumento)
        Me.TabPage_Eliminar.Controls.Add(Me.EUsuario_DataGrid)
        Me.TabPage_Eliminar.Controls.Add(Me.EUsuario_txtNumRegistro)
        Me.TabPage_Eliminar.Controls.Add(Me.EUsuario_txtDocumento)
        Me.TabPage_Eliminar.Location = New System.Drawing.Point(4, 54)
        Me.TabPage_Eliminar.Name = "TabPage_Eliminar"
        Me.TabPage_Eliminar.Size = New System.Drawing.Size(769, 339)
        Me.TabPage_Eliminar.TabIndex = 2
        Me.TabPage_Eliminar.Text = "TabPage3"
        Me.TabPage_Eliminar.UseVisualStyleBackColor = True
        '
        'EUsuario_btnEliminar
        '
        Me.EUsuario_btnEliminar.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.EUsuario_btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.EUsuario_btnEliminar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EUsuario_btnEliminar.ForeColor = System.Drawing.Color.White
        Me.EUsuario_btnEliminar.Location = New System.Drawing.Point(312, 298)
        Me.EUsuario_btnEliminar.Name = "EUsuario_btnEliminar"
        Me.EUsuario_btnEliminar.Size = New System.Drawing.Size(153, 29)
        Me.EUsuario_btnEliminar.TabIndex = 4
        Me.EUsuario_btnEliminar.Text = "DAR DE BAJA"
        Me.EUsuario_btnEliminar.UseVisualStyleBackColor = False
        Me.EUsuario_btnEliminar.Visible = False
        '
        'EUsuario_btnBuscar
        '
        Me.EUsuario_btnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.EUsuario_btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.EUsuario_btnBuscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EUsuario_btnBuscar.ForeColor = System.Drawing.Color.White
        Me.EUsuario_btnBuscar.Location = New System.Drawing.Point(330, 164)
        Me.EUsuario_btnBuscar.Name = "EUsuario_btnBuscar"
        Me.EUsuario_btnBuscar.Size = New System.Drawing.Size(117, 29)
        Me.EUsuario_btnBuscar.TabIndex = 2
        Me.EUsuario_btnBuscar.Text = "BUSCAR"
        Me.EUsuario_btnBuscar.UseVisualStyleBackColor = False
        '
        'EUsuario_lblNumRegistro
        '
        Me.EUsuario_lblNumRegistro.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EUsuario_lblNumRegistro.AutoSize = True
        Me.EUsuario_lblNumRegistro.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EUsuario_lblNumRegistro.Location = New System.Drawing.Point(481, 80)
        Me.EUsuario_lblNumRegistro.Name = "EUsuario_lblNumRegistro"
        Me.EUsuario_lblNumRegistro.Size = New System.Drawing.Size(126, 16)
        Me.EUsuario_lblNumRegistro.TabIndex = 4
        Me.EUsuario_lblNumRegistro.Text = "Numero de registro:"
        '
        'EUsuario_lblDocumento
        '
        Me.EUsuario_lblDocumento.AutoSize = True
        Me.EUsuario_lblDocumento.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EUsuario_lblDocumento.Location = New System.Drawing.Point(59, 80)
        Me.EUsuario_lblDocumento.Name = "EUsuario_lblDocumento"
        Me.EUsuario_lblDocumento.Size = New System.Drawing.Size(80, 16)
        Me.EUsuario_lblDocumento.TabIndex = 3
        Me.EUsuario_lblDocumento.Text = "Documento:"
        '
        'EUsuario_DataGrid
        '
        Me.EUsuario_DataGrid.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.EUsuario_DataGrid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.EUsuario_DataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.EUsuario_DataGrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PersonaidDataGridViewTextBoxColumn, Me.DocDataGridViewTextBoxColumn, Me.NombreDataGridViewTextBoxColumn, Me.ApellidoDataGridViewTextBoxColumn, Me.RolDataGridViewTextBoxColumn, Me.CargoDataGridViewTextBoxColumn})
        Me.EUsuario_DataGrid.DataSource = Me.PersonalBindingSource
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.EUsuario_DataGrid.DefaultCellStyle = DataGridViewCellStyle2
        Me.EUsuario_DataGrid.Location = New System.Drawing.Point(75, 219)
        Me.EUsuario_DataGrid.Name = "EUsuario_DataGrid"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.EUsuario_DataGrid.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.EUsuario_DataGrid.Size = New System.Drawing.Size(643, 73)
        Me.EUsuario_DataGrid.TabIndex = 3
        Me.EUsuario_DataGrid.Visible = False
        '
        'PersonaidDataGridViewTextBoxColumn
        '
        Me.PersonaidDataGridViewTextBoxColumn.DataPropertyName = "persona_id"
        Me.PersonaidDataGridViewTextBoxColumn.HeaderText = "persona_id"
        Me.PersonaidDataGridViewTextBoxColumn.Name = "PersonaidDataGridViewTextBoxColumn"
        '
        'DocDataGridViewTextBoxColumn
        '
        Me.DocDataGridViewTextBoxColumn.DataPropertyName = "doc"
        Me.DocDataGridViewTextBoxColumn.HeaderText = "doc"
        Me.DocDataGridViewTextBoxColumn.Name = "DocDataGridViewTextBoxColumn"
        '
        'NombreDataGridViewTextBoxColumn
        '
        Me.NombreDataGridViewTextBoxColumn.DataPropertyName = "nombre"
        Me.NombreDataGridViewTextBoxColumn.HeaderText = "nombre"
        Me.NombreDataGridViewTextBoxColumn.Name = "NombreDataGridViewTextBoxColumn"
        '
        'ApellidoDataGridViewTextBoxColumn
        '
        Me.ApellidoDataGridViewTextBoxColumn.DataPropertyName = "apellido"
        Me.ApellidoDataGridViewTextBoxColumn.HeaderText = "apellido"
        Me.ApellidoDataGridViewTextBoxColumn.Name = "ApellidoDataGridViewTextBoxColumn"
        '
        'RolDataGridViewTextBoxColumn
        '
        Me.RolDataGridViewTextBoxColumn.DataPropertyName = "rol"
        Me.RolDataGridViewTextBoxColumn.HeaderText = "rol"
        Me.RolDataGridViewTextBoxColumn.Name = "RolDataGridViewTextBoxColumn"
        '
        'CargoDataGridViewTextBoxColumn
        '
        Me.CargoDataGridViewTextBoxColumn.DataPropertyName = "cargo"
        Me.CargoDataGridViewTextBoxColumn.HeaderText = "cargo"
        Me.CargoDataGridViewTextBoxColumn.Name = "CargoDataGridViewTextBoxColumn"
        '
        'PersonalBindingSource
        '
        Me.PersonalBindingSource.DataMember = "personal"
        Me.PersonalBindingSource.DataSource = Me.TaxDataSet
        '
        'TaxDataSet
        '
        Me.TaxDataSet.DataSetName = "taxDataSet"
        Me.TaxDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EUsuario_txtNumRegistro
        '
        Me.EUsuario_txtNumRegistro.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EUsuario_txtNumRegistro.Location = New System.Drawing.Point(484, 115)
        Me.EUsuario_txtNumRegistro.Name = "EUsuario_txtNumRegistro"
        Me.EUsuario_txtNumRegistro.Size = New System.Drawing.Size(234, 20)
        Me.EUsuario_txtNumRegistro.TabIndex = 1
        '
        'EUsuario_txtDocumento
        '
        Me.EUsuario_txtDocumento.Location = New System.Drawing.Point(59, 115)
        Me.EUsuario_txtDocumento.Name = "EUsuario_txtDocumento"
        Me.EUsuario_txtDocumento.Size = New System.Drawing.Size(234, 20)
        Me.EUsuario_txtDocumento.TabIndex = 0
        '
        'TabPage_Listar
        '
        Me.TabPage_Listar.Controls.Add(Me.ListUser_pnlBuscPorRegistro)
        Me.TabPage_Listar.Controls.Add(Me.ListUser_pnlBuscPorNombre)
        Me.TabPage_Listar.Controls.Add(Me.ListUser_pnlBuscPorDocumento)
        Me.TabPage_Listar.Controls.Add(Me.Panel2)
        Me.TabPage_Listar.Controls.Add(Me.ListUser_pnlTitulo)
        Me.TabPage_Listar.Location = New System.Drawing.Point(4, 54)
        Me.TabPage_Listar.Name = "TabPage_Listar"
        Me.TabPage_Listar.Size = New System.Drawing.Size(769, 339)
        Me.TabPage_Listar.TabIndex = 3
        Me.TabPage_Listar.Text = "TabPage4"
        Me.TabPage_Listar.UseVisualStyleBackColor = True
        '
        'ListUser_pnlBuscPorRegistro
        '
        Me.ListUser_pnlBuscPorRegistro.BackColor = System.Drawing.Color.White
        Me.ListUser_pnlBuscPorRegistro.Controls.Add(Me.ListUser_btnBuscPorRegistro)
        Me.ListUser_pnlBuscPorRegistro.Controls.Add(Me.ListUser_txtBuscPorRegistro)
        Me.ListUser_pnlBuscPorRegistro.Controls.Add(Me.ListUser_lblBuscPorRegistro)
        Me.ListUser_pnlBuscPorRegistro.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListUser_pnlBuscPorRegistro.Location = New System.Drawing.Point(258, 65)
        Me.ListUser_pnlBuscPorRegistro.Name = "ListUser_pnlBuscPorRegistro"
        Me.ListUser_pnlBuscPorRegistro.Size = New System.Drawing.Size(255, 154)
        Me.ListUser_pnlBuscPorRegistro.TabIndex = 78
        '
        'ListUser_btnBuscPorRegistro
        '
        Me.ListUser_btnBuscPorRegistro.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.ListUser_btnBuscPorRegistro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ListUser_btnBuscPorRegistro.FlatAppearance.BorderSize = 0
        Me.ListUser_btnBuscPorRegistro.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ListUser_btnBuscPorRegistro.ForeColor = System.Drawing.Color.White
        Me.ListUser_btnBuscPorRegistro.Location = New System.Drawing.Point(85, 87)
        Me.ListUser_btnBuscPorRegistro.Name = "ListUser_btnBuscPorRegistro"
        Me.ListUser_btnBuscPorRegistro.Size = New System.Drawing.Size(75, 23)
        Me.ListUser_btnBuscPorRegistro.TabIndex = 4
        Me.ListUser_btnBuscPorRegistro.Text = "BUSCAR"
        Me.ListUser_btnBuscPorRegistro.UseVisualStyleBackColor = False
        '
        'ListUser_txtBuscPorRegistro
        '
        Me.ListUser_txtBuscPorRegistro.Location = New System.Drawing.Point(34, 51)
        Me.ListUser_txtBuscPorRegistro.Name = "ListUser_txtBuscPorRegistro"
        Me.ListUser_txtBuscPorRegistro.Size = New System.Drawing.Size(189, 20)
        Me.ListUser_txtBuscPorRegistro.TabIndex = 3
        '
        'ListUser_lblBuscPorRegistro
        '
        Me.ListUser_lblBuscPorRegistro.AutoSize = True
        Me.ListUser_lblBuscPorRegistro.Location = New System.Drawing.Point(34, 25)
        Me.ListUser_lblBuscPorRegistro.Name = "ListUser_lblBuscPorRegistro"
        Me.ListUser_lblBuscPorRegistro.Size = New System.Drawing.Size(101, 13)
        Me.ListUser_lblBuscPorRegistro.TabIndex = 0
        Me.ListUser_lblBuscPorRegistro.Text = "Buscar por registro: "
        '
        'ListUser_pnlBuscPorNombre
        '
        Me.ListUser_pnlBuscPorNombre.BackColor = System.Drawing.Color.White
        Me.ListUser_pnlBuscPorNombre.Controls.Add(Me.ListUser_txtBuscPorNombre_Apellido)
        Me.ListUser_pnlBuscPorNombre.Controls.Add(Me.ListUser_btnBuscPorNombre)
        Me.ListUser_pnlBuscPorNombre.Controls.Add(Me.ListUser_txtBuscPorNombre)
        Me.ListUser_pnlBuscPorNombre.Controls.Add(Me.ListUser_lblBuscPorNombre)
        Me.ListUser_pnlBuscPorNombre.Dock = System.Windows.Forms.DockStyle.Right
        Me.ListUser_pnlBuscPorNombre.Location = New System.Drawing.Point(513, 65)
        Me.ListUser_pnlBuscPorNombre.Name = "ListUser_pnlBuscPorNombre"
        Me.ListUser_pnlBuscPorNombre.Size = New System.Drawing.Size(256, 154)
        Me.ListUser_pnlBuscPorNombre.TabIndex = 77
        '
        'ListUser_txtBuscPorNombre_Apellido
        '
        Me.ListUser_txtBuscPorNombre_Apellido.ForeColor = System.Drawing.Color.LightGray
        Me.ListUser_txtBuscPorNombre_Apellido.Location = New System.Drawing.Point(134, 51)
        Me.ListUser_txtBuscPorNombre_Apellido.Name = "ListUser_txtBuscPorNombre_Apellido"
        Me.ListUser_txtBuscPorNombre_Apellido.Size = New System.Drawing.Size(94, 20)
        Me.ListUser_txtBuscPorNombre_Apellido.TabIndex = 6
        Me.ListUser_txtBuscPorNombre_Apellido.Text = "Apellido"
        '
        'ListUser_btnBuscPorNombre
        '
        Me.ListUser_btnBuscPorNombre.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.ListUser_btnBuscPorNombre.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ListUser_btnBuscPorNombre.FlatAppearance.BorderSize = 0
        Me.ListUser_btnBuscPorNombre.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ListUser_btnBuscPorNombre.ForeColor = System.Drawing.Color.White
        Me.ListUser_btnBuscPorNombre.Location = New System.Drawing.Point(98, 87)
        Me.ListUser_btnBuscPorNombre.Name = "ListUser_btnBuscPorNombre"
        Me.ListUser_btnBuscPorNombre.Size = New System.Drawing.Size(75, 23)
        Me.ListUser_btnBuscPorNombre.TabIndex = 7
        Me.ListUser_btnBuscPorNombre.Text = "BUSCAR"
        Me.ListUser_btnBuscPorNombre.UseVisualStyleBackColor = False
        '
        'ListUser_txtBuscPorNombre
        '
        Me.ListUser_txtBuscPorNombre.ForeColor = System.Drawing.Color.LightGray
        Me.ListUser_txtBuscPorNombre.Location = New System.Drawing.Point(34, 51)
        Me.ListUser_txtBuscPorNombre.Name = "ListUser_txtBuscPorNombre"
        Me.ListUser_txtBuscPorNombre.Size = New System.Drawing.Size(94, 20)
        Me.ListUser_txtBuscPorNombre.TabIndex = 5
        Me.ListUser_txtBuscPorNombre.Text = "Nombre"
        '
        'ListUser_lblBuscPorNombre
        '
        Me.ListUser_lblBuscPorNombre.AutoSize = True
        Me.ListUser_lblBuscPorNombre.Location = New System.Drawing.Point(34, 25)
        Me.ListUser_lblBuscPorNombre.Name = "ListUser_lblBuscPorNombre"
        Me.ListUser_lblBuscPorNombre.Size = New System.Drawing.Size(99, 13)
        Me.ListUser_lblBuscPorNombre.TabIndex = 0
        Me.ListUser_lblBuscPorNombre.Text = "Buscar por nombre:"
        '
        'ListUser_pnlBuscPorDocumento
        '
        Me.ListUser_pnlBuscPorDocumento.BackColor = System.Drawing.Color.White
        Me.ListUser_pnlBuscPorDocumento.Controls.Add(Me.ListUser_btnBuscPorDocumento)
        Me.ListUser_pnlBuscPorDocumento.Controls.Add(Me.ListUser_txtBuscPorDocumento)
        Me.ListUser_pnlBuscPorDocumento.Controls.Add(Me.ListUser_lblBuscPorDocumento)
        Me.ListUser_pnlBuscPorDocumento.Dock = System.Windows.Forms.DockStyle.Left
        Me.ListUser_pnlBuscPorDocumento.Location = New System.Drawing.Point(0, 65)
        Me.ListUser_pnlBuscPorDocumento.Name = "ListUser_pnlBuscPorDocumento"
        Me.ListUser_pnlBuscPorDocumento.Size = New System.Drawing.Size(258, 154)
        Me.ListUser_pnlBuscPorDocumento.TabIndex = 76
        '
        'ListUser_btnBuscPorDocumento
        '
        Me.ListUser_btnBuscPorDocumento.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.ListUser_btnBuscPorDocumento.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ListUser_btnBuscPorDocumento.FlatAppearance.BorderSize = 0
        Me.ListUser_btnBuscPorDocumento.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ListUser_btnBuscPorDocumento.ForeColor = System.Drawing.Color.White
        Me.ListUser_btnBuscPorDocumento.Location = New System.Drawing.Point(92, 87)
        Me.ListUser_btnBuscPorDocumento.Name = "ListUser_btnBuscPorDocumento"
        Me.ListUser_btnBuscPorDocumento.Size = New System.Drawing.Size(75, 23)
        Me.ListUser_btnBuscPorDocumento.TabIndex = 2
        Me.ListUser_btnBuscPorDocumento.Text = "BUSCAR"
        Me.ListUser_btnBuscPorDocumento.UseVisualStyleBackColor = False
        '
        'ListUser_txtBuscPorDocumento
        '
        Me.ListUser_txtBuscPorDocumento.Location = New System.Drawing.Point(34, 51)
        Me.ListUser_txtBuscPorDocumento.Name = "ListUser_txtBuscPorDocumento"
        Me.ListUser_txtBuscPorDocumento.Size = New System.Drawing.Size(189, 20)
        Me.ListUser_txtBuscPorDocumento.TabIndex = 1
        '
        'ListUser_lblBuscPorDocumento
        '
        Me.ListUser_lblBuscPorDocumento.AutoSize = True
        Me.ListUser_lblBuscPorDocumento.Location = New System.Drawing.Point(34, 25)
        Me.ListUser_lblBuscPorDocumento.Name = "ListUser_lblBuscPorDocumento"
        Me.ListUser_lblBuscPorDocumento.Size = New System.Drawing.Size(117, 13)
        Me.ListUser_lblBuscPorDocumento.TabIndex = 0
        Me.ListUser_lblBuscPorDocumento.Text = "Buscar por documento:"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.ListUser_btnVer)
        Me.Panel2.Controls.Add(Me.ListUser_DataGrid)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 219)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(769, 120)
        Me.Panel2.TabIndex = 75
        '
        'ListUser_btnVer
        '
        Me.ListUser_btnVer.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListUser_btnVer.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.ListUser_btnVer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ListUser_btnVer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListUser_btnVer.ForeColor = System.Drawing.Color.White
        Me.ListUser_btnVer.Location = New System.Drawing.Point(318, 83)
        Me.ListUser_btnVer.Name = "ListUser_btnVer"
        Me.ListUser_btnVer.Size = New System.Drawing.Size(117, 29)
        Me.ListUser_btnVer.TabIndex = 9
        Me.ListUser_btnVer.Text = "VER"
        Me.ListUser_btnVer.UseVisualStyleBackColor = False
        Me.ListUser_btnVer.Visible = False
        '
        'ListUser_DataGrid
        '
        Me.ListUser_DataGrid.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListUser_DataGrid.AutoGenerateColumns = False
        Me.ListUser_DataGrid.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ListUser_DataGrid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.ListUser_DataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ListUser_DataGrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.ListUser_DataGrid.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.ListUser_DataGrid.DataSource = Me.PersonalBindingSource
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ListUser_DataGrid.DefaultCellStyle = DataGridViewCellStyle5
        Me.ListUser_DataGrid.Location = New System.Drawing.Point(63, 9)
        Me.ListUser_DataGrid.Name = "ListUser_DataGrid"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ListUser_DataGrid.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.ListUser_DataGrid.Size = New System.Drawing.Size(643, 68)
        Me.ListUser_DataGrid.TabIndex = 8
        Me.ListUser_DataGrid.Visible = False
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "persona_id"
        Me.DataGridViewTextBoxColumn1.HeaderText = "persona_id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "doc"
        Me.DataGridViewTextBoxColumn2.HeaderText = "doc"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "nombre"
        Me.DataGridViewTextBoxColumn3.HeaderText = "nombre"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "apellido"
        Me.DataGridViewTextBoxColumn4.HeaderText = "apellido"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "rol"
        Me.DataGridViewTextBoxColumn5.HeaderText = "rol"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "cargo"
        Me.DataGridViewTextBoxColumn6.HeaderText = "cargo"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'ListUser_pnlTitulo
        '
        Me.ListUser_pnlTitulo.Controls.Add(Me.BuscarUser_BuscarEmpleados)
        Me.ListUser_pnlTitulo.Dock = System.Windows.Forms.DockStyle.Top
        Me.ListUser_pnlTitulo.Location = New System.Drawing.Point(0, 0)
        Me.ListUser_pnlTitulo.Name = "ListUser_pnlTitulo"
        Me.ListUser_pnlTitulo.Size = New System.Drawing.Size(769, 65)
        Me.ListUser_pnlTitulo.TabIndex = 74
        '
        'PersonalBindingSource1
        '
        Me.PersonalBindingSource1.DataMember = "personal"
        Me.PersonalBindingSource1.DataSource = Me.TaxDataSetBindingSource
        '
        'TaxDataSetBindingSource
        '
        Me.TaxDataSetBindingSource.DataSource = Me.TaxDataSet
        Me.TaxDataSetBindingSource.Position = 0
        '
        'PersonalTableAdapter
        '
        Me.PersonalTableAdapter.ClearBeforeFill = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'btnListar
        '
        Me.btnListar.FlatAppearance.BorderSize = 0
        Me.btnListar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnListar.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnListar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnListar.Image = Global.TAX.My.Resources.Resources.list_user_gris
        Me.btnListar.Location = New System.Drawing.Point(194, 0)
        Me.btnListar.Name = "btnListar"
        Me.btnListar.Size = New System.Drawing.Size(97, 57)
        Me.btnListar.TabIndex = 3
        Me.btnListar.Text = "LISTAR"
        Me.btnListar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnListar.UseVisualStyleBackColor = True
        '
        'btnEliminar
        '
        Me.btnEliminar.FlatAppearance.BorderSize = 0
        Me.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEliminar.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEliminar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnEliminar.Image = Global.TAX.My.Resources.Resources.del_user_gris
        Me.btnEliminar.Location = New System.Drawing.Point(97, 0)
        Me.btnEliminar.Name = "btnEliminar"
        Me.btnEliminar.Size = New System.Drawing.Size(97, 57)
        Me.btnEliminar.TabIndex = 2
        Me.btnEliminar.Text = "DAR BAJAS"
        Me.btnEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnEliminar.UseVisualStyleBackColor = True
        '
        'btnAgregar
        '
        Me.btnAgregar.FlatAppearance.BorderSize = 0
        Me.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAgregar.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAgregar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.btnAgregar.Image = Global.TAX.My.Resources.Resources.add_user_rojo
        Me.btnAgregar.Location = New System.Drawing.Point(0, 0)
        Me.btnAgregar.Name = "btnAgregar"
        Me.btnAgregar.Size = New System.Drawing.Size(97, 57)
        Me.btnAgregar.TabIndex = 0
        Me.btnAgregar.Text = "AGREGAR"
        Me.btnAgregar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnAgregar.UseVisualStyleBackColor = True
        '
        'AddUser_pbFoto
        '
        Me.AddUser_pbFoto.Image = CType(resources.GetObject("AddUser_pbFoto.Image"), System.Drawing.Image)
        Me.AddUser_pbFoto.Location = New System.Drawing.Point(424, 294)
        Me.AddUser_pbFoto.Name = "AddUser_pbFoto"
        Me.AddUser_pbFoto.Size = New System.Drawing.Size(100, 94)
        Me.AddUser_pbFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.AddUser_pbFoto.TabIndex = 93
        Me.AddUser_pbFoto.TabStop = False
        '
        'AddUser_picAgregarUsuario
        '
        Me.AddUser_picAgregarUsuario.BackColor = System.Drawing.Color.White
        Me.AddUser_picAgregarUsuario.Enabled = False
        Me.AddUser_picAgregarUsuario.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AddUser_picAgregarUsuario.FlatAppearance.BorderSize = 0
        Me.AddUser_picAgregarUsuario.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AddUser_picAgregarUsuario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AddUser_picAgregarUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddUser_picAgregarUsuario.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_picAgregarUsuario.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.AddUser_picAgregarUsuario.Image = CType(resources.GetObject("AddUser_picAgregarUsuario.Image"), System.Drawing.Image)
        Me.AddUser_picAgregarUsuario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.AddUser_picAgregarUsuario.Location = New System.Drawing.Point(3, 6)
        Me.AddUser_picAgregarUsuario.Name = "AddUser_picAgregarUsuario"
        Me.AddUser_picAgregarUsuario.Size = New System.Drawing.Size(278, 53)
        Me.AddUser_picAgregarUsuario.TabIndex = 60
        Me.AddUser_picAgregarUsuario.Text = "Agregar usuarios"
        Me.AddUser_picAgregarUsuario.UseVisualStyleBackColor = False
        '
        'ModUser_picModificarFichas
        '
        Me.ModUser_picModificarFichas.BackColor = System.Drawing.Color.White
        Me.ModUser_picModificarFichas.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ModUser_picModificarFichas.FlatAppearance.BorderSize = 0
        Me.ModUser_picModificarFichas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ModUser_picModificarFichas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ModUser_picModificarFichas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ModUser_picModificarFichas.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_picModificarFichas.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.ModUser_picModificarFichas.Image = CType(resources.GetObject("ModUser_picModificarFichas.Image"), System.Drawing.Image)
        Me.ModUser_picModificarFichas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ModUser_picModificarFichas.Location = New System.Drawing.Point(9, 12)
        Me.ModUser_picModificarFichas.Name = "ModUser_picModificarFichas"
        Me.ModUser_picModificarFichas.Size = New System.Drawing.Size(277, 53)
        Me.ModUser_picModificarFichas.TabIndex = 61
        Me.ModUser_picModificarFichas.Text = "Modificar Fichas"
        Me.ModUser_picModificarFichas.UseVisualStyleBackColor = False
        '
        'picEliminarUser
        '
        Me.picEliminarUser.BackColor = System.Drawing.Color.White
        Me.picEliminarUser.Enabled = False
        Me.picEliminarUser.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.picEliminarUser.FlatAppearance.BorderSize = 0
        Me.picEliminarUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.picEliminarUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.picEliminarUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.picEliminarUser.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.picEliminarUser.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.picEliminarUser.Image = CType(resources.GetObject("picEliminarUser.Image"), System.Drawing.Image)
        Me.picEliminarUser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.picEliminarUser.Location = New System.Drawing.Point(9, 12)
        Me.picEliminarUser.Name = "picEliminarUser"
        Me.picEliminarUser.Size = New System.Drawing.Size(313, 53)
        Me.picEliminarUser.TabIndex = 61
        Me.picEliminarUser.Text = "Dar de baja usuarios"
        Me.picEliminarUser.UseVisualStyleBackColor = False
        '
        'BuscarUser_BuscarEmpleados
        '
        Me.BuscarUser_BuscarEmpleados.BackColor = System.Drawing.Color.White
        Me.BuscarUser_BuscarEmpleados.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BuscarUser_BuscarEmpleados.FlatAppearance.BorderSize = 0
        Me.BuscarUser_BuscarEmpleados.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BuscarUser_BuscarEmpleados.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BuscarUser_BuscarEmpleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BuscarUser_BuscarEmpleados.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BuscarUser_BuscarEmpleados.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.BuscarUser_BuscarEmpleados.Image = CType(resources.GetObject("BuscarUser_BuscarEmpleados.Image"), System.Drawing.Image)
        Me.BuscarUser_BuscarEmpleados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BuscarUser_BuscarEmpleados.Location = New System.Drawing.Point(9, 12)
        Me.BuscarUser_BuscarEmpleados.Name = "BuscarUser_BuscarEmpleados"
        Me.BuscarUser_BuscarEmpleados.Size = New System.Drawing.Size(295, 53)
        Me.BuscarUser_BuscarEmpleados.TabIndex = 61
        Me.BuscarUser_BuscarEmpleados.Text = "Buscar Empleados"
        Me.BuscarUser_BuscarEmpleados.UseVisualStyleBackColor = False
        '
        'Admin_ConfigEmpleados
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(818, 443)
        Me.Controls.Add(Me.pnlCentral)
        Me.Controls.Add(Me.pnlIzq)
        Me.Controls.Add(Me.pnlInf)
        Me.Controls.Add(Me.pnlDer)
        Me.Controls.Add(Me.pnlSup)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_ConfigEmpleados"
        Me.Text = "adminEmpleadosAdmin_inicio"
        Me.pnlCentral.ResumeLayout(False)
        Me.pnlBotones.ResumeLayout(False)
        Me.pnlBotonesGris.ResumeLayout(False)
        Me.TabControl_AdministrarEmpleados.ResumeLayout(False)
        Me.TabPage_Agregar.ResumeLayout(False)
        Me.TabPage_Agregar.PerformLayout()
        Me.TabPage_Modificar.ResumeLayout(False)
        Me.TabPage_Eliminar.ResumeLayout(False)
        Me.TabPage_Eliminar.PerformLayout()
        CType(Me.EUsuario_DataGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PersonalBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TaxDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Listar.ResumeLayout(False)
        Me.ListUser_pnlBuscPorRegistro.ResumeLayout(False)
        Me.ListUser_pnlBuscPorRegistro.PerformLayout()
        Me.ListUser_pnlBuscPorNombre.ResumeLayout(False)
        Me.ListUser_pnlBuscPorNombre.PerformLayout()
        Me.ListUser_pnlBuscPorDocumento.ResumeLayout(False)
        Me.ListUser_pnlBuscPorDocumento.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.ListUser_DataGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ListUser_pnlTitulo.ResumeLayout(False)
        CType(Me.PersonalBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TaxDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AddUser_pbFoto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlSup As System.Windows.Forms.Panel
    Friend WithEvents pnlDer As System.Windows.Forms.Panel
    Friend WithEvents pnlInf As System.Windows.Forms.Panel
    Friend WithEvents pnlIzq As System.Windows.Forms.Panel
    Friend WithEvents pnlCentral As System.Windows.Forms.Panel
    Friend WithEvents TabControl_AdministrarEmpleados As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_Agregar As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_Modificar As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_Eliminar As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_Listar As System.Windows.Forms.TabPage
    Friend WithEvents AddUser_txtDocumento As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_lblDocumento As System.Windows.Forms.Label
    Friend WithEvents AddUser_txtFijo As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txtCelular As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txtHijos As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txtContraseña As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txtApellido As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_lblFijo As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblCelular As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblHijos As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblEmail As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblEstCivil As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblDireccion As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblFNacimiento As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblSexo As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblContraseña As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblApellido As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblNombre As System.Windows.Forms.Label
    Friend WithEvents AddUser_txtMailEmpresarial As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txtTlfEmpresarial As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txtDepartamento As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txtCargo As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_lblEmailEmpresarial As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblTelfEmpresarial As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblDepartamento As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblGrado As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblCargo As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblFIngreso As System.Windows.Forms.Label
    Friend WithEvents EUsuario_DataGrid As System.Windows.Forms.DataGridView
    Friend WithEvents EUsuario_txtNumRegistro As System.Windows.Forms.TextBox
    Friend WithEvents EUsuario_txtDocumento As System.Windows.Forms.TextBox
    Friend WithEvents EUsuario_btnBuscar As System.Windows.Forms.Button
    Friend WithEvents EUsuario_lblNumRegistro As System.Windows.Forms.Label
    Friend WithEvents EUsuario_lblDocumento As System.Windows.Forms.Label
    Friend WithEvents EUsuario_btnEliminar As System.Windows.Forms.Button
    Friend WithEvents AddUser_picAgregarUsuario As System.Windows.Forms.Button
    Friend WithEvents ModUser_picModificarFichas As System.Windows.Forms.Button
    Friend WithEvents picEliminarUser As System.Windows.Forms.Button
    Friend WithEvents BuscarUser_BuscarEmpleados As System.Windows.Forms.Button
    Friend WithEvents pnlBotones As System.Windows.Forms.Panel
    Friend WithEvents btnListar As System.Windows.Forms.Button
    Friend WithEvents btnEliminar As System.Windows.Forms.Button
    Friend WithEvents btnAgregar As System.Windows.Forms.Button
    Friend WithEvents AddUser_rbAdmin As System.Windows.Forms.RadioButton
    Friend WithEvents AddUser_rbUsuario As System.Windows.Forms.RadioButton
    Friend WithEvents AddUser_btnAgregar As System.Windows.Forms.Button
    Friend WithEvents TaxDataSet As TAX.taxDataSet
    Friend WithEvents PersonalBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PersonalTableAdapter As TAX.taxDataSetTableAdapters.personalTableAdapter
    Friend WithEvents PersonaidDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DocDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NombreDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ApellidoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RolDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CargoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PersonalBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents TaxDataSetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents AddUser_cbSexo As System.Windows.Forms.ComboBox
    Friend WithEvents AddUser_dateFIngreso As System.Windows.Forms.DateTimePicker
    Friend WithEvents AddUser_dateFNacimiento As System.Windows.Forms.DateTimePicker
    Friend WithEvents AddUser_cbEstCivil As System.Windows.Forms.ComboBox
    Friend WithEvents AddUser_txtDirCalle As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txtDirNumero As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ListUser_pnlTitulo As System.Windows.Forms.Panel
    Friend WithEvents ListUser_pnlBuscPorRegistro As System.Windows.Forms.Panel
    Friend WithEvents ListUser_pnlBuscPorNombre As System.Windows.Forms.Panel
    Friend WithEvents ListUser_pnlBuscPorDocumento As System.Windows.Forms.Panel
    Friend WithEvents ListUser_lblBuscPorDocumento As System.Windows.Forms.Label
    Friend WithEvents ListUser_lblBuscPorRegistro As System.Windows.Forms.Label
    Friend WithEvents ListUser_lblBuscPorNombre As System.Windows.Forms.Label
    Friend WithEvents ListUser_txtBuscPorRegistro As System.Windows.Forms.TextBox
    Friend WithEvents ListUser_txtBuscPorNombre As System.Windows.Forms.TextBox
    Friend WithEvents ListUser_txtBuscPorDocumento As System.Windows.Forms.TextBox
    Friend WithEvents ListUser_btnBuscPorRegistro As System.Windows.Forms.Button
    Friend WithEvents ListUser_btnBuscPorNombre As System.Windows.Forms.Button
    Friend WithEvents ListUser_btnBuscPorDocumento As System.Windows.Forms.Button
    Friend WithEvents ListUser_btnVer As System.Windows.Forms.Button
    Friend WithEvents ListUser_DataGrid As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ListUser_txtBuscPorNombre_Apellido As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txt2apellido As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_txt2Nombre As System.Windows.Forms.TextBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents pnlBotonesGris As System.Windows.Forms.Panel
    Friend WithEvents pnlSelection As System.Windows.Forms.Panel
    Friend WithEvents ADD_ObligDocumento As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligTipoUsuario As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligEmailEmpr As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligTelfEmpresarial As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligDepartamento As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligGrado As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligCargo As System.Windows.Forms.Label
    Friend WithEvents ADD_FIngreso As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligEmail As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligEstCivil As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligDirNumero As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligDirCalle As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligFNac As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligSexo As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligApellido As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligNombre As System.Windows.Forms.Label
    Friend WithEvents AddUser_cbGrado As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents AddUser_pbFoto As System.Windows.Forms.PictureBox
End Class
