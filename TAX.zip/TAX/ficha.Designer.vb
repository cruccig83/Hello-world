﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ficha
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ficha))
        Me.cmdinicio = New System.Windows.Forms.Button
        Me.cmdhistorialaboral = New System.Windows.Forms.Button
        Me.cmdrecibo = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.cmdhistorialrecibos = New System.Windows.Forms.Button
        Me.txtdocumento = New System.Windows.Forms.TextBox
        Me.txtnombre = New System.Windows.Forms.TextBox
        Me.txtapellido = New System.Windows.Forms.TextBox
        Me.txtcontraseña = New System.Windows.Forms.TextBox
        Me.txtsexo = New System.Windows.Forms.TextBox
        Me.txtnacimiento = New System.Windows.Forms.TextBox
        Me.txtdireccion = New System.Windows.Forms.TextBox
        Me.txtestadocivil = New System.Windows.Forms.TextBox
        Me.txtemail = New System.Windows.Forms.TextBox
        Me.txthijos = New System.Windows.Forms.TextBox
        Me.txtcelular = New System.Windows.Forms.TextBox
        Me.txttelefono = New System.Windows.Forms.TextBox
        Me.cmdayuda = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cmdinicio
        '
        Me.cmdinicio.BackColor = System.Drawing.Color.Transparent
        Me.cmdinicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdinicio.Location = New System.Drawing.Point(23, 152)
        Me.cmdinicio.Name = "cmdinicio"
        Me.cmdinicio.Size = New System.Drawing.Size(116, 36)
        Me.cmdinicio.TabIndex = 0
        Me.cmdinicio.UseVisualStyleBackColor = False
        '
        'cmdhistorialaboral
        '
        Me.cmdhistorialaboral.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialaboral.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialaboral.Location = New System.Drawing.Point(23, 300)
        Me.cmdhistorialaboral.Name = "cmdhistorialaboral"
        Me.cmdhistorialaboral.Size = New System.Drawing.Size(116, 36)
        Me.cmdhistorialaboral.TabIndex = 1
        Me.cmdhistorialaboral.UseVisualStyleBackColor = False
        '
        'cmdrecibo
        '
        Me.cmdrecibo.BackColor = System.Drawing.Color.Transparent
        Me.cmdrecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdrecibo.Location = New System.Drawing.Point(23, 249)
        Me.cmdrecibo.Name = "cmdrecibo"
        Me.cmdrecibo.Size = New System.Drawing.Size(116, 36)
        Me.cmdrecibo.TabIndex = 2
        Me.cmdrecibo.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Transparent
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(231, 169)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(64, 36)
        Me.Button3.TabIndex = 3
        Me.Button3.UseVisualStyleBackColor = False
        '
        'cmdhistorialrecibos
        '
        Me.cmdhistorialrecibos.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialrecibos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialrecibos.Location = New System.Drawing.Point(24, 351)
        Me.cmdhistorialrecibos.Name = "cmdhistorialrecibos"
        Me.cmdhistorialrecibos.Size = New System.Drawing.Size(116, 36)
        Me.cmdhistorialrecibos.TabIndex = 4
        Me.cmdhistorialrecibos.UseVisualStyleBackColor = False
        '
        'txtdocumento
        '
        Me.txtdocumento.Location = New System.Drawing.Point(242, 260)
        Me.txtdocumento.Multiline = True
        Me.txtdocumento.Name = "txtdocumento"
        Me.txtdocumento.Size = New System.Drawing.Size(174, 17)
        Me.txtdocumento.TabIndex = 5
        '
        'txtnombre
        '
        Me.txtnombre.Location = New System.Drawing.Point(242, 282)
        Me.txtnombre.Multiline = True
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(174, 18)
        Me.txtnombre.TabIndex = 6
        '
        'txtapellido
        '
        Me.txtapellido.Location = New System.Drawing.Point(242, 306)
        Me.txtapellido.Multiline = True
        Me.txtapellido.Name = "txtapellido"
        Me.txtapellido.Size = New System.Drawing.Size(174, 18)
        Me.txtapellido.TabIndex = 7
        '
        'txtcontraseña
        '
        Me.txtcontraseña.Location = New System.Drawing.Point(249, 330)
        Me.txtcontraseña.Multiline = True
        Me.txtcontraseña.Name = "txtcontraseña"
        Me.txtcontraseña.Size = New System.Drawing.Size(174, 17)
        Me.txtcontraseña.TabIndex = 8
        '
        'txtsexo
        '
        Me.txtsexo.Location = New System.Drawing.Point(231, 353)
        Me.txtsexo.Multiline = True
        Me.txtsexo.Name = "txtsexo"
        Me.txtsexo.Size = New System.Drawing.Size(174, 16)
        Me.txtsexo.TabIndex = 9
        '
        'txtnacimiento
        '
        Me.txtnacimiento.Location = New System.Drawing.Point(280, 381)
        Me.txtnacimiento.Multiline = True
        Me.txtnacimiento.Name = "txtnacimiento"
        Me.txtnacimiento.Size = New System.Drawing.Size(174, 16)
        Me.txtnacimiento.TabIndex = 10
        '
        'txtdireccion
        '
        Me.txtdireccion.Location = New System.Drawing.Point(240, 407)
        Me.txtdireccion.Multiline = True
        Me.txtdireccion.Name = "txtdireccion"
        Me.txtdireccion.Size = New System.Drawing.Size(174, 16)
        Me.txtdireccion.TabIndex = 11
        '
        'txtestadocivil
        '
        Me.txtestadocivil.Location = New System.Drawing.Point(249, 429)
        Me.txtestadocivil.Multiline = True
        Me.txtestadocivil.Name = "txtestadocivil"
        Me.txtestadocivil.Size = New System.Drawing.Size(174, 16)
        Me.txtestadocivil.TabIndex = 12
        '
        'txtemail
        '
        Me.txtemail.Location = New System.Drawing.Point(229, 453)
        Me.txtemail.Multiline = True
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(174, 16)
        Me.txtemail.TabIndex = 13
        '
        'txthijos
        '
        Me.txthijos.Location = New System.Drawing.Point(533, 260)
        Me.txthijos.Multiline = True
        Me.txthijos.Name = "txthijos"
        Me.txthijos.Size = New System.Drawing.Size(174, 16)
        Me.txthijos.TabIndex = 14
        '
        'txtcelular
        '
        Me.txtcelular.Location = New System.Drawing.Point(568, 282)
        Me.txtcelular.Multiline = True
        Me.txtcelular.Name = "txtcelular"
        Me.txtcelular.Size = New System.Drawing.Size(174, 16)
        Me.txtcelular.TabIndex = 15
        '
        'txttelefono
        '
        Me.txttelefono.Location = New System.Drawing.Point(556, 308)
        Me.txttelefono.Multiline = True
        Me.txttelefono.Name = "txttelefono"
        Me.txttelefono.Size = New System.Drawing.Size(174, 16)
        Me.txttelefono.TabIndex = 16
        '
        'cmdayuda
        '
        Me.cmdayuda.BackColor = System.Drawing.Color.Transparent
        Me.cmdayuda.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdayuda.Location = New System.Drawing.Point(649, 70)
        Me.cmdayuda.Name = "cmdayuda"
        Me.cmdayuda.Size = New System.Drawing.Size(93, 30)
        Me.cmdayuda.TabIndex = 79
        Me.cmdayuda.UseVisualStyleBackColor = False
        '
        'ficha
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(775, 564)
        Me.Controls.Add(Me.cmdayuda)
        Me.Controls.Add(Me.txttelefono)
        Me.Controls.Add(Me.txtcelular)
        Me.Controls.Add(Me.txthijos)
        Me.Controls.Add(Me.txtemail)
        Me.Controls.Add(Me.txtestadocivil)
        Me.Controls.Add(Me.txtdireccion)
        Me.Controls.Add(Me.txtnacimiento)
        Me.Controls.Add(Me.txtsexo)
        Me.Controls.Add(Me.txtcontraseña)
        Me.Controls.Add(Me.txtapellido)
        Me.Controls.Add(Me.txtnombre)
        Me.Controls.Add(Me.txtdocumento)
        Me.Controls.Add(Me.cmdhistorialrecibos)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.cmdrecibo)
        Me.Controls.Add(Me.cmdhistorialaboral)
        Me.Controls.Add(Me.cmdinicio)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ficha"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdinicio As System.Windows.Forms.Button
    Friend WithEvents cmdhistorialaboral As System.Windows.Forms.Button
    Friend WithEvents cmdrecibo As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents cmdhistorialrecibos As System.Windows.Forms.Button
    Friend WithEvents txtdocumento As System.Windows.Forms.TextBox
    Friend WithEvents txtnombre As System.Windows.Forms.TextBox
    Friend WithEvents txtapellido As System.Windows.Forms.TextBox
    Friend WithEvents txtcontraseña As System.Windows.Forms.TextBox
    Friend WithEvents txtsexo As System.Windows.Forms.TextBox
    Friend WithEvents txtnacimiento As System.Windows.Forms.TextBox
    Friend WithEvents txtdireccion As System.Windows.Forms.TextBox
    Friend WithEvents txtestadocivil As System.Windows.Forms.TextBox
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txthijos As System.Windows.Forms.TextBox
    Friend WithEvents txtcelular As System.Windows.Forms.TextBox
    Friend WithEvents txttelefono As System.Windows.Forms.TextBox
    Friend WithEvents cmdayuda As System.Windows.Forms.Button
End Class
