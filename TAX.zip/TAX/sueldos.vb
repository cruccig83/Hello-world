﻿Public Class sueldos

    Private Sub cmdinicio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdinicio.Click
        inicioadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdficha.Click
        ficharoja.Show()
        Me.Close()

    End Sub

    Private Sub cmdrecibo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdrecibo.Click
        mireciboadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdempleados_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdempleados.Click
        empleados.Show()
        Me.Close()
    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub cmdayuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdayuda.Click
        MsgBox("En Progreso")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdliquidar.Click

        If Not (IsNumeric(txtcedula.Text)) Then
            MsgBox("Cedula: Solo se admiten numeros")
            txtcedula.Text = ""
            txtcedula.Focus()
        End If

        If Not (IsNumeric(txthorasextras.Text)) Then
            MsgBox("Horas Extras: Solo se admiten numeros")
            txthorasextras.Text = ""
            txthorasextras.Focus()
        End If


        If Not (IsNumeric(txtnocturnas.Text)) Then
            MsgBox("Horas Nocturnas: Solo se admiten numeros")
            txtnocturnas.Text = ""
            txtnocturnas.Focus()
        End If


        If Not (IsNumeric(txthorasextras.Text)) Then
            MsgBox("Horas Extras: Solo se admiten numeros")
            txthorasextras.Text = ""
            txthorasextras.Focus()
        End If


        If Not (IsNumeric(txtferiados.Text)) Then
            MsgBox("Feriados Pagos: Solo se admiten numeros")
            txtferiados.Text = ""
            txtferiados.Focus()
        End If


        If Not (IsNumeric(txtaguinaldos.Text)) Then
            MsgBox("Aguinaldo: Solo se admiten numeros")
            txtaguinaldos.Text = ""
            txtaguinaldos.Focus()
        End If


        If Not (IsNumeric(txttickets.Text)) Then
            MsgBox("Tickets: Solo se admiten numeros")
            txttickets.Text = ""
            txttickets.Focus()
        End If

        If Not (IsNumeric(txtlicencia.Text)) Then
            MsgBox("Licencia: Solo se admiten numeros")
            txtlicencia.Text = ""
            txtlicencia.Focus()
        End If


        If Not (IsNumeric(txtfaltas.Text)) Then
            MsgBox("Faltas: Solo se admiten numeros")
            txtfaltas.Text = ""
            txtfaltas.Focus()
        End If


        If Not (IsNumeric(txtpresentismo.Text)) Then
            MsgBox("Presentismo: Solo se admiten numeros")
            txtpresentismo.Text = ""
            txtpresentismo.Focus()
        End If

    End Sub
End Class