﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ficharoja
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ficharoja))
        Me.cmdorganizacion = New System.Windows.Forms.Button
        Me.cmdhistorialrecibos = New System.Windows.Forms.Button
        Me.cmdhistorialaboral = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.cmdrecibo = New System.Windows.Forms.Button
        Me.cmdempleados = New System.Windows.Forms.Button
        Me.cmdliquidar = New System.Windows.Forms.Button
        Me.txtcargo = New System.Windows.Forms.TextBox
        Me.txtpuesto = New System.Windows.Forms.TextBox
        Me.txthijos = New System.Windows.Forms.TextBox
        Me.txtemail = New System.Windows.Forms.TextBox
        Me.txtestadocivil = New System.Windows.Forms.TextBox
        Me.txtdireccion = New System.Windows.Forms.TextBox
        Me.txtnacimiento = New System.Windows.Forms.TextBox
        Me.txtsexo = New System.Windows.Forms.TextBox
        Me.txtcontraseña = New System.Windows.Forms.TextBox
        Me.txtapellido = New System.Windows.Forms.TextBox
        Me.txtnombre = New System.Windows.Forms.TextBox
        Me.txtdocumento = New System.Windows.Forms.TextBox
        Me.txttelefono = New System.Windows.Forms.TextBox
        Me.txtcelular = New System.Windows.Forms.TextBox
        Me.cmdayuda = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cmdorganizacion
        '
        Me.cmdorganizacion.BackColor = System.Drawing.Color.Transparent
        Me.cmdorganizacion.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdorganizacion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdorganizacion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdorganizacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdorganizacion.Location = New System.Drawing.Point(361, 150)
        Me.cmdorganizacion.Name = "cmdorganizacion"
        Me.cmdorganizacion.Size = New System.Drawing.Size(73, 50)
        Me.cmdorganizacion.TabIndex = 2
        Me.cmdorganizacion.UseVisualStyleBackColor = False
        '
        'cmdhistorialrecibos
        '
        Me.cmdhistorialrecibos.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialrecibos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialrecibos.Location = New System.Drawing.Point(291, 150)
        Me.cmdhistorialrecibos.Name = "cmdhistorialrecibos"
        Me.cmdhistorialrecibos.Size = New System.Drawing.Size(68, 50)
        Me.cmdhistorialrecibos.TabIndex = 3
        Me.cmdhistorialrecibos.UseVisualStyleBackColor = False
        '
        'cmdhistorialaboral
        '
        Me.cmdhistorialaboral.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialaboral.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialaboral.Location = New System.Drawing.Point(225, 150)
        Me.cmdhistorialaboral.Name = "cmdhistorialaboral"
        Me.cmdhistorialaboral.Size = New System.Drawing.Size(60, 50)
        Me.cmdhistorialaboral.TabIndex = 4
        Me.cmdhistorialaboral.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Transparent
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(12, 143)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(123, 30)
        Me.Button3.TabIndex = 5
        Me.Button3.UseVisualStyleBackColor = False
        '
        'cmdrecibo
        '
        Me.cmdrecibo.BackColor = System.Drawing.Color.Transparent
        Me.cmdrecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdrecibo.Location = New System.Drawing.Point(333, 78)
        Me.cmdrecibo.Name = "cmdrecibo"
        Me.cmdrecibo.Size = New System.Drawing.Size(123, 31)
        Me.cmdrecibo.TabIndex = 6
        Me.cmdrecibo.UseVisualStyleBackColor = False
        '
        'cmdempleados
        '
        Me.cmdempleados.BackColor = System.Drawing.Color.Transparent
        Me.cmdempleados.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdempleados.Location = New System.Drawing.Point(12, 261)
        Me.cmdempleados.Name = "cmdempleados"
        Me.cmdempleados.Size = New System.Drawing.Size(123, 31)
        Me.cmdempleados.TabIndex = 7
        Me.cmdempleados.UseVisualStyleBackColor = False
        '
        'cmdliquidar
        '
        Me.cmdliquidar.BackColor = System.Drawing.Color.Transparent
        Me.cmdliquidar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdliquidar.Location = New System.Drawing.Point(9, 303)
        Me.cmdliquidar.Name = "cmdliquidar"
        Me.cmdliquidar.Size = New System.Drawing.Size(123, 31)
        Me.cmdliquidar.TabIndex = 8
        Me.cmdliquidar.UseVisualStyleBackColor = False
        '
        'txtcargo
        '
        Me.txtcargo.Location = New System.Drawing.Point(549, 307)
        Me.txtcargo.Multiline = True
        Me.txtcargo.Name = "txtcargo"
        Me.txtcargo.Size = New System.Drawing.Size(174, 16)
        Me.txtcargo.TabIndex = 28
        '
        'txtpuesto
        '
        Me.txtpuesto.Location = New System.Drawing.Point(561, 281)
        Me.txtpuesto.Multiline = True
        Me.txtpuesto.Name = "txtpuesto"
        Me.txtpuesto.Size = New System.Drawing.Size(174, 16)
        Me.txtpuesto.TabIndex = 27
        '
        'txthijos
        '
        Me.txthijos.Location = New System.Drawing.Point(526, 259)
        Me.txthijos.Multiline = True
        Me.txthijos.Name = "txthijos"
        Me.txthijos.Size = New System.Drawing.Size(174, 16)
        Me.txthijos.TabIndex = 26
        '
        'txtemail
        '
        Me.txtemail.Location = New System.Drawing.Point(222, 452)
        Me.txtemail.Multiline = True
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(174, 16)
        Me.txtemail.TabIndex = 25
        '
        'txtestadocivil
        '
        Me.txtestadocivil.Location = New System.Drawing.Point(242, 428)
        Me.txtestadocivil.Multiline = True
        Me.txtestadocivil.Name = "txtestadocivil"
        Me.txtestadocivil.Size = New System.Drawing.Size(174, 16)
        Me.txtestadocivil.TabIndex = 24
        '
        'txtdireccion
        '
        Me.txtdireccion.Location = New System.Drawing.Point(233, 406)
        Me.txtdireccion.Multiline = True
        Me.txtdireccion.Name = "txtdireccion"
        Me.txtdireccion.Size = New System.Drawing.Size(174, 16)
        Me.txtdireccion.TabIndex = 23
        '
        'txtnacimiento
        '
        Me.txtnacimiento.Location = New System.Drawing.Point(273, 380)
        Me.txtnacimiento.Multiline = True
        Me.txtnacimiento.Name = "txtnacimiento"
        Me.txtnacimiento.Size = New System.Drawing.Size(174, 16)
        Me.txtnacimiento.TabIndex = 22
        '
        'txtsexo
        '
        Me.txtsexo.Location = New System.Drawing.Point(224, 352)
        Me.txtsexo.Multiline = True
        Me.txtsexo.Name = "txtsexo"
        Me.txtsexo.Size = New System.Drawing.Size(174, 16)
        Me.txtsexo.TabIndex = 21
        '
        'txtcontraseña
        '
        Me.txtcontraseña.Location = New System.Drawing.Point(242, 329)
        Me.txtcontraseña.Multiline = True
        Me.txtcontraseña.Name = "txtcontraseña"
        Me.txtcontraseña.Size = New System.Drawing.Size(174, 17)
        Me.txtcontraseña.TabIndex = 20
        '
        'txtapellido
        '
        Me.txtapellido.Location = New System.Drawing.Point(235, 305)
        Me.txtapellido.Multiline = True
        Me.txtapellido.Name = "txtapellido"
        Me.txtapellido.Size = New System.Drawing.Size(174, 18)
        Me.txtapellido.TabIndex = 19
        '
        'txtnombre
        '
        Me.txtnombre.Location = New System.Drawing.Point(235, 281)
        Me.txtnombre.Multiline = True
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(174, 18)
        Me.txtnombre.TabIndex = 18
        '
        'txtdocumento
        '
        Me.txtdocumento.Location = New System.Drawing.Point(235, 259)
        Me.txtdocumento.Multiline = True
        Me.txtdocumento.Name = "txtdocumento"
        Me.txtdocumento.Size = New System.Drawing.Size(174, 17)
        Me.txtdocumento.TabIndex = 17
        '
        'txttelefono
        '
        Me.txttelefono.Location = New System.Drawing.Point(552, 355)
        Me.txttelefono.Multiline = True
        Me.txttelefono.Name = "txttelefono"
        Me.txttelefono.Size = New System.Drawing.Size(174, 16)
        Me.txttelefono.TabIndex = 30
        '
        'txtcelular
        '
        Me.txtcelular.Location = New System.Drawing.Point(564, 329)
        Me.txtcelular.Multiline = True
        Me.txtcelular.Name = "txtcelular"
        Me.txtcelular.Size = New System.Drawing.Size(174, 16)
        Me.txtcelular.TabIndex = 29
        '
        'cmdayuda
        '
        Me.cmdayuda.BackColor = System.Drawing.Color.Transparent
        Me.cmdayuda.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdayuda.Location = New System.Drawing.Point(656, 69)
        Me.cmdayuda.Name = "cmdayuda"
        Me.cmdayuda.Size = New System.Drawing.Size(93, 30)
        Me.cmdayuda.TabIndex = 79
        Me.cmdayuda.UseVisualStyleBackColor = False
        '
        'ficharoja
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(773, 578)
        Me.Controls.Add(Me.cmdayuda)
        Me.Controls.Add(Me.txttelefono)
        Me.Controls.Add(Me.txtcelular)
        Me.Controls.Add(Me.txtcargo)
        Me.Controls.Add(Me.txtpuesto)
        Me.Controls.Add(Me.txthijos)
        Me.Controls.Add(Me.txtemail)
        Me.Controls.Add(Me.txtestadocivil)
        Me.Controls.Add(Me.txtdireccion)
        Me.Controls.Add(Me.txtnacimiento)
        Me.Controls.Add(Me.txtsexo)
        Me.Controls.Add(Me.txtcontraseña)
        Me.Controls.Add(Me.txtapellido)
        Me.Controls.Add(Me.txtnombre)
        Me.Controls.Add(Me.txtdocumento)
        Me.Controls.Add(Me.cmdliquidar)
        Me.Controls.Add(Me.cmdempleados)
        Me.Controls.Add(Me.cmdrecibo)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.cmdhistorialaboral)
        Me.Controls.Add(Me.cmdhistorialrecibos)
        Me.Controls.Add(Me.cmdorganizacion)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ficharoja"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdorganizacion As System.Windows.Forms.Button
    Friend WithEvents cmdhistorialrecibos As System.Windows.Forms.Button
    Friend WithEvents cmdhistorialaboral As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents cmdrecibo As System.Windows.Forms.Button
    Friend WithEvents cmdempleados As System.Windows.Forms.Button
    Friend WithEvents cmdliquidar As System.Windows.Forms.Button
    Friend WithEvents txtcargo As System.Windows.Forms.TextBox
    Friend WithEvents txtpuesto As System.Windows.Forms.TextBox
    Friend WithEvents txthijos As System.Windows.Forms.TextBox
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtestadocivil As System.Windows.Forms.TextBox
    Friend WithEvents txtdireccion As System.Windows.Forms.TextBox
    Friend WithEvents txtnacimiento As System.Windows.Forms.TextBox
    Friend WithEvents txtsexo As System.Windows.Forms.TextBox
    Friend WithEvents txtcontraseña As System.Windows.Forms.TextBox
    Friend WithEvents txtapellido As System.Windows.Forms.TextBox
    Friend WithEvents txtnombre As System.Windows.Forms.TextBox
    Friend WithEvents txtdocumento As System.Windows.Forms.TextBox
    Friend WithEvents txttelefono As System.Windows.Forms.TextBox
    Friend WithEvents txtcelular As System.Windows.Forms.TextBox
    Friend WithEvents cmdayuda As System.Windows.Forms.Button
End Class
