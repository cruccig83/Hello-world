﻿Imports MySql.Data.MySqlClient
Public Class buscar_usuarios

    Private Sub AddUser_txtEmail_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub List_btnBuscar_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles List_btnBuscar.Click
        Me.ListUser_btnModificar.Visible = True
        Me.ListUser_btnEliminar.Visible = True

        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE doc = '" & List_txtBuscar.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ModUser_txtDocumento.Text = rdr.Item("doc").ToString
                Me.ModUser_txtNombre.Text = rdr.Item("nombre").ToString
                Me.ModUser_txt2Nombre.Text = rdr.Item("2nombre").ToString
                Me.ModUser_txtNombreCompleto.Text = rdr.Item("nombre").ToString + " " + rdr.Item("2nombre").ToString
                Me.ModUser_txtApellido.Text = rdr.Item("apellido").ToString
                Me.ModUser_txt2apellido.Text = rdr.Item("2apellido").ToString
                Me.ModUser_txtApellidosCompleto.Text = rdr.Item("apellido").ToString + " " + rdr.Item("2apellido").ToString
                Me.ModUser_txtContraseña.Text = rdr.Item("passwd").ToString
                Me.ModUser_cbSexo.Text = rdr.Item("sexo").ToString
                Me.ModUser_dateFNacimiento.Text = rdr.Item("f_nac").ToString
                Me.ModUser_txtDirCalle.Text = rdr.Item("calle").ToString
                Me.ModUser_txtDirNumero.Text = rdr.Item("numero").ToString
                Me.ModUser_txtDireccionCompleta.Text = rdr.Item("calle").ToString + " " + rdr.Item("numero").ToString
                Me.ModUser_cbEstCivil.Text = rdr.Item("estado_civil").ToString
                Me.ModUser_txtEmail.Text = rdr.Item("email").ToString
                Me.ModUser_dateFIngreso.Text = rdr.Item("f_ingreso").ToString
                Me.ModUser_txtCargo.Text = rdr.Item("cargo").ToString
                Me.ModUser_cbGrado.Text = rdr.Item("grado").ToString
                Me.ModUser_txtDepartamento.Text = rdr.Item("dpto").ToString
                Me.ModUser_txtTlfEmpresarial.Text = rdr.Item("tlf_empr").ToString
                Me.ModUser_txtMailEmpresarial.Text = rdr.Item("email_empr").ToString

                If rdr.Item("rol").ToString = 1 Then
                    Me.ListUser_rbAdmin.Checked = True
                ElseIf rdr.Item("rol").ToString = 2 Then
                    Me.ListUser_rbUsuario.Checked = True
                End If

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub List_txtBuscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles List_txtBuscar.Click
        List_txtBuscar.ForeColor = Color.Black
        List_txtBuscar.Clear()
    End Sub

    Private Sub ListUser_btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListUser_btnModificar.Click
        Me.ListUser_btnModificar.Visible = False
        Me.ListUser_btnEliminar.Visible = False
        Me.ListUser_btnGuardar.Visible = True
        Me.ListUser_btnCancelar.Visible = True

        Me.ModUser_txtDocumento.Enabled = True
        Me.ModUser_txtNombreCompleto.Visible = False
        Me.ModUser_txtNombre.Visible = True
        Me.ModUser_txt2Nombre.Visible = True
        Me.ModUser_txtApellidosCompleto.Visible = False
        Me.ModUser_txtApellido.Visible = True
        Me.ModUser_txt2apellido.Visible = True
        Me.ModUser_cbSexo.Enabled = True
        Me.ModUser_dateFNacimiento.Enabled = True
        Me.ModUser_txtDirCalle.Visible = True
        Me.ModUser_txtDirNumero.Visible = True
        Me.ModUser_txtDireccionCompleta.Visible = False
        Me.ModUser_cbEstCivil.Enabled = True
        Me.ModUser_txtEmail.Enabled = True
        Me.ModUser_dateFIngreso.Enabled = True
        Me.ModUser_txtCargo.Enabled = True
        Me.ModUser_cbGrado.Enabled = True
        Me.ModUser_txtDepartamento.Enabled = True
        Me.ModUser_txtTlfEmpresarial.Enabled = True
        Me.ModUser_txtMailEmpresarial.Enabled = True
    End Sub

    Private Sub ListUser_btnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListUser_btnGuardar.Click
        Me.ListUser_btnModificar.Visible = True
        Me.ListUser_btnEliminar.Visible = True
        Me.ListUser_btnGuardar.Visible = False
        Me.ListUser_btnCancelar.Visible = False

        Me.ModUser_txtDocumento.Enabled = False
        Me.ModUser_txtNombreCompleto.Visible = True
        Me.ModUser_txtNombre.Visible = False
        Me.ModUser_txt2Nombre.Visible = False
        Me.ModUser_txtApellidosCompleto.Visible = True
        Me.ModUser_txtApellido.Visible = False
        Me.ModUser_txt2apellido.Visible = False
        Me.ModUser_cbSexo.Enabled = False
        Me.ModUser_dateFNacimiento.Enabled = False
        Me.ModUser_txtDireccionCompleta.Enabled = False
        Me.ModUser_cbEstCivil.Enabled = False
        Me.ModUser_txtEmail.Enabled = False
        Me.ModUser_dateFIngreso.Enabled = False
        Me.ModUser_txtCargo.Enabled = False
        Me.ModUser_cbGrado.Enabled = False
        Me.ModUser_txtDepartamento.Enabled = False
        Me.ModUser_txtTlfEmpresarial.Enabled = False
        Me.ModUser_txtMailEmpresarial.Enabled = False

        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "UPDATE personal SET doc = '" & ModUser_txtDocumento.Text & "', nombre = '" & ModUser_txtNombre.Text & "', apellido = '" & ModUser_txtApellido.Text & "', f_nac = '" & ModUser_dateFNacimiento.Text & "', calle = '" & ModUser_txtDirCalle.Text & "', numero = '" & ModUser_txtDirNumero.Text & "', estado_civil = '" & ModUser_cbEstCivil.Text & "', sexo = '" & ModUser_cbSexo.Text & "', email = '" & ModUser_txtEmail.Text & "', f_ingreso = '" & ModUser_dateFIngreso.Text & "', cargo = '" & ModUser_txtCargo.Text & "', grado = '" & ModUser_cbGrado.Text & "', dpto = '" & ModUser_txtDepartamento.Text & "', email_empr = '" & ModUser_txtMailEmpresarial.Text & "', tlf_empr = '" & ModUser_txtTlfEmpresarial.Text & "'  WHERE doc = " & List_txtBuscar.Text & " "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub List_btnLupa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles List_btnLupa.Click
        Buscar.Show()
    End Sub

    Private Sub buscar_usuarios_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class