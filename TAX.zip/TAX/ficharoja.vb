﻿Public Class ficharoja

    Private Sub cmdficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdorganizacion.Click
        organizacionadmin.Show()
        Me.Close()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        inicioadmin.Show()
        Me.Close()
    End Sub

    Private Sub cmdrecibo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdrecibo.Click
        mireciboadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdempleados_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdempleados.Click
        empleados.Show()
        Me.Close()

    End Sub

    Private Sub cmdliquidar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdliquidar.Click
        sueldos.Show()
        Me.Close()

    End Sub

    Private Sub cmdhistorialrecibos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhistorialrecibos.Click
        historialrecibos_admin.Show()
        Me.Close()

    End Sub

    Private Sub cmdhistorialaboral_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhistorialaboral.Click
        historialaboral_admin.Show()
        Me.Close()

    End Sub

    Private Sub ficharoja_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub cmdayuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdayuda.Click
        MsgBox("En Progreso")
    End Sub
End Class