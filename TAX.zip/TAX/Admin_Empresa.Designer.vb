﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Empresa
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Empresa))
        Me.pnlDer = New System.Windows.Forms.Panel
        Me.pnlSup = New System.Windows.Forms.Panel
        Me.pnlIzq = New System.Windows.Forms.Panel
        Me.pnlInf = New System.Windows.Forms.Panel
        Me.pnlCentral = New System.Windows.Forms.Panel
        Me.pnlTitulo = New System.Windows.Forms.Panel
        Me.pnl_seleccionado = New System.Windows.Forms.Panel
        Me.pnlGris = New System.Windows.Forms.Panel
        Me.TabControlEmpresaGrados = New System.Windows.Forms.TabControl
        Me.EmpGra_TabPageEmpresa = New System.Windows.Forms.TabPage
        Me.txtDirNumero = New System.Windows.Forms.TextBox
        Me.lblRUT = New System.Windows.Forms.Label
        Me.txtSitioWeb = New System.Windows.Forms.TextBox
        Me.txtRUT = New System.Windows.Forms.TextBox
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.lblRazonSocial = New System.Windows.Forms.Label
        Me.txtNTelefono = New System.Windows.Forms.TextBox
        Me.lblNFantasia = New System.Windows.Forms.Label
        Me.txtDirCalle = New System.Windows.Forms.TextBox
        Me.txtBSE = New System.Windows.Forms.TextBox
        Me.lblBPS = New System.Windows.Forms.Label
        Me.txtBPS = New System.Windows.Forms.TextBox
        Me.lblBSE = New System.Windows.Forms.Label
        Me.lblDireccion = New System.Windows.Forms.Label
        Me.txtNFantasia = New System.Windows.Forms.TextBox
        Me.lblNTelefono = New System.Windows.Forms.Label
        Me.txtRazonSocial = New System.Windows.Forms.TextBox
        Me.lblEmail = New System.Windows.Forms.Label
        Me.EmpGra_TabPageGrados = New System.Windows.Forms.TabPage
        Me.GRA_pnlBotones = New System.Windows.Forms.Panel
        Me.GRA_pnlSeleccionado = New System.Windows.Forms.Panel
        Me.GRA_pnlGris = New System.Windows.Forms.Panel
        Me.GRA_btnModificar = New System.Windows.Forms.Button
        Me.GRA_btnVer = New System.Windows.Forms.Button
        Me.GRA_TabControlVerMod = New System.Windows.Forms.TabControl
        Me.GRA_TabPageVer = New System.Windows.Forms.TabPage
        Me.VerGRA_lblPesos = New System.Windows.Forms.Label
        Me.VerGRA_cbGrado = New System.Windows.Forms.ComboBox
        Me.VerGRA_txtSalario = New System.Windows.Forms.TextBox
        Me.VerGRA_lblSalario = New System.Windows.Forms.Label
        Me.VerGRA_lblGrado = New System.Windows.Forms.Label
        Me.GRA_TabPageModificar = New System.Windows.Forms.TabPage
        Me.ModGRA_lblPesos = New System.Windows.Forms.Label
        Me.ModGRA_cbGrado = New System.Windows.Forms.ComboBox
        Me.ModGRA_txtSalario = New System.Windows.Forms.TextBox
        Me.ModGRA_lblSalario = New System.Windows.Forms.Label
        Me.ModGRA_lblGrado = New System.Windows.Forms.Label
        Me.pnlX = New System.Windows.Forms.Panel
        Me.btnDepartamentos = New System.Windows.Forms.Button
        Me.btnCargos = New System.Windows.Forms.Button
        Me.btnGrados = New System.Windows.Forms.Button
        Me.btnEmpresa = New System.Windows.Forms.Button
        Me.lblEmpresa = New System.Windows.Forms.Button
        Me.VerGRA_lblVerGrados = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.pnlCentral.SuspendLayout()
        Me.pnlTitulo.SuspendLayout()
        Me.TabControlEmpresaGrados.SuspendLayout()
        Me.EmpGra_TabPageEmpresa.SuspendLayout()
        Me.EmpGra_TabPageGrados.SuspendLayout()
        Me.GRA_pnlBotones.SuspendLayout()
        Me.GRA_TabControlVerMod.SuspendLayout()
        Me.GRA_TabPageVer.SuspendLayout()
        Me.GRA_TabPageModificar.SuspendLayout()
        Me.pnlX.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlDer
        '
        Me.pnlDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlDer.Location = New System.Drawing.Point(782, 0)
        Me.pnlDer.Name = "pnlDer"
        Me.pnlDer.Size = New System.Drawing.Size(20, 404)
        Me.pnlDer.TabIndex = 0
        '
        'pnlSup
        '
        Me.pnlSup.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlSup.Location = New System.Drawing.Point(0, 0)
        Me.pnlSup.Name = "pnlSup"
        Me.pnlSup.Size = New System.Drawing.Size(782, 20)
        Me.pnlSup.TabIndex = 1
        '
        'pnlIzq
        '
        Me.pnlIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlIzq.Location = New System.Drawing.Point(0, 20)
        Me.pnlIzq.Name = "pnlIzq"
        Me.pnlIzq.Size = New System.Drawing.Size(20, 384)
        Me.pnlIzq.TabIndex = 2
        '
        'pnlInf
        '
        Me.pnlInf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlInf.Location = New System.Drawing.Point(20, 384)
        Me.pnlInf.Name = "pnlInf"
        Me.pnlInf.Size = New System.Drawing.Size(762, 20)
        Me.pnlInf.TabIndex = 3
        '
        'pnlCentral
        '
        Me.pnlCentral.AutoScroll = True
        Me.pnlCentral.BackColor = System.Drawing.Color.White
        Me.pnlCentral.Controls.Add(Me.pnlTitulo)
        Me.pnlCentral.Controls.Add(Me.TabControlEmpresaGrados)
        Me.pnlCentral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlCentral.Location = New System.Drawing.Point(0, 0)
        Me.pnlCentral.Name = "pnlCentral"
        Me.pnlCentral.Size = New System.Drawing.Size(762, 364)
        Me.pnlCentral.TabIndex = 4
        '
        'pnlTitulo
        '
        Me.pnlTitulo.BackColor = System.Drawing.Color.White
        Me.pnlTitulo.Controls.Add(Me.pnl_seleccionado)
        Me.pnlTitulo.Controls.Add(Me.pnlGris)
        Me.pnlTitulo.Controls.Add(Me.btnDepartamentos)
        Me.pnlTitulo.Controls.Add(Me.btnCargos)
        Me.pnlTitulo.Controls.Add(Me.btnGrados)
        Me.pnlTitulo.Controls.Add(Me.btnEmpresa)
        Me.pnlTitulo.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitulo.Location = New System.Drawing.Point(0, 0)
        Me.pnlTitulo.Name = "pnlTitulo"
        Me.pnlTitulo.Size = New System.Drawing.Size(762, 62)
        Me.pnlTitulo.TabIndex = 5
        '
        'pnl_seleccionado
        '
        Me.pnl_seleccionado.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.pnl_seleccionado.Location = New System.Drawing.Point(0, 59)
        Me.pnl_seleccionado.Name = "pnl_seleccionado"
        Me.pnl_seleccionado.Size = New System.Drawing.Size(124, 3)
        Me.pnl_seleccionado.TabIndex = 5
        '
        'pnlGris
        '
        Me.pnlGris.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.pnlGris.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlGris.Location = New System.Drawing.Point(0, 59)
        Me.pnlGris.Name = "pnlGris"
        Me.pnlGris.Size = New System.Drawing.Size(762, 3)
        Me.pnlGris.TabIndex = 4
        '
        'TabControlEmpresaGrados
        '
        Me.TabControlEmpresaGrados.Controls.Add(Me.EmpGra_TabPageEmpresa)
        Me.TabControlEmpresaGrados.Controls.Add(Me.EmpGra_TabPageGrados)
        Me.TabControlEmpresaGrados.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControlEmpresaGrados.Location = New System.Drawing.Point(0, 0)
        Me.TabControlEmpresaGrados.Name = "TabControlEmpresaGrados"
        Me.TabControlEmpresaGrados.Padding = New System.Drawing.Point(6, 21)
        Me.TabControlEmpresaGrados.SelectedIndex = 0
        Me.TabControlEmpresaGrados.Size = New System.Drawing.Size(762, 364)
        Me.TabControlEmpresaGrados.TabIndex = 47
        '
        'EmpGra_TabPageEmpresa
        '
        Me.EmpGra_TabPageEmpresa.AutoScroll = True
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.lblEmpresa)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.txtDirNumero)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.lblRUT)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.txtSitioWeb)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.txtRUT)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.txtEmail)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.lblRazonSocial)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.txtNTelefono)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.lblNFantasia)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.txtDirCalle)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.txtBSE)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.lblBPS)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.txtBPS)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.lblBSE)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.lblDireccion)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.txtNFantasia)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.lblNTelefono)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.txtRazonSocial)
        Me.EmpGra_TabPageEmpresa.Controls.Add(Me.lblEmail)
        Me.EmpGra_TabPageEmpresa.Location = New System.Drawing.Point(4, 58)
        Me.EmpGra_TabPageEmpresa.Name = "EmpGra_TabPageEmpresa"
        Me.EmpGra_TabPageEmpresa.Padding = New System.Windows.Forms.Padding(3)
        Me.EmpGra_TabPageEmpresa.Size = New System.Drawing.Size(754, 302)
        Me.EmpGra_TabPageEmpresa.TabIndex = 0
        Me.EmpGra_TabPageEmpresa.Text = "EmpGra_TabPageEmpresa"
        Me.EmpGra_TabPageEmpresa.UseVisualStyleBackColor = True
        '
        'txtDirNumero
        '
        Me.txtDirNumero.BackColor = System.Drawing.Color.White
        Me.txtDirNumero.Enabled = False
        Me.txtDirNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDirNumero.Location = New System.Drawing.Point(266, 226)
        Me.txtDirNumero.Name = "txtDirNumero"
        Me.txtDirNumero.ReadOnly = True
        Me.txtDirNumero.Size = New System.Drawing.Size(65, 20)
        Me.txtDirNumero.TabIndex = 90
        '
        'lblRUT
        '
        Me.lblRUT.AutoSize = True
        Me.lblRUT.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRUT.ForeColor = System.Drawing.Color.Black
        Me.lblRUT.Location = New System.Drawing.Point(37, 54)
        Me.lblRUT.Name = "lblRUT"
        Me.lblRUT.Size = New System.Drawing.Size(42, 17)
        Me.lblRUT.TabIndex = 70
        Me.lblRUT.Text = "R.U.T.:"
        '
        'txtSitioWeb
        '
        Me.txtSitioWeb.BackColor = System.Drawing.Color.White
        Me.txtSitioWeb.Enabled = False
        Me.txtSitioWeb.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSitioWeb.Location = New System.Drawing.Point(199, 283)
        Me.txtSitioWeb.Name = "txtSitioWeb"
        Me.txtSitioWeb.ReadOnly = True
        Me.txtSitioWeb.Size = New System.Drawing.Size(132, 20)
        Me.txtSitioWeb.TabIndex = 89
        '
        'txtRUT
        '
        Me.txtRUT.BackColor = System.Drawing.Color.White
        Me.txtRUT.Enabled = False
        Me.txtRUT.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRUT.Location = New System.Drawing.Point(199, 52)
        Me.txtRUT.Name = "txtRUT"
        Me.txtRUT.ReadOnly = True
        Me.txtRUT.Size = New System.Drawing.Size(132, 20)
        Me.txtRUT.TabIndex = 71
        '
        'txtEmail
        '
        Me.txtEmail.BackColor = System.Drawing.Color.White
        Me.txtEmail.Enabled = False
        Me.txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.Location = New System.Drawing.Point(199, 284)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.ReadOnly = True
        Me.txtEmail.Size = New System.Drawing.Size(132, 20)
        Me.txtEmail.TabIndex = 88
        '
        'lblRazonSocial
        '
        Me.lblRazonSocial.AutoSize = True
        Me.lblRazonSocial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRazonSocial.ForeColor = System.Drawing.Color.Black
        Me.lblRazonSocial.Location = New System.Drawing.Point(37, 83)
        Me.lblRazonSocial.Name = "lblRazonSocial"
        Me.lblRazonSocial.Size = New System.Drawing.Size(80, 17)
        Me.lblRazonSocial.TabIndex = 72
        Me.lblRazonSocial.Text = "Razón social:"
        '
        'txtNTelefono
        '
        Me.txtNTelefono.BackColor = System.Drawing.Color.White
        Me.txtNTelefono.Enabled = False
        Me.txtNTelefono.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNTelefono.Location = New System.Drawing.Point(199, 255)
        Me.txtNTelefono.Name = "txtNTelefono"
        Me.txtNTelefono.ReadOnly = True
        Me.txtNTelefono.Size = New System.Drawing.Size(132, 20)
        Me.txtNTelefono.TabIndex = 87
        '
        'lblNFantasia
        '
        Me.lblNFantasia.AutoSize = True
        Me.lblNFantasia.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNFantasia.ForeColor = System.Drawing.Color.Black
        Me.lblNFantasia.Location = New System.Drawing.Point(37, 112)
        Me.lblNFantasia.Name = "lblNFantasia"
        Me.lblNFantasia.Size = New System.Drawing.Size(103, 17)
        Me.lblNFantasia.TabIndex = 73
        Me.lblNFantasia.Text = "Nombre fantasía:"
        '
        'txtDirCalle
        '
        Me.txtDirCalle.BackColor = System.Drawing.Color.White
        Me.txtDirCalle.Enabled = False
        Me.txtDirCalle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDirCalle.Location = New System.Drawing.Point(199, 226)
        Me.txtDirCalle.Name = "txtDirCalle"
        Me.txtDirCalle.ReadOnly = True
        Me.txtDirCalle.Size = New System.Drawing.Size(65, 20)
        Me.txtDirCalle.TabIndex = 86
        '
        'txtBSE
        '
        Me.txtBSE.BackColor = System.Drawing.Color.White
        Me.txtBSE.Enabled = False
        Me.txtBSE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBSE.Location = New System.Drawing.Point(199, 197)
        Me.txtBSE.Name = "txtBSE"
        Me.txtBSE.ReadOnly = True
        Me.txtBSE.Size = New System.Drawing.Size(132, 20)
        Me.txtBSE.TabIndex = 85
        '
        'lblBPS
        '
        Me.lblBPS.AutoSize = True
        Me.lblBPS.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBPS.ForeColor = System.Drawing.Color.Black
        Me.lblBPS.Location = New System.Drawing.Point(38, 170)
        Me.lblBPS.Name = "lblBPS"
        Me.lblBPS.Size = New System.Drawing.Size(43, 17)
        Me.lblBPS.TabIndex = 75
        Me.lblBPS.Text = "B.P.S.:"
        '
        'txtBPS
        '
        Me.txtBPS.BackColor = System.Drawing.Color.White
        Me.txtBPS.Enabled = False
        Me.txtBPS.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBPS.Location = New System.Drawing.Point(199, 168)
        Me.txtBPS.Name = "txtBPS"
        Me.txtBPS.ReadOnly = True
        Me.txtBPS.Size = New System.Drawing.Size(132, 20)
        Me.txtBPS.TabIndex = 84
        '
        'lblBSE
        '
        Me.lblBSE.AutoSize = True
        Me.lblBSE.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBSE.ForeColor = System.Drawing.Color.Black
        Me.lblBSE.Location = New System.Drawing.Point(37, 199)
        Me.lblBSE.Name = "lblBSE"
        Me.lblBSE.Size = New System.Drawing.Size(42, 17)
        Me.lblBSE.TabIndex = 76
        Me.lblBSE.Text = "B.S.E.:"
        '
        'lblDireccion
        '
        Me.lblDireccion.AutoSize = True
        Me.lblDireccion.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDireccion.ForeColor = System.Drawing.Color.Black
        Me.lblDireccion.Location = New System.Drawing.Point(37, 228)
        Me.lblDireccion.Name = "lblDireccion"
        Me.lblDireccion.Size = New System.Drawing.Size(63, 17)
        Me.lblDireccion.TabIndex = 77
        Me.lblDireccion.Text = "Dirección:"
        '
        'txtNFantasia
        '
        Me.txtNFantasia.BackColor = System.Drawing.Color.White
        Me.txtNFantasia.Enabled = False
        Me.txtNFantasia.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNFantasia.Location = New System.Drawing.Point(199, 110)
        Me.txtNFantasia.Name = "txtNFantasia"
        Me.txtNFantasia.ReadOnly = True
        Me.txtNFantasia.Size = New System.Drawing.Size(132, 20)
        Me.txtNFantasia.TabIndex = 82
        '
        'lblNTelefono
        '
        Me.lblNTelefono.AutoSize = True
        Me.lblNTelefono.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNTelefono.ForeColor = System.Drawing.Color.Black
        Me.lblNTelefono.Location = New System.Drawing.Point(37, 257)
        Me.lblNTelefono.Name = "lblNTelefono"
        Me.lblNTelefono.Size = New System.Drawing.Size(121, 17)
        Me.lblNTelefono.TabIndex = 78
        Me.lblNTelefono.Text = "Número de teléfono:"
        '
        'txtRazonSocial
        '
        Me.txtRazonSocial.BackColor = System.Drawing.Color.White
        Me.txtRazonSocial.Enabled = False
        Me.txtRazonSocial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRazonSocial.Location = New System.Drawing.Point(199, 81)
        Me.txtRazonSocial.Name = "txtRazonSocial"
        Me.txtRazonSocial.ReadOnly = True
        Me.txtRazonSocial.Size = New System.Drawing.Size(132, 20)
        Me.txtRazonSocial.TabIndex = 81
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.ForeColor = System.Drawing.Color.Black
        Me.lblEmail.Location = New System.Drawing.Point(37, 286)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(42, 17)
        Me.lblEmail.TabIndex = 79
        Me.lblEmail.Text = "Email:"
        '
        'EmpGra_TabPageGrados
        '
        Me.EmpGra_TabPageGrados.Controls.Add(Me.GRA_pnlBotones)
        Me.EmpGra_TabPageGrados.Controls.Add(Me.GRA_TabControlVerMod)
        Me.EmpGra_TabPageGrados.Location = New System.Drawing.Point(4, 58)
        Me.EmpGra_TabPageGrados.Name = "EmpGra_TabPageGrados"
        Me.EmpGra_TabPageGrados.Padding = New System.Windows.Forms.Padding(3)
        Me.EmpGra_TabPageGrados.Size = New System.Drawing.Size(754, 302)
        Me.EmpGra_TabPageGrados.TabIndex = 1
        Me.EmpGra_TabPageGrados.Text = "TabPage2"
        Me.EmpGra_TabPageGrados.UseVisualStyleBackColor = True
        '
        'GRA_pnlBotones
        '
        Me.GRA_pnlBotones.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.GRA_pnlBotones.Controls.Add(Me.GRA_pnlSeleccionado)
        Me.GRA_pnlBotones.Controls.Add(Me.GRA_pnlGris)
        Me.GRA_pnlBotones.Controls.Add(Me.GRA_btnModificar)
        Me.GRA_pnlBotones.Controls.Add(Me.GRA_btnVer)
        Me.GRA_pnlBotones.Dock = System.Windows.Forms.DockStyle.Top
        Me.GRA_pnlBotones.Location = New System.Drawing.Point(3, 3)
        Me.GRA_pnlBotones.Name = "GRA_pnlBotones"
        Me.GRA_pnlBotones.Size = New System.Drawing.Size(748, 32)
        Me.GRA_pnlBotones.TabIndex = 1
        '
        'GRA_pnlSeleccionado
        '
        Me.GRA_pnlSeleccionado.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GRA_pnlSeleccionado.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.GRA_pnlSeleccionado.Location = New System.Drawing.Point(0, 27)
        Me.GRA_pnlSeleccionado.Name = "GRA_pnlSeleccionado"
        Me.GRA_pnlSeleccionado.Size = New System.Drawing.Size(90, 5)
        Me.GRA_pnlSeleccionado.TabIndex = 3
        '
        'GRA_pnlGris
        '
        Me.GRA_pnlGris.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.GRA_pnlGris.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.GRA_pnlGris.Location = New System.Drawing.Point(0, 29)
        Me.GRA_pnlGris.Name = "GRA_pnlGris"
        Me.GRA_pnlGris.Size = New System.Drawing.Size(748, 3)
        Me.GRA_pnlGris.TabIndex = 2
        '
        'GRA_btnModificar
        '
        Me.GRA_btnModificar.FlatAppearance.BorderSize = 0
        Me.GRA_btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GRA_btnModificar.ForeColor = System.Drawing.Color.White
        Me.GRA_btnModificar.Location = New System.Drawing.Point(90, 0)
        Me.GRA_btnModificar.Name = "GRA_btnModificar"
        Me.GRA_btnModificar.Size = New System.Drawing.Size(90, 29)
        Me.GRA_btnModificar.TabIndex = 1
        Me.GRA_btnModificar.Text = "MODIFICAR"
        Me.GRA_btnModificar.UseVisualStyleBackColor = True
        '
        'GRA_btnVer
        '
        Me.GRA_btnVer.FlatAppearance.BorderSize = 0
        Me.GRA_btnVer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GRA_btnVer.ForeColor = System.Drawing.Color.White
        Me.GRA_btnVer.Location = New System.Drawing.Point(0, 0)
        Me.GRA_btnVer.Name = "GRA_btnVer"
        Me.GRA_btnVer.Size = New System.Drawing.Size(90, 29)
        Me.GRA_btnVer.TabIndex = 0
        Me.GRA_btnVer.Text = "VER"
        Me.GRA_btnVer.UseVisualStyleBackColor = True
        '
        'GRA_TabControlVerMod
        '
        Me.GRA_TabControlVerMod.Controls.Add(Me.GRA_TabPageVer)
        Me.GRA_TabControlVerMod.Controls.Add(Me.GRA_TabPageModificar)
        Me.GRA_TabControlVerMod.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GRA_TabControlVerMod.Location = New System.Drawing.Point(3, 3)
        Me.GRA_TabControlVerMod.Name = "GRA_TabControlVerMod"
        Me.GRA_TabControlVerMod.Padding = New System.Drawing.Point(6, 6)
        Me.GRA_TabControlVerMod.SelectedIndex = 0
        Me.GRA_TabControlVerMod.Size = New System.Drawing.Size(748, 296)
        Me.GRA_TabControlVerMod.TabIndex = 0
        '
        'GRA_TabPageVer
        '
        Me.GRA_TabPageVer.Controls.Add(Me.VerGRA_lblPesos)
        Me.GRA_TabPageVer.Controls.Add(Me.VerGRA_cbGrado)
        Me.GRA_TabPageVer.Controls.Add(Me.VerGRA_lblVerGrados)
        Me.GRA_TabPageVer.Controls.Add(Me.VerGRA_txtSalario)
        Me.GRA_TabPageVer.Controls.Add(Me.VerGRA_lblSalario)
        Me.GRA_TabPageVer.Controls.Add(Me.VerGRA_lblGrado)
        Me.GRA_TabPageVer.Location = New System.Drawing.Point(4, 28)
        Me.GRA_TabPageVer.Name = "GRA_TabPageVer"
        Me.GRA_TabPageVer.Padding = New System.Windows.Forms.Padding(3)
        Me.GRA_TabPageVer.Size = New System.Drawing.Size(740, 264)
        Me.GRA_TabPageVer.TabIndex = 0
        Me.GRA_TabPageVer.Text = "TabPage1"
        Me.GRA_TabPageVer.UseVisualStyleBackColor = True
        '
        'VerGRA_lblPesos
        '
        Me.VerGRA_lblPesos.AutoSize = True
        Me.VerGRA_lblPesos.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerGRA_lblPesos.ForeColor = System.Drawing.Color.Black
        Me.VerGRA_lblPesos.Location = New System.Drawing.Point(260, 111)
        Me.VerGRA_lblPesos.Name = "VerGRA_lblPesos"
        Me.VerGRA_lblPesos.Size = New System.Drawing.Size(16, 17)
        Me.VerGRA_lblPesos.TabIndex = 42
        Me.VerGRA_lblPesos.Text = "$"
        '
        'VerGRA_cbGrado
        '
        Me.VerGRA_cbGrado.FormattingEnabled = True
        Me.VerGRA_cbGrado.Location = New System.Drawing.Point(279, 80)
        Me.VerGRA_cbGrado.Name = "VerGRA_cbGrado"
        Me.VerGRA_cbGrado.Size = New System.Drawing.Size(132, 21)
        Me.VerGRA_cbGrado.TabIndex = 33
        '
        'VerGRA_txtSalario
        '
        Me.VerGRA_txtSalario.BackColor = System.Drawing.Color.White
        Me.VerGRA_txtSalario.Enabled = False
        Me.VerGRA_txtSalario.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerGRA_txtSalario.Location = New System.Drawing.Point(279, 109)
        Me.VerGRA_txtSalario.Name = "VerGRA_txtSalario"
        Me.VerGRA_txtSalario.ReadOnly = True
        Me.VerGRA_txtSalario.Size = New System.Drawing.Size(132, 20)
        Me.VerGRA_txtSalario.TabIndex = 30
        '
        'VerGRA_lblSalario
        '
        Me.VerGRA_lblSalario.AutoSize = True
        Me.VerGRA_lblSalario.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerGRA_lblSalario.ForeColor = System.Drawing.Color.Black
        Me.VerGRA_lblSalario.Location = New System.Drawing.Point(117, 111)
        Me.VerGRA_lblSalario.Name = "VerGRA_lblSalario"
        Me.VerGRA_lblSalario.Size = New System.Drawing.Size(49, 17)
        Me.VerGRA_lblSalario.TabIndex = 28
        Me.VerGRA_lblSalario.Text = "Salario:"
        '
        'VerGRA_lblGrado
        '
        Me.VerGRA_lblGrado.AutoSize = True
        Me.VerGRA_lblGrado.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerGRA_lblGrado.ForeColor = System.Drawing.Color.Black
        Me.VerGRA_lblGrado.Location = New System.Drawing.Point(117, 82)
        Me.VerGRA_lblGrado.Name = "VerGRA_lblGrado"
        Me.VerGRA_lblGrado.Size = New System.Drawing.Size(44, 17)
        Me.VerGRA_lblGrado.TabIndex = 26
        Me.VerGRA_lblGrado.Text = "Grado:"
        '
        'GRA_TabPageModificar
        '
        Me.GRA_TabPageModificar.Controls.Add(Me.ModGRA_lblPesos)
        Me.GRA_TabPageModificar.Controls.Add(Me.ModGRA_cbGrado)
        Me.GRA_TabPageModificar.Controls.Add(Me.ModGRA_txtSalario)
        Me.GRA_TabPageModificar.Controls.Add(Me.ModGRA_lblSalario)
        Me.GRA_TabPageModificar.Controls.Add(Me.ModGRA_lblGrado)
        Me.GRA_TabPageModificar.Controls.Add(Me.Button1)
        Me.GRA_TabPageModificar.Location = New System.Drawing.Point(4, 28)
        Me.GRA_TabPageModificar.Name = "GRA_TabPageModificar"
        Me.GRA_TabPageModificar.Padding = New System.Windows.Forms.Padding(3)
        Me.GRA_TabPageModificar.Size = New System.Drawing.Size(740, 264)
        Me.GRA_TabPageModificar.TabIndex = 1
        Me.GRA_TabPageModificar.Text = "TabPage2"
        Me.GRA_TabPageModificar.UseVisualStyleBackColor = True
        '
        'ModGRA_lblPesos
        '
        Me.ModGRA_lblPesos.AutoSize = True
        Me.ModGRA_lblPesos.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModGRA_lblPesos.ForeColor = System.Drawing.Color.Black
        Me.ModGRA_lblPesos.Location = New System.Drawing.Point(260, 111)
        Me.ModGRA_lblPesos.Name = "ModGRA_lblPesos"
        Me.ModGRA_lblPesos.Size = New System.Drawing.Size(16, 17)
        Me.ModGRA_lblPesos.TabIndex = 41
        Me.ModGRA_lblPesos.Text = "$"
        '
        'ModGRA_cbGrado
        '
        Me.ModGRA_cbGrado.FormattingEnabled = True
        Me.ModGRA_cbGrado.Location = New System.Drawing.Point(278, 80)
        Me.ModGRA_cbGrado.Name = "ModGRA_cbGrado"
        Me.ModGRA_cbGrado.Size = New System.Drawing.Size(132, 21)
        Me.ModGRA_cbGrado.TabIndex = 40
        '
        'ModGRA_txtSalario
        '
        Me.ModGRA_txtSalario.BackColor = System.Drawing.Color.White
        Me.ModGRA_txtSalario.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModGRA_txtSalario.ForeColor = System.Drawing.Color.Silver
        Me.ModGRA_txtSalario.Location = New System.Drawing.Point(278, 109)
        Me.ModGRA_txtSalario.Name = "ModGRA_txtSalario"
        Me.ModGRA_txtSalario.Size = New System.Drawing.Size(132, 20)
        Me.ModGRA_txtSalario.TabIndex = 37
        '
        'ModGRA_lblSalario
        '
        Me.ModGRA_lblSalario.AutoSize = True
        Me.ModGRA_lblSalario.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModGRA_lblSalario.ForeColor = System.Drawing.Color.Black
        Me.ModGRA_lblSalario.Location = New System.Drawing.Point(116, 111)
        Me.ModGRA_lblSalario.Name = "ModGRA_lblSalario"
        Me.ModGRA_lblSalario.Size = New System.Drawing.Size(49, 17)
        Me.ModGRA_lblSalario.TabIndex = 35
        Me.ModGRA_lblSalario.Text = "Salario:"
        '
        'ModGRA_lblGrado
        '
        Me.ModGRA_lblGrado.AutoSize = True
        Me.ModGRA_lblGrado.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModGRA_lblGrado.ForeColor = System.Drawing.Color.Black
        Me.ModGRA_lblGrado.Location = New System.Drawing.Point(116, 82)
        Me.ModGRA_lblGrado.Name = "ModGRA_lblGrado"
        Me.ModGRA_lblGrado.Size = New System.Drawing.Size(44, 17)
        Me.ModGRA_lblGrado.TabIndex = 34
        Me.ModGRA_lblGrado.Text = "Grado:"
        '
        'pnlX
        '
        Me.pnlX.BackColor = System.Drawing.Color.White
        Me.pnlX.Controls.Add(Me.pnlCentral)
        Me.pnlX.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlX.Location = New System.Drawing.Point(20, 20)
        Me.pnlX.Name = "pnlX"
        Me.pnlX.Size = New System.Drawing.Size(762, 364)
        Me.pnlX.TabIndex = 6
        '
        'btnDepartamentos
        '
        Me.btnDepartamentos.FlatAppearance.BorderSize = 0
        Me.btnDepartamentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDepartamentos.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDepartamentos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnDepartamentos.Image = Global.TAX.My.Resources.Resources.departamentos_gris
        Me.btnDepartamentos.Location = New System.Drawing.Point(372, 0)
        Me.btnDepartamentos.Name = "btnDepartamentos"
        Me.btnDepartamentos.Size = New System.Drawing.Size(124, 59)
        Me.btnDepartamentos.TabIndex = 3
        Me.btnDepartamentos.Text = "DEPARTAMENTOS"
        Me.btnDepartamentos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnDepartamentos.UseVisualStyleBackColor = True
        '
        'btnCargos
        '
        Me.btnCargos.FlatAppearance.BorderSize = 0
        Me.btnCargos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCargos.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCargos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnCargos.Image = Global.TAX.My.Resources.Resources.cargos_gris
        Me.btnCargos.Location = New System.Drawing.Point(248, 0)
        Me.btnCargos.Name = "btnCargos"
        Me.btnCargos.Size = New System.Drawing.Size(124, 59)
        Me.btnCargos.TabIndex = 2
        Me.btnCargos.Text = "CARGOS"
        Me.btnCargos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnCargos.UseVisualStyleBackColor = True
        '
        'btnGrados
        '
        Me.btnGrados.FlatAppearance.BorderSize = 0
        Me.btnGrados.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGrados.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGrados.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnGrados.Image = Global.TAX.My.Resources.Resources.grados_gris
        Me.btnGrados.Location = New System.Drawing.Point(124, 0)
        Me.btnGrados.Name = "btnGrados"
        Me.btnGrados.Size = New System.Drawing.Size(124, 59)
        Me.btnGrados.TabIndex = 1
        Me.btnGrados.Text = "GRADOS"
        Me.btnGrados.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnGrados.UseVisualStyleBackColor = True
        '
        'btnEmpresa
        '
        Me.btnEmpresa.FlatAppearance.BorderSize = 0
        Me.btnEmpresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEmpresa.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEmpresa.ForeColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.btnEmpresa.Image = Global.TAX.My.Resources.Resources.empresa_roja
        Me.btnEmpresa.Location = New System.Drawing.Point(0, 0)
        Me.btnEmpresa.Name = "btnEmpresa"
        Me.btnEmpresa.Size = New System.Drawing.Size(124, 59)
        Me.btnEmpresa.TabIndex = 0
        Me.btnEmpresa.Text = "EMPRESA"
        Me.btnEmpresa.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnEmpresa.UseVisualStyleBackColor = True
        '
        'lblEmpresa
        '
        Me.lblEmpresa.FlatAppearance.BorderSize = 0
        Me.lblEmpresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblEmpresa.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmpresa.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.lblEmpresa.Image = Global.TAX.My.Resources.Resources.empresa
        Me.lblEmpresa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblEmpresa.Location = New System.Drawing.Point(6, 8)
        Me.lblEmpresa.Name = "lblEmpresa"
        Me.lblEmpresa.Size = New System.Drawing.Size(197, 43)
        Me.lblEmpresa.TabIndex = 69
        Me.lblEmpresa.Text = "Empresa"
        Me.lblEmpresa.UseVisualStyleBackColor = True
        '
        'VerGRA_lblVerGrados
        '
        Me.VerGRA_lblVerGrados.BackColor = System.Drawing.Color.White
        Me.VerGRA_lblVerGrados.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.VerGRA_lblVerGrados.FlatAppearance.BorderSize = 0
        Me.VerGRA_lblVerGrados.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.VerGRA_lblVerGrados.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.VerGRA_lblVerGrados.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.VerGRA_lblVerGrados.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerGRA_lblVerGrados.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.VerGRA_lblVerGrados.Image = CType(resources.GetObject("VerGRA_lblVerGrados.Image"), System.Drawing.Image)
        Me.VerGRA_lblVerGrados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.VerGRA_lblVerGrados.Location = New System.Drawing.Point(7, 10)
        Me.VerGRA_lblVerGrados.Name = "VerGRA_lblVerGrados"
        Me.VerGRA_lblVerGrados.Size = New System.Drawing.Size(211, 53)
        Me.VerGRA_lblVerGrados.TabIndex = 32
        Me.VerGRA_lblVerGrados.Text = "Ver grados"
        Me.VerGRA_lblVerGrados.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(6, 10)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(261, 53)
        Me.Button1.TabIndex = 39
        Me.Button1.Text = "Modificar grados"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Admin_Empresa
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(802, 404)
        Me.Controls.Add(Me.pnlX)
        Me.Controls.Add(Me.pnlInf)
        Me.Controls.Add(Me.pnlIzq)
        Me.Controls.Add(Me.pnlSup)
        Me.Controls.Add(Me.pnlDer)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_Empresa"
        Me.Text = "Admin_Empresa"
        Me.pnlCentral.ResumeLayout(False)
        Me.pnlTitulo.ResumeLayout(False)
        Me.TabControlEmpresaGrados.ResumeLayout(False)
        Me.EmpGra_TabPageEmpresa.ResumeLayout(False)
        Me.EmpGra_TabPageEmpresa.PerformLayout()
        Me.EmpGra_TabPageGrados.ResumeLayout(False)
        Me.GRA_pnlBotones.ResumeLayout(False)
        Me.GRA_TabControlVerMod.ResumeLayout(False)
        Me.GRA_TabPageVer.ResumeLayout(False)
        Me.GRA_TabPageVer.PerformLayout()
        Me.GRA_TabPageModificar.ResumeLayout(False)
        Me.GRA_TabPageModificar.PerformLayout()
        Me.pnlX.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlDer As System.Windows.Forms.Panel
    Friend WithEvents pnlSup As System.Windows.Forms.Panel
    Friend WithEvents pnlIzq As System.Windows.Forms.Panel
    Friend WithEvents pnlInf As System.Windows.Forms.Panel
    Friend WithEvents pnlCentral As System.Windows.Forms.Panel
    Friend WithEvents pnlTitulo As System.Windows.Forms.Panel
    Friend WithEvents pnlX As System.Windows.Forms.Panel
    Friend WithEvents TabControlEmpresaGrados As System.Windows.Forms.TabControl
    Friend WithEvents EmpGra_TabPageGrados As System.Windows.Forms.TabPage
    Friend WithEvents EmpGra_TabPageEmpresa As System.Windows.Forms.TabPage
    Friend WithEvents btnDepartamentos As System.Windows.Forms.Button
    Friend WithEvents btnCargos As System.Windows.Forms.Button
    Friend WithEvents btnGrados As System.Windows.Forms.Button
    Friend WithEvents btnEmpresa As System.Windows.Forms.Button
    Friend WithEvents lblEmpresa As System.Windows.Forms.Button
    Friend WithEvents txtDirNumero As System.Windows.Forms.TextBox
    Friend WithEvents lblRUT As System.Windows.Forms.Label
    Friend WithEvents txtSitioWeb As System.Windows.Forms.TextBox
    Friend WithEvents txtRUT As System.Windows.Forms.TextBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents lblRazonSocial As System.Windows.Forms.Label
    Friend WithEvents txtNTelefono As System.Windows.Forms.TextBox
    Friend WithEvents lblNFantasia As System.Windows.Forms.Label
    Friend WithEvents txtDirCalle As System.Windows.Forms.TextBox
    Friend WithEvents txtBSE As System.Windows.Forms.TextBox
    Friend WithEvents lblBPS As System.Windows.Forms.Label
    Friend WithEvents txtBPS As System.Windows.Forms.TextBox
    Friend WithEvents lblBSE As System.Windows.Forms.Label
    Friend WithEvents lblDireccion As System.Windows.Forms.Label
    Friend WithEvents txtNFantasia As System.Windows.Forms.TextBox
    Friend WithEvents lblNTelefono As System.Windows.Forms.Label
    Friend WithEvents txtRazonSocial As System.Windows.Forms.TextBox
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents GRA_pnlBotones As System.Windows.Forms.Panel
    Friend WithEvents GRA_btnModificar As System.Windows.Forms.Button
    Friend WithEvents GRA_btnVer As System.Windows.Forms.Button
    Friend WithEvents GRA_TabControlVerMod As System.Windows.Forms.TabControl
    Friend WithEvents GRA_TabPageVer As System.Windows.Forms.TabPage
    Friend WithEvents GRA_TabPageModificar As System.Windows.Forms.TabPage
    Friend WithEvents pnlGris As System.Windows.Forms.Panel
    Friend WithEvents pnl_seleccionado As System.Windows.Forms.Panel
    Friend WithEvents GRA_pnlSeleccionado As System.Windows.Forms.Panel
    Friend WithEvents GRA_pnlGris As System.Windows.Forms.Panel
    Friend WithEvents VerGRA_lblVerGrados As System.Windows.Forms.Button
    Friend WithEvents VerGRA_txtSalario As System.Windows.Forms.TextBox
    Friend WithEvents VerGRA_lblSalario As System.Windows.Forms.Label
    Friend WithEvents VerGRA_lblGrado As System.Windows.Forms.Label
    Friend WithEvents VerGRA_cbGrado As System.Windows.Forms.ComboBox
    Friend WithEvents VerGRA_lblPesos As System.Windows.Forms.Label
    Friend WithEvents ModGRA_lblPesos As System.Windows.Forms.Label
    Friend WithEvents ModGRA_cbGrado As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ModGRA_txtSalario As System.Windows.Forms.TextBox
    Friend WithEvents ModGRA_lblSalario As System.Windows.Forms.Label
    Friend WithEvents ModGRA_lblGrado As System.Windows.Forms.Label
End Class
