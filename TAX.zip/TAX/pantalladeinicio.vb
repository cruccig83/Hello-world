﻿Public Class pantalladeinicio
    Private Sub cmdficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdficha.Click
        ficha.Show()
        Me.Close()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdrecibogrande.Click
        mirecibo.Show()
        Me.Close()

    End Sub

    Private Sub cmdhistorialgrande_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhistorialgrande.Click
        historial_recibos.Show()
        Me.Close()

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdverficha.Click
        ficha.Show()
        Me.Close()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdrecibo.Click
        mirecibo.Show()
        Me.Close()

    End Sub

    Private Sub cmdhistorialaboral_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhistorialaboral.Click
        historialboral.Show()
        Me.Close()

    End Sub

    Private Sub cmdhistorialrecibos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhistorialrecibos.Click
        historial_recibos.Show()
        Me.Close()

    End Sub

    Private Sub cmdayuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdayuda.Click
        MsgBox("En Progreso")
    End Sub
End Class