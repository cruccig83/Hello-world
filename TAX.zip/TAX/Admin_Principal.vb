﻿Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Runtime.InteropServices
Public Class Admin_Principal

    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")> Private Shared Sub ReleaseCapture()
    End Sub
    <DllImport("user32.DLL", EntryPoint:="SendMessage")> Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub

    Private Sub AbrirFormEnPanel(Of Forms As {Form, New})()
        Dim formulario As Form
        formulario = pnlBarraPrincipal.Controls.OfType(Of Forms)().FirstOrDefault()

        If formulario Is Nothing Then
            formulario = New Forms()
            formulario.TopLevel = False
            formulario.FormBorderStyle = FormBorderStyle.None
            formulario.Dock = DockStyle.Fill
            pnlBarraPrincipal.Controls.Add(formulario)
            pnlBarraPrincipal.Tag = formulario
            formulario.Show()
            formulario.BringToFront()
        Else

            If formulario.WindowState = FormWindowState.Minimized Then
                formulario.WindowState = FormWindowState.Normal
            End If

            formulario.BringToFront()
        End If
    End Sub


    Private Sub btnficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnficha.Click
        AbrirFormEnPanel(Of Admin_Ficha)()

        pnlselectedbtn.Height = btnficha.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnficha.Location.Y)
    End Sub


    Private Sub btnadminempleados_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadminempleados.Click
        AbrirFormEnPanel(Of buscar_usuarios)()

        pnlselectedbtn.Height = btnadminempleados.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnadminempleados.Location.Y)
    End Sub

    Private Sub Admin_Principal_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        MessageBox.Show(MousePosition.X)
        MessageBox.Show(MousePosition.Y)
        MessageBox.Show("hola")


        If pnlUsuario.Visible = True Then
            If MousePosition.X < 717 Or MousePosition.Y > 190 Then
                pnlUsuario.Visible = False
            End If
        End If





    End Sub



    Private Sub inicioadministrador_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        AbrirFormEnPanel(Of Admin_Inicio)()
        pnlselectedbtn.Height = btninicio.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btninicio.Location.Y)

        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim command As New MySqlCommand("SELECT foto FROM personal WHERE doc=@doc ", cnn)
        command.Parameters.Add("@doc", MySqlDbType.UInt64).Value = Module1.document

        Dim adapter As New MySqlDataAdapter(command)
        Dim table As New DataTable

        adapter.Fill(table)

        Dim imgByte() As Byte
        imgByte = table(0)("foto")
        Dim ms As New MemoryStream(imgByte)

        btnUser.Image = Image.FromStream(ms)
        pbFotoUsuario.Image = Image.FromStream(ms)

        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE doc = '" & Module1.document & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.User_lblDoc.Text = rdr.Item("doc").ToString
                Me.User_lblNombre.Text = rdr.Item("nombre").ToString + " " + rdr.Item("apellido").ToString
                Me.User_lblId.Text = rdr.Item("persona_id").ToString


            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub btninicio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninicio.Click
        AbrirFormEnPanel(Of Admin_Inicio)()
        pnlselectedbtn.Height = btninicio.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btninicio.Location.Y)

    End Sub

    Private Sub btnturecibo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnturecibo.Click
        AbrirFormEnPanel(Of Admin_TuRecibo)()
        pnlselectedbtn.Height = btnturecibo.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnturecibo.Location.Y)
    End Sub

    Private Sub btnliqsueldos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnliqsueldos.Click
        AbrirFormEnPanel(Of Admin_TuRecibo)()
        pnlselectedbtn.Height = btnliqsueldos.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnliqsueldos.Location.Y)
    End Sub

    Private Sub btnrestore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Admin_ConfigEmpleados.ListUser_pnlBuscPorDocumento.Width = Admin_ConfigEmpleados.TabPage_Listar.Width / 2

    End Sub


    Private Sub btnEmpresa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmpresa.Click
        pnlselectedbtn.Height = btnEmpresa.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnEmpresa.Location.Y)
        AbrirFormEnPanel(Of Admin_Empresa)()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConceptos.Click
        AbrirFormEnPanel(Of Admin_Conceptos)()
        pnlselectedbtn.Height = btnConceptos.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnConceptos.Location.Y)
    End Sub



    Private Sub btndivisas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndivisas.Click
        AbrirFormEnPanel(Of Admin_TuRecibo)()
        pnlselectedbtn.Height = btndivisas.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btndivisas.Location.Y)
    End Sub



    Private Sub btnclose_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclose.Click
        Application.Exit()
    End Sub

    Private Sub btnMinimizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinimizar.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub


    Private Sub btnUser_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUser.Click
        If pnlUsuario.Visible = False Then
            pnlUsuario.Visible = True
        ElseIf pnlUsuario.Visible = True Then
            pnlUsuario.Visible = False
        End If
    End Sub


    Private Sub pnltitlebar_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pnltitlebar.Paint

    End Sub


    Private Sub pnlSeparacion_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles pnlSeparacion.Click
        MessageBox.Show(MousePosition.X)
        MessageBox.Show(MousePosition.Y)
        MessageBox.Show("hola")


        If pnlUsuario.Visible = True Then
            If MousePosition.X < 717 Or MousePosition.Y > 190 Then
                pnlUsuario.Visible = False
            End If
        End If
    End Sub

    Private Sub Admin_Principal_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        MessageBox.Show(MousePosition.X)
        MessageBox.Show(MousePosition.Y)
        MessageBox.Show("hola")


        If pnlUsuario.Visible = True Then
            If MousePosition.X < 717 Or MousePosition.Y > 190 Then
                pnlUsuario.Visible = False
            End If
        End If
    End Sub


    Private Sub btnMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenu.Click

        If pnlverticalmenu.Width = 175 Then
            pnlverticalmenu.Width = 44
        ElseIf pnlverticalmenu.Width = 44 Then
            pnlverticalmenu.Width = 175
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Admin_CambioContraseña.Show()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
        nuevologin.Show()
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        AbrirFormEnPanel(Of Admin_Ficha)()
        pnlUsuario.Visible = False

        pnlselectedbtn.Height = btnficha.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnficha.Location.Y)
    End Sub

    Private Sub pnltitlebar_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pnltitlebar.MouseMove
        ReleaseCapture()
        SendMessage(Me.Handle, &H112&, &HF012&, 0)
    End Sub

    
    Private Sub User_lblNombre_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles User_lblNombre.Click

    End Sub
End Class