﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Inicio
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Inicio))
        Me.pnl_sup = New System.Windows.Forms.Panel
        Me.pnl_Inf = New System.Windows.Forms.Panel
        Me.pnl_Izq = New System.Windows.Forms.Panel
        Me.pnl_Der = New System.Windows.Forms.Panel
        Me.pnl_Central = New System.Windows.Forms.Panel
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.pbEmpleados = New System.Windows.Forms.PictureBox
        Me.LiqSueldos_pnlInf = New System.Windows.Forms.Panel
        Me.LiqSuedos_pnlDer = New System.Windows.Forms.Panel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.pbLiqSueldos = New System.Windows.Forms.PictureBox
        Me.Empleados_pnlDer = New System.Windows.Forms.Panel
        Me.Empleados_pnlSup = New System.Windows.Forms.Panel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.btnVerFicha = New System.Windows.Forms.Button
        Me.Ficha_pnlIzq = New System.Windows.Forms.Panel
        Me.pnl_Central.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.pbEmpleados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.pbLiqSueldos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnl_sup
        '
        Me.pnl_sup.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.pnl_sup.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnl_sup.Location = New System.Drawing.Point(0, 0)
        Me.pnl_sup.Name = "pnl_sup"
        Me.pnl_sup.Size = New System.Drawing.Size(818, 20)
        Me.pnl_sup.TabIndex = 0
        '
        'pnl_Inf
        '
        Me.pnl_Inf.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.pnl_Inf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnl_Inf.Location = New System.Drawing.Point(0, 422)
        Me.pnl_Inf.Name = "pnl_Inf"
        Me.pnl_Inf.Size = New System.Drawing.Size(818, 20)
        Me.pnl_Inf.TabIndex = 1
        '
        'pnl_Izq
        '
        Me.pnl_Izq.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.pnl_Izq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnl_Izq.Location = New System.Drawing.Point(0, 20)
        Me.pnl_Izq.Name = "pnl_Izq"
        Me.pnl_Izq.Size = New System.Drawing.Size(20, 402)
        Me.pnl_Izq.TabIndex = 2
        '
        'pnl_Der
        '
        Me.pnl_Der.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.pnl_Der.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnl_Der.Location = New System.Drawing.Point(798, 20)
        Me.pnl_Der.Name = "pnl_Der"
        Me.pnl_Der.Size = New System.Drawing.Size(20, 402)
        Me.pnl_Der.TabIndex = 3
        '
        'pnl_Central
        '
        Me.pnl_Central.BackColor = System.Drawing.Color.White
        Me.pnl_Central.Controls.Add(Me.SplitContainer1)
        Me.pnl_Central.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnl_Central.Location = New System.Drawing.Point(20, 20)
        Me.pnl_Central.Name = "pnl_Central"
        Me.pnl_Central.Size = New System.Drawing.Size(778, 402)
        Me.pnl_Central.TabIndex = 4
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.BackColor = System.Drawing.Color.White
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Ficha_pnlIzq)
        Me.SplitContainer1.Size = New System.Drawing.Size(778, 402)
        Me.SplitContainer1.SplitterDistance = 389
        Me.SplitContainer1.SplitterWidth = 1
        Me.SplitContainer1.TabIndex = 0
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.IsSplitterFixed = True
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.BackColor = System.Drawing.Color.White
        Me.SplitContainer2.Panel1.Controls.Add(Me.Panel2)
        Me.SplitContainer2.Panel1.Controls.Add(Me.LiqSueldos_pnlInf)
        Me.SplitContainer2.Panel1.Controls.Add(Me.LiqSuedos_pnlDer)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.BackColor = System.Drawing.Color.White
        Me.SplitContainer2.Panel2.Controls.Add(Me.Panel3)
        Me.SplitContainer2.Panel2.Controls.Add(Me.Empleados_pnlDer)
        Me.SplitContainer2.Panel2.Controls.Add(Me.Empleados_pnlSup)
        Me.SplitContainer2.Size = New System.Drawing.Size(389, 402)
        Me.SplitContainer2.SplitterDistance = 200
        Me.SplitContainer2.SplitterWidth = 1
        Me.SplitContainer2.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.pbEmpleados)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(379, 190)
        Me.Panel2.TabIndex = 4
        '
        'pbEmpleados
        '
        Me.pbEmpleados.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pbEmpleados.Image = CType(resources.GetObject("pbEmpleados.Image"), System.Drawing.Image)
        Me.pbEmpleados.Location = New System.Drawing.Point(0, 0)
        Me.pbEmpleados.Name = "pbEmpleados"
        Me.pbEmpleados.Size = New System.Drawing.Size(379, 190)
        Me.pbEmpleados.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbEmpleados.TabIndex = 0
        Me.pbEmpleados.TabStop = False
        '
        'LiqSueldos_pnlInf
        '
        Me.LiqSueldos_pnlInf.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.LiqSueldos_pnlInf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.LiqSueldos_pnlInf.Location = New System.Drawing.Point(0, 190)
        Me.LiqSueldos_pnlInf.Name = "LiqSueldos_pnlInf"
        Me.LiqSueldos_pnlInf.Size = New System.Drawing.Size(379, 10)
        Me.LiqSueldos_pnlInf.TabIndex = 3
        '
        'LiqSuedos_pnlDer
        '
        Me.LiqSuedos_pnlDer.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.LiqSuedos_pnlDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.LiqSuedos_pnlDer.Location = New System.Drawing.Point(379, 0)
        Me.LiqSuedos_pnlDer.Name = "LiqSuedos_pnlDer"
        Me.LiqSuedos_pnlDer.Size = New System.Drawing.Size(10, 200)
        Me.LiqSuedos_pnlDer.TabIndex = 2
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.pbLiqSueldos)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 10)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(379, 191)
        Me.Panel3.TabIndex = 2
        '
        'pbLiqSueldos
        '
        Me.pbLiqSueldos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pbLiqSueldos.Image = CType(resources.GetObject("pbLiqSueldos.Image"), System.Drawing.Image)
        Me.pbLiqSueldos.Location = New System.Drawing.Point(0, 0)
        Me.pbLiqSueldos.Name = "pbLiqSueldos"
        Me.pbLiqSueldos.Size = New System.Drawing.Size(379, 191)
        Me.pbLiqSueldos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbLiqSueldos.TabIndex = 0
        Me.pbLiqSueldos.TabStop = False
        '
        'Empleados_pnlDer
        '
        Me.Empleados_pnlDer.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.Empleados_pnlDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.Empleados_pnlDer.Location = New System.Drawing.Point(379, 10)
        Me.Empleados_pnlDer.Name = "Empleados_pnlDer"
        Me.Empleados_pnlDer.Size = New System.Drawing.Size(10, 191)
        Me.Empleados_pnlDer.TabIndex = 1
        '
        'Empleados_pnlSup
        '
        Me.Empleados_pnlSup.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.Empleados_pnlSup.Dock = System.Windows.Forms.DockStyle.Top
        Me.Empleados_pnlSup.Location = New System.Drawing.Point(0, 0)
        Me.Empleados_pnlSup.Name = "Empleados_pnlSup"
        Me.Empleados_pnlSup.Size = New System.Drawing.Size(389, 10)
        Me.Empleados_pnlSup.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnVerFicha)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(10, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(378, 402)
        Me.Panel1.TabIndex = 2
        '
        'btnVerFicha
        '
        Me.btnVerFicha.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.btnVerFicha.FlatAppearance.BorderSize = 0
        Me.btnVerFicha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVerFicha.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVerFicha.ForeColor = System.Drawing.Color.White
        Me.btnVerFicha.Location = New System.Drawing.Point(136, 364)
        Me.btnVerFicha.Name = "btnVerFicha"
        Me.btnVerFicha.Size = New System.Drawing.Size(110, 23)
        Me.btnVerFicha.TabIndex = 1
        Me.btnVerFicha.Text = "VER FICHA"
        Me.btnVerFicha.UseVisualStyleBackColor = False
        '
        'Ficha_pnlIzq
        '
        Me.Ficha_pnlIzq.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.Ficha_pnlIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.Ficha_pnlIzq.Location = New System.Drawing.Point(0, 0)
        Me.Ficha_pnlIzq.Name = "Ficha_pnlIzq"
        Me.Ficha_pnlIzq.Size = New System.Drawing.Size(10, 402)
        Me.Ficha_pnlIzq.TabIndex = 0
        '
        'Admin_Inicio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(818, 442)
        Me.Controls.Add(Me.pnl_Central)
        Me.Controls.Add(Me.pnl_Der)
        Me.Controls.Add(Me.pnl_Izq)
        Me.Controls.Add(Me.pnl_Inf)
        Me.Controls.Add(Me.pnl_sup)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_Inicio"
        Me.Text = "inicioadmin_inicio"
        Me.pnl_Central.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.pbEmpleados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        CType(Me.pbLiqSueldos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnl_sup As System.Windows.Forms.Panel
    Friend WithEvents pnl_Inf As System.Windows.Forms.Panel
    Friend WithEvents pnl_Izq As System.Windows.Forms.Panel
    Friend WithEvents pnl_Der As System.Windows.Forms.Panel
    Friend WithEvents pnl_Central As System.Windows.Forms.Panel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents LiqSueldos_pnlInf As System.Windows.Forms.Panel
    Friend WithEvents LiqSuedos_pnlDer As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Empleados_pnlDer As System.Windows.Forms.Panel
    Friend WithEvents Empleados_pnlSup As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnVerFicha As System.Windows.Forms.Button
    Friend WithEvents Ficha_pnlIzq As System.Windows.Forms.Panel
    Friend WithEvents pbEmpleados As System.Windows.Forms.PictureBox
    Friend WithEvents pbLiqSueldos As System.Windows.Forms.PictureBox
End Class
