﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_VerUsuario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_VerUsuario))
        Me.pnlBarraTitulo = New System.Windows.Forms.Panel
        Me.btnClose = New System.Windows.Forms.Button
        Me.pnlBorDer = New System.Windows.Forms.Panel
        Me.pnlBorInf = New System.Windows.Forms.Panel
        Me.pnlBorIzq = New System.Windows.Forms.Panel
        Me.pnlCentral = New System.Windows.Forms.Panel
        Me.pnlBotones = New System.Windows.Forms.Panel
        Me.btnGuardarMods = New System.Windows.Forms.Button
        Me.BtnModificar = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.pnlS_Ficha = New System.Windows.Forms.Panel
        Me.btnHRecibos = New System.Windows.Forms.Button
        Me.btnHLaboral = New System.Windows.Forms.Button
        Me.btnOrganizacion = New System.Windows.Forms.Button
        Me.btnFicha = New System.Windows.Forms.Button
        Me.TabControlPrincipal = New System.Windows.Forms.TabControl
        Me.TabPageFicha = New System.Windows.Forms.TabPage
        Me.FICHA_cbEstCivil = New System.Windows.Forms.ComboBox
        Me.FICHA_cbSexo = New System.Windows.Forms.ComboBox
        Me.FICHA_dpFNac = New System.Windows.Forms.DateTimePicker
        Me.FICHA_txtDirNumero = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.inftrabajador = New System.Windows.Forms.Button
        Me.FICHA_txtFijo = New System.Windows.Forms.TextBox
        Me.FICHA_txtCelular = New System.Windows.Forms.TextBox
        Me.FICHA_txtHijos = New System.Windows.Forms.TextBox
        Me.FICHA_txtEmail = New System.Windows.Forms.TextBox
        Me.FICHA_txtCalle = New System.Windows.Forms.TextBox
        Me.FICHA_txtContraseña = New System.Windows.Forms.TextBox
        Me.FICHA_txtApellido = New System.Windows.Forms.TextBox
        Me.FICHA_txtNombre = New System.Windows.Forms.TextBox
        Me.FICHA_lblFijo = New System.Windows.Forms.Label
        Me.FICHA_lblCelular = New System.Windows.Forms.Label
        Me.FICHA_lblHijos = New System.Windows.Forms.Label
        Me.FICHA_lblEmail = New System.Windows.Forms.Label
        Me.FICHA_lblEstCivil = New System.Windows.Forms.Label
        Me.FICHA_lblDireccion = New System.Windows.Forms.Label
        Me.FICHA_lblFNacimiento = New System.Windows.Forms.Label
        Me.FICHA_lblSexo = New System.Windows.Forms.Label
        Me.FICHA_lblContraseña = New System.Windows.Forms.Label
        Me.FICHA_lblApellido = New System.Windows.Forms.Label
        Me.FICHA_lblNombre = New System.Windows.Forms.Label
        Me.FICHA_txtDocumento = New System.Windows.Forms.TextBox
        Me.FICHA_lblDocumento = New System.Windows.Forms.Label
        Me.TabPageOrganizacion = New System.Windows.Forms.TabPage
        Me.ORG_dpFIngreso = New System.Windows.Forms.DateTimePicker
        Me.ORG_cbGrado = New System.Windows.Forms.ComboBox
        Me.ORG_txtMailEmpresarial = New System.Windows.Forms.TextBox
        Me.ORG_txtTlfEmpresarial = New System.Windows.Forms.TextBox
        Me.ORG_txtDepartamento = New System.Windows.Forms.TextBox
        Me.ORG_txtCargo = New System.Windows.Forms.TextBox
        Me.ORG_txtNRegistro = New System.Windows.Forms.TextBox
        Me.ORG_lblEmailEmpresarial = New System.Windows.Forms.Label
        Me.ORG_lblTelfEmpresarial = New System.Windows.Forms.Label
        Me.ORG_lblDepartamento = New System.Windows.Forms.Label
        Me.ORG_lblGrado = New System.Windows.Forms.Label
        Me.ORG_lblCargo = New System.Windows.Forms.Label
        Me.ORG_lblFIngreso = New System.Windows.Forms.Label
        Me.ORG_lblNRegistro = New System.Windows.Forms.Label
        Me.ORG_txtRUT = New System.Windows.Forms.TextBox
        Me.ORG_lblRUT = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.TabPageHLaboral = New System.Windows.Forms.TabPage
        Me.TabPageHRecibos = New System.Windows.Forms.TabPage
        Me.pnlBarraTitulo.SuspendLayout()
        Me.pnlCentral.SuspendLayout()
        Me.pnlBotones.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabControlPrincipal.SuspendLayout()
        Me.TabPageFicha.SuspendLayout()
        Me.TabPageOrganizacion.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlBarraTitulo
        '
        Me.pnlBarraTitulo.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlBarraTitulo.Controls.Add(Me.btnClose)
        Me.pnlBarraTitulo.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBarraTitulo.Location = New System.Drawing.Point(0, 0)
        Me.pnlBarraTitulo.Name = "pnlBarraTitulo"
        Me.pnlBarraTitulo.Size = New System.Drawing.Size(818, 25)
        Me.pnlBarraTitulo.TabIndex = 0
        '
        'btnClose
        '
        Me.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnClose.FlatAppearance.BorderSize = 0
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.Image = Global.TAX.My.Resources.Resources.close_16
        Me.btnClose.Location = New System.Drawing.Point(788, 0)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(30, 25)
        Me.btnClose.TabIndex = 0
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'pnlBorDer
        '
        Me.pnlBorDer.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlBorDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlBorDer.Location = New System.Drawing.Point(817, 25)
        Me.pnlBorDer.Name = "pnlBorDer"
        Me.pnlBorDer.Size = New System.Drawing.Size(1, 418)
        Me.pnlBorDer.TabIndex = 1
        '
        'pnlBorInf
        '
        Me.pnlBorInf.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlBorInf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlBorInf.Location = New System.Drawing.Point(0, 442)
        Me.pnlBorInf.Name = "pnlBorInf"
        Me.pnlBorInf.Size = New System.Drawing.Size(817, 1)
        Me.pnlBorInf.TabIndex = 2
        '
        'pnlBorIzq
        '
        Me.pnlBorIzq.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlBorIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlBorIzq.Location = New System.Drawing.Point(0, 25)
        Me.pnlBorIzq.Name = "pnlBorIzq"
        Me.pnlBorIzq.Size = New System.Drawing.Size(1, 417)
        Me.pnlBorIzq.TabIndex = 3
        '
        'pnlCentral
        '
        Me.pnlCentral.Controls.Add(Me.pnlBotones)
        Me.pnlCentral.Controls.Add(Me.TabControlPrincipal)
        Me.pnlCentral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlCentral.Location = New System.Drawing.Point(1, 25)
        Me.pnlCentral.Name = "pnlCentral"
        Me.pnlCentral.Size = New System.Drawing.Size(816, 417)
        Me.pnlCentral.TabIndex = 4
        '
        'pnlBotones
        '
        Me.pnlBotones.BackColor = System.Drawing.Color.White
        Me.pnlBotones.Controls.Add(Me.btnGuardarMods)
        Me.pnlBotones.Controls.Add(Me.BtnModificar)
        Me.pnlBotones.Controls.Add(Me.Panel1)
        Me.pnlBotones.Controls.Add(Me.btnHRecibos)
        Me.pnlBotones.Controls.Add(Me.btnHLaboral)
        Me.pnlBotones.Controls.Add(Me.btnOrganizacion)
        Me.pnlBotones.Controls.Add(Me.btnFicha)
        Me.pnlBotones.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBotones.Location = New System.Drawing.Point(0, 0)
        Me.pnlBotones.Name = "pnlBotones"
        Me.pnlBotones.Size = New System.Drawing.Size(816, 60)
        Me.pnlBotones.TabIndex = 1
        '
        'btnGuardarMods
        '
        Me.btnGuardarMods.Location = New System.Drawing.Point(628, 15)
        Me.btnGuardarMods.Name = "btnGuardarMods"
        Me.btnGuardarMods.Size = New System.Drawing.Size(75, 23)
        Me.btnGuardarMods.TabIndex = 11
        Me.btnGuardarMods.Text = "GUARDAR MODIFICACIONES"
        Me.btnGuardarMods.UseVisualStyleBackColor = True
        Me.btnGuardarMods.Visible = False
        '
        'BtnModificar
        '
        Me.BtnModificar.Location = New System.Drawing.Point(730, 15)
        Me.BtnModificar.Name = "BtnModificar"
        Me.BtnModificar.Size = New System.Drawing.Size(75, 23)
        Me.BtnModificar.TabIndex = 10
        Me.BtnModificar.Text = "MODIFICAR"
        Me.BtnModificar.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.Panel1.Controls.Add(Me.pnlS_Ficha)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 57)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(816, 3)
        Me.Panel1.TabIndex = 9
        '
        'pnlS_Ficha
        '
        Me.pnlS_Ficha.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.pnlS_Ficha.Location = New System.Drawing.Point(0, 0)
        Me.pnlS_Ficha.Name = "pnlS_Ficha"
        Me.pnlS_Ficha.Size = New System.Drawing.Size(117, 3)
        Me.pnlS_Ficha.TabIndex = 5
        '
        'btnHRecibos
        '
        Me.btnHRecibos.BackColor = System.Drawing.Color.Transparent
        Me.btnHRecibos.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHRecibos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHRecibos.FlatAppearance.BorderSize = 0
        Me.btnHRecibos.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHRecibos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHRecibos.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHRecibos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnHRecibos.Image = Global.TAX.My.Resources.Resources.historial_gris
        Me.btnHRecibos.Location = New System.Drawing.Point(351, 0)
        Me.btnHRecibos.Name = "btnHRecibos"
        Me.btnHRecibos.Size = New System.Drawing.Size(117, 57)
        Me.btnHRecibos.TabIndex = 7
        Me.btnHRecibos.Text = "HISTORIAL RECIBOS"
        Me.btnHRecibos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnHRecibos.UseVisualStyleBackColor = False
        '
        'btnHLaboral
        '
        Me.btnHLaboral.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHLaboral.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHLaboral.FlatAppearance.BorderSize = 0
        Me.btnHLaboral.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHLaboral.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHLaboral.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHLaboral.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnHLaboral.Image = Global.TAX.My.Resources.Resources.historia_gris
        Me.btnHLaboral.Location = New System.Drawing.Point(234, 0)
        Me.btnHLaboral.Name = "btnHLaboral"
        Me.btnHLaboral.Size = New System.Drawing.Size(117, 57)
        Me.btnHLaboral.TabIndex = 6
        Me.btnHLaboral.Text = "HISTORIA LABORAL"
        Me.btnHLaboral.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnHLaboral.UseVisualStyleBackColor = True
        '
        'btnOrganizacion
        '
        Me.btnOrganizacion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOrganizacion.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnOrganizacion.FlatAppearance.BorderSize = 0
        Me.btnOrganizacion.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnOrganizacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOrganizacion.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrganizacion.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnOrganizacion.Image = Global.TAX.My.Resources.Resources.enterprise_gris
        Me.btnOrganizacion.Location = New System.Drawing.Point(117, 0)
        Me.btnOrganizacion.Name = "btnOrganizacion"
        Me.btnOrganizacion.Size = New System.Drawing.Size(117, 57)
        Me.btnOrganizacion.TabIndex = 5
        Me.btnOrganizacion.Text = "ORGANIZACIÓN" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnOrganizacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnOrganizacion.UseVisualStyleBackColor = True
        '
        'btnFicha
        '
        Me.btnFicha.BackColor = System.Drawing.Color.White
        Me.btnFicha.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFicha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnFicha.FlatAppearance.BorderSize = 0
        Me.btnFicha.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnFicha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFicha.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFicha.ForeColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.btnFicha.Image = Global.TAX.My.Resources.Resources.ficha_roja
        Me.btnFicha.Location = New System.Drawing.Point(0, 0)
        Me.btnFicha.Name = "btnFicha"
        Me.btnFicha.Size = New System.Drawing.Size(117, 57)
        Me.btnFicha.TabIndex = 4
        Me.btnFicha.Text = "FICHA"
        Me.btnFicha.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnFicha.UseVisualStyleBackColor = False
        '
        'TabControlPrincipal
        '
        Me.TabControlPrincipal.Controls.Add(Me.TabPageFicha)
        Me.TabControlPrincipal.Controls.Add(Me.TabPageOrganizacion)
        Me.TabControlPrincipal.Controls.Add(Me.TabPageHLaboral)
        Me.TabControlPrincipal.Controls.Add(Me.TabPageHRecibos)
        Me.TabControlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControlPrincipal.Location = New System.Drawing.Point(0, 0)
        Me.TabControlPrincipal.Name = "TabControlPrincipal"
        Me.TabControlPrincipal.Padding = New System.Drawing.Point(6, 21)
        Me.TabControlPrincipal.SelectedIndex = 0
        Me.TabControlPrincipal.Size = New System.Drawing.Size(816, 417)
        Me.TabControlPrincipal.TabIndex = 0
        '
        'TabPageFicha
        '
        Me.TabPageFicha.AutoScroll = True
        Me.TabPageFicha.Controls.Add(Me.FICHA_cbEstCivil)
        Me.TabPageFicha.Controls.Add(Me.FICHA_cbSexo)
        Me.TabPageFicha.Controls.Add(Me.FICHA_dpFNac)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtDirNumero)
        Me.TabPageFicha.Controls.Add(Me.Label23)
        Me.TabPageFicha.Controls.Add(Me.inftrabajador)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtFijo)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtCelular)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtHijos)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtEmail)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtCalle)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtContraseña)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtApellido)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtNombre)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblFijo)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblCelular)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblHijos)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblEmail)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblEstCivil)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblDireccion)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblFNacimiento)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblSexo)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblContraseña)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblApellido)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblNombre)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtDocumento)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblDocumento)
        Me.TabPageFicha.Location = New System.Drawing.Point(4, 58)
        Me.TabPageFicha.Name = "TabPageFicha"
        Me.TabPageFicha.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageFicha.Size = New System.Drawing.Size(808, 355)
        Me.TabPageFicha.TabIndex = 0
        Me.TabPageFicha.Text = "TabPage1"
        Me.TabPageFicha.UseVisualStyleBackColor = True
        '
        'FICHA_cbEstCivil
        '
        Me.FICHA_cbEstCivil.Enabled = False
        Me.FICHA_cbEstCivil.FormattingEnabled = True
        Me.FICHA_cbEstCivil.Items.AddRange(New Object() {"soltero/a", "casado/a", "divorciado/a", "viudo/a", "concubinato/a"})
        Me.FICHA_cbEstCivil.Location = New System.Drawing.Point(279, 281)
        Me.FICHA_cbEstCivil.Name = "FICHA_cbEstCivil"
        Me.FICHA_cbEstCivil.Size = New System.Drawing.Size(132, 21)
        Me.FICHA_cbEstCivil.TabIndex = 57
        '
        'FICHA_cbSexo
        '
        Me.FICHA_cbSexo.Enabled = False
        Me.FICHA_cbSexo.FormattingEnabled = True
        Me.FICHA_cbSexo.Items.AddRange(New Object() {"hombre", "mujer", "otro"})
        Me.FICHA_cbSexo.Location = New System.Drawing.Point(279, 194)
        Me.FICHA_cbSexo.Name = "FICHA_cbSexo"
        Me.FICHA_cbSexo.Size = New System.Drawing.Size(132, 21)
        Me.FICHA_cbSexo.TabIndex = 56
        '
        'FICHA_dpFNac
        '
        Me.FICHA_dpFNac.CustomFormat = "yyyy-MM-dd"
        Me.FICHA_dpFNac.Enabled = False
        Me.FICHA_dpFNac.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.FICHA_dpFNac.Location = New System.Drawing.Point(279, 223)
        Me.FICHA_dpFNac.Name = "FICHA_dpFNac"
        Me.FICHA_dpFNac.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_dpFNac.TabIndex = 55
        '
        'FICHA_txtDirNumero
        '
        Me.FICHA_txtDirNumero.BackColor = System.Drawing.Color.White
        Me.FICHA_txtDirNumero.Enabled = False
        Me.FICHA_txtDirNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtDirNumero.Location = New System.Drawing.Point(346, 252)
        Me.FICHA_txtDirNumero.Name = "FICHA_txtDirNumero"
        Me.FICHA_txtDirNumero.Size = New System.Drawing.Size(65, 20)
        Me.FICHA_txtDirNumero.TabIndex = 54
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Enabled = False
        Me.Label23.Location = New System.Drawing.Point(449, 414)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(0, 13)
        Me.Label23.TabIndex = 53
        '
        'inftrabajador
        '
        Me.inftrabajador.BackColor = System.Drawing.Color.White
        Me.inftrabajador.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatAppearance.BorderSize = 0
        Me.inftrabajador.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.inftrabajador.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.inftrabajador.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.inftrabajador.Image = CType(resources.GetObject("inftrabajador.Image"), System.Drawing.Image)
        Me.inftrabajador.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.inftrabajador.Location = New System.Drawing.Point(7, 8)
        Me.inftrabajador.Name = "inftrabajador"
        Me.inftrabajador.Size = New System.Drawing.Size(354, 53)
        Me.inftrabajador.TabIndex = 52
        Me.inftrabajador.Text = "Información del Trabajador"
        Me.inftrabajador.UseVisualStyleBackColor = False
        '
        'FICHA_txtFijo
        '
        Me.FICHA_txtFijo.BackColor = System.Drawing.Color.White
        Me.FICHA_txtFijo.Enabled = False
        Me.FICHA_txtFijo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtFijo.Location = New System.Drawing.Point(279, 397)
        Me.FICHA_txtFijo.Name = "FICHA_txtFijo"
        Me.FICHA_txtFijo.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtFijo.TabIndex = 51
        '
        'FICHA_txtCelular
        '
        Me.FICHA_txtCelular.BackColor = System.Drawing.Color.White
        Me.FICHA_txtCelular.Enabled = False
        Me.FICHA_txtCelular.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtCelular.Location = New System.Drawing.Point(279, 368)
        Me.FICHA_txtCelular.Name = "FICHA_txtCelular"
        Me.FICHA_txtCelular.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtCelular.TabIndex = 50
        '
        'FICHA_txtHijos
        '
        Me.FICHA_txtHijos.BackColor = System.Drawing.Color.White
        Me.FICHA_txtHijos.Enabled = False
        Me.FICHA_txtHijos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtHijos.Location = New System.Drawing.Point(279, 339)
        Me.FICHA_txtHijos.Name = "FICHA_txtHijos"
        Me.FICHA_txtHijos.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtHijos.TabIndex = 49
        '
        'FICHA_txtEmail
        '
        Me.FICHA_txtEmail.BackColor = System.Drawing.Color.White
        Me.FICHA_txtEmail.Enabled = False
        Me.FICHA_txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtEmail.Location = New System.Drawing.Point(279, 310)
        Me.FICHA_txtEmail.Name = "FICHA_txtEmail"
        Me.FICHA_txtEmail.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtEmail.TabIndex = 48
        '
        'FICHA_txtCalle
        '
        Me.FICHA_txtCalle.BackColor = System.Drawing.Color.White
        Me.FICHA_txtCalle.Enabled = False
        Me.FICHA_txtCalle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtCalle.Location = New System.Drawing.Point(279, 252)
        Me.FICHA_txtCalle.Name = "FICHA_txtCalle"
        Me.FICHA_txtCalle.Size = New System.Drawing.Size(65, 20)
        Me.FICHA_txtCalle.TabIndex = 46
        '
        'FICHA_txtContraseña
        '
        Me.FICHA_txtContraseña.BackColor = System.Drawing.Color.White
        Me.FICHA_txtContraseña.Enabled = False
        Me.FICHA_txtContraseña.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtContraseña.Location = New System.Drawing.Point(279, 165)
        Me.FICHA_txtContraseña.Name = "FICHA_txtContraseña"
        Me.FICHA_txtContraseña.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtContraseña.TabIndex = 43
        '
        'FICHA_txtApellido
        '
        Me.FICHA_txtApellido.BackColor = System.Drawing.Color.White
        Me.FICHA_txtApellido.Enabled = False
        Me.FICHA_txtApellido.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtApellido.Location = New System.Drawing.Point(279, 136)
        Me.FICHA_txtApellido.Name = "FICHA_txtApellido"
        Me.FICHA_txtApellido.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtApellido.TabIndex = 42
        '
        'FICHA_txtNombre
        '
        Me.FICHA_txtNombre.BackColor = System.Drawing.Color.White
        Me.FICHA_txtNombre.Enabled = False
        Me.FICHA_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtNombre.Location = New System.Drawing.Point(279, 107)
        Me.FICHA_txtNombre.Name = "FICHA_txtNombre"
        Me.FICHA_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtNombre.TabIndex = 41
        '
        'FICHA_lblFijo
        '
        Me.FICHA_lblFijo.AutoSize = True
        Me.FICHA_lblFijo.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblFijo.Location = New System.Drawing.Point(118, 399)
        Me.FICHA_lblFijo.Name = "FICHA_lblFijo"
        Me.FICHA_lblFijo.Size = New System.Drawing.Size(68, 13)
        Me.FICHA_lblFijo.TabIndex = 40
        Me.FICHA_lblFijo.Text = "Teléfono fijo:"
        '
        'FICHA_lblCelular
        '
        Me.FICHA_lblCelular.AutoSize = True
        Me.FICHA_lblCelular.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblCelular.Location = New System.Drawing.Point(117, 370)
        Me.FICHA_lblCelular.Name = "FICHA_lblCelular"
        Me.FICHA_lblCelular.Size = New System.Drawing.Size(86, 13)
        Me.FICHA_lblCelular.TabIndex = 39
        Me.FICHA_lblCelular.Text = "Teléfono celular:"
        '
        'FICHA_lblHijos
        '
        Me.FICHA_lblHijos.AutoSize = True
        Me.FICHA_lblHijos.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblHijos.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblHijos.Location = New System.Drawing.Point(117, 341)
        Me.FICHA_lblHijos.Name = "FICHA_lblHijos"
        Me.FICHA_lblHijos.Size = New System.Drawing.Size(38, 17)
        Me.FICHA_lblHijos.TabIndex = 38
        Me.FICHA_lblHijos.Text = "Hijos:"
        '
        'FICHA_lblEmail
        '
        Me.FICHA_lblEmail.AutoSize = True
        Me.FICHA_lblEmail.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblEmail.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblEmail.Location = New System.Drawing.Point(117, 312)
        Me.FICHA_lblEmail.Name = "FICHA_lblEmail"
        Me.FICHA_lblEmail.Size = New System.Drawing.Size(42, 17)
        Me.FICHA_lblEmail.TabIndex = 37
        Me.FICHA_lblEmail.Text = "Email:"
        '
        'FICHA_lblEstCivil
        '
        Me.FICHA_lblEstCivil.AutoSize = True
        Me.FICHA_lblEstCivil.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblEstCivil.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblEstCivil.Location = New System.Drawing.Point(117, 283)
        Me.FICHA_lblEstCivil.Name = "FICHA_lblEstCivil"
        Me.FICHA_lblEstCivil.Size = New System.Drawing.Size(75, 17)
        Me.FICHA_lblEstCivil.TabIndex = 36
        Me.FICHA_lblEstCivil.Text = "Estado Civil:"
        '
        'FICHA_lblDireccion
        '
        Me.FICHA_lblDireccion.AutoSize = True
        Me.FICHA_lblDireccion.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblDireccion.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblDireccion.Location = New System.Drawing.Point(117, 254)
        Me.FICHA_lblDireccion.Name = "FICHA_lblDireccion"
        Me.FICHA_lblDireccion.Size = New System.Drawing.Size(63, 17)
        Me.FICHA_lblDireccion.TabIndex = 35
        Me.FICHA_lblDireccion.Text = "Dirección:"
        '
        'FICHA_lblFNacimiento
        '
        Me.FICHA_lblFNacimiento.AutoSize = True
        Me.FICHA_lblFNacimiento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblFNacimiento.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblFNacimiento.Location = New System.Drawing.Point(117, 225)
        Me.FICHA_lblFNacimiento.Name = "FICHA_lblFNacimiento"
        Me.FICHA_lblFNacimiento.Size = New System.Drawing.Size(127, 17)
        Me.FICHA_lblFNacimiento.TabIndex = 34
        Me.FICHA_lblFNacimiento.Text = "Fecha de nacimiento:"
        '
        'FICHA_lblSexo
        '
        Me.FICHA_lblSexo.AutoSize = True
        Me.FICHA_lblSexo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblSexo.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblSexo.Location = New System.Drawing.Point(118, 196)
        Me.FICHA_lblSexo.Name = "FICHA_lblSexo"
        Me.FICHA_lblSexo.Size = New System.Drawing.Size(37, 17)
        Me.FICHA_lblSexo.TabIndex = 33
        Me.FICHA_lblSexo.Text = "Sexo:"
        '
        'FICHA_lblContraseña
        '
        Me.FICHA_lblContraseña.AutoSize = True
        Me.FICHA_lblContraseña.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblContraseña.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblContraseña.Location = New System.Drawing.Point(117, 167)
        Me.FICHA_lblContraseña.Name = "FICHA_lblContraseña"
        Me.FICHA_lblContraseña.Size = New System.Drawing.Size(75, 17)
        Me.FICHA_lblContraseña.TabIndex = 32
        Me.FICHA_lblContraseña.Text = "Contraseña:"
        '
        'FICHA_lblApellido
        '
        Me.FICHA_lblApellido.AutoSize = True
        Me.FICHA_lblApellido.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblApellido.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblApellido.Location = New System.Drawing.Point(117, 138)
        Me.FICHA_lblApellido.Name = "FICHA_lblApellido"
        Me.FICHA_lblApellido.Size = New System.Drawing.Size(56, 17)
        Me.FICHA_lblApellido.TabIndex = 31
        Me.FICHA_lblApellido.Text = "Apellido:"
        '
        'FICHA_lblNombre
        '
        Me.FICHA_lblNombre.AutoSize = True
        Me.FICHA_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblNombre.Location = New System.Drawing.Point(117, 109)
        Me.FICHA_lblNombre.Name = "FICHA_lblNombre"
        Me.FICHA_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.FICHA_lblNombre.TabIndex = 30
        Me.FICHA_lblNombre.Text = "Nombre:"
        '
        'FICHA_txtDocumento
        '
        Me.FICHA_txtDocumento.BackColor = System.Drawing.Color.White
        Me.FICHA_txtDocumento.Enabled = False
        Me.FICHA_txtDocumento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtDocumento.Location = New System.Drawing.Point(279, 78)
        Me.FICHA_txtDocumento.Name = "FICHA_txtDocumento"
        Me.FICHA_txtDocumento.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtDocumento.TabIndex = 29
        '
        'FICHA_lblDocumento
        '
        Me.FICHA_lblDocumento.AutoSize = True
        Me.FICHA_lblDocumento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblDocumento.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblDocumento.Location = New System.Drawing.Point(117, 80)
        Me.FICHA_lblDocumento.Name = "FICHA_lblDocumento"
        Me.FICHA_lblDocumento.Size = New System.Drawing.Size(76, 17)
        Me.FICHA_lblDocumento.TabIndex = 28
        Me.FICHA_lblDocumento.Text = "Documento:"
        '
        'TabPageOrganizacion
        '
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_dpFIngreso)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_cbGrado)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtMailEmpresarial)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtTlfEmpresarial)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtDepartamento)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtCargo)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtNRegistro)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblEmailEmpresarial)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblTelfEmpresarial)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblDepartamento)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblGrado)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblCargo)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblFIngreso)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblNRegistro)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtRUT)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblRUT)
        Me.TabPageOrganizacion.Controls.Add(Me.Button2)
        Me.TabPageOrganizacion.Location = New System.Drawing.Point(4, 58)
        Me.TabPageOrganizacion.Name = "TabPageOrganizacion"
        Me.TabPageOrganizacion.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageOrganizacion.Size = New System.Drawing.Size(808, 355)
        Me.TabPageOrganizacion.TabIndex = 1
        Me.TabPageOrganizacion.Text = "TabPage2"
        Me.TabPageOrganizacion.UseVisualStyleBackColor = True
        '
        'ORG_dpFIngreso
        '
        Me.ORG_dpFIngreso.CustomFormat = "yyyy-MM-dd"
        Me.ORG_dpFIngreso.Enabled = False
        Me.ORG_dpFIngreso.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ORG_dpFIngreso.Location = New System.Drawing.Point(279, 136)
        Me.ORG_dpFIngreso.Name = "ORG_dpFIngreso"
        Me.ORG_dpFIngreso.Size = New System.Drawing.Size(132, 20)
        Me.ORG_dpFIngreso.TabIndex = 70
        '
        'ORG_cbGrado
        '
        Me.ORG_cbGrado.Enabled = False
        Me.ORG_cbGrado.FormattingEnabled = True
        Me.ORG_cbGrado.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.ORG_cbGrado.Location = New System.Drawing.Point(279, 194)
        Me.ORG_cbGrado.Name = "ORG_cbGrado"
        Me.ORG_cbGrado.Size = New System.Drawing.Size(132, 21)
        Me.ORG_cbGrado.TabIndex = 69
        '
        'ORG_txtMailEmpresarial
        '
        Me.ORG_txtMailEmpresarial.BackColor = System.Drawing.Color.White
        Me.ORG_txtMailEmpresarial.Enabled = False
        Me.ORG_txtMailEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtMailEmpresarial.Location = New System.Drawing.Point(279, 281)
        Me.ORG_txtMailEmpresarial.Name = "ORG_txtMailEmpresarial"
        Me.ORG_txtMailEmpresarial.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtMailEmpresarial.TabIndex = 67
        '
        'ORG_txtTlfEmpresarial
        '
        Me.ORG_txtTlfEmpresarial.BackColor = System.Drawing.Color.White
        Me.ORG_txtTlfEmpresarial.Enabled = False
        Me.ORG_txtTlfEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtTlfEmpresarial.Location = New System.Drawing.Point(279, 252)
        Me.ORG_txtTlfEmpresarial.Name = "ORG_txtTlfEmpresarial"
        Me.ORG_txtTlfEmpresarial.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtTlfEmpresarial.TabIndex = 66
        '
        'ORG_txtDepartamento
        '
        Me.ORG_txtDepartamento.BackColor = System.Drawing.Color.White
        Me.ORG_txtDepartamento.Enabled = False
        Me.ORG_txtDepartamento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtDepartamento.Location = New System.Drawing.Point(279, 223)
        Me.ORG_txtDepartamento.Name = "ORG_txtDepartamento"
        Me.ORG_txtDepartamento.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtDepartamento.TabIndex = 65
        '
        'ORG_txtCargo
        '
        Me.ORG_txtCargo.BackColor = System.Drawing.Color.White
        Me.ORG_txtCargo.Enabled = False
        Me.ORG_txtCargo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtCargo.Location = New System.Drawing.Point(279, 165)
        Me.ORG_txtCargo.Name = "ORG_txtCargo"
        Me.ORG_txtCargo.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtCargo.TabIndex = 63
        '
        'ORG_txtNRegistro
        '
        Me.ORG_txtNRegistro.BackColor = System.Drawing.Color.White
        Me.ORG_txtNRegistro.Enabled = False
        Me.ORG_txtNRegistro.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtNRegistro.Location = New System.Drawing.Point(279, 107)
        Me.ORG_txtNRegistro.Name = "ORG_txtNRegistro"
        Me.ORG_txtNRegistro.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtNRegistro.TabIndex = 61
        '
        'ORG_lblEmailEmpresarial
        '
        Me.ORG_lblEmailEmpresarial.AutoSize = True
        Me.ORG_lblEmailEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblEmailEmpresarial.Location = New System.Drawing.Point(117, 283)
        Me.ORG_lblEmailEmpresarial.Name = "ORG_lblEmailEmpresarial"
        Me.ORG_lblEmailEmpresarial.Size = New System.Drawing.Size(111, 17)
        Me.ORG_lblEmailEmpresarial.TabIndex = 60
        Me.ORG_lblEmailEmpresarial.Text = "Email empresarial:"
        '
        'ORG_lblTelfEmpresarial
        '
        Me.ORG_lblTelfEmpresarial.AutoSize = True
        Me.ORG_lblTelfEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblTelfEmpresarial.Location = New System.Drawing.Point(117, 254)
        Me.ORG_lblTelfEmpresarial.Name = "ORG_lblTelfEmpresarial"
        Me.ORG_lblTelfEmpresarial.Size = New System.Drawing.Size(128, 17)
        Me.ORG_lblTelfEmpresarial.TabIndex = 59
        Me.ORG_lblTelfEmpresarial.Text = "Telefono empresarial:"
        '
        'ORG_lblDepartamento
        '
        Me.ORG_lblDepartamento.AutoSize = True
        Me.ORG_lblDepartamento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblDepartamento.Location = New System.Drawing.Point(117, 225)
        Me.ORG_lblDepartamento.Name = "ORG_lblDepartamento"
        Me.ORG_lblDepartamento.Size = New System.Drawing.Size(92, 17)
        Me.ORG_lblDepartamento.TabIndex = 58
        Me.ORG_lblDepartamento.Text = "Departamento:"
        '
        'ORG_lblGrado
        '
        Me.ORG_lblGrado.AutoSize = True
        Me.ORG_lblGrado.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblGrado.Location = New System.Drawing.Point(117, 196)
        Me.ORG_lblGrado.Name = "ORG_lblGrado"
        Me.ORG_lblGrado.Size = New System.Drawing.Size(44, 17)
        Me.ORG_lblGrado.TabIndex = 57
        Me.ORG_lblGrado.Text = "Grado:"
        '
        'ORG_lblCargo
        '
        Me.ORG_lblCargo.AutoSize = True
        Me.ORG_lblCargo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblCargo.Location = New System.Drawing.Point(117, 167)
        Me.ORG_lblCargo.Name = "ORG_lblCargo"
        Me.ORG_lblCargo.Size = New System.Drawing.Size(44, 17)
        Me.ORG_lblCargo.TabIndex = 56
        Me.ORG_lblCargo.Text = "Cargo:"
        '
        'ORG_lblFIngreso
        '
        Me.ORG_lblFIngreso.AutoSize = True
        Me.ORG_lblFIngreso.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblFIngreso.Location = New System.Drawing.Point(117, 138)
        Me.ORG_lblFIngreso.Name = "ORG_lblFIngreso"
        Me.ORG_lblFIngreso.Size = New System.Drawing.Size(106, 17)
        Me.ORG_lblFIngreso.TabIndex = 55
        Me.ORG_lblFIngreso.Text = "Fecha de ingreso:"
        '
        'ORG_lblNRegistro
        '
        Me.ORG_lblNRegistro.AutoSize = True
        Me.ORG_lblNRegistro.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblNRegistro.Location = New System.Drawing.Point(117, 109)
        Me.ORG_lblNRegistro.Name = "ORG_lblNRegistro"
        Me.ORG_lblNRegistro.Size = New System.Drawing.Size(117, 17)
        Me.ORG_lblNRegistro.TabIndex = 54
        Me.ORG_lblNRegistro.Text = "Número de registro:"
        '
        'ORG_txtRUT
        '
        Me.ORG_txtRUT.BackColor = System.Drawing.Color.White
        Me.ORG_txtRUT.Enabled = False
        Me.ORG_txtRUT.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtRUT.Location = New System.Drawing.Point(279, 78)
        Me.ORG_txtRUT.Name = "ORG_txtRUT"
        Me.ORG_txtRUT.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtRUT.TabIndex = 53
        '
        'ORG_lblRUT
        '
        Me.ORG_lblRUT.AutoSize = True
        Me.ORG_lblRUT.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblRUT.Location = New System.Drawing.Point(117, 80)
        Me.ORG_lblRUT.Name = "ORG_lblRUT"
        Me.ORG_lblRUT.Size = New System.Drawing.Size(33, 17)
        Me.ORG_lblRUT.TabIndex = 52
        Me.ORG_lblRUT.Text = "RUT:"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(7, 8)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(354, 53)
        Me.Button2.TabIndex = 68
        Me.Button2.Text = "Información Empresarial"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'TabPageHLaboral
        '
        Me.TabPageHLaboral.Location = New System.Drawing.Point(4, 58)
        Me.TabPageHLaboral.Name = "TabPageHLaboral"
        Me.TabPageHLaboral.Size = New System.Drawing.Size(808, 355)
        Me.TabPageHLaboral.TabIndex = 2
        Me.TabPageHLaboral.Text = "TabPage1"
        Me.TabPageHLaboral.UseVisualStyleBackColor = True
        '
        'TabPageHRecibos
        '
        Me.TabPageHRecibos.Location = New System.Drawing.Point(4, 58)
        Me.TabPageHRecibos.Name = "TabPageHRecibos"
        Me.TabPageHRecibos.Size = New System.Drawing.Size(808, 355)
        Me.TabPageHRecibos.TabIndex = 3
        Me.TabPageHRecibos.Text = "TabPage1"
        Me.TabPageHRecibos.UseVisualStyleBackColor = True
        '
        'Admin_VerUsuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(818, 443)
        Me.Controls.Add(Me.pnlCentral)
        Me.Controls.Add(Me.pnlBorIzq)
        Me.Controls.Add(Me.pnlBorInf)
        Me.Controls.Add(Me.pnlBorDer)
        Me.Controls.Add(Me.pnlBarraTitulo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_VerUsuario"
        Me.Text = "Admin_VerUsuario"
        Me.pnlBarraTitulo.ResumeLayout(False)
        Me.pnlCentral.ResumeLayout(False)
        Me.pnlBotones.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.TabControlPrincipal.ResumeLayout(False)
        Me.TabPageFicha.ResumeLayout(False)
        Me.TabPageFicha.PerformLayout()
        Me.TabPageOrganizacion.ResumeLayout(False)
        Me.TabPageOrganizacion.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlBarraTitulo As System.Windows.Forms.Panel
    Friend WithEvents pnlBorDer As System.Windows.Forms.Panel
    Friend WithEvents pnlBorInf As System.Windows.Forms.Panel
    Friend WithEvents pnlBorIzq As System.Windows.Forms.Panel
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents pnlCentral As System.Windows.Forms.Panel
    Friend WithEvents pnlBotones As System.Windows.Forms.Panel
    Friend WithEvents TabControlPrincipal As System.Windows.Forms.TabControl
    Friend WithEvents TabPageFicha As System.Windows.Forms.TabPage
    Friend WithEvents TabPageOrganizacion As System.Windows.Forms.TabPage
    Friend WithEvents btnHRecibos As System.Windows.Forms.Button
    Friend WithEvents btnHLaboral As System.Windows.Forms.Button
    Friend WithEvents btnOrganizacion As System.Windows.Forms.Button
    Friend WithEvents btnFicha As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents pnlS_Ficha As System.Windows.Forms.Panel
    Friend WithEvents TabPageHLaboral As System.Windows.Forms.TabPage
    Friend WithEvents TabPageHRecibos As System.Windows.Forms.TabPage
    Friend WithEvents BtnModificar As System.Windows.Forms.Button
    Friend WithEvents FICHA_txtDirNumero As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents inftrabajador As System.Windows.Forms.Button
    Friend WithEvents FICHA_txtFijo As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtCelular As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtHijos As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtCalle As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtContraseña As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtApellido As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_lblFijo As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblCelular As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblHijos As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblEmail As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblEstCivil As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblDireccion As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblFNacimiento As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblSexo As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblContraseña As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblApellido As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblNombre As System.Windows.Forms.Label
    Friend WithEvents FICHA_txtDocumento As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_lblDocumento As System.Windows.Forms.Label
    Friend WithEvents ORG_txtMailEmpresarial As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtTlfEmpresarial As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtDepartamento As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtCargo As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtNRegistro As System.Windows.Forms.TextBox
    Friend WithEvents ORG_lblEmailEmpresarial As System.Windows.Forms.Label
    Friend WithEvents ORG_lblTelfEmpresarial As System.Windows.Forms.Label
    Friend WithEvents ORG_lblDepartamento As System.Windows.Forms.Label
    Friend WithEvents ORG_lblGrado As System.Windows.Forms.Label
    Friend WithEvents ORG_lblCargo As System.Windows.Forms.Label
    Friend WithEvents ORG_lblFIngreso As System.Windows.Forms.Label
    Friend WithEvents ORG_lblNRegistro As System.Windows.Forms.Label
    Friend WithEvents ORG_txtRUT As System.Windows.Forms.TextBox
    Friend WithEvents ORG_lblRUT As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents btnGuardarMods As System.Windows.Forms.Button
    Friend WithEvents FICHA_dpFNac As System.Windows.Forms.DateTimePicker
    Friend WithEvents FICHA_cbEstCivil As System.Windows.Forms.ComboBox
    Friend WithEvents FICHA_cbSexo As System.Windows.Forms.ComboBox
    Friend WithEvents ORG_dpFIngreso As System.Windows.Forms.DateTimePicker
    Friend WithEvents ORG_cbGrado As System.Windows.Forms.ComboBox
End Class
