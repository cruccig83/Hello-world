﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class Admin_ConfigEmpleados
    Dim cnn As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim dr As DataRow
    Dim dataadapter As MySqlDataAdapter
    Dim dataset As New DataSet
    Dim comma As MySqlCommand
    Dim da As MySqlDataAdapter
    Dim sw As Boolean = False

    Private Sub adminEmpleadosAdmin_inicio_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Dock = DockStyle.Fill
        TabControl_AdministrarEmpleados.Dock = DockStyle.Fill

        AddUser_txtContraseña.UseSystemPasswordChar = True

    End Sub

    Private Sub btnAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregar.Click
        TabControl_AdministrarEmpleados.SelectedTab = TabPage_Agregar

        btnAgregar.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnAgregar.Image = My.Resources.add_user_rojo
        btnEliminar.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnEliminar.Image = My.Resources.del_user_gris
        btnListar.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnListar.Image = My.Resources.list_user_gris

        pnlSelection.Width = btnAgregar.Width
        pnlSelection.Location = New Point(btnAgregar.Location.X, pnlSelection.Location.Y)
    End Sub

    

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        TabControl_AdministrarEmpleados.SelectedTab = TabPage_Eliminar

        btnAgregar.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnAgregar.Image = My.Resources.add_user_gris
        btnEliminar.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnEliminar.Image = My.Resources.del_user_rojo
        btnListar.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnListar.Image = My.Resources.list_user_gris

        pnlSelection.Width = btnEliminar.Width
        pnlSelection.Location = New Point(btnEliminar.Location.X, pnlSelection.Location.Y)
    End Sub

    Private Sub btnListar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnListar.Click
        TabControl_AdministrarEmpleados.SelectedTab = TabPage_Listar

        btnAgregar.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnAgregar.Image = My.Resources.add_user_gris
        btnEliminar.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnEliminar.Image = My.Resources.del_user_gris
        btnListar.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnListar.Image = My.Resources.list_user_rojo

        pnlSelection.Width = btnListar.Width
        pnlSelection.Location = New Point(btnListar.Location.X, pnlSelection.Location.Y)
    End Sub

    Private Sub AddUser_btnAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddUser_btnAgregar.Click
        Dim adduser_rol As Integer
        Dim ms As New MemoryStream
        AddUser_pbFoto.Image.Save(ms, AddUser_pbFoto.Image.RawFormat)

        If AddUser_rbAdmin.Checked Then
            adduser_rol = 1
        ElseIf AddUser_rbUsuario.Checked Then
            adduser_rol = 2
        Else
            MsgBox("Debe seleccionar si el nuevo empleado es usuario o administrador.")
        End If
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Try
            Dim Query As String
            Query = "insert into Personal (rol, doc, nombre, apellido, passwd, sexo, f_nac, estado_civil, f_ingreso, cargo, grado, dpto, email, email_empr, tlf_empr, calle, numero, 2nombre, 2apellido, activo, foto) values(" & adduser_rol & ", " & AddUser_txtDocumento.Text & ", '" & AddUser_txtNombre.Text & "', '" & AddUser_txtApellido.Text & "', " & AddUser_txtContraseña.Text & ", '" & AddUser_cbSexo.Text & "', '" & AddUser_dateFNacimiento.Text & "', '" & AddUser_cbEstCivil.Text & "', '" & AddUser_dateFIngreso.Text & "', '" & AddUser_txtCargo.Text & "', " & AddUser_cbGrado.Text & ", '" & AddUser_txtDepartamento.Text & "', '" & AddUser_txtEmail.Text & "', '" & AddUser_txtMailEmpresarial.Text & "', " & AddUser_txtTlfEmpresarial.Text & ", '" & AddUser_txtDirCalle.Text & "', " & AddUser_txtDirNumero.Text & ", '" & AddUser_txt2Nombre.Text & "', '" & AddUser_txt2apellido.Text & "', 's', @img )"
            cnn.Open()
            Dim cmd As New MySqlCommand
            cmd = New MySqlCommand(Query, cnn)
            cmd.Parameters.Add("@img", MySqlDbType.Blob).Value = ms.ToArray()

            cmd.ExecuteNonQuery()
            MessageBox.Show("Usuario guardado")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    
    

    Private Sub TabPage_Listar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage_Listar.Click

    End Sub

    Private Sub ListUser_btnBuscPorDocumento_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListUser_btnBuscPorDocumento.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE doc = '" & ListUser_txtBuscPorDocumento.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            Dim Dt As New DataTable
            Dim da As New MySqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(Dt)
            ListUser_DataGrid.DataSource = Dt

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

        If ListUser_DataGrid.RowCount > 1 Then
            ListUser_DataGrid.Visible = True

        Else
            MsgBox("Documento del usuario incorrecto")
        End If
    End Sub

    

    Private Sub ListUser_btnBuscPorRegistro_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListUser_btnBuscPorRegistro.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE persona_id = '" & ListUser_txtBuscPorRegistro.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            Dim Dt As New DataTable
            Dim da As New MySqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(Dt)
            ListUser_DataGrid.DataSource = Dt

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

        If ListUser_DataGrid.RowCount > 1 Then
            ListUser_DataGrid.Visible = True

        Else
            MsgBox("Numero de registro incorrecto")
        End If
    End Sub

   

    Private Sub ListUser_btnBuscPorNombre_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListUser_btnBuscPorNombre.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE (nombre = '" & ListUser_txtBuscPorNombre.Text & "' OR 2nombre= '" & ListUser_txtBuscPorNombre.Text & "') AND apellido= '" & ListUser_txtBuscPorNombre_Apellido.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            Dim Dt As New DataTable
            Dim da As New MySqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(Dt)
            ListUser_DataGrid.DataSource = Dt

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

        If ListUser_DataGrid.RowCount > 1 Then
            ListUser_DataGrid.Visible = True
            

        Else
            MsgBox("Nombre y/o apellido del usuario incorrectos")
        End If
    End Sub


    Private Sub ListUser_btnVer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListUser_btnVer.Click
        Admin_VerUsuario.Show()
    End Sub

    

    Private Sub ListUser_txtBuscPorNombre_Apellido_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListUser_txtBuscPorNombre_Apellido.Click
        ListUser_txtBuscPorNombre_Apellido.ForeColor = Color.Black
        ListUser_txtBuscPorNombre_Apellido.Clear()

    End Sub

    Private Sub ListUser_txtBuscPorNombre_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListUser_txtBuscPorNombre.Click
        ListUser_txtBuscPorNombre.ForeColor = Color.Black
        ListUser_txtBuscPorNombre.Clear()

    End Sub


    
    
    Private Sub EUsuario_btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EUsuario_btnBuscar.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE doc = '" & EUsuario_txtDocumento.Text & "' AND persona_id = '" & EUsuario_txtNumRegistro.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            Dim Dt As New DataTable
            Dim da As New MySqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(Dt)
            EUsuario_DataGrid.DataSource = Dt

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

        If EUsuario_DataGrid.RowCount > 1 Then
            EUsuario_DataGrid.Visible = True
            Module1.elim_document = EUsuario_txtDocumento.Text

        Else
            MsgBox("Documento y/o Numero de registro del usuario incorrectos")
        End If


    End Sub


    Private Sub EUsuario_btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EUsuario_btnEliminar.Click

        If EUsuario_DataGrid.SelectedRows.Count > 0 Then
            Module1.elim_document = EUsuario_txtDocumento.Text
            Admin_SeguroElimUser.Show()
        Else
            MsgBox("Debe ingresar un usuario valido")
        End If

    End Sub

    Private Sub EUsuario_DataGrid_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles EUsuario_DataGrid.CellClick
        EUsuario_btnEliminar.Visible = True
    End Sub

    Dim duki As Integer

    Private Sub ListUser_DataGrid_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles ListUser_DataGrid.CellClick
        ListUser_btnVer.Visible = True

        Dim indice As Integer
        indice = e.RowIndex
        Dim FilaSeleccionada As DataGridViewRow
        FilaSeleccionada = ListUser_DataGrid.Rows(indice)
        Module1.busc_nombre = FilaSeleccionada.Cells(1).Value.ToString()

    End Sub

    
    Private Sub AddUser_txtGrado_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim opf As New OpenFileDialog
        opf.Filter = "Seleccione una imagen (*.JPG;*.JPEG;*.PNG)|*.jpg;*.jpeg;*.png"

        If opf.ShowDialog = Windows.Forms.DialogResult.OK Then
            AddUser_pbFoto.Image = Image.FromFile(opf.FileName)

        End If

    End Sub

    Private Sub ListUser_txtBuscPorNombre_Apellido_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListUser_txtBuscPorNombre_Apellido.TextChanged

    End Sub

    Private Sub ListUser_DataGrid_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles ListUser_DataGrid.CellContentClick

    End Sub
End Class