﻿Imports MySql.Data.MySqlClient
Public Class Admin_Empresa

    Private Sub Admin_Empresa_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM empresa "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.txtRUT.Text = rdr.Item("RUT").ToString
                Me.txtRazonSocial.Text = rdr.Item("razon_social").ToString
                Me.txtNFantasia.Text = rdr.Item("nombre_fantasia").ToString
                Me.txtBPS.Text = rdr.Item("BPS").ToString
                Me.txtBSE.Text = rdr.Item("BSE").ToString
                Me.txtDirCalle.Text = rdr.Item("calle").ToString
                Me.txtDirNumero.Text = rdr.Item("numero").ToString
                Me.txtNTelefono.Text = rdr.Item("telefono").ToString
                Me.txtEmail.Text = rdr.Item("mail").ToString
                Me.txtSitioWeb.Text = rdr.Item("sitioweb").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    

    Private Sub btnTabEmpresa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmpresa.Click
        btnDepartamentos.Image = My.Resources.departamentos_gris
        btnDepartamentos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnCargos.Image = My.Resources.cargos_gris
        btnCargos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnEmpresa.Image = My.Resources.empresa_roja
        btnEmpresa.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnGrados.Image = My.Resources.grados_gris
        btnGrados.ForeColor = Color.FromArgb(255, 91, 91, 91)
        TabControlEmpresaGrados.SelectedTab = EmpGra_TabPageEmpresa
        pnl_seleccionado.Width = btnEmpresa.Width
        pnl_seleccionado.Location = New Point(btnEmpresa.Location.X, pnl_seleccionado.Location.Y)

    End Sub

    Private Sub btnTabGrados_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGrados.Click
        btnDepartamentos.Image = My.Resources.departamentos_gris
        btnDepartamentos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnCargos.Image = My.Resources.cargos_gris
        btnCargos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnEmpresa.Image = My.Resources.empresa_gris
        btnEmpresa.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnDepartamentos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnGrados.Image = My.Resources.grados_rojo
        btnGrados.ForeColor = Color.FromArgb(255, 167, 37, 57)
        TabControlEmpresaGrados.SelectedTab = EmpGra_TabPageGrados
        pnl_seleccionado.Width = btnGrados.Width
        pnl_seleccionado.Location = New Point(btnGrados.Location.X, pnl_seleccionado.Location.Y)
        '------------------------------------------------------------------------------------------------
        Dim VerGRA_cnn As New MySqlConnection("data source=localhost;user id=root; password='1234';database=tax")
        Dim VerGRA_adapter As New MySqlDataAdapter("SELECT * FROM grados ", VerGRA_cnn)
        Dim VerGRA_table As New DataTable()

        VerGRA_adapter.Fill(VerGRA_table)

        VerGRA_cbGrado.DataSource = VerGRA_table
        VerGRA_cbGrado.ValueMember = "grado_id"
        VerGRA_cbGrado.DisplayMember = "grado_id"
        '---------------------------------------------------------------------------------------------------
        Dim ModGRA_cnn As New MySqlConnection("data source=localhost;user id=root; password='1234';database=tax")
        Dim ModGRA_adapter As New MySqlDataAdapter("SELECT * FROM grados ", ModGRA_cnn)
        Dim ModGRA_table As New DataTable()

        ModGRA_adapter.Fill(ModGRA_table)

        ModGRA_cbGrado.DataSource = ModGRA_table
        ModGRA_cbGrado.ValueMember = "grado_id"
        ModGRA_cbGrado.DisplayMember = "grado_id"
    End Sub

    Private Sub GRA_btnVer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GRA_btnVer.Click
        GRA_TabControlVerMod.SelectedTab = GRA_TabPageVer
        GRA_pnlSeleccionado.Width = GRA_btnVer.Width
        GRA_pnlSeleccionado.Location = New Point(GRA_btnVer.Location.X, GRA_pnlSeleccionado.Location.Y)
    End Sub

    Private Sub GRA_btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GRA_btnModificar.Click
        GRA_TabControlVerMod.SelectedTab = GRA_TabPageModificar
        GRA_pnlSeleccionado.Width = GRA_btnModificar.Width
        GRA_pnlSeleccionado.Location = New Point(GRA_btnModificar.Location.X, GRA_pnlSeleccionado.Location.Y)
    End Sub

    Private Sub btnCargos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCargos.Click
        btnDepartamentos.Image = My.Resources.departamentos_gris
        btnDepartamentos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnCargos.Image = My.Resources.cargos_rojos
        btnCargos.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnEmpresa.Image = My.Resources.empresa_gris
        btnEmpresa.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnDepartamentos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnGrados.Image = My.Resources.grados_gris
        btnGrados.ForeColor = Color.FromArgb(255, 91, 91, 91)
        TabControlEmpresaGrados.SelectedTab = EmpGra_TabPageEmpresa
        pnl_seleccionado.Width = btnCargos.Width
        pnl_seleccionado.Location = New Point(btnCargos.Location.X, pnl_seleccionado.Location.Y)
    End Sub

    Private Sub btnDepartamentos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDepartamentos.Click
        btnDepartamentos.Image = My.Resources.departamentos_rojo
        btnDepartamentos.ForeColor = Color.FromArgb(255, 167, 37, 57)
        btnCargos.Image = My.Resources.cargos_gris
        btnCargos.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnEmpresa.Image = My.Resources.empresa_gris
        btnEmpresa.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnGrados.Image = My.Resources.grados_gris
        btnGrados.ForeColor = Color.FromArgb(255, 91, 91, 91)
        pnl_seleccionado.Width = btnDepartamentos.Width
        pnl_seleccionado.Location = New Point(btnDepartamentos.Location.X, pnl_seleccionado.Location.Y)

    End Sub

    Private Sub VerGRA_cbGrado_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VerGRA_cbGrado.SelectedIndexChanged
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM grados WHERE grado_id = '" & VerGRA_cbGrado.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.VerGRA_txtSalario.Text = rdr.Item("salario").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    

    Private Sub ModGRA_cbGrado_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModGRA_cbGrado.SelectedIndexChanged
        ModGRA_txtSalario.ForeColor = Color.Silver

        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM grados WHERE grado_id = '" & ModGRA_cbGrado.Text & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ModGRA_txtSalario.Text = rdr.Item("salario").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub ModGRA_txtSalario_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ModGRA_txtSalario.Click
        ModGRA_txtSalario.Clear()
        ModGRA_txtSalario.ForeColor = Color.Black
    End Sub

    Private Sub pnlSup_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pnlSup.Paint

    End Sub
End Class