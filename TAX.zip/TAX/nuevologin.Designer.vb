﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class nuevologin
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(nuevologin))
        Me.pnlBarraDeTitulo = New System.Windows.Forms.Panel
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.txtDocumento = New System.Windows.Forms.TextBox
        Me.pnlError = New System.Windows.Forms.Panel
        Me.lblError = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.lblBIENVENIDO = New System.Windows.Forms.Button
        Me.btnentrar = New System.Windows.Forms.Button
        Me.lblContraseña = New System.Windows.Forms.Label
        Me.txtContraseña = New System.Windows.Forms.TextBox
        Me.lblDocumento = New System.Windows.Forms.Label
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.btnVerContraseña = New System.Windows.Forms.Button
        Me.PictureBox3 = New System.Windows.Forms.PictureBox
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.pbImagenTax = New System.Windows.Forms.PictureBox
        Me.btnMinimizar = New System.Windows.Forms.Button
        Me.btnclose = New System.Windows.Forms.Button
        Me.pnlBarraDeTitulo.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbImagenTax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlBarraDeTitulo
        '
        Me.pnlBarraDeTitulo.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.pnlBarraDeTitulo.Controls.Add(Me.btnMinimizar)
        Me.pnlBarraDeTitulo.Controls.Add(Me.btnclose)
        Me.pnlBarraDeTitulo.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBarraDeTitulo.Location = New System.Drawing.Point(0, 0)
        Me.pnlBarraDeTitulo.Name = "pnlBarraDeTitulo"
        Me.pnlBarraDeTitulo.Size = New System.Drawing.Size(792, 25)
        Me.pnlBarraDeTitulo.TabIndex = 0
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BackColor = System.Drawing.Color.Transparent
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(2, 25)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.Color.White
        Me.SplitContainer1.Panel1.Controls.Add(Me.txtDocumento)
        Me.SplitContainer1.Panel1.Controls.Add(Me.pnlError)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblError)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Panel4)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Panel2)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnVerContraseña)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblBIENVENIDO)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnentrar)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblContraseña)
        Me.SplitContainer1.Panel1.Controls.Add(Me.txtContraseña)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblDocumento)
        Me.SplitContainer1.Panel1.Controls.Add(Me.PictureBox3)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel5)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel3)
        Me.SplitContainer1.Panel2.Controls.Add(Me.PictureBox2)
        Me.SplitContainer1.Size = New System.Drawing.Size(789, 449)
        Me.SplitContainer1.SplitterDistance = 382
        Me.SplitContainer1.SplitterWidth = 1
        Me.SplitContainer1.TabIndex = 2
        '
        'txtDocumento
        '
        Me.txtDocumento.Location = New System.Drawing.Point(73, 218)
        Me.txtDocumento.MaxLength = 8
        Me.txtDocumento.Name = "txtDocumento"
        Me.txtDocumento.Size = New System.Drawing.Size(229, 20)
        Me.txtDocumento.TabIndex = 2
        '
        'pnlError
        '
        Me.pnlError.BackColor = System.Drawing.Color.Red
        Me.pnlError.Location = New System.Drawing.Point(72, 217)
        Me.pnlError.Name = "pnlError"
        Me.pnlError.Size = New System.Drawing.Size(231, 22)
        Me.pnlError.TabIndex = 11
        Me.pnlError.Visible = False
        '
        'lblError
        '
        Me.lblError.AutoSize = True
        Me.lblError.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblError.Location = New System.Drawing.Point(7, 215)
        Me.lblError.Name = "lblError"
        Me.lblError.Size = New System.Drawing.Size(59, 26)
        Me.lblError.TabIndex = 3
        Me.lblError.Text = "Deben ser " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "numeros." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lblError.Visible = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1, 448)
        Me.Panel4.TabIndex = 10
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 448)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(382, 1)
        Me.Panel2.TabIndex = 9
        '
        'lblBIENVENIDO
        '
        Me.lblBIENVENIDO.BackColor = System.Drawing.Color.Transparent
        Me.lblBIENVENIDO.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblBIENVENIDO.FlatAppearance.BorderSize = 0
        Me.lblBIENVENIDO.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblBIENVENIDO.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblBIENVENIDO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblBIENVENIDO.Font = New System.Drawing.Font("Myanmar Text", 36.0!, System.Drawing.FontStyle.Bold)
        Me.lblBIENVENIDO.Location = New System.Drawing.Point(20, 95)
        Me.lblBIENVENIDO.Name = "lblBIENVENIDO"
        Me.lblBIENVENIDO.Size = New System.Drawing.Size(342, 85)
        Me.lblBIENVENIDO.TabIndex = 8
        Me.lblBIENVENIDO.Text = "BIENVENIDO"
        Me.lblBIENVENIDO.UseVisualStyleBackColor = False
        '
        'btnentrar
        '
        Me.btnentrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(84, Byte), Integer), CType(CType(8, Byte), Integer), CType(CType(164, Byte), Integer))
        Me.btnentrar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(147, Byte), Integer))
        Me.btnentrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(142, Byte), Integer))
        Me.btnentrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(142, Byte), Integer))
        Me.btnentrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnentrar.Font = New System.Drawing.Font("Berlin Sans FB Demi", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnentrar.ForeColor = System.Drawing.Color.White
        Me.btnentrar.Location = New System.Drawing.Point(77, 335)
        Me.btnentrar.Name = "btnentrar"
        Me.btnentrar.Size = New System.Drawing.Size(225, 29)
        Me.btnentrar.TabIndex = 1
        Me.btnentrar.Text = "ENTRAR"
        Me.btnentrar.UseVisualStyleBackColor = False
        '
        'lblContraseña
        '
        Me.lblContraseña.AutoSize = True
        Me.lblContraseña.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContraseña.Location = New System.Drawing.Point(74, 243)
        Me.lblContraseña.Name = "lblContraseña"
        Me.lblContraseña.Size = New System.Drawing.Size(75, 17)
        Me.lblContraseña.TabIndex = 5
        Me.lblContraseña.Text = "Contraseña:"
        '
        'txtContraseña
        '
        Me.txtContraseña.Location = New System.Drawing.Point(73, 263)
        Me.txtContraseña.Name = "txtContraseña"
        Me.txtContraseña.Size = New System.Drawing.Size(229, 20)
        Me.txtContraseña.TabIndex = 3
        '
        'lblDocumento
        '
        Me.lblDocumento.AutoSize = True
        Me.lblDocumento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDocumento.Location = New System.Drawing.Point(74, 198)
        Me.lblDocumento.Name = "lblDocumento"
        Me.lblDocumento.Size = New System.Drawing.Size(76, 17)
        Me.lblDocumento.TabIndex = 4
        Me.lblDocumento.Text = "Documento:"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel5.Location = New System.Drawing.Point(405, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1, 448)
        Me.Panel5.TabIndex = 2
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(0, 448)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(406, 1)
        Me.Panel3.TabIndex = 1
        '
        'btnVerContraseña
        '
        Me.btnVerContraseña.BackColor = System.Drawing.Color.White
        Me.btnVerContraseña.FlatAppearance.BorderSize = 0
        Me.btnVerContraseña.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVerContraseña.Image = Global.TAX.My.Resources.Resources.ver_16
        Me.btnVerContraseña.Location = New System.Drawing.Point(308, 261)
        Me.btnVerContraseña.Name = "btnVerContraseña"
        Me.btnVerContraseña.Size = New System.Drawing.Size(25, 25)
        Me.btnVerContraseña.TabIndex = 4
        Me.btnVerContraseña.UseVisualStyleBackColor = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox3.Image = Global.TAX.My.Resources.Resources.Fondo_logos
        Me.PictureBox3.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(382, 449)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 7
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(1, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(403, 449)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'pbImagenTax
        '
        Me.pbImagenTax.BackgroundImage = CType(resources.GetObject("pbImagenTax.BackgroundImage"), System.Drawing.Image)
        Me.pbImagenTax.Image = CType(resources.GetObject("pbImagenTax.Image"), System.Drawing.Image)
        Me.pbImagenTax.Location = New System.Drawing.Point(0, 25)
        Me.pbImagenTax.Name = "pbImagenTax"
        Me.pbImagenTax.Size = New System.Drawing.Size(792, 449)
        Me.pbImagenTax.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbImagenTax.TabIndex = 1
        Me.pbImagenTax.TabStop = False
        '
        'btnMinimizar
        '
        Me.btnMinimizar.FlatAppearance.BorderSize = 0
        Me.btnMinimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinimizar.Image = Global.TAX.My.Resources.Resources.minimize_
        Me.btnMinimizar.Location = New System.Drawing.Point(718, 0)
        Me.btnMinimizar.Name = "btnMinimizar"
        Me.btnMinimizar.Size = New System.Drawing.Size(37, 25)
        Me.btnMinimizar.TabIndex = 8
        Me.btnMinimizar.UseVisualStyleBackColor = True
        '
        'btnclose
        '
        Me.btnclose.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnclose.FlatAppearance.BorderSize = 0
        Me.btnclose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red
        Me.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnclose.Image = Global.TAX.My.Resources.Resources.close_16
        Me.btnclose.Location = New System.Drawing.Point(755, 0)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(37, 25)
        Me.btnclose.TabIndex = 7
        Me.btnclose.UseVisualStyleBackColor = False
        '
        'nuevologin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(792, 474)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.pbImagenTax)
        Me.Controls.Add(Me.pnlBarraDeTitulo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "nuevologin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "nuevologin"
        Me.pnlBarraDeTitulo.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbImagenTax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlBarraDeTitulo As System.Windows.Forms.Panel
    Friend WithEvents pbImagenTax As System.Windows.Forms.PictureBox
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents btnentrar As System.Windows.Forms.Button
    Friend WithEvents txtContraseña As System.Windows.Forms.TextBox
    Friend WithEvents txtDocumento As System.Windows.Forms.TextBox
    Friend WithEvents lblDocumento As System.Windows.Forms.Label
    Friend WithEvents lblContraseña As System.Windows.Forms.Label
    Friend WithEvents lblBIENVENIDO As System.Windows.Forms.Button
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents btnVerContraseña As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents lblError As System.Windows.Forms.Label
    Friend WithEvents pnlError As System.Windows.Forms.Panel
    Friend WithEvents btnMinimizar As System.Windows.Forms.Button
    Friend WithEvents btnclose As System.Windows.Forms.Button
End Class
