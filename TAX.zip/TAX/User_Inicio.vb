﻿Public Class User_Inicio

    

    Private Sub pbRecibo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbRecibo.Click
        User_Principal.btnrecibo.PerformClick()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        User_Principal.btnficha.PerformClick()
    End Sub

    Private Sub pbHlaboral_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbHlaboral.Click
        User_Principal.btnhlaboral.PerformClick()
    End Sub
End Class