﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class User_HistLaboral
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelizq = New System.Windows.Forms.Panel
        Me.panelder = New System.Windows.Forms.Panel
        Me.paneldown = New System.Windows.Forms.Panel
        Me.panelup = New System.Windows.Forms.Panel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelizq
        '
        Me.panelizq.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.panelizq.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelizq.Location = New System.Drawing.Point(0, 20)
        Me.panelizq.Name = "panelizq"
        Me.panelizq.Size = New System.Drawing.Size(13, 469)
        Me.panelizq.TabIndex = 7
        '
        'panelder
        '
        Me.panelder.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.panelder.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelder.Location = New System.Drawing.Point(829, 20)
        Me.panelder.Name = "panelder"
        Me.panelder.Size = New System.Drawing.Size(13, 469)
        Me.panelder.TabIndex = 6
        '
        'paneldown
        '
        Me.paneldown.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.paneldown.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.paneldown.Location = New System.Drawing.Point(0, 489)
        Me.paneldown.Name = "paneldown"
        Me.paneldown.Size = New System.Drawing.Size(842, 20)
        Me.paneldown.TabIndex = 5
        '
        'panelup
        '
        Me.panelup.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.panelup.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelup.Location = New System.Drawing.Point(0, 0)
        Me.panelup.Name = "panelup"
        Me.panelup.Size = New System.Drawing.Size(842, 20)
        Me.panelup.TabIndex = 4
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(13, 20)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(816, 469)
        Me.Panel1.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tw Cen MT", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(253, 43)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Historia Laboral"
        '
        'iniciouserhistorialaboral
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(842, 509)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.panelizq)
        Me.Controls.Add(Me.panelder)
        Me.Controls.Add(Me.paneldown)
        Me.Controls.Add(Me.panelup)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "iniciouserhistorialaboral"
        Me.Text = "iniciouserhistorialaboral"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelizq As System.Windows.Forms.Panel
    Friend WithEvents panelder As System.Windows.Forms.Panel
    Friend WithEvents paneldown As System.Windows.Forms.Panel
    Friend WithEvents panelup As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
