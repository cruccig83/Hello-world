﻿Public Class Admin_Inicio


    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerFicha.Click
        Admin_Principal.btnficha.PerformClick()
    End Sub

    
    Private Sub pbEmpleados_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbEmpleados.Click
        Admin_Principal.btnadminempleados.PerformClick()
    End Sub

    Private Sub pbLiqSueldos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbLiqSueldos.Click
        Admin_Principal.btnliqsueldos.PerformClick()
    End Sub
End Class