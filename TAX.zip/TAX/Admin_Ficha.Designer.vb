﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Ficha
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Ficha))
        Me.panel_izq2 = New System.Windows.Forms.Panel
        Me.panel_up = New System.Windows.Forms.Panel
        Me.panel_down2 = New System.Windows.Forms.Panel
        Me.panel_der = New System.Windows.Forms.Panel
        Me.TabControl_FichaAdmin = New System.Windows.Forms.TabControl
        Me.TabPageFicha = New System.Windows.Forms.TabPage
        Me.FICHA_btnCambiarContraseña = New System.Windows.Forms.Button
        Me.Label23 = New System.Windows.Forms.Label
        Me.inftrabajador = New System.Windows.Forms.Button
        Me.FICHA_txtFijo = New System.Windows.Forms.TextBox
        Me.FICHA_txtCelular = New System.Windows.Forms.TextBox
        Me.FICHA_txtHijos = New System.Windows.Forms.TextBox
        Me.FICHA_txtEmail = New System.Windows.Forms.TextBox
        Me.FICHA_txtEstCivil = New System.Windows.Forms.TextBox
        Me.FICHA_txtCalle = New System.Windows.Forms.TextBox
        Me.FICHA_txtFNacimiento = New System.Windows.Forms.TextBox
        Me.FICHA_txtSexo = New System.Windows.Forms.TextBox
        Me.FICHA_txtContraseña = New System.Windows.Forms.TextBox
        Me.FICHA_txtApellido = New System.Windows.Forms.TextBox
        Me.FICHA_txtNombre = New System.Windows.Forms.TextBox
        Me.FICHA_lblFijo = New System.Windows.Forms.Label
        Me.FICHA_lblCelular = New System.Windows.Forms.Label
        Me.FICHA_lblHijos = New System.Windows.Forms.Label
        Me.FICHA_lblEmail = New System.Windows.Forms.Label
        Me.FICHA_lblEstCivil = New System.Windows.Forms.Label
        Me.FICHA_lblDireccion = New System.Windows.Forms.Label
        Me.FICHA_lblFNacimiento = New System.Windows.Forms.Label
        Me.FICHA_lblSexo = New System.Windows.Forms.Label
        Me.FICHA_lblContraseña = New System.Windows.Forms.Label
        Me.FICHA_lblApellido = New System.Windows.Forms.Label
        Me.FICHA_lblNombre = New System.Windows.Forms.Label
        Me.FICHA_txtDocumento = New System.Windows.Forms.TextBox
        Me.FICHA_lblDocumento = New System.Windows.Forms.Label
        Me.TabPageOrganizacion = New System.Windows.Forms.TabPage
        Me.Label24 = New System.Windows.Forms.Label
        Me.ORG_txtMailEmpresarial = New System.Windows.Forms.TextBox
        Me.ORG_txtTlfEmpresarial = New System.Windows.Forms.TextBox
        Me.ORG_txtDepartamento = New System.Windows.Forms.TextBox
        Me.ORG_txtGrado = New System.Windows.Forms.TextBox
        Me.ORG_txtCargo = New System.Windows.Forms.TextBox
        Me.ORG_txtFIngreso = New System.Windows.Forms.TextBox
        Me.ORG_txtNRegistro = New System.Windows.Forms.TextBox
        Me.ORG_lblEmailEmpresarial = New System.Windows.Forms.Label
        Me.ORG_lblTelfEmpresarial = New System.Windows.Forms.Label
        Me.ORG_lblDepartamento = New System.Windows.Forms.Label
        Me.ORG_lblGrado = New System.Windows.Forms.Label
        Me.ORG_lblCargo = New System.Windows.Forms.Label
        Me.ORG_lblFIngreso = New System.Windows.Forms.Label
        Me.ORG_lblNRegistro = New System.Windows.Forms.Label
        Me.ORG_txtRUT = New System.Windows.Forms.TextBox
        Me.ORG_lblRUT = New System.Windows.Forms.Label
        Me.ORG_lblInInformacionEmpresarial = New System.Windows.Forms.Button
        Me.TabPageHrecibos = New System.Windows.Forms.TabPage
        Me.Label1 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.TabPageHLaboral = New System.Windows.Forms.TabPage
        Me.HLaboral_lblEstamos = New System.Windows.Forms.Label
        Me.HLaboral_pbTractor = New System.Windows.Forms.PictureBox
        Me.pnlBotones = New System.Windows.Forms.Panel
        Me.pnlBotonesGris = New System.Windows.Forms.Panel
        Me.pnlSelection = New System.Windows.Forms.Panel
        Me.pnlGris = New System.Windows.Forms.Panel
        Me.btnHRecibos = New System.Windows.Forms.Button
        Me.btnHLaboral = New System.Windows.Forms.Button
        Me.btnOrganizacion = New System.Windows.Forms.Button
        Me.btnFicha = New System.Windows.Forms.Button
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.TabControl_FichaAdmin.SuspendLayout()
        Me.TabPageFicha.SuspendLayout()
        Me.TabPageOrganizacion.SuspendLayout()
        Me.TabPageHrecibos.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageHLaboral.SuspendLayout()
        CType(Me.HLaboral_pbTractor, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlBotones.SuspendLayout()
        Me.pnlBotonesGris.SuspendLayout()
        Me.SuspendLayout()
        '
        'panel_izq2
        '
        Me.panel_izq2.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.panel_izq2.Dock = System.Windows.Forms.DockStyle.Left
        Me.panel_izq2.Location = New System.Drawing.Point(0, 20)
        Me.panel_izq2.Name = "panel_izq2"
        Me.panel_izq2.Size = New System.Drawing.Size(20, 442)
        Me.panel_izq2.TabIndex = 8
        '
        'panel_up
        '
        Me.panel_up.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.panel_up.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel_up.Location = New System.Drawing.Point(0, 0)
        Me.panel_up.Name = "panel_up"
        Me.panel_up.Size = New System.Drawing.Size(814, 20)
        Me.panel_up.TabIndex = 10
        '
        'panel_down2
        '
        Me.panel_down2.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.panel_down2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panel_down2.Location = New System.Drawing.Point(0, 462)
        Me.panel_down2.Name = "panel_down2"
        Me.panel_down2.Size = New System.Drawing.Size(814, 20)
        Me.panel_down2.TabIndex = 9
        '
        'panel_der
        '
        Me.panel_der.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.panel_der.Dock = System.Windows.Forms.DockStyle.Right
        Me.panel_der.Location = New System.Drawing.Point(814, 0)
        Me.panel_der.Name = "panel_der"
        Me.panel_der.Size = New System.Drawing.Size(20, 482)
        Me.panel_der.TabIndex = 7
        '
        'TabControl_FichaAdmin
        '
        Me.TabControl_FichaAdmin.Controls.Add(Me.TabPageFicha)
        Me.TabControl_FichaAdmin.Controls.Add(Me.TabPageOrganizacion)
        Me.TabControl_FichaAdmin.Controls.Add(Me.TabPageHrecibos)
        Me.TabControl_FichaAdmin.Controls.Add(Me.TabPageHLaboral)
        Me.TabControl_FichaAdmin.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl_FichaAdmin.ItemSize = New System.Drawing.Size(77, 53)
        Me.TabControl_FichaAdmin.Location = New System.Drawing.Point(26, 26)
        Me.TabControl_FichaAdmin.Name = "TabControl_FichaAdmin"
        Me.TabControl_FichaAdmin.SelectedIndex = 0
        Me.TabControl_FichaAdmin.Size = New System.Drawing.Size(785, 436)
        Me.TabControl_FichaAdmin.TabIndex = 11
        '
        'TabPageFicha
        '
        Me.TabPageFicha.AutoScroll = True
        Me.TabPageFicha.Controls.Add(Me.FICHA_btnCambiarContraseña)
        Me.TabPageFicha.Controls.Add(Me.Label23)
        Me.TabPageFicha.Controls.Add(Me.inftrabajador)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtFijo)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtCelular)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtHijos)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtEmail)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtEstCivil)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtCalle)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtFNacimiento)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtSexo)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtContraseña)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtApellido)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtNombre)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblFijo)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblCelular)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblHijos)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblEmail)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblEstCivil)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblDireccion)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblFNacimiento)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblSexo)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblContraseña)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblApellido)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblNombre)
        Me.TabPageFicha.Controls.Add(Me.FICHA_txtDocumento)
        Me.TabPageFicha.Controls.Add(Me.FICHA_lblDocumento)
        Me.TabPageFicha.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageFicha.ForeColor = System.Drawing.Color.Black
        Me.TabPageFicha.Location = New System.Drawing.Point(4, 57)
        Me.TabPageFicha.Name = "TabPageFicha"
        Me.TabPageFicha.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageFicha.Size = New System.Drawing.Size(777, 375)
        Me.TabPageFicha.TabIndex = 0
        Me.TabPageFicha.Text = "TabPage1"
        Me.TabPageFicha.UseVisualStyleBackColor = True
        '
        'FICHA_btnCambiarContraseña
        '
        Me.FICHA_btnCambiarContraseña.BackColor = System.Drawing.Color.Transparent
        Me.FICHA_btnCambiarContraseña.FlatAppearance.BorderSize = 0
        Me.FICHA_btnCambiarContraseña.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.FICHA_btnCambiarContraseña.Image = Global.TAX.My.Resources.Resources.edit__2_
        Me.FICHA_btnCambiarContraseña.Location = New System.Drawing.Point(416, 161)
        Me.FICHA_btnCambiarContraseña.Name = "FICHA_btnCambiarContraseña"
        Me.FICHA_btnCambiarContraseña.Size = New System.Drawing.Size(25, 25)
        Me.FICHA_btnCambiarContraseña.TabIndex = 28
        Me.FICHA_btnCambiarContraseña.UseVisualStyleBackColor = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Enabled = False
        Me.Label23.Location = New System.Drawing.Point(448, 412)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(0, 17)
        Me.Label23.TabIndex = 26
        '
        'inftrabajador
        '
        Me.inftrabajador.BackColor = System.Drawing.Color.White
        Me.inftrabajador.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatAppearance.BorderSize = 0
        Me.inftrabajador.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.inftrabajador.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.inftrabajador.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.inftrabajador.Image = CType(resources.GetObject("inftrabajador.Image"), System.Drawing.Image)
        Me.inftrabajador.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.inftrabajador.Location = New System.Drawing.Point(6, 6)
        Me.inftrabajador.Name = "inftrabajador"
        Me.inftrabajador.Size = New System.Drawing.Size(354, 53)
        Me.inftrabajador.TabIndex = 25
        Me.inftrabajador.Text = "Información del Trabajador"
        Me.inftrabajador.UseVisualStyleBackColor = False
        '
        'FICHA_txtFijo
        '
        Me.FICHA_txtFijo.BackColor = System.Drawing.Color.White
        Me.FICHA_txtFijo.Enabled = False
        Me.FICHA_txtFijo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtFijo.Location = New System.Drawing.Point(278, 395)
        Me.FICHA_txtFijo.Name = "FICHA_txtFijo"
        Me.FICHA_txtFijo.ReadOnly = True
        Me.FICHA_txtFijo.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtFijo.TabIndex = 23
        '
        'FICHA_txtCelular
        '
        Me.FICHA_txtCelular.BackColor = System.Drawing.Color.White
        Me.FICHA_txtCelular.Enabled = False
        Me.FICHA_txtCelular.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtCelular.Location = New System.Drawing.Point(278, 366)
        Me.FICHA_txtCelular.Name = "FICHA_txtCelular"
        Me.FICHA_txtCelular.ReadOnly = True
        Me.FICHA_txtCelular.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtCelular.TabIndex = 22
        '
        'FICHA_txtHijos
        '
        Me.FICHA_txtHijos.BackColor = System.Drawing.Color.White
        Me.FICHA_txtHijos.Enabled = False
        Me.FICHA_txtHijos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtHijos.Location = New System.Drawing.Point(278, 337)
        Me.FICHA_txtHijos.Name = "FICHA_txtHijos"
        Me.FICHA_txtHijos.ReadOnly = True
        Me.FICHA_txtHijos.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtHijos.TabIndex = 21
        '
        'FICHA_txtEmail
        '
        Me.FICHA_txtEmail.BackColor = System.Drawing.Color.White
        Me.FICHA_txtEmail.Enabled = False
        Me.FICHA_txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtEmail.Location = New System.Drawing.Point(278, 308)
        Me.FICHA_txtEmail.Name = "FICHA_txtEmail"
        Me.FICHA_txtEmail.ReadOnly = True
        Me.FICHA_txtEmail.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtEmail.TabIndex = 20
        '
        'FICHA_txtEstCivil
        '
        Me.FICHA_txtEstCivil.BackColor = System.Drawing.Color.White
        Me.FICHA_txtEstCivil.Enabled = False
        Me.FICHA_txtEstCivil.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtEstCivil.Location = New System.Drawing.Point(278, 279)
        Me.FICHA_txtEstCivil.Name = "FICHA_txtEstCivil"
        Me.FICHA_txtEstCivil.ReadOnly = True
        Me.FICHA_txtEstCivil.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtEstCivil.TabIndex = 19
        '
        'FICHA_txtCalle
        '
        Me.FICHA_txtCalle.BackColor = System.Drawing.Color.White
        Me.FICHA_txtCalle.Enabled = False
        Me.FICHA_txtCalle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtCalle.Location = New System.Drawing.Point(278, 250)
        Me.FICHA_txtCalle.Name = "FICHA_txtCalle"
        Me.FICHA_txtCalle.ReadOnly = True
        Me.FICHA_txtCalle.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtCalle.TabIndex = 18
        '
        'FICHA_txtFNacimiento
        '
        Me.FICHA_txtFNacimiento.BackColor = System.Drawing.Color.White
        Me.FICHA_txtFNacimiento.Enabled = False
        Me.FICHA_txtFNacimiento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtFNacimiento.Location = New System.Drawing.Point(278, 221)
        Me.FICHA_txtFNacimiento.Name = "FICHA_txtFNacimiento"
        Me.FICHA_txtFNacimiento.ReadOnly = True
        Me.FICHA_txtFNacimiento.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtFNacimiento.TabIndex = 17
        '
        'FICHA_txtSexo
        '
        Me.FICHA_txtSexo.BackColor = System.Drawing.Color.White
        Me.FICHA_txtSexo.Enabled = False
        Me.FICHA_txtSexo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtSexo.Location = New System.Drawing.Point(278, 192)
        Me.FICHA_txtSexo.Name = "FICHA_txtSexo"
        Me.FICHA_txtSexo.ReadOnly = True
        Me.FICHA_txtSexo.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtSexo.TabIndex = 16
        '
        'FICHA_txtContraseña
        '
        Me.FICHA_txtContraseña.BackColor = System.Drawing.Color.White
        Me.FICHA_txtContraseña.Enabled = False
        Me.FICHA_txtContraseña.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtContraseña.Location = New System.Drawing.Point(278, 163)
        Me.FICHA_txtContraseña.Name = "FICHA_txtContraseña"
        Me.FICHA_txtContraseña.ReadOnly = True
        Me.FICHA_txtContraseña.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtContraseña.TabIndex = 15
        '
        'FICHA_txtApellido
        '
        Me.FICHA_txtApellido.BackColor = System.Drawing.Color.White
        Me.FICHA_txtApellido.Enabled = False
        Me.FICHA_txtApellido.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtApellido.Location = New System.Drawing.Point(278, 134)
        Me.FICHA_txtApellido.Name = "FICHA_txtApellido"
        Me.FICHA_txtApellido.ReadOnly = True
        Me.FICHA_txtApellido.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtApellido.TabIndex = 14
        '
        'FICHA_txtNombre
        '
        Me.FICHA_txtNombre.BackColor = System.Drawing.Color.White
        Me.FICHA_txtNombre.Enabled = False
        Me.FICHA_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtNombre.Location = New System.Drawing.Point(278, 105)
        Me.FICHA_txtNombre.Name = "FICHA_txtNombre"
        Me.FICHA_txtNombre.ReadOnly = True
        Me.FICHA_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtNombre.TabIndex = 13
        '
        'FICHA_lblFijo
        '
        Me.FICHA_lblFijo.AutoSize = True
        Me.FICHA_lblFijo.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblFijo.Location = New System.Drawing.Point(117, 397)
        Me.FICHA_lblFijo.Name = "FICHA_lblFijo"
        Me.FICHA_lblFijo.Size = New System.Drawing.Size(79, 17)
        Me.FICHA_lblFijo.TabIndex = 12
        Me.FICHA_lblFijo.Text = "Teléfono fijo:"
        '
        'FICHA_lblCelular
        '
        Me.FICHA_lblCelular.AutoSize = True
        Me.FICHA_lblCelular.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblCelular.Location = New System.Drawing.Point(116, 368)
        Me.FICHA_lblCelular.Name = "FICHA_lblCelular"
        Me.FICHA_lblCelular.Size = New System.Drawing.Size(99, 17)
        Me.FICHA_lblCelular.TabIndex = 11
        Me.FICHA_lblCelular.Text = "Teléfono celular:"
        '
        'FICHA_lblHijos
        '
        Me.FICHA_lblHijos.AutoSize = True
        Me.FICHA_lblHijos.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblHijos.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblHijos.Location = New System.Drawing.Point(116, 339)
        Me.FICHA_lblHijos.Name = "FICHA_lblHijos"
        Me.FICHA_lblHijos.Size = New System.Drawing.Size(38, 17)
        Me.FICHA_lblHijos.TabIndex = 10
        Me.FICHA_lblHijos.Text = "Hijos:"
        '
        'FICHA_lblEmail
        '
        Me.FICHA_lblEmail.AutoSize = True
        Me.FICHA_lblEmail.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblEmail.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblEmail.Location = New System.Drawing.Point(116, 310)
        Me.FICHA_lblEmail.Name = "FICHA_lblEmail"
        Me.FICHA_lblEmail.Size = New System.Drawing.Size(42, 17)
        Me.FICHA_lblEmail.TabIndex = 9
        Me.FICHA_lblEmail.Text = "Email:"
        '
        'FICHA_lblEstCivil
        '
        Me.FICHA_lblEstCivil.AutoSize = True
        Me.FICHA_lblEstCivil.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblEstCivil.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblEstCivil.Location = New System.Drawing.Point(116, 281)
        Me.FICHA_lblEstCivil.Name = "FICHA_lblEstCivil"
        Me.FICHA_lblEstCivil.Size = New System.Drawing.Size(75, 17)
        Me.FICHA_lblEstCivil.TabIndex = 8
        Me.FICHA_lblEstCivil.Text = "Estado Civil:"
        '
        'FICHA_lblDireccion
        '
        Me.FICHA_lblDireccion.AutoSize = True
        Me.FICHA_lblDireccion.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblDireccion.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblDireccion.Location = New System.Drawing.Point(116, 252)
        Me.FICHA_lblDireccion.Name = "FICHA_lblDireccion"
        Me.FICHA_lblDireccion.Size = New System.Drawing.Size(63, 17)
        Me.FICHA_lblDireccion.TabIndex = 7
        Me.FICHA_lblDireccion.Text = "Dirección:"
        '
        'FICHA_lblFNacimiento
        '
        Me.FICHA_lblFNacimiento.AutoSize = True
        Me.FICHA_lblFNacimiento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblFNacimiento.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblFNacimiento.Location = New System.Drawing.Point(116, 223)
        Me.FICHA_lblFNacimiento.Name = "FICHA_lblFNacimiento"
        Me.FICHA_lblFNacimiento.Size = New System.Drawing.Size(127, 17)
        Me.FICHA_lblFNacimiento.TabIndex = 6
        Me.FICHA_lblFNacimiento.Text = "Fecha de nacimiento:"
        '
        'FICHA_lblSexo
        '
        Me.FICHA_lblSexo.AutoSize = True
        Me.FICHA_lblSexo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblSexo.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblSexo.Location = New System.Drawing.Point(117, 194)
        Me.FICHA_lblSexo.Name = "FICHA_lblSexo"
        Me.FICHA_lblSexo.Size = New System.Drawing.Size(37, 17)
        Me.FICHA_lblSexo.TabIndex = 5
        Me.FICHA_lblSexo.Text = "Sexo:"
        '
        'FICHA_lblContraseña
        '
        Me.FICHA_lblContraseña.AutoSize = True
        Me.FICHA_lblContraseña.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblContraseña.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblContraseña.Location = New System.Drawing.Point(116, 165)
        Me.FICHA_lblContraseña.Name = "FICHA_lblContraseña"
        Me.FICHA_lblContraseña.Size = New System.Drawing.Size(75, 17)
        Me.FICHA_lblContraseña.TabIndex = 4
        Me.FICHA_lblContraseña.Text = "Contraseña:"
        '
        'FICHA_lblApellido
        '
        Me.FICHA_lblApellido.AutoSize = True
        Me.FICHA_lblApellido.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblApellido.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblApellido.Location = New System.Drawing.Point(116, 136)
        Me.FICHA_lblApellido.Name = "FICHA_lblApellido"
        Me.FICHA_lblApellido.Size = New System.Drawing.Size(56, 17)
        Me.FICHA_lblApellido.TabIndex = 3
        Me.FICHA_lblApellido.Text = "Apellido:"
        '
        'FICHA_lblNombre
        '
        Me.FICHA_lblNombre.AutoSize = True
        Me.FICHA_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblNombre.Location = New System.Drawing.Point(116, 107)
        Me.FICHA_lblNombre.Name = "FICHA_lblNombre"
        Me.FICHA_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.FICHA_lblNombre.TabIndex = 2
        Me.FICHA_lblNombre.Text = "Nombre:"
        '
        'FICHA_txtDocumento
        '
        Me.FICHA_txtDocumento.BackColor = System.Drawing.Color.White
        Me.FICHA_txtDocumento.Enabled = False
        Me.FICHA_txtDocumento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtDocumento.Location = New System.Drawing.Point(278, 76)
        Me.FICHA_txtDocumento.Name = "FICHA_txtDocumento"
        Me.FICHA_txtDocumento.ReadOnly = True
        Me.FICHA_txtDocumento.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtDocumento.TabIndex = 1
        '
        'FICHA_lblDocumento
        '
        Me.FICHA_lblDocumento.AutoSize = True
        Me.FICHA_lblDocumento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblDocumento.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblDocumento.Location = New System.Drawing.Point(116, 78)
        Me.FICHA_lblDocumento.Name = "FICHA_lblDocumento"
        Me.FICHA_lblDocumento.Size = New System.Drawing.Size(76, 17)
        Me.FICHA_lblDocumento.TabIndex = 0
        Me.FICHA_lblDocumento.Text = "Documento:"
        '
        'TabPageOrganizacion
        '
        Me.TabPageOrganizacion.AutoScroll = True
        Me.TabPageOrganizacion.BackColor = System.Drawing.Color.White
        Me.TabPageOrganizacion.Controls.Add(Me.Label24)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtMailEmpresarial)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtTlfEmpresarial)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtDepartamento)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtGrado)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtCargo)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtFIngreso)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtNRegistro)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblEmailEmpresarial)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblTelfEmpresarial)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblDepartamento)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblGrado)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblCargo)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblFIngreso)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblNRegistro)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_txtRUT)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblRUT)
        Me.TabPageOrganizacion.Controls.Add(Me.ORG_lblInInformacionEmpresarial)
        Me.TabPageOrganizacion.Location = New System.Drawing.Point(4, 57)
        Me.TabPageOrganizacion.Name = "TabPageOrganizacion"
        Me.TabPageOrganizacion.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageOrganizacion.Size = New System.Drawing.Size(777, 375)
        Me.TabPageOrganizacion.TabIndex = 1
        Me.TabPageOrganizacion.Text = "TabPage2"
        Me.TabPageOrganizacion.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(413, 339)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(0, 17)
        Me.Label24.TabIndex = 52
        '
        'ORG_txtMailEmpresarial
        '
        Me.ORG_txtMailEmpresarial.BackColor = System.Drawing.Color.White
        Me.ORG_txtMailEmpresarial.Enabled = False
        Me.ORG_txtMailEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtMailEmpresarial.Location = New System.Drawing.Point(281, 285)
        Me.ORG_txtMailEmpresarial.Name = "ORG_txtMailEmpresarial"
        Me.ORG_txtMailEmpresarial.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtMailEmpresarial.TabIndex = 46
        '
        'ORG_txtTlfEmpresarial
        '
        Me.ORG_txtTlfEmpresarial.BackColor = System.Drawing.Color.White
        Me.ORG_txtTlfEmpresarial.Enabled = False
        Me.ORG_txtTlfEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtTlfEmpresarial.Location = New System.Drawing.Point(281, 256)
        Me.ORG_txtTlfEmpresarial.Name = "ORG_txtTlfEmpresarial"
        Me.ORG_txtTlfEmpresarial.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtTlfEmpresarial.TabIndex = 45
        '
        'ORG_txtDepartamento
        '
        Me.ORG_txtDepartamento.BackColor = System.Drawing.Color.White
        Me.ORG_txtDepartamento.Enabled = False
        Me.ORG_txtDepartamento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtDepartamento.Location = New System.Drawing.Point(281, 227)
        Me.ORG_txtDepartamento.Name = "ORG_txtDepartamento"
        Me.ORG_txtDepartamento.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtDepartamento.TabIndex = 44
        '
        'ORG_txtGrado
        '
        Me.ORG_txtGrado.BackColor = System.Drawing.Color.White
        Me.ORG_txtGrado.Enabled = False
        Me.ORG_txtGrado.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtGrado.Location = New System.Drawing.Point(281, 198)
        Me.ORG_txtGrado.Name = "ORG_txtGrado"
        Me.ORG_txtGrado.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtGrado.TabIndex = 43
        '
        'ORG_txtCargo
        '
        Me.ORG_txtCargo.BackColor = System.Drawing.Color.White
        Me.ORG_txtCargo.Enabled = False
        Me.ORG_txtCargo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtCargo.Location = New System.Drawing.Point(281, 169)
        Me.ORG_txtCargo.Name = "ORG_txtCargo"
        Me.ORG_txtCargo.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtCargo.TabIndex = 42
        '
        'ORG_txtFIngreso
        '
        Me.ORG_txtFIngreso.BackColor = System.Drawing.Color.White
        Me.ORG_txtFIngreso.Enabled = False
        Me.ORG_txtFIngreso.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtFIngreso.Location = New System.Drawing.Point(281, 140)
        Me.ORG_txtFIngreso.Name = "ORG_txtFIngreso"
        Me.ORG_txtFIngreso.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtFIngreso.TabIndex = 41
        '
        'ORG_txtNRegistro
        '
        Me.ORG_txtNRegistro.BackColor = System.Drawing.Color.White
        Me.ORG_txtNRegistro.Enabled = False
        Me.ORG_txtNRegistro.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtNRegistro.Location = New System.Drawing.Point(281, 111)
        Me.ORG_txtNRegistro.Name = "ORG_txtNRegistro"
        Me.ORG_txtNRegistro.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtNRegistro.TabIndex = 40
        '
        'ORG_lblEmailEmpresarial
        '
        Me.ORG_lblEmailEmpresarial.AutoSize = True
        Me.ORG_lblEmailEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblEmailEmpresarial.Location = New System.Drawing.Point(119, 287)
        Me.ORG_lblEmailEmpresarial.Name = "ORG_lblEmailEmpresarial"
        Me.ORG_lblEmailEmpresarial.Size = New System.Drawing.Size(111, 17)
        Me.ORG_lblEmailEmpresarial.TabIndex = 35
        Me.ORG_lblEmailEmpresarial.Text = "Email empresarial:"
        '
        'ORG_lblTelfEmpresarial
        '
        Me.ORG_lblTelfEmpresarial.AutoSize = True
        Me.ORG_lblTelfEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblTelfEmpresarial.Location = New System.Drawing.Point(119, 258)
        Me.ORG_lblTelfEmpresarial.Name = "ORG_lblTelfEmpresarial"
        Me.ORG_lblTelfEmpresarial.Size = New System.Drawing.Size(128, 17)
        Me.ORG_lblTelfEmpresarial.TabIndex = 34
        Me.ORG_lblTelfEmpresarial.Text = "Telefono empresarial:"
        '
        'ORG_lblDepartamento
        '
        Me.ORG_lblDepartamento.AutoSize = True
        Me.ORG_lblDepartamento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblDepartamento.Location = New System.Drawing.Point(119, 229)
        Me.ORG_lblDepartamento.Name = "ORG_lblDepartamento"
        Me.ORG_lblDepartamento.Size = New System.Drawing.Size(92, 17)
        Me.ORG_lblDepartamento.TabIndex = 33
        Me.ORG_lblDepartamento.Text = "Departamento:"
        '
        'ORG_lblGrado
        '
        Me.ORG_lblGrado.AutoSize = True
        Me.ORG_lblGrado.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblGrado.Location = New System.Drawing.Point(119, 200)
        Me.ORG_lblGrado.Name = "ORG_lblGrado"
        Me.ORG_lblGrado.Size = New System.Drawing.Size(44, 17)
        Me.ORG_lblGrado.TabIndex = 32
        Me.ORG_lblGrado.Text = "Grado:"
        '
        'ORG_lblCargo
        '
        Me.ORG_lblCargo.AutoSize = True
        Me.ORG_lblCargo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblCargo.Location = New System.Drawing.Point(119, 171)
        Me.ORG_lblCargo.Name = "ORG_lblCargo"
        Me.ORG_lblCargo.Size = New System.Drawing.Size(44, 17)
        Me.ORG_lblCargo.TabIndex = 31
        Me.ORG_lblCargo.Text = "Cargo:"
        '
        'ORG_lblFIngreso
        '
        Me.ORG_lblFIngreso.AutoSize = True
        Me.ORG_lblFIngreso.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblFIngreso.Location = New System.Drawing.Point(119, 142)
        Me.ORG_lblFIngreso.Name = "ORG_lblFIngreso"
        Me.ORG_lblFIngreso.Size = New System.Drawing.Size(106, 17)
        Me.ORG_lblFIngreso.TabIndex = 30
        Me.ORG_lblFIngreso.Text = "Fecha de ingreso:"
        '
        'ORG_lblNRegistro
        '
        Me.ORG_lblNRegistro.AutoSize = True
        Me.ORG_lblNRegistro.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblNRegistro.Location = New System.Drawing.Point(119, 113)
        Me.ORG_lblNRegistro.Name = "ORG_lblNRegistro"
        Me.ORG_lblNRegistro.Size = New System.Drawing.Size(117, 17)
        Me.ORG_lblNRegistro.TabIndex = 29
        Me.ORG_lblNRegistro.Text = "Número de registro:"
        '
        'ORG_txtRUT
        '
        Me.ORG_txtRUT.BackColor = System.Drawing.Color.White
        Me.ORG_txtRUT.Enabled = False
        Me.ORG_txtRUT.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtRUT.Location = New System.Drawing.Point(281, 82)
        Me.ORG_txtRUT.Name = "ORG_txtRUT"
        Me.ORG_txtRUT.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtRUT.TabIndex = 28
        '
        'ORG_lblRUT
        '
        Me.ORG_lblRUT.AutoSize = True
        Me.ORG_lblRUT.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblRUT.Location = New System.Drawing.Point(119, 84)
        Me.ORG_lblRUT.Name = "ORG_lblRUT"
        Me.ORG_lblRUT.Size = New System.Drawing.Size(33, 17)
        Me.ORG_lblRUT.TabIndex = 27
        Me.ORG_lblRUT.Text = "RUT:"
        '
        'ORG_lblInInformacionEmpresarial
        '
        Me.ORG_lblInInformacionEmpresarial.BackColor = System.Drawing.Color.White
        Me.ORG_lblInInformacionEmpresarial.Enabled = False
        Me.ORG_lblInInformacionEmpresarial.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ORG_lblInInformacionEmpresarial.FlatAppearance.BorderSize = 0
        Me.ORG_lblInInformacionEmpresarial.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ORG_lblInInformacionEmpresarial.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ORG_lblInInformacionEmpresarial.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ORG_lblInInformacionEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblInInformacionEmpresarial.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.ORG_lblInInformacionEmpresarial.Image = CType(resources.GetObject("ORG_lblInInformacionEmpresarial.Image"), System.Drawing.Image)
        Me.ORG_lblInInformacionEmpresarial.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ORG_lblInInformacionEmpresarial.Location = New System.Drawing.Point(9, 12)
        Me.ORG_lblInInformacionEmpresarial.Name = "ORG_lblInInformacionEmpresarial"
        Me.ORG_lblInInformacionEmpresarial.Size = New System.Drawing.Size(354, 53)
        Me.ORG_lblInInformacionEmpresarial.TabIndex = 51
        Me.ORG_lblInInformacionEmpresarial.Text = "Información Empresarial"
        Me.ORG_lblInInformacionEmpresarial.UseVisualStyleBackColor = False
        '
        'TabPageHrecibos
        '
        Me.TabPageHrecibos.Controls.Add(Me.Label1)
        Me.TabPageHrecibos.Controls.Add(Me.PictureBox1)
        Me.TabPageHrecibos.Location = New System.Drawing.Point(4, 57)
        Me.TabPageHrecibos.Name = "TabPageHrecibos"
        Me.TabPageHrecibos.Size = New System.Drawing.Size(777, 375)
        Me.TabPageHrecibos.TabIndex = 2
        Me.TabPageHrecibos.Text = "TabPage3"
        Me.TabPageHrecibos.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkGray
        Me.Label1.Location = New System.Drawing.Point(255, 225)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(507, 39)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Estamos trabajando en esto..."
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.TAX.My.Resources.Resources.tractor_clarito
        Me.PictureBox1.Location = New System.Drawing.Point(49, 147)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(200, 195)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'TabPageHLaboral
        '
        Me.TabPageHLaboral.Controls.Add(Me.HLaboral_lblEstamos)
        Me.TabPageHLaboral.Controls.Add(Me.HLaboral_pbTractor)
        Me.TabPageHLaboral.Location = New System.Drawing.Point(4, 57)
        Me.TabPageHLaboral.Name = "TabPageHLaboral"
        Me.TabPageHLaboral.Size = New System.Drawing.Size(777, 375)
        Me.TabPageHLaboral.TabIndex = 3
        Me.TabPageHLaboral.Text = "TabPage4"
        Me.TabPageHLaboral.UseVisualStyleBackColor = True
        '
        'HLaboral_lblEstamos
        '
        Me.HLaboral_lblEstamos.AutoSize = True
        Me.HLaboral_lblEstamos.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HLaboral_lblEstamos.ForeColor = System.Drawing.Color.DarkGray
        Me.HLaboral_lblEstamos.Location = New System.Drawing.Point(255, 225)
        Me.HLaboral_lblEstamos.Name = "HLaboral_lblEstamos"
        Me.HLaboral_lblEstamos.Size = New System.Drawing.Size(507, 39)
        Me.HLaboral_lblEstamos.TabIndex = 1
        Me.HLaboral_lblEstamos.Text = "Estamos trabajando en esto..."
        '
        'HLaboral_pbTractor
        '
        Me.HLaboral_pbTractor.Image = Global.TAX.My.Resources.Resources.tractor_clarito
        Me.HLaboral_pbTractor.Location = New System.Drawing.Point(49, 147)
        Me.HLaboral_pbTractor.Name = "HLaboral_pbTractor"
        Me.HLaboral_pbTractor.Size = New System.Drawing.Size(200, 195)
        Me.HLaboral_pbTractor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.HLaboral_pbTractor.TabIndex = 0
        Me.HLaboral_pbTractor.TabStop = False
        '
        'pnlBotones
        '
        Me.pnlBotones.Controls.Add(Me.pnlBotonesGris)
        Me.pnlBotones.Controls.Add(Me.pnlGris)
        Me.pnlBotones.Controls.Add(Me.btnHRecibos)
        Me.pnlBotones.Controls.Add(Me.btnHLaboral)
        Me.pnlBotones.Controls.Add(Me.btnOrganizacion)
        Me.pnlBotones.Controls.Add(Me.btnFicha)
        Me.pnlBotones.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBotones.Location = New System.Drawing.Point(20, 20)
        Me.pnlBotones.Name = "pnlBotones"
        Me.pnlBotones.Size = New System.Drawing.Size(794, 60)
        Me.pnlBotones.TabIndex = 12
        '
        'pnlBotonesGris
        '
        Me.pnlBotonesGris.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.pnlBotonesGris.Controls.Add(Me.pnlSelection)
        Me.pnlBotonesGris.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlBotonesGris.Location = New System.Drawing.Point(0, 54)
        Me.pnlBotonesGris.Name = "pnlBotonesGris"
        Me.pnlBotonesGris.Size = New System.Drawing.Size(794, 3)
        Me.pnlBotonesGris.TabIndex = 10
        '
        'pnlSelection
        '
        Me.pnlSelection.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlSelection.Location = New System.Drawing.Point(0, 0)
        Me.pnlSelection.Name = "pnlSelection"
        Me.pnlSelection.Size = New System.Drawing.Size(102, 3)
        Me.pnlSelection.TabIndex = 9
        '
        'pnlGris
        '
        Me.pnlGris.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.pnlGris.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlGris.Location = New System.Drawing.Point(0, 57)
        Me.pnlGris.Name = "pnlGris"
        Me.pnlGris.Size = New System.Drawing.Size(794, 3)
        Me.pnlGris.TabIndex = 8
        '
        'btnHRecibos
        '
        Me.btnHRecibos.BackColor = System.Drawing.Color.Transparent
        Me.btnHRecibos.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHRecibos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHRecibos.FlatAppearance.BorderSize = 0
        Me.btnHRecibos.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHRecibos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHRecibos.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHRecibos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnHRecibos.Image = Global.TAX.My.Resources.Resources.historial_gris
        Me.btnHRecibos.Location = New System.Drawing.Point(351, 0)
        Me.btnHRecibos.Name = "btnHRecibos"
        Me.btnHRecibos.Size = New System.Drawing.Size(117, 57)
        Me.btnHRecibos.TabIndex = 3
        Me.btnHRecibos.Text = "HISTORIAL RECIBOS"
        Me.btnHRecibos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnHRecibos.UseVisualStyleBackColor = False
        '
        'btnHLaboral
        '
        Me.btnHLaboral.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHLaboral.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHLaboral.FlatAppearance.BorderSize = 0
        Me.btnHLaboral.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHLaboral.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHLaboral.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHLaboral.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnHLaboral.Image = Global.TAX.My.Resources.Resources.historia_gris
        Me.btnHLaboral.Location = New System.Drawing.Point(234, 0)
        Me.btnHLaboral.Name = "btnHLaboral"
        Me.btnHLaboral.Size = New System.Drawing.Size(117, 57)
        Me.btnHLaboral.TabIndex = 2
        Me.btnHLaboral.Text = "HISTORIA LABORAL"
        Me.btnHLaboral.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnHLaboral.UseVisualStyleBackColor = True
        '
        'btnOrganizacion
        '
        Me.btnOrganizacion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOrganizacion.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnOrganizacion.FlatAppearance.BorderSize = 0
        Me.btnOrganizacion.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnOrganizacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOrganizacion.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrganizacion.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnOrganizacion.Image = Global.TAX.My.Resources.Resources.enterprise_gris
        Me.btnOrganizacion.Location = New System.Drawing.Point(117, 0)
        Me.btnOrganizacion.Name = "btnOrganizacion"
        Me.btnOrganizacion.Size = New System.Drawing.Size(117, 57)
        Me.btnOrganizacion.TabIndex = 1
        Me.btnOrganizacion.Text = "ORGANIZACIÓN" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnOrganizacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnOrganizacion.UseVisualStyleBackColor = True
        '
        'btnFicha
        '
        Me.btnFicha.BackColor = System.Drawing.Color.White
        Me.btnFicha.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFicha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnFicha.FlatAppearance.BorderSize = 0
        Me.btnFicha.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnFicha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFicha.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFicha.ForeColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.btnFicha.Image = Global.TAX.My.Resources.Resources.ficha_roja
        Me.btnFicha.Location = New System.Drawing.Point(0, 0)
        Me.btnFicha.Name = "btnFicha"
        Me.btnFicha.Size = New System.Drawing.Size(117, 57)
        Me.btnFicha.TabIndex = 0
        Me.btnFicha.Text = "FICHA"
        Me.btnFicha.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnFicha.UseVisualStyleBackColor = False
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(281, 94)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(132, 20)
        Me.TextBox2.TabIndex = 13
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(35, 359)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(68, 13)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Teléfono fijo:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(34, 329)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(86, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Teléfono celular:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(34, 312)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(33, 13)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = "Hijos:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(34, 295)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(35, 13)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "Email:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(35, 265)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(65, 13)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "Estado Civil:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(35, 248)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(55, 13)
        Me.Label16.TabIndex = 7
        Me.Label16.Text = "Dirección:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(34, 221)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(109, 13)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "Fecha de nacimiento:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(35, 195)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(34, 13)
        Me.Label18.TabIndex = 5
        Me.Label18.Text = "Sexo:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(34, 161)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(64, 13)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "Contraseña:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(34, 124)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(47, 13)
        Me.Label20.TabIndex = 3
        Me.Label20.Text = "Apellido:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(34, 94)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(47, 13)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "Nombre:"
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(281, 60)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(132, 20)
        Me.TextBox3.TabIndex = 1
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(34, 63)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(65, 13)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Documento:"
        '
        'Admin_Ficha
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(834, 482)
        Me.Controls.Add(Me.pnlBotones)
        Me.Controls.Add(Me.TabControl_FichaAdmin)
        Me.Controls.Add(Me.panel_izq2)
        Me.Controls.Add(Me.panel_up)
        Me.Controls.Add(Me.panel_down2)
        Me.Controls.Add(Me.panel_der)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_Ficha"
        Me.Text = "fichaadminicio"
        Me.TabControl_FichaAdmin.ResumeLayout(False)
        Me.TabPageFicha.ResumeLayout(False)
        Me.TabPageFicha.PerformLayout()
        Me.TabPageOrganizacion.ResumeLayout(False)
        Me.TabPageOrganizacion.PerformLayout()
        Me.TabPageHrecibos.ResumeLayout(False)
        Me.TabPageHrecibos.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageHLaboral.ResumeLayout(False)
        Me.TabPageHLaboral.PerformLayout()
        CType(Me.HLaboral_pbTractor, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlBotones.ResumeLayout(False)
        Me.pnlBotonesGris.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panel_izq2 As System.Windows.Forms.Panel
    Friend WithEvents panel_up As System.Windows.Forms.Panel
    Friend WithEvents panel_down2 As System.Windows.Forms.Panel
    Friend WithEvents panel_der As System.Windows.Forms.Panel
    Friend WithEvents TabControl_FichaAdmin As System.Windows.Forms.TabControl
    Friend WithEvents TabPageFicha As System.Windows.Forms.TabPage
    Friend WithEvents TabPageOrganizacion As System.Windows.Forms.TabPage
    Friend WithEvents TabPageHrecibos As System.Windows.Forms.TabPage
    Friend WithEvents TabPageHLaboral As System.Windows.Forms.TabPage
    Friend WithEvents pnlBotones As System.Windows.Forms.Panel
    Friend WithEvents btnHRecibos As System.Windows.Forms.Button
    Friend WithEvents btnHLaboral As System.Windows.Forms.Button
    Friend WithEvents btnOrganizacion As System.Windows.Forms.Button
    Friend WithEvents btnFicha As System.Windows.Forms.Button
    Friend WithEvents FICHA_txtDocumento As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_lblDocumento As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblEstCivil As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblDireccion As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblFNacimiento As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblSexo As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblContraseña As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblApellido As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblNombre As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblCelular As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblHijos As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblEmail As System.Windows.Forms.Label
    Friend WithEvents FICHA_txtFijo As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtCelular As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtHijos As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtEstCivil As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtCalle As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtFNacimiento As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtSexo As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtContraseña As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtApellido As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_lblFijo As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents inftrabajador As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents ORG_lblInInformacionEmpresarial As System.Windows.Forms.Button
    Friend WithEvents ORG_txtMailEmpresarial As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtTlfEmpresarial As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtDepartamento As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtGrado As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtCargo As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtFIngreso As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtNRegistro As System.Windows.Forms.TextBox
    Friend WithEvents ORG_lblEmailEmpresarial As System.Windows.Forms.Label
    Friend WithEvents ORG_lblTelfEmpresarial As System.Windows.Forms.Label
    Friend WithEvents ORG_lblDepartamento As System.Windows.Forms.Label
    Friend WithEvents ORG_lblGrado As System.Windows.Forms.Label
    Friend WithEvents ORG_lblCargo As System.Windows.Forms.Label
    Friend WithEvents ORG_lblFIngreso As System.Windows.Forms.Label
    Friend WithEvents ORG_lblNRegistro As System.Windows.Forms.Label
    Friend WithEvents ORG_txtRUT As System.Windows.Forms.TextBox
    Friend WithEvents ORG_lblRUT As System.Windows.Forms.Label
    Friend WithEvents pnlGris As System.Windows.Forms.Panel
    Friend WithEvents pnlBotonesGris As System.Windows.Forms.Panel
    Friend WithEvents pnlSelection As System.Windows.Forms.Panel
    Friend WithEvents FICHA_btnCambiarContraseña As System.Windows.Forms.Button
    Friend WithEvents HLaboral_lblEstamos As System.Windows.Forms.Label
    Friend WithEvents HLaboral_pbTractor As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
