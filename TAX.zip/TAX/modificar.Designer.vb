﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class modificar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(modificar))
        Me.rbadmin = New System.Windows.Forms.RadioButton
        Me.rbuser = New System.Windows.Forms.RadioButton
        Me.datenacimiento = New System.Windows.Forms.DateTimePicker
        Me.dateingreso = New System.Windows.Forms.DateTimePicker
        Me.txttelefonoemp = New System.Windows.Forms.TextBox
        Me.txtemailempre = New System.Windows.Forms.TextBox
        Me.txtdepartamento = New System.Windows.Forms.TextBox
        Me.txtgrado = New System.Windows.Forms.TextBox
        Me.txtcargo = New System.Windows.Forms.TextBox
        Me.txtpuesto = New System.Windows.Forms.TextBox
        Me.txtrut = New System.Windows.Forms.TextBox
        Me.cbhijos = New System.Windows.Forms.ComboBox
        Me.cbestadocivil = New System.Windows.Forms.ComboBox
        Me.txtcontraseña = New System.Windows.Forms.TextBox
        Me.txtemailperso = New System.Windows.Forms.TextBox
        Me.txttelefono = New System.Windows.Forms.TextBox
        Me.txtcelular = New System.Windows.Forms.TextBox
        Me.txtdireccion = New System.Windows.Forms.TextBox
        Me.cbSexo = New System.Windows.Forms.ComboBox
        Me.txtapellido = New System.Windows.Forms.TextBox
        Me.txtnombre = New System.Windows.Forms.TextBox
        Me.cmdmodificaar2 = New System.Windows.Forms.Button
        Me.cmdlistar = New System.Windows.Forms.Button
        Me.cmdeliminar = New System.Windows.Forms.Button
        Me.cmdagregar = New System.Windows.Forms.Button
        Me.cmdliquidar = New System.Windows.Forms.Button
        Me.cmdficha = New System.Windows.Forms.Button
        Me.cmdrecibo = New System.Windows.Forms.Button
        Me.cmdinicio = New System.Windows.Forms.Button
        Me.cbcédula = New System.Windows.Forms.ComboBox
        Me.cbregistro = New System.Windows.Forms.ComboBox
        Me.cmdayuda = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'rbadmin
        '
        Me.rbadmin.AutoSize = True
        Me.rbadmin.Location = New System.Drawing.Point(631, 379)
        Me.rbadmin.Name = "rbadmin"
        Me.rbadmin.Size = New System.Drawing.Size(60, 17)
        Me.rbadmin.TabIndex = 81
        Me.rbadmin.TabStop = True
        Me.rbadmin.Text = "ADMIN"
        Me.rbadmin.UseVisualStyleBackColor = True
        '
        'rbuser
        '
        Me.rbuser.AutoSize = True
        Me.rbuser.Location = New System.Drawing.Point(631, 354)
        Me.rbuser.Name = "rbuser"
        Me.rbuser.Size = New System.Drawing.Size(55, 17)
        Me.rbuser.TabIndex = 80
        Me.rbuser.TabStop = True
        Me.rbuser.Text = "USER"
        Me.rbuser.UseVisualStyleBackColor = True
        '
        'datenacimiento
        '
        Me.datenacimiento.Location = New System.Drawing.Point(237, 308)
        Me.datenacimiento.Name = "datenacimiento"
        Me.datenacimiento.Size = New System.Drawing.Size(109, 20)
        Me.datenacimiento.TabIndex = 79
        '
        'dateingreso
        '
        Me.dateingreso.Location = New System.Drawing.Point(469, 288)
        Me.dateingreso.Name = "dateingreso"
        Me.dateingreso.Size = New System.Drawing.Size(109, 20)
        Me.dateingreso.TabIndex = 78
        '
        'txttelefonoemp
        '
        Me.txttelefonoemp.Location = New System.Drawing.Point(485, 447)
        Me.txttelefonoemp.Multiline = True
        Me.txttelefonoemp.Name = "txttelefonoemp"
        Me.txttelefonoemp.Size = New System.Drawing.Size(128, 17)
        Me.txttelefonoemp.TabIndex = 77
        '
        'txtemailempre
        '
        Me.txtemailempre.Location = New System.Drawing.Point(472, 424)
        Me.txtemailempre.Multiline = True
        Me.txtemailempre.Name = "txtemailempre"
        Me.txtemailempre.Size = New System.Drawing.Size(128, 17)
        Me.txtemailempre.TabIndex = 76
        '
        'txtdepartamento
        '
        Me.txtdepartamento.Location = New System.Drawing.Point(453, 401)
        Me.txtdepartamento.Multiline = True
        Me.txtdepartamento.Name = "txtdepartamento"
        Me.txtdepartamento.Size = New System.Drawing.Size(128, 17)
        Me.txtdepartamento.TabIndex = 75
        '
        'txtgrado
        '
        Me.txtgrado.Location = New System.Drawing.Point(424, 379)
        Me.txtgrado.Multiline = True
        Me.txtgrado.Name = "txtgrado"
        Me.txtgrado.Size = New System.Drawing.Size(128, 17)
        Me.txtgrado.TabIndex = 74
        '
        'txtcargo
        '
        Me.txtcargo.Location = New System.Drawing.Point(425, 356)
        Me.txtcargo.Multiline = True
        Me.txtcargo.Name = "txtcargo"
        Me.txtcargo.Size = New System.Drawing.Size(128, 17)
        Me.txtcargo.TabIndex = 73
        '
        'txtpuesto
        '
        Me.txtpuesto.Location = New System.Drawing.Point(425, 333)
        Me.txtpuesto.Multiline = True
        Me.txtpuesto.Name = "txtpuesto"
        Me.txtpuesto.Size = New System.Drawing.Size(128, 17)
        Me.txtpuesto.TabIndex = 72
        '
        'txtrut
        '
        Me.txtrut.Location = New System.Drawing.Point(415, 270)
        Me.txtrut.Multiline = True
        Me.txtrut.Name = "txtrut"
        Me.txtrut.Size = New System.Drawing.Size(128, 17)
        Me.txtrut.TabIndex = 70
        '
        'cbhijos
        '
        Me.cbhijos.FormattingEnabled = True
        Me.cbhijos.Location = New System.Drawing.Point(424, 247)
        Me.cbhijos.Name = "cbhijos"
        Me.cbhijos.Size = New System.Drawing.Size(129, 21)
        Me.cbhijos.TabIndex = 69
        '
        'cbestadocivil
        '
        Me.cbestadocivil.FormattingEnabled = True
        Me.cbestadocivil.Location = New System.Drawing.Point(449, 224)
        Me.cbestadocivil.Name = "cbestadocivil"
        Me.cbestadocivil.Size = New System.Drawing.Size(129, 21)
        Me.cbestadocivil.TabIndex = 68
        '
        'txtcontraseña
        '
        Me.txtcontraseña.Location = New System.Drawing.Point(200, 428)
        Me.txtcontraseña.Multiline = True
        Me.txtcontraseña.Name = "txtcontraseña"
        Me.txtcontraseña.Size = New System.Drawing.Size(128, 17)
        Me.txtcontraseña.TabIndex = 67
        '
        'txtemailperso
        '
        Me.txtemailperso.Location = New System.Drawing.Point(216, 402)
        Me.txtemailperso.Multiline = True
        Me.txtemailperso.Name = "txtemailperso"
        Me.txtemailperso.Size = New System.Drawing.Size(128, 17)
        Me.txtemailperso.TabIndex = 66
        '
        'txttelefono
        '
        Me.txttelefono.Location = New System.Drawing.Point(210, 379)
        Me.txttelefono.Multiline = True
        Me.txttelefono.Name = "txttelefono"
        Me.txttelefono.Size = New System.Drawing.Size(128, 17)
        Me.txttelefono.TabIndex = 65
        '
        'txtcelular
        '
        Me.txtcelular.Location = New System.Drawing.Point(228, 353)
        Me.txtcelular.Multiline = True
        Me.txtcelular.Name = "txtcelular"
        Me.txtcelular.Size = New System.Drawing.Size(128, 17)
        Me.txtcelular.TabIndex = 64
        '
        'txtdireccion
        '
        Me.txtdireccion.Location = New System.Drawing.Point(192, 330)
        Me.txtdireccion.Multiline = True
        Me.txtdireccion.Name = "txtdireccion"
        Me.txtdireccion.Size = New System.Drawing.Size(154, 17)
        Me.txtdireccion.TabIndex = 63
        '
        'cbSexo
        '
        Me.cbSexo.FormattingEnabled = True
        Me.cbSexo.Location = New System.Drawing.Point(176, 285)
        Me.cbSexo.Name = "cbSexo"
        Me.cbSexo.Size = New System.Drawing.Size(196, 21)
        Me.cbSexo.TabIndex = 62
        '
        'txtapellido
        '
        Me.txtapellido.Location = New System.Drawing.Point(190, 267)
        Me.txtapellido.Multiline = True
        Me.txtapellido.Name = "txtapellido"
        Me.txtapellido.Size = New System.Drawing.Size(154, 17)
        Me.txtapellido.TabIndex = 61
        '
        'txtnombre
        '
        Me.txtnombre.Location = New System.Drawing.Point(187, 249)
        Me.txtnombre.Multiline = True
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(154, 17)
        Me.txtnombre.TabIndex = 60
        '
        'cmdmodificaar2
        '
        Me.cmdmodificaar2.Location = New System.Drawing.Point(633, 413)
        Me.cmdmodificaar2.Name = "cmdmodificaar2"
        Me.cmdmodificaar2.Size = New System.Drawing.Size(84, 21)
        Me.cmdmodificaar2.TabIndex = 58
        Me.cmdmodificaar2.Text = "AGREGAR"
        Me.cmdmodificaar2.UseVisualStyleBackColor = True
        '
        'cmdlistar
        '
        Me.cmdlistar.BackColor = System.Drawing.Color.Transparent
        Me.cmdlistar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdlistar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdlistar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdlistar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdlistar.Location = New System.Drawing.Point(364, 156)
        Me.cmdlistar.Name = "cmdlistar"
        Me.cmdlistar.Size = New System.Drawing.Size(54, 42)
        Me.cmdlistar.TabIndex = 57
        Me.cmdlistar.UseVisualStyleBackColor = False
        '
        'cmdeliminar
        '
        Me.cmdeliminar.BackColor = System.Drawing.Color.Transparent
        Me.cmdeliminar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdeliminar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdeliminar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdeliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdeliminar.Location = New System.Drawing.Point(302, 156)
        Me.cmdeliminar.Name = "cmdeliminar"
        Me.cmdeliminar.Size = New System.Drawing.Size(54, 42)
        Me.cmdeliminar.TabIndex = 56
        Me.cmdeliminar.UseVisualStyleBackColor = False
        '
        'cmdagregar
        '
        Me.cmdagregar.BackColor = System.Drawing.Color.Transparent
        Me.cmdagregar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdagregar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdagregar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdagregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdagregar.Location = New System.Drawing.Point(155, 156)
        Me.cmdagregar.Name = "cmdagregar"
        Me.cmdagregar.Size = New System.Drawing.Size(56, 42)
        Me.cmdagregar.TabIndex = 55
        Me.cmdagregar.UseVisualStyleBackColor = False
        '
        'cmdliquidar
        '
        Me.cmdliquidar.BackColor = System.Drawing.Color.Transparent
        Me.cmdliquidar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdliquidar.Location = New System.Drawing.Point(12, 302)
        Me.cmdliquidar.Name = "cmdliquidar"
        Me.cmdliquidar.Size = New System.Drawing.Size(123, 31)
        Me.cmdliquidar.TabIndex = 54
        Me.cmdliquidar.UseVisualStyleBackColor = False
        '
        'cmdficha
        '
        Me.cmdficha.BackColor = System.Drawing.Color.Transparent
        Me.cmdficha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdficha.Location = New System.Drawing.Point(15, 178)
        Me.cmdficha.Name = "cmdficha"
        Me.cmdficha.Size = New System.Drawing.Size(123, 31)
        Me.cmdficha.TabIndex = 53
        Me.cmdficha.UseVisualStyleBackColor = False
        '
        'cmdrecibo
        '
        Me.cmdrecibo.BackColor = System.Drawing.Color.Transparent
        Me.cmdrecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdrecibo.Location = New System.Drawing.Point(15, 219)
        Me.cmdrecibo.Name = "cmdrecibo"
        Me.cmdrecibo.Size = New System.Drawing.Size(123, 31)
        Me.cmdrecibo.TabIndex = 52
        Me.cmdrecibo.UseVisualStyleBackColor = False
        '
        'cmdinicio
        '
        Me.cmdinicio.BackColor = System.Drawing.Color.Transparent
        Me.cmdinicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdinicio.Location = New System.Drawing.Point(15, 142)
        Me.cmdinicio.Name = "cmdinicio"
        Me.cmdinicio.Size = New System.Drawing.Size(123, 30)
        Me.cmdinicio.TabIndex = 51
        Me.cmdinicio.UseVisualStyleBackColor = False
        '
        'cbcédula
        '
        Me.cbcédula.FormattingEnabled = True
        Me.cbcédula.Location = New System.Drawing.Point(183, 227)
        Me.cbcédula.Name = "cbcédula"
        Me.cbcédula.Size = New System.Drawing.Size(156, 21)
        Me.cbcédula.TabIndex = 82
        '
        'cbregistro
        '
        Me.cbregistro.FormattingEnabled = True
        Me.cbregistro.Location = New System.Drawing.Point(475, 309)
        Me.cbregistro.Name = "cbregistro"
        Me.cbregistro.Size = New System.Drawing.Size(125, 21)
        Me.cbregistro.TabIndex = 83
        '
        'cmdayuda
        '
        Me.cmdayuda.BackColor = System.Drawing.Color.Transparent
        Me.cmdayuda.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdayuda.Location = New System.Drawing.Point(658, 67)
        Me.cmdayuda.Name = "cmdayuda"
        Me.cmdayuda.Size = New System.Drawing.Size(93, 30)
        Me.cmdayuda.TabIndex = 84
        Me.cmdayuda.UseVisualStyleBackColor = False
        '
        'modificar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(772, 579)
        Me.Controls.Add(Me.cmdayuda)
        Me.Controls.Add(Me.cbregistro)
        Me.Controls.Add(Me.cbcédula)
        Me.Controls.Add(Me.rbadmin)
        Me.Controls.Add(Me.rbuser)
        Me.Controls.Add(Me.datenacimiento)
        Me.Controls.Add(Me.dateingreso)
        Me.Controls.Add(Me.txttelefonoemp)
        Me.Controls.Add(Me.txtemailempre)
        Me.Controls.Add(Me.txtdepartamento)
        Me.Controls.Add(Me.txtgrado)
        Me.Controls.Add(Me.txtcargo)
        Me.Controls.Add(Me.txtpuesto)
        Me.Controls.Add(Me.txtrut)
        Me.Controls.Add(Me.cbhijos)
        Me.Controls.Add(Me.cbestadocivil)
        Me.Controls.Add(Me.txtcontraseña)
        Me.Controls.Add(Me.txtemailperso)
        Me.Controls.Add(Me.txttelefono)
        Me.Controls.Add(Me.txtcelular)
        Me.Controls.Add(Me.txtdireccion)
        Me.Controls.Add(Me.cbSexo)
        Me.Controls.Add(Me.txtapellido)
        Me.Controls.Add(Me.txtnombre)
        Me.Controls.Add(Me.cmdmodificaar2)
        Me.Controls.Add(Me.cmdlistar)
        Me.Controls.Add(Me.cmdeliminar)
        Me.Controls.Add(Me.cmdagregar)
        Me.Controls.Add(Me.cmdliquidar)
        Me.Controls.Add(Me.cmdficha)
        Me.Controls.Add(Me.cmdrecibo)
        Me.Controls.Add(Me.cmdinicio)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "modificar"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents rbadmin As System.Windows.Forms.RadioButton
    Friend WithEvents rbuser As System.Windows.Forms.RadioButton
    Friend WithEvents datenacimiento As System.Windows.Forms.DateTimePicker
    Friend WithEvents dateingreso As System.Windows.Forms.DateTimePicker
    Friend WithEvents txttelefonoemp As System.Windows.Forms.TextBox
    Friend WithEvents txtemailempre As System.Windows.Forms.TextBox
    Friend WithEvents txtdepartamento As System.Windows.Forms.TextBox
    Friend WithEvents txtgrado As System.Windows.Forms.TextBox
    Friend WithEvents txtcargo As System.Windows.Forms.TextBox
    Friend WithEvents txtpuesto As System.Windows.Forms.TextBox
    Friend WithEvents txtrut As System.Windows.Forms.TextBox
    Friend WithEvents cbhijos As System.Windows.Forms.ComboBox
    Friend WithEvents cbestadocivil As System.Windows.Forms.ComboBox
    Friend WithEvents txtcontraseña As System.Windows.Forms.TextBox
    Friend WithEvents txtemailperso As System.Windows.Forms.TextBox
    Friend WithEvents txttelefono As System.Windows.Forms.TextBox
    Friend WithEvents txtcelular As System.Windows.Forms.TextBox
    Friend WithEvents txtdireccion As System.Windows.Forms.TextBox
    Friend WithEvents cbSexo As System.Windows.Forms.ComboBox
    Friend WithEvents txtapellido As System.Windows.Forms.TextBox
    Friend WithEvents txtnombre As System.Windows.Forms.TextBox
    Friend WithEvents cmdmodificaar2 As System.Windows.Forms.Button
    Friend WithEvents cmdlistar As System.Windows.Forms.Button
    Friend WithEvents cmdeliminar As System.Windows.Forms.Button
    Friend WithEvents cmdagregar As System.Windows.Forms.Button
    Friend WithEvents cmdliquidar As System.Windows.Forms.Button
    Friend WithEvents cmdficha As System.Windows.Forms.Button
    Friend WithEvents cmdrecibo As System.Windows.Forms.Button
    Friend WithEvents cmdinicio As System.Windows.Forms.Button
    Friend WithEvents cbcédula As System.Windows.Forms.ComboBox
    Friend WithEvents cbregistro As System.Windows.Forms.ComboBox
    Friend WithEvents cmdayuda As System.Windows.Forms.Button
End Class
