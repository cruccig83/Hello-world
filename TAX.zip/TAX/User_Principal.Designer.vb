﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class User_Principal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(User_Principal))
        Me.pnlverticalmenu = New System.Windows.Forms.Panel
        Me.pnlBorInfIzq = New System.Windows.Forms.Panel
        Me.pnlBorIzq = New System.Windows.Forms.Panel
        Me.pnlselectedbtn = New System.Windows.Forms.Panel
        Me.pnltitlebar = New System.Windows.Forms.Panel
        Me.panelcontenedor = New System.Windows.Forms.Panel
        Me.centralpanel = New System.Windows.Forms.Panel
        Me.pnlBorDer = New System.Windows.Forms.Panel
        Me.pnlBorInfCentro = New System.Windows.Forms.Panel
        Me.Button1 = New System.Windows.Forms.Button
        Me.btnhrecibos = New System.Windows.Forms.Button
        Me.btnhlaboral = New System.Windows.Forms.Button
        Me.btnrecibo = New System.Windows.Forms.Button
        Me.btnficha = New System.Windows.Forms.Button
        Me.btninicio = New System.Windows.Forms.Button
        Me.PBtab = New System.Windows.Forms.PictureBox
        Me.btnMinimizar = New System.Windows.Forms.Button
        Me.btnclose = New System.Windows.Forms.Button
        Me.pnlverticalmenu.SuspendLayout()
        Me.pnltitlebar.SuspendLayout()
        Me.panelcontenedor.SuspendLayout()
        Me.centralpanel.SuspendLayout()
        CType(Me.PBtab, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlverticalmenu
        '
        Me.pnlverticalmenu.BackColor = System.Drawing.Color.White
        Me.pnlverticalmenu.Controls.Add(Me.pnlBorInfIzq)
        Me.pnlverticalmenu.Controls.Add(Me.pnlBorIzq)
        Me.pnlverticalmenu.Controls.Add(Me.Button1)
        Me.pnlverticalmenu.Controls.Add(Me.pnlselectedbtn)
        Me.pnlverticalmenu.Controls.Add(Me.btnhrecibos)
        Me.pnlverticalmenu.Controls.Add(Me.btnhlaboral)
        Me.pnlverticalmenu.Controls.Add(Me.btnrecibo)
        Me.pnlverticalmenu.Controls.Add(Me.btnficha)
        Me.pnlverticalmenu.Controls.Add(Me.btninicio)
        Me.pnlverticalmenu.Controls.Add(Me.PBtab)
        Me.pnlverticalmenu.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlverticalmenu.Location = New System.Drawing.Point(0, 25)
        Me.pnlverticalmenu.Name = "pnlverticalmenu"
        Me.pnlverticalmenu.Size = New System.Drawing.Size(175, 508)
        Me.pnlverticalmenu.TabIndex = 1
        '
        'pnlBorInfIzq
        '
        Me.pnlBorInfIzq.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.pnlBorInfIzq.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlBorInfIzq.Location = New System.Drawing.Point(1, 507)
        Me.pnlBorInfIzq.Name = "pnlBorInfIzq"
        Me.pnlBorInfIzq.Size = New System.Drawing.Size(174, 1)
        Me.pnlBorInfIzq.TabIndex = 22
        '
        'pnlBorIzq
        '
        Me.pnlBorIzq.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.pnlBorIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlBorIzq.Location = New System.Drawing.Point(0, 0)
        Me.pnlBorIzq.Name = "pnlBorIzq"
        Me.pnlBorIzq.Size = New System.Drawing.Size(1, 508)
        Me.pnlBorIzq.TabIndex = 21
        '
        'pnlselectedbtn
        '
        Me.pnlselectedbtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.pnlselectedbtn.Location = New System.Drawing.Point(0, 88)
        Me.pnlselectedbtn.Name = "pnlselectedbtn"
        Me.pnlselectedbtn.Size = New System.Drawing.Size(7, 44)
        Me.pnlselectedbtn.TabIndex = 8
        '
        'pnltitlebar
        '
        Me.pnltitlebar.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.pnltitlebar.Controls.Add(Me.btnMinimizar)
        Me.pnltitlebar.Controls.Add(Me.btnclose)
        Me.pnltitlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnltitlebar.Location = New System.Drawing.Point(0, 0)
        Me.pnltitlebar.Name = "pnltitlebar"
        Me.pnltitlebar.Size = New System.Drawing.Size(1017, 25)
        Me.pnltitlebar.TabIndex = 4
        '
        'panelcontenedor
        '
        Me.panelcontenedor.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.panelcontenedor.Controls.Add(Me.centralpanel)
        Me.panelcontenedor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelcontenedor.Location = New System.Drawing.Point(0, 25)
        Me.panelcontenedor.Name = "panelcontenedor"
        Me.panelcontenedor.Size = New System.Drawing.Size(1017, 508)
        Me.panelcontenedor.TabIndex = 7
        '
        'centralpanel
        '
        Me.centralpanel.Controls.Add(Me.pnlBorDer)
        Me.centralpanel.Controls.Add(Me.pnlBorInfCentro)
        Me.centralpanel.Location = New System.Drawing.Point(178, -1)
        Me.centralpanel.Name = "centralpanel"
        Me.centralpanel.Size = New System.Drawing.Size(842, 509)
        Me.centralpanel.TabIndex = 0
        '
        'pnlBorDer
        '
        Me.pnlBorDer.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.pnlBorDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlBorDer.Location = New System.Drawing.Point(841, 0)
        Me.pnlBorDer.Name = "pnlBorDer"
        Me.pnlBorDer.Size = New System.Drawing.Size(1, 508)
        Me.pnlBorDer.TabIndex = 1
        '
        'pnlBorInfCentro
        '
        Me.pnlBorInfCentro.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.pnlBorInfCentro.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlBorInfCentro.Location = New System.Drawing.Point(0, 508)
        Me.pnlBorInfCentro.Name = "pnlBorInfCentro"
        Me.pnlBorInfCentro.Size = New System.Drawing.Size(842, 1)
        Me.pnlBorInfCentro.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Image = Global.TAX.My.Resources.Resources.shutdown24
        Me.Button1.Location = New System.Drawing.Point(143, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(30, 30)
        Me.Button1.TabIndex = 20
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnhrecibos
        '
        Me.btnhrecibos.BackColor = System.Drawing.Color.White
        Me.btnhrecibos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnhrecibos.FlatAppearance.BorderSize = 0
        Me.btnhrecibos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnhrecibos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnhrecibos.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhrecibos.Image = CType(resources.GetObject("btnhrecibos.Image"), System.Drawing.Image)
        Me.btnhrecibos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnhrecibos.Location = New System.Drawing.Point(7, 264)
        Me.btnhrecibos.Name = "btnhrecibos"
        Me.btnhrecibos.Size = New System.Drawing.Size(167, 44)
        Me.btnhrecibos.TabIndex = 7
        Me.btnhrecibos.Text = "HISTORIAL" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RECIBOS"
        Me.btnhrecibos.UseVisualStyleBackColor = False
        '
        'btnhlaboral
        '
        Me.btnhlaboral.BackColor = System.Drawing.Color.White
        Me.btnhlaboral.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnhlaboral.FlatAppearance.BorderSize = 0
        Me.btnhlaboral.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnhlaboral.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnhlaboral.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhlaboral.Image = CType(resources.GetObject("btnhlaboral.Image"), System.Drawing.Image)
        Me.btnhlaboral.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnhlaboral.Location = New System.Drawing.Point(7, 220)
        Me.btnhlaboral.Name = "btnhlaboral"
        Me.btnhlaboral.Size = New System.Drawing.Size(167, 44)
        Me.btnhlaboral.TabIndex = 6
        Me.btnhlaboral.Text = "HISTORIA" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " LABORAL"
        Me.btnhlaboral.UseVisualStyleBackColor = False
        '
        'btnrecibo
        '
        Me.btnrecibo.BackColor = System.Drawing.Color.White
        Me.btnrecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnrecibo.FlatAppearance.BorderSize = 0
        Me.btnrecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnrecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnrecibo.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrecibo.Image = CType(resources.GetObject("btnrecibo.Image"), System.Drawing.Image)
        Me.btnrecibo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnrecibo.Location = New System.Drawing.Point(7, 176)
        Me.btnrecibo.Name = "btnrecibo"
        Me.btnrecibo.Size = New System.Drawing.Size(167, 44)
        Me.btnrecibo.TabIndex = 5
        Me.btnrecibo.Text = "RECIBO"
        Me.btnrecibo.UseVisualStyleBackColor = False
        '
        'btnficha
        '
        Me.btnficha.BackColor = System.Drawing.Color.White
        Me.btnficha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnficha.FlatAppearance.BorderSize = 0
        Me.btnficha.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnficha.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnficha.Image = CType(resources.GetObject("btnficha.Image"), System.Drawing.Image)
        Me.btnficha.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnficha.Location = New System.Drawing.Point(7, 132)
        Me.btnficha.Name = "btnficha"
        Me.btnficha.Size = New System.Drawing.Size(167, 44)
        Me.btnficha.TabIndex = 4
        Me.btnficha.Text = "FICHA"
        Me.btnficha.UseVisualStyleBackColor = False
        '
        'btninicio
        '
        Me.btninicio.BackColor = System.Drawing.Color.White
        Me.btninicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btninicio.FlatAppearance.BorderSize = 0
        Me.btninicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btninicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btninicio.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btninicio.Image = CType(resources.GetObject("btninicio.Image"), System.Drawing.Image)
        Me.btninicio.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btninicio.Location = New System.Drawing.Point(7, 88)
        Me.btninicio.Name = "btninicio"
        Me.btninicio.Size = New System.Drawing.Size(167, 44)
        Me.btninicio.TabIndex = 3
        Me.btninicio.Text = "INICIO"
        Me.btninicio.UseVisualStyleBackColor = False
        '
        'PBtab
        '
        Me.PBtab.Image = CType(resources.GetObject("PBtab.Image"), System.Drawing.Image)
        Me.PBtab.Location = New System.Drawing.Point(1, 35)
        Me.PBtab.Name = "PBtab"
        Me.PBtab.Size = New System.Drawing.Size(173, 42)
        Me.PBtab.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PBtab.TabIndex = 2
        Me.PBtab.TabStop = False
        '
        'btnMinimizar
        '
        Me.btnMinimizar.FlatAppearance.BorderSize = 0
        Me.btnMinimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinimizar.Image = Global.TAX.My.Resources.Resources.minimize_
        Me.btnMinimizar.Location = New System.Drawing.Point(944, 0)
        Me.btnMinimizar.Name = "btnMinimizar"
        Me.btnMinimizar.Size = New System.Drawing.Size(37, 25)
        Me.btnMinimizar.TabIndex = 6
        Me.btnMinimizar.UseVisualStyleBackColor = True
        '
        'btnclose
        '
        Me.btnclose.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnclose.FlatAppearance.BorderSize = 0
        Me.btnclose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red
        Me.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnclose.Image = Global.TAX.My.Resources.Resources.close_16
        Me.btnclose.Location = New System.Drawing.Point(981, 0)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(37, 25)
        Me.btnclose.TabIndex = 5
        Me.btnclose.UseVisualStyleBackColor = False
        '
        'User_Principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1017, 533)
        Me.Controls.Add(Me.pnlverticalmenu)
        Me.Controls.Add(Me.panelcontenedor)
        Me.Controls.Add(Me.pnltitlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "User_Principal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "iniciouser"
        Me.TransparencyKey = System.Drawing.Color.Maroon
        Me.pnlverticalmenu.ResumeLayout(False)
        Me.pnltitlebar.ResumeLayout(False)
        Me.panelcontenedor.ResumeLayout(False)
        Me.centralpanel.ResumeLayout(False)
        CType(Me.PBtab, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlverticalmenu As System.Windows.Forms.Panel
    Friend WithEvents PBtab As System.Windows.Forms.PictureBox
    Friend WithEvents btninicio As System.Windows.Forms.Button
    Friend WithEvents pnltitlebar As System.Windows.Forms.Panel
    Friend WithEvents btnhrecibos As System.Windows.Forms.Button
    Friend WithEvents btnhlaboral As System.Windows.Forms.Button
    Friend WithEvents btnrecibo As System.Windows.Forms.Button
    Friend WithEvents btnficha As System.Windows.Forms.Button
    Friend WithEvents panelcontenedor As System.Windows.Forms.Panel
    Friend WithEvents pnlselectedbtn As System.Windows.Forms.Panel
    Friend WithEvents centralpanel As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents pnlBorIzq As System.Windows.Forms.Panel
    Friend WithEvents pnlBorInfCentro As System.Windows.Forms.Panel
    Friend WithEvents pnlBorInfIzq As System.Windows.Forms.Panel
    Friend WithEvents pnlBorDer As System.Windows.Forms.Panel
    Friend WithEvents btnMinimizar As System.Windows.Forms.Button
    Friend WithEvents btnclose As System.Windows.Forms.Button
End Class
