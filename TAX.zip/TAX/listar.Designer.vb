﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class listar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(listar))
        Me.txtbusquedacedula = New System.Windows.Forms.TextBox
        Me.txtbusquedanombre = New System.Windows.Forms.TextBox
        Me.lbcedula = New System.Windows.Forms.ListBox
        Me.lbnombre = New System.Windows.Forms.ListBox
        Me.cmdinicio = New System.Windows.Forms.Button
        Me.cmdeliminar = New System.Windows.Forms.Button
        Me.cmdmodificar = New System.Windows.Forms.Button
        Me.cmdagregar = New System.Windows.Forms.Button
        Me.cmdficha = New System.Windows.Forms.Button
        Me.cmdliquidar = New System.Windows.Forms.Button
        Me.cmdrecibo = New System.Windows.Forms.Button
        Me.cmdayuda = New System.Windows.Forms.Button
        Me.cmdcomprobar = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'txtbusquedacedula
        '
        Me.txtbusquedacedula.Location = New System.Drawing.Point(176, 249)
        Me.txtbusquedacedula.Name = "txtbusquedacedula"
        Me.txtbusquedacedula.Size = New System.Drawing.Size(172, 20)
        Me.txtbusquedacedula.TabIndex = 0
        '
        'txtbusquedanombre
        '
        Me.txtbusquedanombre.Location = New System.Drawing.Point(484, 249)
        Me.txtbusquedanombre.Name = "txtbusquedanombre"
        Me.txtbusquedanombre.Size = New System.Drawing.Size(172, 20)
        Me.txtbusquedanombre.TabIndex = 1
        '
        'lbcedula
        '
        Me.lbcedula.FormattingEnabled = True
        Me.lbcedula.Location = New System.Drawing.Point(176, 299)
        Me.lbcedula.Name = "lbcedula"
        Me.lbcedula.Size = New System.Drawing.Size(172, 160)
        Me.lbcedula.TabIndex = 2
        '
        'lbnombre
        '
        Me.lbnombre.FormattingEnabled = True
        Me.lbnombre.Location = New System.Drawing.Point(484, 299)
        Me.lbnombre.Name = "lbnombre"
        Me.lbnombre.Size = New System.Drawing.Size(172, 160)
        Me.lbnombre.TabIndex = 3
        '
        'cmdinicio
        '
        Me.cmdinicio.BackColor = System.Drawing.Color.Transparent
        Me.cmdinicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdinicio.Location = New System.Drawing.Point(16, 145)
        Me.cmdinicio.Name = "cmdinicio"
        Me.cmdinicio.Size = New System.Drawing.Size(123, 30)
        Me.cmdinicio.TabIndex = 67
        Me.cmdinicio.UseVisualStyleBackColor = False
        '
        'cmdeliminar
        '
        Me.cmdeliminar.BackColor = System.Drawing.Color.Transparent
        Me.cmdeliminar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdeliminar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdeliminar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdeliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdeliminar.Location = New System.Drawing.Point(294, 158)
        Me.cmdeliminar.Name = "cmdeliminar"
        Me.cmdeliminar.Size = New System.Drawing.Size(54, 42)
        Me.cmdeliminar.TabIndex = 66
        Me.cmdeliminar.UseVisualStyleBackColor = False
        '
        'cmdmodificar
        '
        Me.cmdmodificar.BackColor = System.Drawing.Color.Transparent
        Me.cmdmodificar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdmodificar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdmodificar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdmodificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdmodificar.Location = New System.Drawing.Point(225, 158)
        Me.cmdmodificar.Name = "cmdmodificar"
        Me.cmdmodificar.Size = New System.Drawing.Size(54, 42)
        Me.cmdmodificar.TabIndex = 65
        Me.cmdmodificar.UseVisualStyleBackColor = False
        '
        'cmdagregar
        '
        Me.cmdagregar.BackColor = System.Drawing.Color.Transparent
        Me.cmdagregar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdagregar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdagregar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdagregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdagregar.Location = New System.Drawing.Point(153, 158)
        Me.cmdagregar.Name = "cmdagregar"
        Me.cmdagregar.Size = New System.Drawing.Size(56, 42)
        Me.cmdagregar.TabIndex = 64
        Me.cmdagregar.UseVisualStyleBackColor = False
        '
        'cmdficha
        '
        Me.cmdficha.BackColor = System.Drawing.Color.Transparent
        Me.cmdficha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdficha.Location = New System.Drawing.Point(16, 181)
        Me.cmdficha.Name = "cmdficha"
        Me.cmdficha.Size = New System.Drawing.Size(123, 31)
        Me.cmdficha.TabIndex = 63
        Me.cmdficha.UseVisualStyleBackColor = False
        '
        'cmdliquidar
        '
        Me.cmdliquidar.BackColor = System.Drawing.Color.Transparent
        Me.cmdliquidar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdliquidar.Location = New System.Drawing.Point(13, 301)
        Me.cmdliquidar.Name = "cmdliquidar"
        Me.cmdliquidar.Size = New System.Drawing.Size(123, 31)
        Me.cmdliquidar.TabIndex = 69
        Me.cmdliquidar.UseVisualStyleBackColor = False
        '
        'cmdrecibo
        '
        Me.cmdrecibo.BackColor = System.Drawing.Color.Transparent
        Me.cmdrecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdrecibo.Location = New System.Drawing.Point(16, 218)
        Me.cmdrecibo.Name = "cmdrecibo"
        Me.cmdrecibo.Size = New System.Drawing.Size(123, 31)
        Me.cmdrecibo.TabIndex = 68
        Me.cmdrecibo.UseVisualStyleBackColor = False
        '
        'cmdayuda
        '
        Me.cmdayuda.BackColor = System.Drawing.Color.Transparent
        Me.cmdayuda.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdayuda.Location = New System.Drawing.Point(664, 66)
        Me.cmdayuda.Name = "cmdayuda"
        Me.cmdayuda.Size = New System.Drawing.Size(93, 30)
        Me.cmdayuda.TabIndex = 79
        Me.cmdayuda.UseVisualStyleBackColor = False
        '
        'cmdcomprobar
        '
        Me.cmdcomprobar.Location = New System.Drawing.Point(379, 438)
        Me.cmdcomprobar.Name = "cmdcomprobar"
        Me.cmdcomprobar.Size = New System.Drawing.Size(70, 20)
        Me.cmdcomprobar.TabIndex = 80
        Me.cmdcomprobar.Text = "Comprobar"
        Me.cmdcomprobar.UseVisualStyleBackColor = True
        '
        'listar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(769, 563)
        Me.Controls.Add(Me.cmdcomprobar)
        Me.Controls.Add(Me.cmdayuda)
        Me.Controls.Add(Me.cmdliquidar)
        Me.Controls.Add(Me.cmdrecibo)
        Me.Controls.Add(Me.cmdinicio)
        Me.Controls.Add(Me.cmdeliminar)
        Me.Controls.Add(Me.cmdmodificar)
        Me.Controls.Add(Me.cmdagregar)
        Me.Controls.Add(Me.cmdficha)
        Me.Controls.Add(Me.lbnombre)
        Me.Controls.Add(Me.lbcedula)
        Me.Controls.Add(Me.txtbusquedanombre)
        Me.Controls.Add(Me.txtbusquedacedula)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "listar"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtbusquedacedula As System.Windows.Forms.TextBox
    Friend WithEvents txtbusquedanombre As System.Windows.Forms.TextBox
    Friend WithEvents lbcedula As System.Windows.Forms.ListBox
    Friend WithEvents lbnombre As System.Windows.Forms.ListBox
    Friend WithEvents cmdinicio As System.Windows.Forms.Button
    Friend WithEvents cmdeliminar As System.Windows.Forms.Button
    Friend WithEvents cmdmodificar As System.Windows.Forms.Button
    Friend WithEvents cmdagregar As System.Windows.Forms.Button
    Friend WithEvents cmdficha As System.Windows.Forms.Button
    Friend WithEvents cmdliquidar As System.Windows.Forms.Button
    Friend WithEvents cmdrecibo As System.Windows.Forms.Button
    Friend WithEvents cmdayuda As System.Windows.Forms.Button
    Friend WithEvents cmdcomprobar As System.Windows.Forms.Button
End Class
