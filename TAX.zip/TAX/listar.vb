﻿Public Class listar

    Private Sub cmdinicio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdinicio.Click
        inicioadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdficha.Click
        ficharoja.Show()
        Me.Close()

    End Sub

    Private Sub cmdrecibo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdrecibo.Click
        mireciboadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdliquidar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdliquidar.Click
        sueldos.Show()
        Me.Close()

    End Sub

    Private Sub cmdagregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdagregar.Click
        empleados.Show()
        Me.Close()

    End Sub

    Private Sub cmdmodificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdmodificar.Click
        modificar.Show()
        Me.Close()

    End Sub

    Private Sub cmdeliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdeliminar.Click
        eliminar.Show()
        Me.Close()

    End Sub

    Private Sub cmdayuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdayuda.Click
        MsgBox("En Progreso")
    End Sub

    Private Sub txtbusquedacedula_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtbusquedacedula.TextChanged
    End Sub

    Private Sub cmdcomprobar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdcomprobar.Click
        If Not (IsNumeric(txtbusquedacedula.Text)) Then
            MsgBox("Cedula: Solo se admiten numeros")
            txtbusquedacedula.Text = ""
            txtbusquedacedula.Focus()
        End If
    End Sub
End Class