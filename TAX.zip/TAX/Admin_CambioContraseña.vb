﻿Imports MySql.Data.MySqlClient
Imports System.Runtime.InteropServices
Public Class Admin_CambioContraseña

    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")> Private Shared Sub ReleaseCapture()
    End Sub
    <DllImport("user32.DLL", EntryPoint:="SendMessage")> Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub

    Dim contraseña As String
    Private Sub btnCambiarContraseña_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCambiarContraseña.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader
        Dim rdr2 As MySqlDataReader
        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE doc = '" & Module1.document & "' AND passwd= '" & txtContraseñaActual.Text & "'"
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            Dim cont As Integer
            cont = 0
            While rdr.Read
                cont = cont + 1
            End While
            rdr.Close()

            If cont = 1 Then


                If txtContraseñaNueva.Text = txtRepetirContraseña.Text Then

                    Dim Query2 As String
                    Query2 = "UPDATE personal SET passwd = '" & txtContraseñaNueva.Text & "' WHERE doc = " & Module1.document & " "
                    Dim cmd2 As New MySqlCommand(Query2, cnn)
                    rdr2 = cmd2.ExecuteReader
                    While rdr2.Read
                        cont = cont
                    End While
                    rdr.Close()
                    MsgBox("Su contraseña ha sido actualizada")
                    Me.Close()
                Else
                    MsgBox("Las contraseñas no coinciden, verifique")
                End If

            ElseIf cont < 1 Then
                MsgBox("La contraseña actual es incorrecta, verifique")
            End If



            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub btnVerContraseñaActual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerContraseñaActual.Click
        If txtContraseñaActual.UseSystemPasswordChar = False Then
            txtContraseñaActual.UseSystemPasswordChar = True
            btnVerContraseñaActual.Image = My.Resources.ver_16
        Else
            txtContraseñaActual.UseSystemPasswordChar = False
            btnVerContraseñaActual.Image = My.Resources.ocultar

        End If
    End Sub

    Private Sub btnVerNuevaContraseña_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerNuevaContraseña.Click
        If txtContraseñaNueva.UseSystemPasswordChar = False Then
            txtContraseñaNueva.UseSystemPasswordChar = True
            btnVerNuevaContraseña.Image = My.Resources.ver_16
        Else
            txtContraseñaNueva.UseSystemPasswordChar = False
            btnVerNuevaContraseña.Image = My.Resources.ocultar

        End If
    End Sub

    Private Sub btnVerRepitaContraseña_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerRepitaContraseña.Click
        If txtRepetirContraseña.UseSystemPasswordChar = False Then
            txtRepetirContraseña.UseSystemPasswordChar = True
            btnVerRepitaContraseña.Image = My.Resources.ver_16
        Else
            txtRepetirContraseña.UseSystemPasswordChar = False
            btnVerRepitaContraseña.Image = My.Resources.ocultar

        End If
    End Sub

    Private Sub Admin_CambioContraseña_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        txtContraseñaActual.UseSystemPasswordChar = True
        txtContraseñaNueva.UseSystemPasswordChar = True
        txtRepetirContraseña.UseSystemPasswordChar = True
    End Sub

    Private Sub btnclose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub


    Private Sub pnlTitulo_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pnlTitulo.MouseMove
        ReleaseCapture()
        SendMessage(Me.Handle, &H112&, &HF012&, 0)
    End Sub
End Class