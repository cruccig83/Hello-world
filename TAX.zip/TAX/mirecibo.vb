﻿Public Class mirecibo

    Private Sub cmdinicio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdinicio.Click
        pantalladeinicio.Show()
        Me.Close()


    End Sub

    Private Sub cmdficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdficha.Click
        ficha.Show()
        Me.Close()

    End Sub

    Private Sub cmdhistorialaboral_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhistorialaboral.Click
        historialboral.Show()
        Me.Close()

    End Sub

    Private Sub cmdhistorialrecibos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhistorialrecibos.Click
        historial_recibos.Show()
        Me.Close()

    End Sub

    Private Sub cmdayuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdayuda.Click
        MsgBox("En Progreso")
    End Sub
End Class