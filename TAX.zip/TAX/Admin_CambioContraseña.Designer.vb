﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_CambioContraseña
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlTitulo = New System.Windows.Forms.Panel
        Me.btnclose = New System.Windows.Forms.PictureBox
        Me.pnlBorDer = New System.Windows.Forms.Panel
        Me.pnlBorInf = New System.Windows.Forms.Panel
        Me.pnlBorIzq = New System.Windows.Forms.Panel
        Me.lblUstedVaACambiar = New System.Windows.Forms.Label
        Me.pnlCentral = New System.Windows.Forms.Panel
        Me.btnVerRepitaContraseña = New System.Windows.Forms.Button
        Me.btnVerNuevaContraseña = New System.Windows.Forms.Button
        Me.btnVerContraseñaActual = New System.Windows.Forms.Button
        Me.txtRepetirContraseña = New System.Windows.Forms.TextBox
        Me.txtContraseñaNueva = New System.Windows.Forms.TextBox
        Me.txtContraseñaActual = New System.Windows.Forms.TextBox
        Me.btnCambiarContraseña = New System.Windows.Forms.Button
        Me.lblRepetirContraseña = New System.Windows.Forms.Label
        Me.lblNuevaContraseña = New System.Windows.Forms.Label
        Me.lblContraseñaActual = New System.Windows.Forms.Label
        Me.pnlTitulo.SuspendLayout()
        CType(Me.btnclose, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlCentral.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlTitulo
        '
        Me.pnlTitulo.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlTitulo.Controls.Add(Me.btnclose)
        Me.pnlTitulo.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitulo.Location = New System.Drawing.Point(0, 0)
        Me.pnlTitulo.Name = "pnlTitulo"
        Me.pnlTitulo.Size = New System.Drawing.Size(440, 25)
        Me.pnlTitulo.TabIndex = 0
        '
        'btnclose
        '
        Me.btnclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnclose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnclose.Image = Global.TAX.My.Resources.Resources.close_16
        Me.btnclose.ImageLocation = ""
        Me.btnclose.Location = New System.Drawing.Point(421, 3)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(16, 16)
        Me.btnclose.TabIndex = 3
        Me.btnclose.TabStop = False
        '
        'pnlBorDer
        '
        Me.pnlBorDer.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlBorDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlBorDer.Location = New System.Drawing.Point(439, 25)
        Me.pnlBorDer.Name = "pnlBorDer"
        Me.pnlBorDer.Size = New System.Drawing.Size(1, 263)
        Me.pnlBorDer.TabIndex = 1
        '
        'pnlBorInf
        '
        Me.pnlBorInf.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlBorInf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlBorInf.Location = New System.Drawing.Point(0, 287)
        Me.pnlBorInf.Name = "pnlBorInf"
        Me.pnlBorInf.Size = New System.Drawing.Size(439, 1)
        Me.pnlBorInf.TabIndex = 2
        '
        'pnlBorIzq
        '
        Me.pnlBorIzq.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlBorIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlBorIzq.Location = New System.Drawing.Point(0, 25)
        Me.pnlBorIzq.Name = "pnlBorIzq"
        Me.pnlBorIzq.Size = New System.Drawing.Size(1, 262)
        Me.pnlBorIzq.TabIndex = 3
        '
        'lblUstedVaACambiar
        '
        Me.lblUstedVaACambiar.AutoSize = True
        Me.lblUstedVaACambiar.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUstedVaACambiar.Location = New System.Drawing.Point(99, 14)
        Me.lblUstedVaACambiar.Name = "lblUstedVaACambiar"
        Me.lblUstedVaACambiar.Size = New System.Drawing.Size(228, 20)
        Me.lblUstedVaACambiar.TabIndex = 4
        Me.lblUstedVaACambiar.Text = "Usted va a cambiar su contraseña"
        '
        'pnlCentral
        '
        Me.pnlCentral.Controls.Add(Me.btnVerRepitaContraseña)
        Me.pnlCentral.Controls.Add(Me.btnVerNuevaContraseña)
        Me.pnlCentral.Controls.Add(Me.btnVerContraseñaActual)
        Me.pnlCentral.Controls.Add(Me.txtRepetirContraseña)
        Me.pnlCentral.Controls.Add(Me.txtContraseñaNueva)
        Me.pnlCentral.Controls.Add(Me.txtContraseñaActual)
        Me.pnlCentral.Controls.Add(Me.btnCambiarContraseña)
        Me.pnlCentral.Controls.Add(Me.lblRepetirContraseña)
        Me.pnlCentral.Controls.Add(Me.lblNuevaContraseña)
        Me.pnlCentral.Controls.Add(Me.lblUstedVaACambiar)
        Me.pnlCentral.Controls.Add(Me.lblContraseñaActual)
        Me.pnlCentral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlCentral.Location = New System.Drawing.Point(1, 25)
        Me.pnlCentral.Name = "pnlCentral"
        Me.pnlCentral.Size = New System.Drawing.Size(438, 262)
        Me.pnlCentral.TabIndex = 5
        '
        'btnVerRepitaContraseña
        '
        Me.btnVerRepitaContraseña.BackColor = System.Drawing.SystemColors.Control
        Me.btnVerRepitaContraseña.FlatAppearance.BorderSize = 0
        Me.btnVerRepitaContraseña.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVerRepitaContraseña.Image = Global.TAX.My.Resources.Resources.ver_16
        Me.btnVerRepitaContraseña.Location = New System.Drawing.Point(285, 170)
        Me.btnVerRepitaContraseña.Name = "btnVerRepitaContraseña"
        Me.btnVerRepitaContraseña.Size = New System.Drawing.Size(25, 25)
        Me.btnVerRepitaContraseña.TabIndex = 13
        Me.btnVerRepitaContraseña.UseVisualStyleBackColor = False
        '
        'btnVerNuevaContraseña
        '
        Me.btnVerNuevaContraseña.BackColor = System.Drawing.SystemColors.Control
        Me.btnVerNuevaContraseña.FlatAppearance.BorderSize = 0
        Me.btnVerNuevaContraseña.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVerNuevaContraseña.Image = Global.TAX.My.Resources.Resources.ver_16
        Me.btnVerNuevaContraseña.Location = New System.Drawing.Point(285, 120)
        Me.btnVerNuevaContraseña.Name = "btnVerNuevaContraseña"
        Me.btnVerNuevaContraseña.Size = New System.Drawing.Size(25, 25)
        Me.btnVerNuevaContraseña.TabIndex = 12
        Me.btnVerNuevaContraseña.UseVisualStyleBackColor = False
        '
        'btnVerContraseñaActual
        '
        Me.btnVerContraseñaActual.BackColor = System.Drawing.SystemColors.Control
        Me.btnVerContraseñaActual.FlatAppearance.BorderSize = 0
        Me.btnVerContraseñaActual.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVerContraseñaActual.Image = Global.TAX.My.Resources.Resources.ver_16
        Me.btnVerContraseñaActual.Location = New System.Drawing.Point(285, 70)
        Me.btnVerContraseñaActual.Name = "btnVerContraseñaActual"
        Me.btnVerContraseñaActual.Size = New System.Drawing.Size(25, 25)
        Me.btnVerContraseñaActual.TabIndex = 11
        Me.btnVerContraseñaActual.UseVisualStyleBackColor = False
        '
        'txtRepetirContraseña
        '
        Me.txtRepetirContraseña.Location = New System.Drawing.Point(147, 172)
        Me.txtRepetirContraseña.Name = "txtRepetirContraseña"
        Me.txtRepetirContraseña.Size = New System.Drawing.Size(132, 20)
        Me.txtRepetirContraseña.TabIndex = 10
        '
        'txtContraseñaNueva
        '
        Me.txtContraseñaNueva.Location = New System.Drawing.Point(147, 122)
        Me.txtContraseñaNueva.Name = "txtContraseñaNueva"
        Me.txtContraseñaNueva.Size = New System.Drawing.Size(132, 20)
        Me.txtContraseñaNueva.TabIndex = 9
        '
        'txtContraseñaActual
        '
        Me.txtContraseñaActual.Location = New System.Drawing.Point(147, 72)
        Me.txtContraseñaActual.Name = "txtContraseñaActual"
        Me.txtContraseñaActual.Size = New System.Drawing.Size(132, 20)
        Me.txtContraseñaActual.TabIndex = 8
        '
        'btnCambiarContraseña
        '
        Me.btnCambiarContraseña.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.btnCambiarContraseña.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.btnCambiarContraseña.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(143, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.btnCambiarContraseña.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(143, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.btnCambiarContraseña.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCambiarContraseña.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCambiarContraseña.ForeColor = System.Drawing.Color.White
        Me.btnCambiarContraseña.Location = New System.Drawing.Point(138, 214)
        Me.btnCambiarContraseña.Name = "btnCambiarContraseña"
        Me.btnCambiarContraseña.Size = New System.Drawing.Size(152, 30)
        Me.btnCambiarContraseña.TabIndex = 7
        Me.btnCambiarContraseña.Text = "CAMBIAR CONTRASEÑA"
        Me.btnCambiarContraseña.UseVisualStyleBackColor = False
        '
        'lblRepetirContraseña
        '
        Me.lblRepetirContraseña.AutoSize = True
        Me.lblRepetirContraseña.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRepetirContraseña.Location = New System.Drawing.Point(156, 149)
        Me.lblRepetirContraseña.Name = "lblRepetirContraseña"
        Me.lblRepetirContraseña.Size = New System.Drawing.Size(114, 16)
        Me.lblRepetirContraseña.TabIndex = 6
        Me.lblRepetirContraseña.Text = "Repita la contraseña:"
        '
        'lblNuevaContraseña
        '
        Me.lblNuevaContraseña.AutoSize = True
        Me.lblNuevaContraseña.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNuevaContraseña.Location = New System.Drawing.Point(163, 99)
        Me.lblNuevaContraseña.Name = "lblNuevaContraseña"
        Me.lblNuevaContraseña.Size = New System.Drawing.Size(100, 16)
        Me.lblNuevaContraseña.TabIndex = 5
        Me.lblNuevaContraseña.Text = "Nueva contraseña:"
        '
        'lblContraseñaActual
        '
        Me.lblContraseñaActual.AutoSize = True
        Me.lblContraseñaActual.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContraseñaActual.Location = New System.Drawing.Point(162, 49)
        Me.lblContraseñaActual.Name = "lblContraseñaActual"
        Me.lblContraseñaActual.Size = New System.Drawing.Size(102, 16)
        Me.lblContraseñaActual.TabIndex = 0
        Me.lblContraseñaActual.Text = "Contraseña Acutal:"
        '
        'Admin_CambioContraseña
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(440, 288)
        Me.Controls.Add(Me.pnlCentral)
        Me.Controls.Add(Me.pnlBorIzq)
        Me.Controls.Add(Me.pnlBorInf)
        Me.Controls.Add(Me.pnlBorDer)
        Me.Controls.Add(Me.pnlTitulo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_CambioContraseña"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Admin_CambioContraseña"
        Me.pnlTitulo.ResumeLayout(False)
        CType(Me.btnclose, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlCentral.ResumeLayout(False)
        Me.pnlCentral.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlTitulo As System.Windows.Forms.Panel
    Friend WithEvents pnlBorDer As System.Windows.Forms.Panel
    Friend WithEvents pnlBorInf As System.Windows.Forms.Panel
    Friend WithEvents pnlBorIzq As System.Windows.Forms.Panel
    Friend WithEvents lblUstedVaACambiar As System.Windows.Forms.Label
    Friend WithEvents pnlCentral As System.Windows.Forms.Panel
    Friend WithEvents lblContraseñaActual As System.Windows.Forms.Label
    Friend WithEvents txtContraseñaActual As System.Windows.Forms.TextBox
    Friend WithEvents btnCambiarContraseña As System.Windows.Forms.Button
    Friend WithEvents lblRepetirContraseña As System.Windows.Forms.Label
    Friend WithEvents lblNuevaContraseña As System.Windows.Forms.Label
    Friend WithEvents txtRepetirContraseña As System.Windows.Forms.TextBox
    Friend WithEvents txtContraseñaNueva As System.Windows.Forms.TextBox
    Friend WithEvents btnVerRepitaContraseña As System.Windows.Forms.Button
    Friend WithEvents btnVerNuevaContraseña As System.Windows.Forms.Button
    Friend WithEvents btnVerContraseñaActual As System.Windows.Forms.Button
    Friend WithEvents btnclose As System.Windows.Forms.PictureBox
End Class
