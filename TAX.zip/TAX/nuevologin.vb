﻿Imports MySql.Data.MySqlClient
Imports System.Runtime.InteropServices
Public Class nuevologin

    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")> Private Shared Sub ReleaseCapture()
    End Sub
    <DllImport("user32.DLL", EntryPoint:="SendMessage")> Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub

    Private Sub btnentrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnentrar.Click

        

        Module1.document = txtDocumento.Text
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader
        Dim cont As Integer
        Dim activo As Char
        cont = 0
        Dim rol As Integer
        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE doc = '" & txtDocumento.Text & "' AND passwd= '" & txtContraseña.Text & "'"
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            cont = 0
            While rdr.Read
                cont = cont + 1
                rol = rdr.Item("rol").ToString
                activo = rdr.Item("activo").ToString
            End While
            rdr.Close()


            If cont = 1 Then

                If activo = "s" Then

                    If rol = 1 Then
                        Admin_Principal.Show()
                        MsgBox("Bienvenido.")
                        Me.Close()
                    ElseIf rol = 2 Then
                        User_Principal.Show()
                        MsgBox("bienvenido.")
                        Me.Close()
                    End If

                ElseIf activo = "n" Then
                    MsgBox("Usted ya no tiene permisos para ingresar al sistema. Comuniquese con su administrador.")
                End If
            Else
                MsgBox("Usuario y/o contraseña incorrecto(s).")
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub


    Private Sub nuevologin_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblBIENVENIDO.Parent = PictureBox3
        txtContraseña.UseSystemPasswordChar = True
    End Sub

    
    Private Sub btnVerContraseña_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerContraseña.Click
        If txtContraseña.UseSystemPasswordChar = False Then
            txtContraseña.UseSystemPasswordChar = True
            btnVerContraseña.Image = My.Resources.ver_16
        Else
            txtContraseña.UseSystemPasswordChar = False
            btnVerContraseña.Image = My.Resources.ocultar

        End If
    End Sub

    Private Sub btnclose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Application.Exit()
    End Sub

    
    Private Sub txtDocumento_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDocumento.Leave
        If Not IsNumeric(txtDocumento.Text) Then
            lblError.Visible = True
            pnlError.Visible = True
        Else
            lblError.Visible = False
            pnlError.Visible = False
        End If
    End Sub



    Private Sub btnMinimizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinimizar.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btnclose_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclose.Click
        Application.Exit()
    End Sub

    Private Sub pnlBarraDeTitulo_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pnlBarraDeTitulo.MouseMove
        ReleaseCapture()
        SendMessage(Me.Handle, &H112&, &HF012&, 0)
    End Sub
End Class