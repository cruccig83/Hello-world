﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class organizacion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(organizacion))
        Me.cmdhistorialrecibos = New System.Windows.Forms.Button
        Me.cmdrecibo = New System.Windows.Forms.Button
        Me.cmdhistorialaboral = New System.Windows.Forms.Button
        Me.cmdinicio = New System.Windows.Forms.Button
        Me.cmdficha = New System.Windows.Forms.Button
        Me.txtrut = New System.Windows.Forms.TextBox
        Me.txtnregistros = New System.Windows.Forms.TextBox
        Me.txtingreso = New System.Windows.Forms.TextBox
        Me.txtpuesto = New System.Windows.Forms.TextBox
        Me.txtcargo = New System.Windows.Forms.TextBox
        Me.txtgrado = New System.Windows.Forms.TextBox
        Me.txtdept = New System.Windows.Forms.TextBox
        Me.txttelefono = New System.Windows.Forms.TextBox
        Me.txtemailempre = New System.Windows.Forms.TextBox
        Me.cmdayuda = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cmdhistorialrecibos
        '
        Me.cmdhistorialrecibos.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialrecibos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialrecibos.Location = New System.Drawing.Point(31, 356)
        Me.cmdhistorialrecibos.Name = "cmdhistorialrecibos"
        Me.cmdhistorialrecibos.Size = New System.Drawing.Size(116, 36)
        Me.cmdhistorialrecibos.TabIndex = 8
        Me.cmdhistorialrecibos.UseVisualStyleBackColor = False
        '
        'cmdrecibo
        '
        Me.cmdrecibo.BackColor = System.Drawing.Color.Transparent
        Me.cmdrecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdrecibo.Location = New System.Drawing.Point(30, 254)
        Me.cmdrecibo.Name = "cmdrecibo"
        Me.cmdrecibo.Size = New System.Drawing.Size(116, 36)
        Me.cmdrecibo.TabIndex = 7
        Me.cmdrecibo.UseVisualStyleBackColor = False
        '
        'cmdhistorialaboral
        '
        Me.cmdhistorialaboral.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialaboral.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialaboral.Location = New System.Drawing.Point(30, 305)
        Me.cmdhistorialaboral.Name = "cmdhistorialaboral"
        Me.cmdhistorialaboral.Size = New System.Drawing.Size(116, 36)
        Me.cmdhistorialaboral.TabIndex = 6
        Me.cmdhistorialaboral.UseVisualStyleBackColor = False
        '
        'cmdinicio
        '
        Me.cmdinicio.BackColor = System.Drawing.Color.Transparent
        Me.cmdinicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdinicio.Location = New System.Drawing.Point(30, 157)
        Me.cmdinicio.Name = "cmdinicio"
        Me.cmdinicio.Size = New System.Drawing.Size(116, 36)
        Me.cmdinicio.TabIndex = 5
        Me.cmdinicio.UseVisualStyleBackColor = False
        '
        'cmdficha
        '
        Me.cmdficha.BackColor = System.Drawing.Color.Transparent
        Me.cmdficha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdficha.Location = New System.Drawing.Point(170, 172)
        Me.cmdficha.Name = "cmdficha"
        Me.cmdficha.Size = New System.Drawing.Size(46, 36)
        Me.cmdficha.TabIndex = 9
        Me.cmdficha.UseVisualStyleBackColor = False
        '
        'txtrut
        '
        Me.txtrut.Location = New System.Drawing.Point(224, 259)
        Me.txtrut.Name = "txtrut"
        Me.txtrut.Size = New System.Drawing.Size(173, 20)
        Me.txtrut.TabIndex = 10
        '
        'txtnregistros
        '
        Me.txtnregistros.Location = New System.Drawing.Point(281, 284)
        Me.txtnregistros.Name = "txtnregistros"
        Me.txtnregistros.Size = New System.Drawing.Size(173, 20)
        Me.txtnregistros.TabIndex = 11
        '
        'txtingreso
        '
        Me.txtingreso.Location = New System.Drawing.Point(276, 309)
        Me.txtingreso.Name = "txtingreso"
        Me.txtingreso.Size = New System.Drawing.Size(173, 20)
        Me.txtingreso.TabIndex = 12
        '
        'txtpuesto
        '
        Me.txtpuesto.Location = New System.Drawing.Point(237, 333)
        Me.txtpuesto.Name = "txtpuesto"
        Me.txtpuesto.Size = New System.Drawing.Size(173, 20)
        Me.txtpuesto.TabIndex = 13
        '
        'txtcargo
        '
        Me.txtcargo.Location = New System.Drawing.Point(236, 358)
        Me.txtcargo.Name = "txtcargo"
        Me.txtcargo.Size = New System.Drawing.Size(173, 20)
        Me.txtcargo.TabIndex = 14
        '
        'txtgrado
        '
        Me.txtgrado.Location = New System.Drawing.Point(234, 386)
        Me.txtgrado.Name = "txtgrado"
        Me.txtgrado.Size = New System.Drawing.Size(173, 20)
        Me.txtgrado.TabIndex = 15
        '
        'txtdept
        '
        Me.txtdept.Location = New System.Drawing.Point(262, 411)
        Me.txtdept.Name = "txtdept"
        Me.txtdept.Size = New System.Drawing.Size(173, 20)
        Me.txtdept.TabIndex = 16
        '
        'txttelefono
        '
        Me.txttelefono.Location = New System.Drawing.Point(290, 435)
        Me.txttelefono.Name = "txttelefono"
        Me.txttelefono.Size = New System.Drawing.Size(173, 20)
        Me.txttelefono.TabIndex = 17
        '
        'txtemailempre
        '
        Me.txtemailempre.Location = New System.Drawing.Point(276, 461)
        Me.txtemailempre.Name = "txtemailempre"
        Me.txtemailempre.Size = New System.Drawing.Size(173, 20)
        Me.txtemailempre.TabIndex = 18
        '
        'cmdayuda
        '
        Me.cmdayuda.BackColor = System.Drawing.Color.Transparent
        Me.cmdayuda.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdayuda.Location = New System.Drawing.Point(671, 70)
        Me.cmdayuda.Name = "cmdayuda"
        Me.cmdayuda.Size = New System.Drawing.Size(93, 30)
        Me.cmdayuda.TabIndex = 79
        Me.cmdayuda.UseVisualStyleBackColor = False
        '
        'organizacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(776, 562)
        Me.Controls.Add(Me.cmdayuda)
        Me.Controls.Add(Me.txtemailempre)
        Me.Controls.Add(Me.txttelefono)
        Me.Controls.Add(Me.txtdept)
        Me.Controls.Add(Me.txtgrado)
        Me.Controls.Add(Me.txtcargo)
        Me.Controls.Add(Me.txtpuesto)
        Me.Controls.Add(Me.txtingreso)
        Me.Controls.Add(Me.txtnregistros)
        Me.Controls.Add(Me.txtrut)
        Me.Controls.Add(Me.cmdficha)
        Me.Controls.Add(Me.cmdhistorialrecibos)
        Me.Controls.Add(Me.cmdrecibo)
        Me.Controls.Add(Me.cmdhistorialaboral)
        Me.Controls.Add(Me.cmdinicio)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "organizacion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdhistorialrecibos As System.Windows.Forms.Button
    Friend WithEvents cmdrecibo As System.Windows.Forms.Button
    Friend WithEvents cmdhistorialaboral As System.Windows.Forms.Button
    Friend WithEvents cmdinicio As System.Windows.Forms.Button
    Friend WithEvents cmdficha As System.Windows.Forms.Button
    Friend WithEvents txtrut As System.Windows.Forms.TextBox
    Friend WithEvents txtnregistros As System.Windows.Forms.TextBox
    Friend WithEvents txtingreso As System.Windows.Forms.TextBox
    Friend WithEvents txtpuesto As System.Windows.Forms.TextBox
    Friend WithEvents txtcargo As System.Windows.Forms.TextBox
    Friend WithEvents txtgrado As System.Windows.Forms.TextBox
    Friend WithEvents txtdept As System.Windows.Forms.TextBox
    Friend WithEvents txttelefono As System.Windows.Forms.TextBox
    Friend WithEvents txtemailempre As System.Windows.Forms.TextBox
    Friend WithEvents cmdayuda As System.Windows.Forms.Button
End Class
