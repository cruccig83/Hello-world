﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class login
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(login))
        Me.cmdentrar = New System.Windows.Forms.Button
        Me.txtdoc = New System.Windows.Forms.TextBox
        Me.txtpasswd = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cmdentrar
        '
        Me.cmdentrar.BackColor = System.Drawing.Color.Transparent
        Me.cmdentrar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdentrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdentrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdentrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdentrar.Location = New System.Drawing.Point(77, 327)
        Me.cmdentrar.Name = "cmdentrar"
        Me.cmdentrar.Size = New System.Drawing.Size(222, 26)
        Me.cmdentrar.TabIndex = 0
        Me.cmdentrar.UseVisualStyleBackColor = False
        '
        'txtdoc
        '
        Me.txtdoc.Location = New System.Drawing.Point(61, 212)
        Me.txtdoc.Name = "txtdoc"
        Me.txtdoc.Size = New System.Drawing.Size(251, 20)
        Me.txtdoc.TabIndex = 1
        '
        'txtpasswd
        '
        Me.txtpasswd.Location = New System.Drawing.Point(61, 259)
        Me.txtpasswd.Name = "txtpasswd"
        Me.txtpasswd.Size = New System.Drawing.Size(251, 20)
        Me.txtpasswd.TabIndex = 2
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Image = Global.TAX.My.Resources.Resources.ver_16
        Me.Button1.Location = New System.Drawing.Point(315, 257)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(25, 25)
        Me.Button1.TabIndex = 3
        Me.Button1.UseVisualStyleBackColor = False
        '
        'login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(776, 447)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtpasswd)
        Me.Controls.Add(Me.txtdoc)
        Me.Controls.Add(Me.cmdentrar)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "login"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdentrar As System.Windows.Forms.Button
    Friend WithEvents txtpasswd As System.Windows.Forms.TextBox
    Public WithEvents txtdoc As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
