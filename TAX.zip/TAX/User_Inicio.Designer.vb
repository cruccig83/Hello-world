﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class User_Inicio
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(User_Inicio))
        Me.pnl_Der = New System.Windows.Forms.Panel
        Me.pnl_Izq = New System.Windows.Forms.Panel
        Me.pnl_Inf = New System.Windows.Forms.Panel
        Me.pnl_sup = New System.Windows.Forms.Panel
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer
        Me.pbRecibo = New System.Windows.Forms.PictureBox
        Me.LiqSueldos_pnlInf = New System.Windows.Forms.Panel
        Me.LiqSuedos_pnlDer = New System.Windows.Forms.Panel
        Me.Empleados_pnlDer = New System.Windows.Forms.Panel
        Me.Empleados_pnlSup = New System.Windows.Forms.Panel
        Me.pbHlaboral = New System.Windows.Forms.PictureBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Button3 = New System.Windows.Forms.Button
        Me.Ficha_pnlIzq = New System.Windows.Forms.Panel
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.pbRecibo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbHlaboral, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnl_Der
        '
        Me.pnl_Der.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.pnl_Der.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnl_Der.Location = New System.Drawing.Point(798, 20)
        Me.pnl_Der.Name = "pnl_Der"
        Me.pnl_Der.Size = New System.Drawing.Size(20, 402)
        Me.pnl_Der.TabIndex = 7
        '
        'pnl_Izq
        '
        Me.pnl_Izq.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.pnl_Izq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnl_Izq.Location = New System.Drawing.Point(0, 20)
        Me.pnl_Izq.Name = "pnl_Izq"
        Me.pnl_Izq.Size = New System.Drawing.Size(20, 402)
        Me.pnl_Izq.TabIndex = 6
        '
        'pnl_Inf
        '
        Me.pnl_Inf.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.pnl_Inf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnl_Inf.Location = New System.Drawing.Point(0, 422)
        Me.pnl_Inf.Name = "pnl_Inf"
        Me.pnl_Inf.Size = New System.Drawing.Size(818, 20)
        Me.pnl_Inf.TabIndex = 5
        '
        'pnl_sup
        '
        Me.pnl_sup.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.pnl_sup.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnl_sup.Location = New System.Drawing.Point(0, 0)
        Me.pnl_sup.Name = "pnl_sup"
        Me.pnl_sup.Size = New System.Drawing.Size(818, 20)
        Me.pnl_sup.TabIndex = 4
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(20, 20)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Ficha_pnlIzq)
        Me.SplitContainer1.Size = New System.Drawing.Size(778, 402)
        Me.SplitContainer1.SplitterDistance = 397
        Me.SplitContainer1.TabIndex = 8
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.pbRecibo)
        Me.SplitContainer2.Panel1.Controls.Add(Me.LiqSueldos_pnlInf)
        Me.SplitContainer2.Panel1.Controls.Add(Me.LiqSuedos_pnlDer)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.Empleados_pnlDer)
        Me.SplitContainer2.Panel2.Controls.Add(Me.Empleados_pnlSup)
        Me.SplitContainer2.Panel2.Controls.Add(Me.pbHlaboral)
        Me.SplitContainer2.Size = New System.Drawing.Size(397, 402)
        Me.SplitContainer2.SplitterDistance = 200
        Me.SplitContainer2.TabIndex = 0
        '
        'pbRecibo
        '
        Me.pbRecibo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pbRecibo.Image = CType(resources.GetObject("pbRecibo.Image"), System.Drawing.Image)
        Me.pbRecibo.Location = New System.Drawing.Point(0, 0)
        Me.pbRecibo.Name = "pbRecibo"
        Me.pbRecibo.Size = New System.Drawing.Size(387, 190)
        Me.pbRecibo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbRecibo.TabIndex = 4
        Me.pbRecibo.TabStop = False
        '
        'LiqSueldos_pnlInf
        '
        Me.LiqSueldos_pnlInf.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.LiqSueldos_pnlInf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.LiqSueldos_pnlInf.Location = New System.Drawing.Point(0, 190)
        Me.LiqSueldos_pnlInf.Name = "LiqSueldos_pnlInf"
        Me.LiqSueldos_pnlInf.Size = New System.Drawing.Size(387, 10)
        Me.LiqSueldos_pnlInf.TabIndex = 6
        '
        'LiqSuedos_pnlDer
        '
        Me.LiqSuedos_pnlDer.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.LiqSuedos_pnlDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.LiqSuedos_pnlDer.Location = New System.Drawing.Point(387, 0)
        Me.LiqSuedos_pnlDer.Name = "LiqSuedos_pnlDer"
        Me.LiqSuedos_pnlDer.Size = New System.Drawing.Size(10, 200)
        Me.LiqSuedos_pnlDer.TabIndex = 5
        '
        'Empleados_pnlDer
        '
        Me.Empleados_pnlDer.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.Empleados_pnlDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.Empleados_pnlDer.Location = New System.Drawing.Point(387, 10)
        Me.Empleados_pnlDer.Name = "Empleados_pnlDer"
        Me.Empleados_pnlDer.Size = New System.Drawing.Size(10, 188)
        Me.Empleados_pnlDer.TabIndex = 4
        '
        'Empleados_pnlSup
        '
        Me.Empleados_pnlSup.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.Empleados_pnlSup.Dock = System.Windows.Forms.DockStyle.Top
        Me.Empleados_pnlSup.Location = New System.Drawing.Point(0, 0)
        Me.Empleados_pnlSup.Name = "Empleados_pnlSup"
        Me.Empleados_pnlSup.Size = New System.Drawing.Size(397, 10)
        Me.Empleados_pnlSup.TabIndex = 3
        '
        'pbHlaboral
        '
        Me.pbHlaboral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pbHlaboral.Image = CType(resources.GetObject("pbHlaboral.Image"), System.Drawing.Image)
        Me.pbHlaboral.Location = New System.Drawing.Point(0, 0)
        Me.pbHlaboral.Name = "pbHlaboral"
        Me.pbHlaboral.Size = New System.Drawing.Size(397, 198)
        Me.pbHlaboral.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbHlaboral.TabIndex = 2
        Me.pbHlaboral.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(10, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(367, 402)
        Me.Panel1.TabIndex = 4
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(136, 364)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(110, 23)
        Me.Button3.TabIndex = 1
        Me.Button3.Text = "VER FICHA"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Ficha_pnlIzq
        '
        Me.Ficha_pnlIzq.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.Ficha_pnlIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.Ficha_pnlIzq.Location = New System.Drawing.Point(0, 0)
        Me.Ficha_pnlIzq.Name = "Ficha_pnlIzq"
        Me.Ficha_pnlIzq.Size = New System.Drawing.Size(10, 402)
        Me.Ficha_pnlIzq.TabIndex = 3
        '
        'User_Inicio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(818, 442)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.pnl_Der)
        Me.Controls.Add(Me.pnl_Izq)
        Me.Controls.Add(Me.pnl_Inf)
        Me.Controls.Add(Me.pnl_sup)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "User_Inicio"
        Me.Text = "User_Inicio"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        CType(Me.pbRecibo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbHlaboral, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnl_Der As System.Windows.Forms.Panel
    Friend WithEvents pnl_Izq As System.Windows.Forms.Panel
    Friend WithEvents pnl_Inf As System.Windows.Forms.Panel
    Friend WithEvents pnl_sup As System.Windows.Forms.Panel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents Empleados_pnlDer As System.Windows.Forms.Panel
    Friend WithEvents Empleados_pnlSup As System.Windows.Forms.Panel
    Friend WithEvents pbHlaboral As System.Windows.Forms.PictureBox
    Friend WithEvents pbRecibo As System.Windows.Forms.PictureBox
    Friend WithEvents LiqSueldos_pnlInf As System.Windows.Forms.Panel
    Friend WithEvents LiqSuedos_pnlDer As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Ficha_pnlIzq As System.Windows.Forms.Panel
End Class
