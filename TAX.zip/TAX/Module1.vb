﻿Module Module1
    Public document As Integer
    Public elim_document As Integer
    Public busc_doc As Integer
    Public busc_nombre As String
    Public busc_id As Integer
End Module
