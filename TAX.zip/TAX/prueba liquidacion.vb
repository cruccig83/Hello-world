﻿Public Class prueba_liquidacion

    Dim valorHora As New Single
    Dim porcentajeHNocturna As New Single
    Dim porcentajeHExtra As New Single
    Dim porcentajeHExtraE As Integer
    Dim valorTickets As Integer

    Dim sueldo As Single
    Dim totalHExtra As Single
    Dim totalHExtraE
    Dim totalHNocturna As Single
    Dim totalhaberes As Single

    Dim cantHExtraE As Integer = 0
    Dim cantHExtra As Integer = 0
    Dim cantHNocturna As Integer = 0

    Dim IRPF As New Single
    Dim IRPF1 As New Single
    Dim IRPF2 As New Single
    Dim IRPF3 As New Single
    Dim IRPF4 As New Single
    Dim IRPF5 As New Single
    Dim IRPF6 As New Single
    Dim IRPF7 As New Single
    Dim IRPF8 As New Single
    

    Private Sub txtValSuedo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtValSuedo.TextChanged

        If txtValSuedo.Text = String.Empty Then
            sueldo = 0
        Else
            sueldo = txtValSuedo.Text
            txtTotalSueldo.Text = sueldo

            valorHora = (sueldo / 30) / 8
        End If
    End Sub

    Private Sub txtCantHExtra_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCantHExtra.TextChanged
        porcentajeHExtra = 200




        If txtCantHExtra.Text = String.Empty Then
            cantHExtra = 0
        Else
            cantHExtra = txtCantHExtra.Text
        End If


        totalHExtra = ((porcentajeHExtra * valorHora) / 100) * cantHExtra
        txtTotalHExtra.Text = totalHExtra

        totalhaberes = sueldo + totalHExtra + totalHExtraE + totalHNocturna
        txtTotalHaberes.Text = totalhaberes
    End Sub

    Private Sub txtCantHExtraE_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCantHExtraE.TextChanged
        porcentajeHExtraE = 250





        If txtCantHExtraE.Text = String.Empty Then
            cantHExtraE = 0
        Else
            cantHExtraE = txtCantHExtraE.Text
        End If


        totalHExtraE = ((porcentajeHExtraE * valorHora) / 100) * cantHExtraE
        txtTotalHExtraE.Text = totalHExtraE

        totalhaberes = sueldo + totalHExtra + totalHExtraE + totalHNocturna
        txtTotalHaberes.Text = totalhaberes
    End Sub

    Private Sub txtCantHNoctura_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCantHNoctura.TextChanged
        porcentajeHNocturna = 20




        If txtCantHNoctura.Text = String.Empty Then
            cantHNocturna = 0
        Else
            cantHNocturna = txtCantHNoctura.Text
        End If




        totalHNocturna = ((porcentajeHNocturna * valorHora) / 100) * cantHNocturna
        txtTotalHNocturna.Text = totalHNocturna

        totalhaberes = sueldo + totalHExtra + totalHExtraE + totalHNocturna
        txtTotalHaberes.Text = totalhaberes
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckHExtra.CheckedChanged

        If CheckHExtra.Checked = False Then
            txtCantHExtra.Enabled = False
            cantHExtra = 0
        ElseIf CheckHExtra.Checked = True Then
            txtCantHExtra.Enabled = True
        End If

    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckHExtraE.CheckedChanged
        If CheckHExtraE.Checked = False Then
            txtCantHExtraE.Enabled = False
            cantHExtraE = 0
        ElseIf CheckHExtraE.Checked = True Then
            txtCantHExtraE.Enabled = True
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckHNocturna.CheckedChanged
        If CheckHNocturna.Checked = False Then
            txtCantHNoctura.Enabled = False
            cantHExtra = 0
        ElseIf CheckHNocturna.Checked = True Then
            txtCantHNoctura.Enabled = True
        End If
    End Sub

    Private Sub CheckTicket_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckTicket.CheckedChanged
        If CheckTicket.Checked = False Then
            txtValTickets.Enabled = False
            valorTickets = 0
        ElseIf CheckTicket.Checked = True Then
            txtValTickets.Enabled = True
            valorTickets = txtValTickets.Text
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim valorbps As Integer = 15
        Dim valorfrl As Single = 0.125
        Dim BPS As Single
        Dim FRL As Single

        BPS = (totalhaberes * valorbps) / 100
        txtBPS.Text = BPS
        FRL = (totalhaberes * valorfrl) / 100
        txtFRL.Text = FRL

    End Sub



    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        If totalhaberes >= 29078 Then

            If totalhaberes >= 41540 Then

                If totalhaberes >= 62310 Then

                    If totalhaberes >= 124620 Then

                        If totalhaberes >= 207700 Then

                            If totalhaberes >= 311550 Then

                                If totalhaberes >= 477710 Then
                                    IRPF8 = totalhaberes - 477710
                                    IRPF8 = (IRPF8 * 36) / 100

                                End If

                            End If

                        End If

                    End If

                End If

            End If

        End If

    End Sub
End Class