﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mirecibo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mirecibo))
        Me.cmdhistorialrecibos = New System.Windows.Forms.Button
        Me.cmdficha = New System.Windows.Forms.Button
        Me.cmdhistorialaboral = New System.Windows.Forms.Button
        Me.cmdinicio = New System.Windows.Forms.Button
        Me.cmdayuda = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cmdhistorialrecibos
        '
        Me.cmdhistorialrecibos.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialrecibos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialrecibos.Location = New System.Drawing.Point(26, 352)
        Me.cmdhistorialrecibos.Name = "cmdhistorialrecibos"
        Me.cmdhistorialrecibos.Size = New System.Drawing.Size(116, 36)
        Me.cmdhistorialrecibos.TabIndex = 8
        Me.cmdhistorialrecibos.UseVisualStyleBackColor = False
        '
        'cmdficha
        '
        Me.cmdficha.BackColor = System.Drawing.Color.Transparent
        Me.cmdficha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdficha.Location = New System.Drawing.Point(26, 195)
        Me.cmdficha.Name = "cmdficha"
        Me.cmdficha.Size = New System.Drawing.Size(116, 36)
        Me.cmdficha.TabIndex = 7
        Me.cmdficha.UseVisualStyleBackColor = False
        '
        'cmdhistorialaboral
        '
        Me.cmdhistorialaboral.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialaboral.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialaboral.Location = New System.Drawing.Point(25, 301)
        Me.cmdhistorialaboral.Name = "cmdhistorialaboral"
        Me.cmdhistorialaboral.Size = New System.Drawing.Size(116, 36)
        Me.cmdhistorialaboral.TabIndex = 6
        Me.cmdhistorialaboral.UseVisualStyleBackColor = False
        '
        'cmdinicio
        '
        Me.cmdinicio.BackColor = System.Drawing.Color.Transparent
        Me.cmdinicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdinicio.Location = New System.Drawing.Point(25, 153)
        Me.cmdinicio.Name = "cmdinicio"
        Me.cmdinicio.Size = New System.Drawing.Size(116, 36)
        Me.cmdinicio.TabIndex = 5
        Me.cmdinicio.UseVisualStyleBackColor = False
        '
        'cmdayuda
        '
        Me.cmdayuda.BackColor = System.Drawing.Color.Transparent
        Me.cmdayuda.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdayuda.Location = New System.Drawing.Point(672, 70)
        Me.cmdayuda.Name = "cmdayuda"
        Me.cmdayuda.Size = New System.Drawing.Size(93, 30)
        Me.cmdayuda.TabIndex = 79
        Me.cmdayuda.UseVisualStyleBackColor = False
        '
        'mirecibo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(777, 579)
        Me.Controls.Add(Me.cmdayuda)
        Me.Controls.Add(Me.cmdhistorialrecibos)
        Me.Controls.Add(Me.cmdficha)
        Me.Controls.Add(Me.cmdhistorialaboral)
        Me.Controls.Add(Me.cmdinicio)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "mirecibo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdhistorialrecibos As System.Windows.Forms.Button
    Friend WithEvents cmdficha As System.Windows.Forms.Button
    Friend WithEvents cmdhistorialaboral As System.Windows.Forms.Button
    Friend WithEvents cmdinicio As System.Windows.Forms.Button
    Friend WithEvents cmdayuda As System.Windows.Forms.Button
End Class
