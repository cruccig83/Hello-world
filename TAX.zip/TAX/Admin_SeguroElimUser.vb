﻿Imports MySql.Data.MySqlClient
Public Class Admin_SeguroElimUser

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCancelar.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub Admin_SeguroElimUser_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE doc = '" & Module1.elim_document & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.txtdocumento.Text = rdr.Item("doc").ToString
                Me.txtNRegistro.Text = rdr.Item("persona_id").ToString
                Me.txtNombre.Text = rdr.Item("nombre").ToString + " " + rdr.Item("apellido").ToString
            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "UPDATE personal SET activo = 'n' WHERE doc = " & Module1.elim_document & " "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.txtdocumento.Text = rdr.Item("doc").ToString
            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        MessageBox.Show("Se ha dado de baja al usuario")
    End Sub
End Class