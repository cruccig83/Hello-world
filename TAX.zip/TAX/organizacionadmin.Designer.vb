﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class organizacionadmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(organizacionadmin))
        Me.cmdliquidar = New System.Windows.Forms.Button
        Me.cmdempleados = New System.Windows.Forms.Button
        Me.cmdrecibo = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.cmdhistorialaboral = New System.Windows.Forms.Button
        Me.cmdhistorialrecibos = New System.Windows.Forms.Button
        Me.cmdficha = New System.Windows.Forms.Button
        Me.txtemailempre = New System.Windows.Forms.TextBox
        Me.txttelefono = New System.Windows.Forms.TextBox
        Me.txtdept = New System.Windows.Forms.TextBox
        Me.txtgrado = New System.Windows.Forms.TextBox
        Me.txtcargo = New System.Windows.Forms.TextBox
        Me.txtpuesto = New System.Windows.Forms.TextBox
        Me.txtingreso = New System.Windows.Forms.TextBox
        Me.txtnregistros = New System.Windows.Forms.TextBox
        Me.txtrut = New System.Windows.Forms.TextBox
        Me.cmdayuda = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cmdliquidar
        '
        Me.cmdliquidar.BackColor = System.Drawing.Color.Transparent
        Me.cmdliquidar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdliquidar.Location = New System.Drawing.Point(10, 304)
        Me.cmdliquidar.Name = "cmdliquidar"
        Me.cmdliquidar.Size = New System.Drawing.Size(123, 31)
        Me.cmdliquidar.TabIndex = 15
        Me.cmdliquidar.UseVisualStyleBackColor = False
        '
        'cmdempleados
        '
        Me.cmdempleados.BackColor = System.Drawing.Color.Transparent
        Me.cmdempleados.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdempleados.Location = New System.Drawing.Point(13, 262)
        Me.cmdempleados.Name = "cmdempleados"
        Me.cmdempleados.Size = New System.Drawing.Size(123, 31)
        Me.cmdempleados.TabIndex = 14
        Me.cmdempleados.UseVisualStyleBackColor = False
        '
        'cmdrecibo
        '
        Me.cmdrecibo.BackColor = System.Drawing.Color.Transparent
        Me.cmdrecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdrecibo.Location = New System.Drawing.Point(13, 221)
        Me.cmdrecibo.Name = "cmdrecibo"
        Me.cmdrecibo.Size = New System.Drawing.Size(123, 31)
        Me.cmdrecibo.TabIndex = 13
        Me.cmdrecibo.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Transparent
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(13, 144)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(123, 30)
        Me.Button3.TabIndex = 12
        Me.Button3.UseVisualStyleBackColor = False
        '
        'cmdhistorialaboral
        '
        Me.cmdhistorialaboral.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialaboral.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialaboral.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialaboral.Location = New System.Drawing.Point(226, 151)
        Me.cmdhistorialaboral.Name = "cmdhistorialaboral"
        Me.cmdhistorialaboral.Size = New System.Drawing.Size(60, 50)
        Me.cmdhistorialaboral.TabIndex = 11
        Me.cmdhistorialaboral.UseVisualStyleBackColor = False
        '
        'cmdhistorialrecibos
        '
        Me.cmdhistorialrecibos.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialrecibos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialrecibos.Location = New System.Drawing.Point(292, 151)
        Me.cmdhistorialrecibos.Name = "cmdhistorialrecibos"
        Me.cmdhistorialrecibos.Size = New System.Drawing.Size(68, 50)
        Me.cmdhistorialrecibos.TabIndex = 10
        Me.cmdhistorialrecibos.UseVisualStyleBackColor = False
        '
        'cmdficha
        '
        Me.cmdficha.BackColor = System.Drawing.Color.Transparent
        Me.cmdficha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdficha.Location = New System.Drawing.Point(139, 148)
        Me.cmdficha.Name = "cmdficha"
        Me.cmdficha.Size = New System.Drawing.Size(73, 50)
        Me.cmdficha.TabIndex = 9
        Me.cmdficha.UseVisualStyleBackColor = False
        '
        'txtemailempre
        '
        Me.txtemailempre.Location = New System.Drawing.Point(267, 453)
        Me.txtemailempre.Name = "txtemailempre"
        Me.txtemailempre.Size = New System.Drawing.Size(173, 20)
        Me.txtemailempre.TabIndex = 27
        '
        'txttelefono
        '
        Me.txttelefono.Location = New System.Drawing.Point(281, 427)
        Me.txttelefono.Name = "txttelefono"
        Me.txttelefono.Size = New System.Drawing.Size(173, 20)
        Me.txttelefono.TabIndex = 26
        '
        'txtdept
        '
        Me.txtdept.Location = New System.Drawing.Point(253, 403)
        Me.txtdept.Name = "txtdept"
        Me.txtdept.Size = New System.Drawing.Size(173, 20)
        Me.txtdept.TabIndex = 25
        '
        'txtgrado
        '
        Me.txtgrado.Location = New System.Drawing.Point(225, 378)
        Me.txtgrado.Name = "txtgrado"
        Me.txtgrado.Size = New System.Drawing.Size(173, 20)
        Me.txtgrado.TabIndex = 24
        '
        'txtcargo
        '
        Me.txtcargo.Location = New System.Drawing.Point(227, 350)
        Me.txtcargo.Name = "txtcargo"
        Me.txtcargo.Size = New System.Drawing.Size(173, 20)
        Me.txtcargo.TabIndex = 23
        '
        'txtpuesto
        '
        Me.txtpuesto.Location = New System.Drawing.Point(228, 325)
        Me.txtpuesto.Name = "txtpuesto"
        Me.txtpuesto.Size = New System.Drawing.Size(173, 20)
        Me.txtpuesto.TabIndex = 22
        '
        'txtingreso
        '
        Me.txtingreso.Location = New System.Drawing.Point(267, 301)
        Me.txtingreso.Name = "txtingreso"
        Me.txtingreso.Size = New System.Drawing.Size(173, 20)
        Me.txtingreso.TabIndex = 21
        '
        'txtnregistros
        '
        Me.txtnregistros.Location = New System.Drawing.Point(272, 276)
        Me.txtnregistros.Name = "txtnregistros"
        Me.txtnregistros.Size = New System.Drawing.Size(173, 20)
        Me.txtnregistros.TabIndex = 20
        '
        'txtrut
        '
        Me.txtrut.Location = New System.Drawing.Point(215, 252)
        Me.txtrut.Name = "txtrut"
        Me.txtrut.Size = New System.Drawing.Size(173, 20)
        Me.txtrut.TabIndex = 19
        '
        'cmdayuda
        '
        Me.cmdayuda.BackColor = System.Drawing.Color.Transparent
        Me.cmdayuda.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdayuda.Location = New System.Drawing.Point(657, 69)
        Me.cmdayuda.Name = "cmdayuda"
        Me.cmdayuda.Size = New System.Drawing.Size(93, 30)
        Me.cmdayuda.TabIndex = 79
        Me.cmdayuda.UseVisualStyleBackColor = False
        '
        'organizacionadmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(776, 549)
        Me.Controls.Add(Me.cmdayuda)
        Me.Controls.Add(Me.txtemailempre)
        Me.Controls.Add(Me.txttelefono)
        Me.Controls.Add(Me.txtdept)
        Me.Controls.Add(Me.txtgrado)
        Me.Controls.Add(Me.txtcargo)
        Me.Controls.Add(Me.txtpuesto)
        Me.Controls.Add(Me.txtingreso)
        Me.Controls.Add(Me.txtnregistros)
        Me.Controls.Add(Me.txtrut)
        Me.Controls.Add(Me.cmdliquidar)
        Me.Controls.Add(Me.cmdempleados)
        Me.Controls.Add(Me.cmdrecibo)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.cmdhistorialaboral)
        Me.Controls.Add(Me.cmdhistorialrecibos)
        Me.Controls.Add(Me.cmdficha)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "organizacionadmin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdliquidar As System.Windows.Forms.Button
    Friend WithEvents cmdempleados As System.Windows.Forms.Button
    Friend WithEvents cmdrecibo As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents cmdhistorialaboral As System.Windows.Forms.Button
    Friend WithEvents cmdhistorialrecibos As System.Windows.Forms.Button
    Friend WithEvents cmdficha As System.Windows.Forms.Button
    Friend WithEvents txtemailempre As System.Windows.Forms.TextBox
    Friend WithEvents txttelefono As System.Windows.Forms.TextBox
    Friend WithEvents txtdept As System.Windows.Forms.TextBox
    Friend WithEvents txtgrado As System.Windows.Forms.TextBox
    Friend WithEvents txtcargo As System.Windows.Forms.TextBox
    Friend WithEvents txtpuesto As System.Windows.Forms.TextBox
    Friend WithEvents txtingreso As System.Windows.Forms.TextBox
    Friend WithEvents txtnregistros As System.Windows.Forms.TextBox
    Friend WithEvents txtrut As System.Windows.Forms.TextBox
    Friend WithEvents cmdayuda As System.Windows.Forms.Button
End Class
