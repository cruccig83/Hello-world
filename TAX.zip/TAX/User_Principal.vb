﻿
Public Class User_Principal
    Dim px, py As Integer
    Dim mover As Boolean

    Private Sub cmdslide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        If pnlverticalmenu.Width = 175 Then
            pnlverticalmenu.Width = 56
        Else
            pnlverticalmenu.Width = 175

        End If

    End Sub

    Private Sub btnclose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Application.Exit()
    End Sub

    

    Private Sub btnminimize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.WindowState = FormWindowState.Minimized
    End Sub


    Private Sub btnficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnficha.Click
        pnlselectedbtn.Height = btnficha.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnficha.Location.Y)

        AbrirFormEnPanel(Of User_Ficha)()
    End Sub

    Private Sub btninicio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninicio.Click
        pnlselectedbtn.Height = btninicio.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btninicio.Location.Y)


        AbrirFormEnPanel(Of User_Inicio)()
    End Sub

    Private Sub btnrecibo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrecibo.Click
        pnlselectedbtn.Height = btnrecibo.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnrecibo.Location.Y)

        AbrirFormEnPanel(Of Admin_TuRecibo)()
    End Sub

    Private Sub AbrirFormEnPanel(Of Forms As {Form, New})()
        Dim formulario As Form
        formulario = centralpanel.Controls.OfType(Of Forms)().FirstOrDefault()

        If formulario Is Nothing Then
            formulario = New Forms()
            formulario.TopLevel = False
            formulario.FormBorderStyle = FormBorderStyle.None
            formulario.Dock = DockStyle.Fill
            centralpanel.Controls.Add(formulario)
            centralpanel.Tag = formulario
            formulario.Show()
            formulario.BringToFront()
        Else

            If formulario.WindowState = FormWindowState.Minimized Then
                formulario.WindowState = FormWindowState.Normal
            End If

            formulario.BringToFront()
        End If
    End Sub


    Private Sub btnhlaboral_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnhlaboral.Click
        pnlselectedbtn.Height = btnhlaboral.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnhlaboral.Location.Y)

        AbrirFormEnPanel(Of Admin_TuRecibo)()
    End Sub


    Private Sub btnhrecibos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnhrecibos.Click
        pnlselectedbtn.Height = btnhrecibos.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btnhrecibos.Location.Y)

        AbrirFormEnPanel(Of Admin_TuRecibo)()

    End Sub

    Private Sub pnltitlebar_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pnltitlebar.MouseMove

        If mover Then
            Me.Location = Me.PointToScreen(New Point(Me.MousePosition.X - Me.Location.X - px, Me.MousePosition.Y - Me.Location.Y - py))
        End If

    End Sub

    Private Sub pnltitlebar_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pnltitlebar.MouseDown
        px = e.X
        py = e.Y
        mover = True
    End Sub

    Private Sub pnltitlebar_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles pnltitlebar.MouseUp
        mover = False
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
        nuevologin.Show()
    End Sub

    Private Sub pnltitlebar_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pnltitlebar.Paint

    End Sub

    Private Sub User_Principal_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        AbrirFormEnPanel(Of User_Inicio)()
        pnlselectedbtn.Height = btninicio.Height
        pnlselectedbtn.Location = New Point(pnlselectedbtn.Location.X, btninicio.Location.Y)
    End Sub

    Private Sub btnMinimizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinimizar.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btnclose_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclose.Click
        Application.Exit()
    End Sub
End Class