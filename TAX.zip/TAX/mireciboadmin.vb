﻿Public Class mireciboadmin

    Private Sub cmdinicio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdinicio.Click
        inicioadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdficha.Click
        ficharoja.Show()
        Me.Close()

    End Sub

    Private Sub cmdempleados_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdempleados.Click
        empleados.Show()
        Me.Close()

    End Sub

    Private Sub cmdliquidar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdliquidar.Click
        sueldos.Show()
        Me.Close()

    End Sub

    Private Sub cmdayuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdayuda.Click
        MsgBox("En Progreso")
    End Sub
End Class