﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Principal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Principal))
        Me.pnltitlebar = New System.Windows.Forms.Panel
        Me.pnlverticalmenu = New System.Windows.Forms.Panel
        Me.pnlBordeIzq = New System.Windows.Forms.Panel
        Me.pblBordeInf2 = New System.Windows.Forms.Panel
        Me.pnlselectedbtn = New System.Windows.Forms.Panel
        Me.pnlBarraPrincipal = New System.Windows.Forms.Panel
        Me.PnlBordeInf1 = New System.Windows.Forms.Panel
        Me.pnlBordeDer = New System.Windows.Forms.Panel
        Me.pnlSeparacion = New System.Windows.Forms.Panel
        Me.pnlOtraseparacion = New System.Windows.Forms.Panel
        Me.pnlPrincipal = New System.Windows.Forms.Panel
        Me.pnlUsuario = New System.Windows.Forms.Panel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.Button1 = New System.Windows.Forms.Button
        Me.User_lblId = New System.Windows.Forms.Label
        Me.User_lblDoc = New System.Windows.Forms.Label
        Me.User_lblNombre = New System.Windows.Forms.Label
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.pbFotoUsuario = New System.Windows.Forms.PictureBox
        Me.btnConceptos = New System.Windows.Forms.Button
        Me.btndivisas = New System.Windows.Forms.Button
        Me.btnEmpresa = New System.Windows.Forms.Button
        Me.btnliqsueldos = New System.Windows.Forms.Button
        Me.btnadminempleados = New System.Windows.Forms.Button
        Me.btnturecibo = New System.Windows.Forms.Button
        Me.btnficha = New System.Windows.Forms.Button
        Me.btninicio = New System.Windows.Forms.Button
        Me.btnUser = New System.Windows.Forms.PictureBox
        Me.btnMenu = New System.Windows.Forms.Button
        Me.pbTAX = New System.Windows.Forms.PictureBox
        Me.btnMinimizar = New System.Windows.Forms.Button
        Me.btnclose = New System.Windows.Forms.Button
        Me.pnltitlebar.SuspendLayout()
        Me.pnlverticalmenu.SuspendLayout()
        Me.pnlBarraPrincipal.SuspendLayout()
        Me.pnlSeparacion.SuspendLayout()
        Me.pnlPrincipal.SuspendLayout()
        Me.pnlUsuario.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.pbFotoUsuario, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbTAX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnltitlebar
        '
        Me.pnltitlebar.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnltitlebar.Controls.Add(Me.btnMinimizar)
        Me.pnltitlebar.Controls.Add(Me.btnclose)
        Me.pnltitlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnltitlebar.Location = New System.Drawing.Point(0, 0)
        Me.pnltitlebar.Name = "pnltitlebar"
        Me.pnltitlebar.Size = New System.Drawing.Size(1009, 25)
        Me.pnltitlebar.TabIndex = 0
        '
        'pnlverticalmenu
        '
        Me.pnlverticalmenu.BackColor = System.Drawing.Color.White
        Me.pnlverticalmenu.Controls.Add(Me.pnlBordeIzq)
        Me.pnlverticalmenu.Controls.Add(Me.pblBordeInf2)
        Me.pnlverticalmenu.Controls.Add(Me.btnConceptos)
        Me.pnlverticalmenu.Controls.Add(Me.btndivisas)
        Me.pnlverticalmenu.Controls.Add(Me.btnEmpresa)
        Me.pnlverticalmenu.Controls.Add(Me.btnliqsueldos)
        Me.pnlverticalmenu.Controls.Add(Me.btnadminempleados)
        Me.pnlverticalmenu.Controls.Add(Me.btnturecibo)
        Me.pnlverticalmenu.Controls.Add(Me.btnficha)
        Me.pnlverticalmenu.Controls.Add(Me.pnlselectedbtn)
        Me.pnlverticalmenu.Controls.Add(Me.btninicio)
        Me.pnlverticalmenu.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlverticalmenu.Location = New System.Drawing.Point(0, 0)
        Me.pnlverticalmenu.Name = "pnlverticalmenu"
        Me.pnlverticalmenu.Size = New System.Drawing.Size(175, 481)
        Me.pnlverticalmenu.TabIndex = 1
        '
        'pnlBordeIzq
        '
        Me.pnlBordeIzq.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlBordeIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlBordeIzq.Location = New System.Drawing.Point(0, 0)
        Me.pnlBordeIzq.Name = "pnlBordeIzq"
        Me.pnlBordeIzq.Size = New System.Drawing.Size(1, 480)
        Me.pnlBordeIzq.TabIndex = 18
        '
        'pblBordeInf2
        '
        Me.pblBordeInf2.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pblBordeInf2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pblBordeInf2.Location = New System.Drawing.Point(0, 480)
        Me.pblBordeInf2.Name = "pblBordeInf2"
        Me.pblBordeInf2.Size = New System.Drawing.Size(175, 1)
        Me.pblBordeInf2.TabIndex = 17
        '
        'pnlselectedbtn
        '
        Me.pnlselectedbtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlselectedbtn.Location = New System.Drawing.Point(0, 88)
        Me.pnlselectedbtn.Name = "pnlselectedbtn"
        Me.pnlselectedbtn.Size = New System.Drawing.Size(7, 44)
        Me.pnlselectedbtn.TabIndex = 9
        '
        'pnlBarraPrincipal
        '
        Me.pnlBarraPrincipal.Controls.Add(Me.PnlBordeInf1)
        Me.pnlBarraPrincipal.Controls.Add(Me.pnlBordeDer)
        Me.pnlBarraPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlBarraPrincipal.ForeColor = System.Drawing.Color.Coral
        Me.pnlBarraPrincipal.Location = New System.Drawing.Point(175, 0)
        Me.pnlBarraPrincipal.Name = "pnlBarraPrincipal"
        Me.pnlBarraPrincipal.Size = New System.Drawing.Size(834, 481)
        Me.pnlBarraPrincipal.TabIndex = 2
        '
        'PnlBordeInf1
        '
        Me.PnlBordeInf1.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.PnlBordeInf1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PnlBordeInf1.Location = New System.Drawing.Point(0, 480)
        Me.PnlBordeInf1.Name = "PnlBordeInf1"
        Me.PnlBordeInf1.Size = New System.Drawing.Size(833, 1)
        Me.PnlBordeInf1.TabIndex = 1
        '
        'pnlBordeDer
        '
        Me.pnlBordeDer.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlBordeDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlBordeDer.Location = New System.Drawing.Point(833, 0)
        Me.pnlBordeDer.Name = "pnlBordeDer"
        Me.pnlBordeDer.Size = New System.Drawing.Size(1, 481)
        Me.pnlBordeDer.TabIndex = 0
        '
        'pnlSeparacion
        '
        Me.pnlSeparacion.BackColor = System.Drawing.Color.White
        Me.pnlSeparacion.Controls.Add(Me.btnUser)
        Me.pnlSeparacion.Controls.Add(Me.pnlOtraseparacion)
        Me.pnlSeparacion.Controls.Add(Me.btnMenu)
        Me.pnlSeparacion.Controls.Add(Me.pbTAX)
        Me.pnlSeparacion.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlSeparacion.Location = New System.Drawing.Point(0, 25)
        Me.pnlSeparacion.Name = "pnlSeparacion"
        Me.pnlSeparacion.Size = New System.Drawing.Size(1009, 44)
        Me.pnlSeparacion.TabIndex = 3
        '
        'pnlOtraseparacion
        '
        Me.pnlOtraseparacion.BackColor = System.Drawing.Color.WhiteSmoke
        Me.pnlOtraseparacion.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlOtraseparacion.Location = New System.Drawing.Point(44, 42)
        Me.pnlOtraseparacion.Name = "pnlOtraseparacion"
        Me.pnlOtraseparacion.Size = New System.Drawing.Size(965, 2)
        Me.pnlOtraseparacion.TabIndex = 23
        '
        'pnlPrincipal
        '
        Me.pnlPrincipal.Controls.Add(Me.pnlUsuario)
        Me.pnlPrincipal.Controls.Add(Me.pnlBarraPrincipal)
        Me.pnlPrincipal.Controls.Add(Me.pnlverticalmenu)
        Me.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlPrincipal.Location = New System.Drawing.Point(0, 69)
        Me.pnlPrincipal.Name = "pnlPrincipal"
        Me.pnlPrincipal.Size = New System.Drawing.Size(1009, 481)
        Me.pnlPrincipal.TabIndex = 4
        '
        'pnlUsuario
        '
        Me.pnlUsuario.BackColor = System.Drawing.Color.White
        Me.pnlUsuario.Controls.Add(Me.Panel1)
        Me.pnlUsuario.Controls.Add(Me.Button1)
        Me.pnlUsuario.Controls.Add(Me.User_lblId)
        Me.pnlUsuario.Controls.Add(Me.User_lblDoc)
        Me.pnlUsuario.Controls.Add(Me.User_lblNombre)
        Me.pnlUsuario.Controls.Add(Me.pbFotoUsuario)
        Me.pnlUsuario.Controls.Add(Me.Panel5)
        Me.pnlUsuario.Controls.Add(Me.Panel4)
        Me.pnlUsuario.Controls.Add(Me.Panel3)
        Me.pnlUsuario.Controls.Add(Me.Panel2)
        Me.pnlUsuario.Location = New System.Drawing.Point(717, 1)
        Me.pnlUsuario.Name = "pnlUsuario"
        Me.pnlUsuario.Size = New System.Drawing.Size(291, 189)
        Me.pnlUsuario.TabIndex = 3
        Me.pnlUsuario.Visible = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Panel6)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(1, 132)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(288, 56)
        Me.Panel1.TabIndex = 9
        '
        'Button3
        '
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.Button3.Location = New System.Drawing.Point(158, 17)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(121, 23)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Cerrar sesión"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer))
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.Button2.Location = New System.Drawing.Point(17, 17)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(121, 23)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Cambiar contraseña"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(288, 1)
        Me.Panel6.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(143, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(143, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(128, 93)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(92, 25)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Ver tus datos"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'User_lblId
        '
        Me.User_lblId.AutoSize = True
        Me.User_lblId.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.User_lblId.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.User_lblId.Location = New System.Drawing.Point(125, 68)
        Me.User_lblId.Name = "User_lblId"
        Me.User_lblId.Size = New System.Drawing.Size(45, 15)
        Me.User_lblId.TabIndex = 7
        Me.User_lblId.Text = "Label3"
        '
        'User_lblDoc
        '
        Me.User_lblDoc.AutoSize = True
        Me.User_lblDoc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.User_lblDoc.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.User_lblDoc.Location = New System.Drawing.Point(125, 43)
        Me.User_lblDoc.Name = "User_lblDoc"
        Me.User_lblDoc.Size = New System.Drawing.Size(45, 15)
        Me.User_lblDoc.TabIndex = 6
        Me.User_lblDoc.Text = "Label2"
        '
        'User_lblNombre
        '
        Me.User_lblNombre.AutoSize = True
        Me.User_lblNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.User_lblNombre.Location = New System.Drawing.Point(125, 18)
        Me.User_lblNombre.Name = "User_lblNombre"
        Me.User_lblNombre.Size = New System.Drawing.Size(51, 15)
        Me.User_lblNombre.TabIndex = 5
        Me.User_lblNombre.Text = "Label1"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel5.Location = New System.Drawing.Point(289, 1)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(2, 187)
        Me.Panel5.TabIndex = 3
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel4.Location = New System.Drawing.Point(1, 188)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(290, 1)
        Me.Panel4.TabIndex = 2
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel3.Location = New System.Drawing.Point(0, 1)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1, 188)
        Me.Panel3.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(291, 1)
        Me.Panel2.TabIndex = 0
        '
        'pbFotoUsuario
        '
        Me.pbFotoUsuario.Location = New System.Drawing.Point(18, 18)
        Me.pbFotoUsuario.Name = "pbFotoUsuario"
        Me.pbFotoUsuario.Size = New System.Drawing.Size(100, 100)
        Me.pbFotoUsuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbFotoUsuario.TabIndex = 4
        Me.pbFotoUsuario.TabStop = False
        '
        'btnConceptos
        '
        Me.btnConceptos.BackColor = System.Drawing.Color.White
        Me.btnConceptos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnConceptos.FlatAppearance.BorderSize = 0
        Me.btnConceptos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnConceptos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnConceptos.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConceptos.Image = Global.TAX.My.Resources.Resources.parameters__2_
        Me.btnConceptos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnConceptos.Location = New System.Drawing.Point(7, 408)
        Me.btnConceptos.Name = "btnConceptos"
        Me.btnConceptos.Size = New System.Drawing.Size(167, 44)
        Me.btnConceptos.TabIndex = 16
        Me.btnConceptos.Text = "CONCEPTOS"
        Me.btnConceptos.UseVisualStyleBackColor = False
        '
        'btndivisas
        '
        Me.btndivisas.BackColor = System.Drawing.Color.White
        Me.btndivisas.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btndivisas.FlatAppearance.BorderSize = 0
        Me.btndivisas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btndivisas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndivisas.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndivisas.Image = Global.TAX.My.Resources.Resources.exchange__1_
        Me.btndivisas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btndivisas.Location = New System.Drawing.Point(7, 358)
        Me.btndivisas.Name = "btndivisas"
        Me.btndivisas.Size = New System.Drawing.Size(167, 44)
        Me.btndivisas.TabIndex = 15
        Me.btndivisas.Text = "DIVISAS"
        Me.btndivisas.UseVisualStyleBackColor = False
        '
        'btnEmpresa
        '
        Me.btnEmpresa.BackColor = System.Drawing.Color.White
        Me.btnEmpresa.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnEmpresa.FlatAppearance.BorderSize = 0
        Me.btnEmpresa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnEmpresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEmpresa.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEmpresa.Image = CType(resources.GetObject("btnEmpresa.Image"), System.Drawing.Image)
        Me.btnEmpresa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnEmpresa.Location = New System.Drawing.Point(7, 314)
        Me.btnEmpresa.Name = "btnEmpresa"
        Me.btnEmpresa.Size = New System.Drawing.Size(167, 44)
        Me.btnEmpresa.TabIndex = 14
        Me.btnEmpresa.Text = "EMPRESA"
        Me.btnEmpresa.UseVisualStyleBackColor = False
        '
        'btnliqsueldos
        '
        Me.btnliqsueldos.BackColor = System.Drawing.Color.White
        Me.btnliqsueldos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnliqsueldos.FlatAppearance.BorderSize = 0
        Me.btnliqsueldos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnliqsueldos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnliqsueldos.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnliqsueldos.Image = CType(resources.GetObject("btnliqsueldos.Image"), System.Drawing.Image)
        Me.btnliqsueldos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnliqsueldos.Location = New System.Drawing.Point(7, 264)
        Me.btnliqsueldos.Name = "btnliqsueldos"
        Me.btnliqsueldos.Size = New System.Drawing.Size(167, 44)
        Me.btnliqsueldos.TabIndex = 13
        Me.btnliqsueldos.Text = "LIQUIDAR" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "SUELDOS" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnliqsueldos.UseVisualStyleBackColor = False
        '
        'btnadminempleados
        '
        Me.btnadminempleados.BackColor = System.Drawing.Color.White
        Me.btnadminempleados.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnadminempleados.FlatAppearance.BorderSize = 0
        Me.btnadminempleados.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnadminempleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnadminempleados.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadminempleados.Image = CType(resources.GetObject("btnadminempleados.Image"), System.Drawing.Image)
        Me.btnadminempleados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnadminempleados.Location = New System.Drawing.Point(7, 220)
        Me.btnadminempleados.Name = "btnadminempleados"
        Me.btnadminempleados.Size = New System.Drawing.Size(167, 44)
        Me.btnadminempleados.TabIndex = 12
        Me.btnadminempleados.Text = "ADMINISTRAR" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "EMPLEADOS" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnadminempleados.UseVisualStyleBackColor = False
        '
        'btnturecibo
        '
        Me.btnturecibo.BackColor = System.Drawing.Color.White
        Me.btnturecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnturecibo.FlatAppearance.BorderSize = 0
        Me.btnturecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnturecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnturecibo.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnturecibo.Image = CType(resources.GetObject("btnturecibo.Image"), System.Drawing.Image)
        Me.btnturecibo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnturecibo.Location = New System.Drawing.Point(7, 176)
        Me.btnturecibo.Name = "btnturecibo"
        Me.btnturecibo.Size = New System.Drawing.Size(167, 44)
        Me.btnturecibo.TabIndex = 11
        Me.btnturecibo.Text = "TU RECIBO"
        Me.btnturecibo.UseVisualStyleBackColor = False
        '
        'btnficha
        '
        Me.btnficha.BackColor = System.Drawing.Color.White
        Me.btnficha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnficha.FlatAppearance.BorderSize = 0
        Me.btnficha.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnficha.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnficha.Image = CType(resources.GetObject("btnficha.Image"), System.Drawing.Image)
        Me.btnficha.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnficha.Location = New System.Drawing.Point(7, 132)
        Me.btnficha.Name = "btnficha"
        Me.btnficha.Size = New System.Drawing.Size(167, 44)
        Me.btnficha.TabIndex = 10
        Me.btnficha.Text = "FICHA"
        Me.btnficha.UseVisualStyleBackColor = False
        '
        'btninicio
        '
        Me.btninicio.BackColor = System.Drawing.Color.White
        Me.btninicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btninicio.FlatAppearance.BorderSize = 0
        Me.btninicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btninicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btninicio.Font = New System.Drawing.Font("Eras Demi ITC", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btninicio.Image = CType(resources.GetObject("btninicio.Image"), System.Drawing.Image)
        Me.btninicio.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btninicio.Location = New System.Drawing.Point(7, 88)
        Me.btninicio.Name = "btninicio"
        Me.btninicio.Size = New System.Drawing.Size(167, 44)
        Me.btninicio.TabIndex = 4
        Me.btninicio.Text = "INICIO"
        Me.btninicio.UseVisualStyleBackColor = False
        '
        'btnUser
        '
        Me.btnUser.Location = New System.Drawing.Point(964, 2)
        Me.btnUser.Name = "btnUser"
        Me.btnUser.Size = New System.Drawing.Size(41, 41)
        Me.btnUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnUser.TabIndex = 24
        Me.btnUser.TabStop = False
        '
        'btnMenu
        '
        Me.btnMenu.Dock = System.Windows.Forms.DockStyle.Left
        Me.btnMenu.FlatAppearance.BorderSize = 0
        Me.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMenu.Image = Global.TAX.My.Resources.Resources.menu_button
        Me.btnMenu.Location = New System.Drawing.Point(0, 0)
        Me.btnMenu.Name = "btnMenu"
        Me.btnMenu.Size = New System.Drawing.Size(44, 44)
        Me.btnMenu.TabIndex = 22
        Me.btnMenu.UseVisualStyleBackColor = True
        '
        'pbTAX
        '
        Me.pbTAX.Image = Global.TAX.My.Resources.Resources.nuevo_tax_admin_mode_logo
        Me.pbTAX.Location = New System.Drawing.Point(43, 0)
        Me.pbTAX.Name = "pbTAX"
        Me.pbTAX.Size = New System.Drawing.Size(131, 44)
        Me.pbTAX.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbTAX.TabIndex = 20
        Me.pbTAX.TabStop = False
        '
        'btnMinimizar
        '
        Me.btnMinimizar.FlatAppearance.BorderSize = 0
        Me.btnMinimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinimizar.Image = Global.TAX.My.Resources.Resources.minimize_
        Me.btnMinimizar.Location = New System.Drawing.Point(935, 0)
        Me.btnMinimizar.Name = "btnMinimizar"
        Me.btnMinimizar.Size = New System.Drawing.Size(37, 25)
        Me.btnMinimizar.TabIndex = 4
        Me.btnMinimizar.UseVisualStyleBackColor = True
        '
        'btnclose
        '
        Me.btnclose.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.btnclose.FlatAppearance.BorderSize = 0
        Me.btnclose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red
        Me.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnclose.Image = Global.TAX.My.Resources.Resources.close_16
        Me.btnclose.Location = New System.Drawing.Point(972, 0)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(37, 25)
        Me.btnclose.TabIndex = 3
        Me.btnclose.UseVisualStyleBackColor = False
        '
        'Admin_Principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1009, 550)
        Me.Controls.Add(Me.pnlPrincipal)
        Me.Controls.Add(Me.pnlSeparacion)
        Me.Controls.Add(Me.pnltitlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_Principal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.pnltitlebar.ResumeLayout(False)
        Me.pnlverticalmenu.ResumeLayout(False)
        Me.pnlBarraPrincipal.ResumeLayout(False)
        Me.pnlSeparacion.ResumeLayout(False)
        Me.pnlPrincipal.ResumeLayout(False)
        Me.pnlUsuario.ResumeLayout(False)
        Me.pnlUsuario.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.pbFotoUsuario, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbTAX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnltitlebar As System.Windows.Forms.Panel
    Friend WithEvents pnlverticalmenu As System.Windows.Forms.Panel
    Friend WithEvents btninicio As System.Windows.Forms.Button
    Friend WithEvents pnlselectedbtn As System.Windows.Forms.Panel
    Friend WithEvents btnliqsueldos As System.Windows.Forms.Button
    Friend WithEvents btnadminempleados As System.Windows.Forms.Button
    Friend WithEvents btnturecibo As System.Windows.Forms.Button
    Friend WithEvents btnficha As System.Windows.Forms.Button
    Friend WithEvents pnlBarraPrincipal As System.Windows.Forms.Panel
    Friend WithEvents btnEmpresa As System.Windows.Forms.Button
    Friend WithEvents btndivisas As System.Windows.Forms.Button
    Friend WithEvents btnConceptos As System.Windows.Forms.Button
    Friend WithEvents pnlBordeDer As System.Windows.Forms.Panel
    Friend WithEvents PnlBordeInf1 As System.Windows.Forms.Panel
    Friend WithEvents pnlBordeIzq As System.Windows.Forms.Panel
    Friend WithEvents pblBordeInf2 As System.Windows.Forms.Panel
    Friend WithEvents pbTAX As System.Windows.Forms.PictureBox
    Friend WithEvents btnclose As System.Windows.Forms.Button
    Friend WithEvents btnMinimizar As System.Windows.Forms.Button
    Friend WithEvents pnlSeparacion As System.Windows.Forms.Panel
    Friend WithEvents pnlPrincipal As System.Windows.Forms.Panel
    Friend WithEvents btnMenu As System.Windows.Forms.Button
    Friend WithEvents pnlOtraseparacion As System.Windows.Forms.Panel
    Friend WithEvents pnlUsuario As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents btnUser As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents User_lblId As System.Windows.Forms.Label
    Friend WithEvents User_lblDoc As System.Windows.Forms.Label
    Friend WithEvents User_lblNombre As System.Windows.Forms.Label
    Friend WithEvents pbFotoUsuario As System.Windows.Forms.PictureBox
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
