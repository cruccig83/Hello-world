﻿Imports MySql.Data.MySqlClient
Public Class empleados
    Dim sql As String
    Dim cmd As MySqlCommand
    Dim cnn As New MySqlConnection
    Private Sub cmdinicio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdinicio.Click
        inicioadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdficha.Click
        ficharoja.Show()
        Me.Close()

    End Sub

    Private Sub cmdrecibo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdrecibo.Click
        mireciboadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdliquidar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdliquidar.Click
        sueldos.Show()
        Me.Close()

    End Sub

    Private Sub cmdmodificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdmodificar.Click
        modificar.Show()
        Me.Close()

    End Sub

    Private Sub cmdeliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdeliminar.Click
        eliminar.Show()
        Me.Close()

    End Sub

    Private Sub cmdlistar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdlistar.Click
        listar.Show()
        Me.Close()

    End Sub

    Private Sub TextBox16_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttelefonoemp.TextChanged

    End Sub

    Private Sub cmdayuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdayuda.Click
        MsgBox("En Progreso")
    End Sub

    Private Sub cmdagregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdagregar.Click

        If Not (IsNumeric(txtcedula.Text)) Then
            MsgBox("Cedula: Solo se admiten numeros")
            txtcedula.Text = ""
            txtcedula.Focus()
        End If


        If Not (IsNumeric(txtcelular.Text)) Then
            MsgBox("Celular: Solo se admiten numeros")
            txtcelular.Text = ""
            txtcelular.Focus()
        End If


        If Not (IsNumeric(txttelefono.Text)) Then
            MsgBox("Telefono: Solo se admiten numeros")
            txttelefono.Text = ""
            txttelefono.Focus()
        End If


        If Not (IsNumeric(txtrut.Text)) Then
            MsgBox("Rut: Solo se admiten numeros")
            txtrut.Text = ""
            txtrut.Focus()
        End If


        If Not (IsNumeric(txtregistro.Text)) Then
            MsgBox("Número de Registro: Solo se admiten numeros")
            txtregistro.Text = ""
            txtregistro.Focus()
        End If


        If Not (IsNumeric(txttelefonoemp.Text)) Then
            MsgBox("Telefono Empresarial: Solo se admiten numeros")
            txttelefonoemp.Text = ""
            txttelefonoemp.Focus()
        End If


        If Not (Char.IsLetter(txtnombre.Text)) Then
            MsgBox("Nombre: Solo admite letras")
            txtnombre.Text = ""
            txtnombre.Focus()

        End If

        If Not (Char.IsLetter(txtapellido.Text)) Then
            MsgBox("Apellido: Solo admite letras")
            txtapellido.Text = ""
            txtapellido.Focus()

        End If

        If Not (Char.IsLetter(txtpuesto.Text)) Then
            MsgBox("Puesto: Solo admite letras")
            txtpuesto.Text = ""
            txtpuesto.Focus()

        End If

        If Not (Char.IsLetter(txtcargo.Text)) Then
            MsgBox("Cargo: Solo admite letras")
            txtcargo.Text = ""
            txtcargo.Focus()

        End If

        If Not (IsNumeric(txtgrado.Text)) Then
            MsgBox("Grado: Solo admite letras")
            txtgrado.Text = ""
            txtgrado.Focus()

        End If
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        cnn.Open()
        sql = "insert into personal (doc, nombre, apellido) values (" & txtcedula.Text & ",'" & txtnombre.Text & "','" & txtapellido.Text & "')"
        cmd = New MySqlCommand(sql, cnn)
        cmd.ExecuteNonQuery()
    End Sub

    Private Sub txtcedula_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcedula.TextChanged

    End Sub
End Class