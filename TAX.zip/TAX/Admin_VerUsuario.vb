﻿Imports MySql.Data.MySqlClient
Public Class Admin_VerUsuario


    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub


    Private Sub btnFicha_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFicha.Click
        TabControlPrincipal.SelectedTab = TabPageFicha
        pnlS_Ficha.Width = btnFicha.Width
        pnlS_Ficha.Location = New Point(btnFicha.Location.X, pnlS_Ficha.Location.Y)
    End Sub

    Private Sub btnOrganizacion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrganizacion.Click
        TabControlPrincipal.SelectedTab = TabPageOrganizacion
       


        pnlS_Ficha.Width = btnOrganizacion.Width
        pnlS_Ficha.Location = New Point(btnOrganizacion.Location.X, pnlS_Ficha.Location.Y)
    End Sub

    Private Sub btnHLaboral_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHLaboral.Click
        TabControlPrincipal.SelectedTab = TabPageHLaboral
        pnlS_Ficha.Width = btnHLaboral.Width
        pnlS_Ficha.Location = New Point(btnHLaboral.Location.X, pnlS_Ficha.Location.Y)
    End Sub

    Private Sub btnHRecibos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHRecibos.Click
        TabControlPrincipal.SelectedTab = TabPageHRecibos
        pnlS_Ficha.Width = btnHRecibos.Width
        pnlS_Ficha.Location = New Point(btnHRecibos.Location.X, pnlS_Ficha.Location.Y)
    End Sub

    Private Sub Admin_VerUsuario_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE doc = '" & Module1.busc_nombre & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.FICHA_txtDocumento.Text = rdr.Item("doc").ToString
                Me.FICHA_txtNombre.Text = rdr.Item("nombre").ToString
                Me.FICHA_txtApellido.Text = rdr.Item("apellido").ToString
                Me.FICHA_txtContraseña.Text = rdr.Item("passwd").ToString
                Me.FICHA_cbSexo.Text = rdr.Item("sexo").ToString
                Me.FICHA_dpFNac.Text = rdr.Item("f_nac").ToString
                Me.FICHA_txtCalle.Text = rdr.Item("calle").ToString
                Me.FICHA_txtDirNumero.Text = rdr.Item("numero").ToString
                Me.FICHA_cbEstCivil.Text = rdr.Item("estado_civil").ToString
                Me.FICHA_txtEmail.Text = rdr.Item("email").ToString
                '---------------------------------------------------------------
                Me.ORG_txtNRegistro.Text = rdr.Item("persona_id").ToString
                Me.ORG_dpFIngreso.Text = rdr.Item("f_ingreso").ToString
                Me.ORG_txtCargo.Text = rdr.Item("cargo").ToString
                Me.ORG_cbGrado.Text = rdr.Item("grado").ToString
                Me.ORG_txtDepartamento.Text = rdr.Item("dpto").ToString
                Me.ORG_txtTlfEmpresarial.Text = rdr.Item("tlf_empr").ToString
                Me.ORG_txtMailEmpresarial.Text = rdr.Item("email_empr").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnModificar.Click
        BtnModificar.Visible = False
        btnGuardarMods.Visible = True


        FICHA_txtDocumento.Enabled = True
        FICHA_txtDocumento.ForeColor = Color.LightGray
        FICHA_txtNombre.Enabled = True
        FICHA_txtNombre.ForeColor = Color.LightGray
        FICHA_txtApellido.Enabled = True
        FICHA_txtApellido.ForeColor = Color.LightGray
        FICHA_cbSexo.Enabled = True
        FICHA_cbSexo.ForeColor = Color.LightGray
        FICHA_dpFNac.Enabled = True
        FICHA_dpFNac.ForeColor = Color.LightGray
        FICHA_txtCalle.Enabled = True
        FICHA_txtCalle.ForeColor = Color.LightGray
        FICHA_txtDirNumero.Enabled = True
        FICHA_txtDirNumero.ForeColor = Color.LightGray
        FICHA_cbEstCivil.Enabled = True
        FICHA_cbEstCivil.ForeColor = Color.LightGray
        FICHA_txtEmail.Enabled = True
        FICHA_txtEmail.ForeColor = Color.LightGray
        ORG_txtNRegistro.Enabled = True
        ORG_txtNRegistro.ForeColor = Color.LightGray
        ORG_dpFIngreso.Enabled = True
        ORG_dpFIngreso.ForeColor = Color.LightGray
        ORG_txtCargo.Enabled = True
        ORG_txtCargo.ForeColor = Color.LightGray
        ORG_cbGrado.Enabled = True
        ORG_cbGrado.ForeColor = Color.LightGray
        ORG_txtDepartamento.Enabled = True
        ORG_txtDepartamento.ForeColor = Color.LightGray
        ORG_txtTlfEmpresarial.Enabled = True
        ORG_txtTlfEmpresarial.ForeColor = Color.LightGray
        ORG_txtMailEmpresarial.Enabled = True
        ORG_txtMailEmpresarial.ForeColor = Color.LightGray
    End Sub

    Private Sub btnGuardarMods_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGuardarMods.Click
        BtnModificar.Visible = True
        btnGuardarMods.Visible = False


        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "UPDATE personal SET doc = '" & FICHA_txtDocumento.Text & "', nombre = '" & FICHA_txtNombre.Text & "', apellido = '" & FICHA_txtApellido.Text & "', f_nac = '" & FICHA_dpFNac.Text & "', calle = '" & FICHA_txtCalle.Text & "', numero = '" & FICHA_txtDirNumero.Text & "', estado_civil = '" & FICHA_cbEstCivil.Text & "', sexo = '" & FICHA_cbSexo.Text & "', email = '" & FICHA_txtEmail.Text & "', persona_id = '" & ORG_txtNRegistro.Text & "', f_ingreso = '" & ORG_dpFIngreso.Text & "', cargo = '" & ORG_txtCargo.Text & "', grado = '" & ORG_cbGrado.Text & "', dpto = '" & ORG_txtDepartamento.Text & "', email_empr = '" & ORG_txtMailEmpresarial.Text & "', tlf_empr = '" & ORG_txtTlfEmpresarial.Text & "'  WHERE doc = " & Module1.busc_nombre & " "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub


    Private Sub FICHA_cbEstCivil_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_cbEstCivil.Click
        FICHA_cbEstCivil.ForeColor = Color.Black
    End Sub

    Private Sub FICHA_cbSexo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_cbSexo.Click
        FICHA_cbSexo.ForeColor = Color.Black
    End Sub

    Private Sub FICHA_txtApellido_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_txtApellido.Click
        FICHA_txtApellido.ForeColor = Color.Black
        FICHA_txtApellido.Clear()
    End Sub

    Private Sub FICHA_txtCalle_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_txtCalle.Click
        FICHA_txtCalle.ForeColor = Color.Black
        FICHA_txtCalle.Clear()
    End Sub

    Private Sub FICHA_txtCelular_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_txtCelular.Click
        FICHA_txtCelular.ForeColor = Color.Black
        FICHA_txtCelular.Clear()
    End Sub

    Private Sub FICHA_txtContraseña_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_txtContraseña.Click
        FICHA_txtContraseña.ForeColor = Color.Black
        FICHA_txtContraseña.Clear()
    End Sub

    Private Sub FICHA_txtDirNumero_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_txtDirNumero.Click
        FICHA_txtDirNumero.ForeColor = Color.Black
        FICHA_txtDirNumero.Clear()
    End Sub

    Private Sub FICHA_txtDocumento_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_txtDocumento.Click
        FICHA_txtDocumento.ForeColor = Color.Black
        FICHA_txtDocumento.Clear()
    End Sub

    Private Sub FICHA_txtEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_txtEmail.Click
        FICHA_txtEmail.ForeColor = Color.Black
        FICHA_txtEmail.Clear()
    End Sub

    Private Sub FICHA_txtFijo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_txtFijo.Click
        FICHA_txtFijo.ForeColor = Color.Black
        FICHA_txtFijo.Clear()
    End Sub

    Private Sub FICHA_txtHijos_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_txtHijos.Click
        FICHA_txtHijos.ForeColor = Color.Black
        FICHA_txtHijos.Clear()
    End Sub

    Private Sub FICHA_txtNombre_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FICHA_txtNombre.Click
        FICHA_txtNombre.ForeColor = Color.Black
        FICHA_txtNombre.Clear()
    End Sub

    Private Sub ORG_cbGrado_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ORG_cbGrado.Click
        ORG_cbGrado.ForeColor = Color.Black
    End Sub

    Private Sub ORG_txtCargo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ORG_txtCargo.Click
        ORG_txtCargo.ForeColor = Color.Black
        ORG_txtCargo.Clear()
    End Sub

    Private Sub ORG_txtDepartamento_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ORG_txtDepartamento.Click
        ORG_txtDepartamento.ForeColor = Color.Black
        ORG_txtDepartamento.Clear()
    End Sub

    Private Sub ORG_txtMailEmpresarial_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ORG_txtMailEmpresarial.Click
        ORG_txtMailEmpresarial.ForeColor = Color.Black
        ORG_txtMailEmpresarial.Clear()
    End Sub

    Private Sub ORG_txtNRegistro_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ORG_txtNRegistro.Click
        ORG_txtNRegistro.ForeColor = Color.Black
        ORG_txtNRegistro.Clear()
    End Sub

    Private Sub ORG_txtTlfEmpresarial_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ORG_txtTlfEmpresarial.Click
        ORG_txtTlfEmpresarial.ForeColor = Color.Black
        ORG_txtTlfEmpresarial.Clear()
    End Sub
End Class