﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class buscar_usuarios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim TabPageListar As System.Windows.Forms.TabPage
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(buscar_usuarios))
        Me.ModUser_txtDireccionCompleta = New System.Windows.Forms.TextBox
        Me.ModUser_txtApellidosCompleto = New System.Windows.Forms.TextBox
        Me.ModUser_txtNombreCompleto = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.ModUser_cbGrado = New System.Windows.Forms.ComboBox
        Me.ADD_ObligTipoUsuario = New System.Windows.Forms.Label
        Me.ADD_ObligEmailEmpr = New System.Windows.Forms.Label
        Me.ADD_ObligTelfEmpresarial = New System.Windows.Forms.Label
        Me.ADD_ObligDepartamento = New System.Windows.Forms.Label
        Me.ADD_ObligGrado = New System.Windows.Forms.Label
        Me.ADD_ObligCargo = New System.Windows.Forms.Label
        Me.ADD_FIngreso = New System.Windows.Forms.Label
        Me.ADD_ObligEmail = New System.Windows.Forms.Label
        Me.ADD_ObligEstCivil = New System.Windows.Forms.Label
        Me.ADD_ObligDirNumero = New System.Windows.Forms.Label
        Me.ADD_ObligDirCalle = New System.Windows.Forms.Label
        Me.ADD_ObligFNac = New System.Windows.Forms.Label
        Me.ADD_ObligSexo = New System.Windows.Forms.Label
        Me.ADD_ObligApellido = New System.Windows.Forms.Label
        Me.ADD_ObligNombre = New System.Windows.Forms.Label
        Me.ADD_ObligDocumento = New System.Windows.Forms.Label
        Me.ModUser_txt2apellido = New System.Windows.Forms.TextBox
        Me.ModUser_txt2Nombre = New System.Windows.Forms.TextBox
        Me.ModUser_txtDirCalle = New System.Windows.Forms.TextBox
        Me.ModUser_txtDirNumero = New System.Windows.Forms.TextBox
        Me.ModUser_cbEstCivil = New System.Windows.Forms.ComboBox
        Me.ModUser_cbSexo = New System.Windows.Forms.ComboBox
        Me.ModUser_dateFIngreso = New System.Windows.Forms.DateTimePicker
        Me.ModUser_dateFNacimiento = New System.Windows.Forms.DateTimePicker
        Me.ListUser_rbAdmin = New System.Windows.Forms.RadioButton
        Me.ListUser_rbUsuario = New System.Windows.Forms.RadioButton
        Me.ModUser_txtMailEmpresarial = New System.Windows.Forms.TextBox
        Me.ModUser_txtTlfEmpresarial = New System.Windows.Forms.TextBox
        Me.ModUser_txtDepartamento = New System.Windows.Forms.TextBox
        Me.ModUser_txtCargo = New System.Windows.Forms.TextBox
        Me.AddUser_lblEmailEmpresarial = New System.Windows.Forms.Label
        Me.AddUser_lblTelfEmpresarial = New System.Windows.Forms.Label
        Me.AddUser_lblDepartamento = New System.Windows.Forms.Label
        Me.AddUser_lblGrado = New System.Windows.Forms.Label
        Me.AddUser_lblCargo = New System.Windows.Forms.Label
        Me.AddUser_lblFIngreso = New System.Windows.Forms.Label
        Me.ModUser_txtFijo = New System.Windows.Forms.TextBox
        Me.ModUser_txtCelular = New System.Windows.Forms.TextBox
        Me.ModUser_txtHijos = New System.Windows.Forms.TextBox
        Me.ModUser_txtEmail = New System.Windows.Forms.TextBox
        Me.ModUser_txtContraseña = New System.Windows.Forms.TextBox
        Me.ModUser_txtApellido = New System.Windows.Forms.TextBox
        Me.ModUser_txtNombre = New System.Windows.Forms.TextBox
        Me.AddUser_lblFijo = New System.Windows.Forms.Label
        Me.AddUser_lblCelular = New System.Windows.Forms.Label
        Me.AddUser_lblEmail = New System.Windows.Forms.Label
        Me.AddUser_lblEstCivil = New System.Windows.Forms.Label
        Me.AddUser_lblDireccion = New System.Windows.Forms.Label
        Me.AddUser_lblFNacimiento = New System.Windows.Forms.Label
        Me.AddUser_lblContraseña = New System.Windows.Forms.Label
        Me.AddUser_lblApellido = New System.Windows.Forms.Label
        Me.AddUser_lblNombre = New System.Windows.Forms.Label
        Me.ModUser_txtDocumento = New System.Windows.Forms.TextBox
        Me.AddUser_lblDocumento = New System.Windows.Forms.Label
        Me.List_btnBuscar = New System.Windows.Forms.Button
        Me.List_txtBuscar = New System.Windows.Forms.TextBox
        Me.pnlDer = New System.Windows.Forms.Panel
        Me.pnlSup = New System.Windows.Forms.Panel
        Me.pnlIzq = New System.Windows.Forms.Panel
        Me.pnlInf = New System.Windows.Forms.Panel
        Me.pnlCentral = New System.Windows.Forms.Panel
        Me.pnlBarra = New System.Windows.Forms.Panel
        Me.TabControlAgregarMod = New System.Windows.Forms.TabControl
        Me.TabPageAgregar = New System.Windows.Forms.TabPage
        Me.ListUser_btnCancelar = New System.Windows.Forms.Button
        Me.ListUser_btnGuardar = New System.Windows.Forms.Button
        Me.ListUser_btnEliminar = New System.Windows.Forms.Button
        Me.ListUser_btnModificar = New System.Windows.Forms.Button
        Me.AddUser_pbFoto = New System.Windows.Forms.PictureBox
        Me.List_btnLupa = New System.Windows.Forms.Button
        TabPageListar = New System.Windows.Forms.TabPage
        TabPageListar.SuspendLayout()
        Me.pnlCentral.SuspendLayout()
        Me.TabControlAgregarMod.SuspendLayout()
        CType(Me.AddUser_pbFoto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabPageListar
        '
        TabPageListar.AutoScroll = True
        TabPageListar.Controls.Add(Me.ListUser_btnCancelar)
        TabPageListar.Controls.Add(Me.ListUser_btnGuardar)
        TabPageListar.Controls.Add(Me.ModUser_txtDireccionCompleta)
        TabPageListar.Controls.Add(Me.ListUser_btnEliminar)
        TabPageListar.Controls.Add(Me.ListUser_btnModificar)
        TabPageListar.Controls.Add(Me.ModUser_txtApellidosCompleto)
        TabPageListar.Controls.Add(Me.ModUser_txtNombreCompleto)
        TabPageListar.Controls.Add(Me.Button1)
        TabPageListar.Controls.Add(Me.ModUser_cbGrado)
        TabPageListar.Controls.Add(Me.AddUser_pbFoto)
        TabPageListar.Controls.Add(Me.ADD_ObligTipoUsuario)
        TabPageListar.Controls.Add(Me.ADD_ObligEmailEmpr)
        TabPageListar.Controls.Add(Me.ADD_ObligTelfEmpresarial)
        TabPageListar.Controls.Add(Me.ADD_ObligDepartamento)
        TabPageListar.Controls.Add(Me.ADD_ObligGrado)
        TabPageListar.Controls.Add(Me.ADD_ObligCargo)
        TabPageListar.Controls.Add(Me.ADD_FIngreso)
        TabPageListar.Controls.Add(Me.ADD_ObligEmail)
        TabPageListar.Controls.Add(Me.ADD_ObligEstCivil)
        TabPageListar.Controls.Add(Me.ADD_ObligDirNumero)
        TabPageListar.Controls.Add(Me.ADD_ObligDirCalle)
        TabPageListar.Controls.Add(Me.ADD_ObligFNac)
        TabPageListar.Controls.Add(Me.ADD_ObligSexo)
        TabPageListar.Controls.Add(Me.ADD_ObligApellido)
        TabPageListar.Controls.Add(Me.ADD_ObligNombre)
        TabPageListar.Controls.Add(Me.ADD_ObligDocumento)
        TabPageListar.Controls.Add(Me.ModUser_txt2apellido)
        TabPageListar.Controls.Add(Me.ModUser_txt2Nombre)
        TabPageListar.Controls.Add(Me.ModUser_txtDirCalle)
        TabPageListar.Controls.Add(Me.ModUser_txtDirNumero)
        TabPageListar.Controls.Add(Me.ModUser_cbEstCivil)
        TabPageListar.Controls.Add(Me.ModUser_cbSexo)
        TabPageListar.Controls.Add(Me.ModUser_dateFIngreso)
        TabPageListar.Controls.Add(Me.ModUser_dateFNacimiento)
        TabPageListar.Controls.Add(Me.ListUser_rbAdmin)
        TabPageListar.Controls.Add(Me.ListUser_rbUsuario)
        TabPageListar.Controls.Add(Me.ModUser_txtMailEmpresarial)
        TabPageListar.Controls.Add(Me.ModUser_txtTlfEmpresarial)
        TabPageListar.Controls.Add(Me.ModUser_txtDepartamento)
        TabPageListar.Controls.Add(Me.ModUser_txtCargo)
        TabPageListar.Controls.Add(Me.AddUser_lblEmailEmpresarial)
        TabPageListar.Controls.Add(Me.AddUser_lblTelfEmpresarial)
        TabPageListar.Controls.Add(Me.AddUser_lblDepartamento)
        TabPageListar.Controls.Add(Me.AddUser_lblGrado)
        TabPageListar.Controls.Add(Me.AddUser_lblCargo)
        TabPageListar.Controls.Add(Me.AddUser_lblFIngreso)
        TabPageListar.Controls.Add(Me.ModUser_txtFijo)
        TabPageListar.Controls.Add(Me.ModUser_txtCelular)
        TabPageListar.Controls.Add(Me.ModUser_txtHijos)
        TabPageListar.Controls.Add(Me.ModUser_txtEmail)
        TabPageListar.Controls.Add(Me.ModUser_txtContraseña)
        TabPageListar.Controls.Add(Me.ModUser_txtApellido)
        TabPageListar.Controls.Add(Me.ModUser_txtNombre)
        TabPageListar.Controls.Add(Me.AddUser_lblFijo)
        TabPageListar.Controls.Add(Me.AddUser_lblCelular)
        TabPageListar.Controls.Add(Me.AddUser_lblEmail)
        TabPageListar.Controls.Add(Me.AddUser_lblEstCivil)
        TabPageListar.Controls.Add(Me.AddUser_lblDireccion)
        TabPageListar.Controls.Add(Me.AddUser_lblFNacimiento)
        TabPageListar.Controls.Add(Me.AddUser_lblContraseña)
        TabPageListar.Controls.Add(Me.AddUser_lblApellido)
        TabPageListar.Controls.Add(Me.AddUser_lblNombre)
        TabPageListar.Controls.Add(Me.ModUser_txtDocumento)
        TabPageListar.Controls.Add(Me.AddUser_lblDocumento)
        TabPageListar.Controls.Add(Me.List_btnBuscar)
        TabPageListar.Controls.Add(Me.List_btnLupa)
        TabPageListar.Controls.Add(Me.List_txtBuscar)
        TabPageListar.Location = New System.Drawing.Point(4, 22)
        TabPageListar.Name = "TabPageListar"
        TabPageListar.Padding = New System.Windows.Forms.Padding(3)
        TabPageListar.Size = New System.Drawing.Size(761, 350)
        TabPageListar.TabIndex = 0
        TabPageListar.Text = "TabPage1"
        TabPageListar.UseVisualStyleBackColor = True
        '
        'ModUser_txtDireccionCompleta
        '
        Me.ModUser_txtDireccionCompleta.BackColor = System.Drawing.Color.White
        Me.ModUser_txtDireccionCompleta.Enabled = False
        Me.ModUser_txtDireccionCompleta.ForeColor = System.Drawing.Color.White
        Me.ModUser_txtDireccionCompleta.Location = New System.Drawing.Point(223, 282)
        Me.ModUser_txtDireccionCompleta.Name = "ModUser_txtDireccionCompleta"
        Me.ModUser_txtDireccionCompleta.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtDireccionCompleta.TabIndex = 156
        '
        'ModUser_txtApellidosCompleto
        '
        Me.ModUser_txtApellidosCompleto.BackColor = System.Drawing.Color.White
        Me.ModUser_txtApellidosCompleto.Enabled = False
        Me.ModUser_txtApellidosCompleto.Location = New System.Drawing.Point(223, 166)
        Me.ModUser_txtApellidosCompleto.Name = "ModUser_txtApellidosCompleto"
        Me.ModUser_txtApellidosCompleto.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtApellidosCompleto.TabIndex = 153
        '
        'ModUser_txtNombreCompleto
        '
        Me.ModUser_txtNombreCompleto.BackColor = System.Drawing.Color.White
        Me.ModUser_txtNombreCompleto.Enabled = False
        Me.ModUser_txtNombreCompleto.Location = New System.Drawing.Point(223, 137)
        Me.ModUser_txtNombreCompleto.Name = "ModUser_txtNombreCompleto"
        Me.ModUser_txtNombreCompleto.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtNombreCompleto.TabIndex = 152
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(552, 76)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(124, 23)
        Me.Button1.TabIndex = 151
        Me.Button1.Text = "Seleccionar foto"
        Me.Button1.UseVisualStyleBackColor = False
        Me.Button1.Visible = False
        '
        'ModUser_cbGrado
        '
        Me.ModUser_cbGrado.BackColor = System.Drawing.Color.White
        Me.ModUser_cbGrado.Enabled = False
        Me.ModUser_cbGrado.ForeColor = System.Drawing.Color.White
        Me.ModUser_cbGrado.FormattingEnabled = True
        Me.ModUser_cbGrado.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.ModUser_cbGrado.Location = New System.Drawing.Point(552, 227)
        Me.ModUser_cbGrado.Name = "ModUser_cbGrado"
        Me.ModUser_cbGrado.Size = New System.Drawing.Size(132, 21)
        Me.ModUser_cbGrado.TabIndex = 149
        '
        'ADD_ObligTipoUsuario
        '
        Me.ADD_ObligTipoUsuario.AutoSize = True
        Me.ADD_ObligTipoUsuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligTipoUsuario.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligTipoUsuario.Location = New System.Drawing.Point(399, 350)
        Me.ADD_ObligTipoUsuario.Name = "ADD_ObligTipoUsuario"
        Me.ADD_ObligTipoUsuario.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligTipoUsuario.TabIndex = 148
        Me.ADD_ObligTipoUsuario.Text = "*"
        '
        'ADD_ObligEmailEmpr
        '
        Me.ADD_ObligEmailEmpr.AutoSize = True
        Me.ADD_ObligEmailEmpr.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligEmailEmpr.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligEmailEmpr.Location = New System.Drawing.Point(532, 316)
        Me.ADD_ObligEmailEmpr.Name = "ADD_ObligEmailEmpr"
        Me.ADD_ObligEmailEmpr.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligEmailEmpr.TabIndex = 147
        Me.ADD_ObligEmailEmpr.Text = "*"
        '
        'ADD_ObligTelfEmpresarial
        '
        Me.ADD_ObligTelfEmpresarial.AutoSize = True
        Me.ADD_ObligTelfEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligTelfEmpresarial.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligTelfEmpresarial.Location = New System.Drawing.Point(532, 287)
        Me.ADD_ObligTelfEmpresarial.Name = "ADD_ObligTelfEmpresarial"
        Me.ADD_ObligTelfEmpresarial.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligTelfEmpresarial.TabIndex = 146
        Me.ADD_ObligTelfEmpresarial.Text = "*"
        '
        'ADD_ObligDepartamento
        '
        Me.ADD_ObligDepartamento.AutoSize = True
        Me.ADD_ObligDepartamento.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligDepartamento.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligDepartamento.Location = New System.Drawing.Point(532, 258)
        Me.ADD_ObligDepartamento.Name = "ADD_ObligDepartamento"
        Me.ADD_ObligDepartamento.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligDepartamento.TabIndex = 145
        Me.ADD_ObligDepartamento.Text = "*"
        '
        'ADD_ObligGrado
        '
        Me.ADD_ObligGrado.AutoSize = True
        Me.ADD_ObligGrado.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligGrado.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligGrado.Location = New System.Drawing.Point(532, 229)
        Me.ADD_ObligGrado.Name = "ADD_ObligGrado"
        Me.ADD_ObligGrado.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligGrado.TabIndex = 144
        Me.ADD_ObligGrado.Text = "*"
        '
        'ADD_ObligCargo
        '
        Me.ADD_ObligCargo.AutoSize = True
        Me.ADD_ObligCargo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligCargo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligCargo.Location = New System.Drawing.Point(532, 200)
        Me.ADD_ObligCargo.Name = "ADD_ObligCargo"
        Me.ADD_ObligCargo.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligCargo.TabIndex = 143
        Me.ADD_ObligCargo.Text = "*"
        '
        'ADD_FIngreso
        '
        Me.ADD_FIngreso.AutoSize = True
        Me.ADD_FIngreso.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_FIngreso.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_FIngreso.Location = New System.Drawing.Point(532, 168)
        Me.ADD_FIngreso.Name = "ADD_FIngreso"
        Me.ADD_FIngreso.Size = New System.Drawing.Size(14, 18)
        Me.ADD_FIngreso.TabIndex = 142
        Me.ADD_FIngreso.Text = "*"
        '
        'ADD_ObligEmail
        '
        Me.ADD_ObligEmail.AutoSize = True
        Me.ADD_ObligEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligEmail.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligEmail.Location = New System.Drawing.Point(203, 341)
        Me.ADD_ObligEmail.Name = "ADD_ObligEmail"
        Me.ADD_ObligEmail.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligEmail.TabIndex = 141
        Me.ADD_ObligEmail.Text = "*"
        '
        'ADD_ObligEstCivil
        '
        Me.ADD_ObligEstCivil.AutoSize = True
        Me.ADD_ObligEstCivil.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligEstCivil.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligEstCivil.Location = New System.Drawing.Point(203, 314)
        Me.ADD_ObligEstCivil.Name = "ADD_ObligEstCivil"
        Me.ADD_ObligEstCivil.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligEstCivil.TabIndex = 140
        Me.ADD_ObligEstCivil.Text = "*"
        '
        'ADD_ObligDirNumero
        '
        Me.ADD_ObligDirNumero.AutoSize = True
        Me.ADD_ObligDirNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligDirNumero.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligDirNumero.Location = New System.Drawing.Point(361, 284)
        Me.ADD_ObligDirNumero.Name = "ADD_ObligDirNumero"
        Me.ADD_ObligDirNumero.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligDirNumero.TabIndex = 139
        Me.ADD_ObligDirNumero.Text = "*"
        '
        'ADD_ObligDirCalle
        '
        Me.ADD_ObligDirCalle.AutoSize = True
        Me.ADD_ObligDirCalle.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligDirCalle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligDirCalle.Location = New System.Drawing.Point(203, 284)
        Me.ADD_ObligDirCalle.Name = "ADD_ObligDirCalle"
        Me.ADD_ObligDirCalle.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligDirCalle.TabIndex = 138
        Me.ADD_ObligDirCalle.Text = "*"
        '
        'ADD_ObligFNac
        '
        Me.ADD_ObligFNac.AutoSize = True
        Me.ADD_ObligFNac.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligFNac.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligFNac.Location = New System.Drawing.Point(203, 255)
        Me.ADD_ObligFNac.Name = "ADD_ObligFNac"
        Me.ADD_ObligFNac.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligFNac.TabIndex = 137
        Me.ADD_ObligFNac.Text = "*"
        '
        'ADD_ObligSexo
        '
        Me.ADD_ObligSexo.AutoSize = True
        Me.ADD_ObligSexo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligSexo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligSexo.Location = New System.Drawing.Point(203, 227)
        Me.ADD_ObligSexo.Name = "ADD_ObligSexo"
        Me.ADD_ObligSexo.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligSexo.TabIndex = 136
        Me.ADD_ObligSexo.Text = "*"
        '
        'ADD_ObligApellido
        '
        Me.ADD_ObligApellido.AutoSize = True
        Me.ADD_ObligApellido.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligApellido.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligApellido.Location = New System.Drawing.Point(203, 165)
        Me.ADD_ObligApellido.Name = "ADD_ObligApellido"
        Me.ADD_ObligApellido.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligApellido.TabIndex = 135
        Me.ADD_ObligApellido.Text = "*"
        '
        'ADD_ObligNombre
        '
        Me.ADD_ObligNombre.AutoSize = True
        Me.ADD_ObligNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligNombre.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligNombre.Location = New System.Drawing.Point(203, 139)
        Me.ADD_ObligNombre.Name = "ADD_ObligNombre"
        Me.ADD_ObligNombre.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligNombre.TabIndex = 134
        Me.ADD_ObligNombre.Text = "*"
        '
        'ADD_ObligDocumento
        '
        Me.ADD_ObligDocumento.AutoSize = True
        Me.ADD_ObligDocumento.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADD_ObligDocumento.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ADD_ObligDocumento.Location = New System.Drawing.Point(203, 107)
        Me.ADD_ObligDocumento.Name = "ADD_ObligDocumento"
        Me.ADD_ObligDocumento.Size = New System.Drawing.Size(14, 18)
        Me.ADD_ObligDocumento.TabIndex = 133
        Me.ADD_ObligDocumento.Text = "*"
        '
        'ModUser_txt2apellido
        '
        Me.ModUser_txt2apellido.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txt2apellido.ForeColor = System.Drawing.Color.Black
        Me.ModUser_txt2apellido.Location = New System.Drawing.Point(290, 166)
        Me.ModUser_txt2apellido.Name = "ModUser_txt2apellido"
        Me.ModUser_txt2apellido.Size = New System.Drawing.Size(65, 20)
        Me.ModUser_txt2apellido.TabIndex = 100
        Me.ModUser_txt2apellido.Visible = False
        '
        'ModUser_txt2Nombre
        '
        Me.ModUser_txt2Nombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txt2Nombre.ForeColor = System.Drawing.Color.Black
        Me.ModUser_txt2Nombre.Location = New System.Drawing.Point(290, 137)
        Me.ModUser_txt2Nombre.Name = "ModUser_txt2Nombre"
        Me.ModUser_txt2Nombre.Size = New System.Drawing.Size(65, 20)
        Me.ModUser_txt2Nombre.TabIndex = 97
        Me.ModUser_txt2Nombre.Visible = False
        '
        'ModUser_txtDirCalle
        '
        Me.ModUser_txtDirCalle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtDirCalle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ModUser_txtDirCalle.Location = New System.Drawing.Point(223, 282)
        Me.ModUser_txtDirCalle.Name = "ModUser_txtDirCalle"
        Me.ModUser_txtDirCalle.Size = New System.Drawing.Size(65, 20)
        Me.ModUser_txtDirCalle.TabIndex = 103
        Me.ModUser_txtDirCalle.Visible = False
        '
        'ModUser_txtDirNumero
        '
        Me.ModUser_txtDirNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtDirNumero.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ModUser_txtDirNumero.Location = New System.Drawing.Point(290, 282)
        Me.ModUser_txtDirNumero.Name = "ModUser_txtDirNumero"
        Me.ModUser_txtDirNumero.Size = New System.Drawing.Size(65, 20)
        Me.ModUser_txtDirNumero.TabIndex = 104
        Me.ModUser_txtDirNumero.Visible = False
        '
        'ModUser_cbEstCivil
        '
        Me.ModUser_cbEstCivil.BackColor = System.Drawing.Color.White
        Me.ModUser_cbEstCivil.Enabled = False
        Me.ModUser_cbEstCivil.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_cbEstCivil.ForeColor = System.Drawing.Color.White
        Me.ModUser_cbEstCivil.FormattingEnabled = True
        Me.ModUser_cbEstCivil.Items.AddRange(New Object() {"casado/a", "soltero/a", "divorciado/a", "concubinato/a", "viudo/a"})
        Me.ModUser_cbEstCivil.Location = New System.Drawing.Point(223, 311)
        Me.ModUser_cbEstCivil.Name = "ModUser_cbEstCivil"
        Me.ModUser_cbEstCivil.Size = New System.Drawing.Size(132, 21)
        Me.ModUser_cbEstCivil.TabIndex = 105
        '
        'ModUser_cbSexo
        '
        Me.ModUser_cbSexo.BackColor = System.Drawing.Color.White
        Me.ModUser_cbSexo.Enabled = False
        Me.ModUser_cbSexo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_cbSexo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ModUser_cbSexo.FormattingEnabled = True
        Me.ModUser_cbSexo.Items.AddRange(New Object() {"hombre", "mujer", "otro"})
        Me.ModUser_cbSexo.Location = New System.Drawing.Point(223, 224)
        Me.ModUser_cbSexo.Name = "ModUser_cbSexo"
        Me.ModUser_cbSexo.Size = New System.Drawing.Size(132, 21)
        Me.ModUser_cbSexo.TabIndex = 101
        '
        'ModUser_dateFIngreso
        '
        Me.ModUser_dateFIngreso.CalendarMonthBackground = System.Drawing.Color.White
        Me.ModUser_dateFIngreso.CustomFormat = "yyyy-MM-dd"
        Me.ModUser_dateFIngreso.Enabled = False
        Me.ModUser_dateFIngreso.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ModUser_dateFIngreso.Location = New System.Drawing.Point(552, 166)
        Me.ModUser_dateFIngreso.Name = "ModUser_dateFIngreso"
        Me.ModUser_dateFIngreso.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_dateFIngreso.TabIndex = 110
        '
        'ModUser_dateFNacimiento
        '
        Me.ModUser_dateFNacimiento.CalendarMonthBackground = System.Drawing.Color.White
        Me.ModUser_dateFNacimiento.CustomFormat = "yyyy-MM-dd"
        Me.ModUser_dateFNacimiento.Enabled = False
        Me.ModUser_dateFNacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ModUser_dateFNacimiento.Location = New System.Drawing.Point(223, 253)
        Me.ModUser_dateFNacimiento.Name = "ModUser_dateFNacimiento"
        Me.ModUser_dateFNacimiento.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_dateFNacimiento.TabIndex = 102
        '
        'ListUser_rbAdmin
        '
        Me.ListUser_rbAdmin.AutoSize = True
        Me.ListUser_rbAdmin.Enabled = False
        Me.ListUser_rbAdmin.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListUser_rbAdmin.Location = New System.Drawing.Point(552, 349)
        Me.ListUser_rbAdmin.Name = "ListUser_rbAdmin"
        Me.ListUser_rbAdmin.Size = New System.Drawing.Size(107, 19)
        Me.ListUser_rbAdmin.TabIndex = 116
        Me.ListUser_rbAdmin.TabStop = True
        Me.ListUser_rbAdmin.Text = "ADMINISTRADOR"
        Me.ListUser_rbAdmin.UseVisualStyleBackColor = True
        '
        'ListUser_rbUsuario
        '
        Me.ListUser_rbUsuario.AutoSize = True
        Me.ListUser_rbUsuario.Enabled = False
        Me.ListUser_rbUsuario.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListUser_rbUsuario.Location = New System.Drawing.Point(419, 349)
        Me.ListUser_rbUsuario.Name = "ListUser_rbUsuario"
        Me.ListUser_rbUsuario.Size = New System.Drawing.Size(69, 19)
        Me.ListUser_rbUsuario.TabIndex = 115
        Me.ListUser_rbUsuario.TabStop = True
        Me.ListUser_rbUsuario.Text = "USUARIO"
        Me.ListUser_rbUsuario.UseVisualStyleBackColor = True
        '
        'ModUser_txtMailEmpresarial
        '
        Me.ModUser_txtMailEmpresarial.BackColor = System.Drawing.Color.White
        Me.ModUser_txtMailEmpresarial.Enabled = False
        Me.ModUser_txtMailEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtMailEmpresarial.ForeColor = System.Drawing.Color.White
        Me.ModUser_txtMailEmpresarial.Location = New System.Drawing.Point(552, 314)
        Me.ModUser_txtMailEmpresarial.Name = "ModUser_txtMailEmpresarial"
        Me.ModUser_txtMailEmpresarial.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtMailEmpresarial.TabIndex = 114
        '
        'ModUser_txtTlfEmpresarial
        '
        Me.ModUser_txtTlfEmpresarial.BackColor = System.Drawing.Color.White
        Me.ModUser_txtTlfEmpresarial.Enabled = False
        Me.ModUser_txtTlfEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtTlfEmpresarial.ForeColor = System.Drawing.Color.White
        Me.ModUser_txtTlfEmpresarial.Location = New System.Drawing.Point(552, 285)
        Me.ModUser_txtTlfEmpresarial.MaxLength = 8
        Me.ModUser_txtTlfEmpresarial.Name = "ModUser_txtTlfEmpresarial"
        Me.ModUser_txtTlfEmpresarial.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtTlfEmpresarial.TabIndex = 113
        '
        'ModUser_txtDepartamento
        '
        Me.ModUser_txtDepartamento.BackColor = System.Drawing.Color.White
        Me.ModUser_txtDepartamento.Enabled = False
        Me.ModUser_txtDepartamento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtDepartamento.ForeColor = System.Drawing.Color.White
        Me.ModUser_txtDepartamento.Location = New System.Drawing.Point(552, 256)
        Me.ModUser_txtDepartamento.Name = "ModUser_txtDepartamento"
        Me.ModUser_txtDepartamento.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtDepartamento.TabIndex = 112
        '
        'ModUser_txtCargo
        '
        Me.ModUser_txtCargo.BackColor = System.Drawing.Color.White
        Me.ModUser_txtCargo.Enabled = False
        Me.ModUser_txtCargo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtCargo.ForeColor = System.Drawing.Color.White
        Me.ModUser_txtCargo.Location = New System.Drawing.Point(552, 198)
        Me.ModUser_txtCargo.Name = "ModUser_txtCargo"
        Me.ModUser_txtCargo.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtCargo.TabIndex = 111
        '
        'AddUser_lblEmailEmpresarial
        '
        Me.AddUser_lblEmailEmpresarial.AutoSize = True
        Me.AddUser_lblEmailEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblEmailEmpresarial.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblEmailEmpresarial.Location = New System.Drawing.Point(391, 316)
        Me.AddUser_lblEmailEmpresarial.Name = "AddUser_lblEmailEmpresarial"
        Me.AddUser_lblEmailEmpresarial.Size = New System.Drawing.Size(111, 17)
        Me.AddUser_lblEmailEmpresarial.TabIndex = 132
        Me.AddUser_lblEmailEmpresarial.Text = "Email empresarial:"
        '
        'AddUser_lblTelfEmpresarial
        '
        Me.AddUser_lblTelfEmpresarial.AutoSize = True
        Me.AddUser_lblTelfEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblTelfEmpresarial.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblTelfEmpresarial.Location = New System.Drawing.Point(391, 287)
        Me.AddUser_lblTelfEmpresarial.Name = "AddUser_lblTelfEmpresarial"
        Me.AddUser_lblTelfEmpresarial.Size = New System.Drawing.Size(128, 17)
        Me.AddUser_lblTelfEmpresarial.TabIndex = 131
        Me.AddUser_lblTelfEmpresarial.Text = "Teléfono empresarial:"
        '
        'AddUser_lblDepartamento
        '
        Me.AddUser_lblDepartamento.AutoSize = True
        Me.AddUser_lblDepartamento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblDepartamento.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblDepartamento.Location = New System.Drawing.Point(390, 258)
        Me.AddUser_lblDepartamento.Name = "AddUser_lblDepartamento"
        Me.AddUser_lblDepartamento.Size = New System.Drawing.Size(92, 17)
        Me.AddUser_lblDepartamento.TabIndex = 130
        Me.AddUser_lblDepartamento.Text = "Departamento:"
        '
        'AddUser_lblGrado
        '
        Me.AddUser_lblGrado.AutoSize = True
        Me.AddUser_lblGrado.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblGrado.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblGrado.Location = New System.Drawing.Point(390, 229)
        Me.AddUser_lblGrado.Name = "AddUser_lblGrado"
        Me.AddUser_lblGrado.Size = New System.Drawing.Size(44, 17)
        Me.AddUser_lblGrado.TabIndex = 129
        Me.AddUser_lblGrado.Text = "Grado:"
        '
        'AddUser_lblCargo
        '
        Me.AddUser_lblCargo.AutoSize = True
        Me.AddUser_lblCargo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblCargo.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblCargo.Location = New System.Drawing.Point(390, 200)
        Me.AddUser_lblCargo.Name = "AddUser_lblCargo"
        Me.AddUser_lblCargo.Size = New System.Drawing.Size(44, 17)
        Me.AddUser_lblCargo.TabIndex = 128
        Me.AddUser_lblCargo.Text = "Cargo:"
        '
        'AddUser_lblFIngreso
        '
        Me.AddUser_lblFIngreso.AutoSize = True
        Me.AddUser_lblFIngreso.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblFIngreso.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblFIngreso.Location = New System.Drawing.Point(390, 168)
        Me.AddUser_lblFIngreso.Name = "AddUser_lblFIngreso"
        Me.AddUser_lblFIngreso.Size = New System.Drawing.Size(106, 17)
        Me.AddUser_lblFIngreso.TabIndex = 127
        Me.AddUser_lblFIngreso.Text = "Fecha de ingreso:"
        '
        'ModUser_txtFijo
        '
        Me.ModUser_txtFijo.BackColor = System.Drawing.Color.White
        Me.ModUser_txtFijo.Enabled = False
        Me.ModUser_txtFijo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtFijo.ForeColor = System.Drawing.Color.White
        Me.ModUser_txtFijo.Location = New System.Drawing.Point(223, 433)
        Me.ModUser_txtFijo.MaxLength = 8
        Me.ModUser_txtFijo.Name = "ModUser_txtFijo"
        Me.ModUser_txtFijo.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtFijo.TabIndex = 109
        '
        'ModUser_txtCelular
        '
        Me.ModUser_txtCelular.BackColor = System.Drawing.Color.White
        Me.ModUser_txtCelular.Enabled = False
        Me.ModUser_txtCelular.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtCelular.ForeColor = System.Drawing.Color.White
        Me.ModUser_txtCelular.Location = New System.Drawing.Point(223, 398)
        Me.ModUser_txtCelular.MaxLength = 8
        Me.ModUser_txtCelular.Name = "ModUser_txtCelular"
        Me.ModUser_txtCelular.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtCelular.TabIndex = 108
        '
        'ModUser_txtHijos
        '
        Me.ModUser_txtHijos.BackColor = System.Drawing.Color.White
        Me.ModUser_txtHijos.Enabled = False
        Me.ModUser_txtHijos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtHijos.ForeColor = System.Drawing.Color.White
        Me.ModUser_txtHijos.Location = New System.Drawing.Point(223, 369)
        Me.ModUser_txtHijos.Name = "ModUser_txtHijos"
        Me.ModUser_txtHijos.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtHijos.TabIndex = 107
        '
        'ModUser_txtEmail
        '
        Me.ModUser_txtEmail.BackColor = System.Drawing.Color.White
        Me.ModUser_txtEmail.Enabled = False
        Me.ModUser_txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtEmail.ForeColor = System.Drawing.Color.White
        Me.ModUser_txtEmail.Location = New System.Drawing.Point(223, 340)
        Me.ModUser_txtEmail.Name = "ModUser_txtEmail"
        Me.ModUser_txtEmail.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtEmail.TabIndex = 106
        '
        'ModUser_txtContraseña
        '
        Me.ModUser_txtContraseña.BackColor = System.Drawing.Color.White
        Me.ModUser_txtContraseña.Enabled = False
        Me.ModUser_txtContraseña.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtContraseña.Location = New System.Drawing.Point(223, 195)
        Me.ModUser_txtContraseña.Name = "ModUser_txtContraseña"
        Me.ModUser_txtContraseña.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtContraseña.TabIndex = 126
        Me.ModUser_txtContraseña.Text = "12345678"
        '
        'ModUser_txtApellido
        '
        Me.ModUser_txtApellido.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtApellido.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ModUser_txtApellido.Location = New System.Drawing.Point(223, 166)
        Me.ModUser_txtApellido.Name = "ModUser_txtApellido"
        Me.ModUser_txtApellido.Size = New System.Drawing.Size(65, 20)
        Me.ModUser_txtApellido.TabIndex = 99
        Me.ModUser_txtApellido.Visible = False
        '
        'ModUser_txtNombre
        '
        Me.ModUser_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtNombre.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ModUser_txtNombre.Location = New System.Drawing.Point(223, 137)
        Me.ModUser_txtNombre.Name = "ModUser_txtNombre"
        Me.ModUser_txtNombre.Size = New System.Drawing.Size(65, 20)
        Me.ModUser_txtNombre.TabIndex = 96
        Me.ModUser_txtNombre.Visible = False
        '
        'AddUser_lblFijo
        '
        Me.AddUser_lblFijo.AutoSize = True
        Me.AddUser_lblFijo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!)
        Me.AddUser_lblFijo.Location = New System.Drawing.Point(62, 435)
        Me.AddUser_lblFijo.Name = "AddUser_lblFijo"
        Me.AddUser_lblFijo.Size = New System.Drawing.Size(79, 17)
        Me.AddUser_lblFijo.TabIndex = 125
        Me.AddUser_lblFijo.Text = "Teléfono fijo:"
        '
        'AddUser_lblCelular
        '
        Me.AddUser_lblCelular.AutoSize = True
        Me.AddUser_lblCelular.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblCelular.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblCelular.Location = New System.Drawing.Point(61, 400)
        Me.AddUser_lblCelular.Name = "AddUser_lblCelular"
        Me.AddUser_lblCelular.Size = New System.Drawing.Size(99, 17)
        Me.AddUser_lblCelular.TabIndex = 124
        Me.AddUser_lblCelular.Text = "Teléfono celular:"
        '
        'AddUser_lblEmail
        '
        Me.AddUser_lblEmail.AutoSize = True
        Me.AddUser_lblEmail.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblEmail.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblEmail.Location = New System.Drawing.Point(61, 342)
        Me.AddUser_lblEmail.Name = "AddUser_lblEmail"
        Me.AddUser_lblEmail.Size = New System.Drawing.Size(42, 17)
        Me.AddUser_lblEmail.TabIndex = 123
        Me.AddUser_lblEmail.Text = "Email:"
        '
        'AddUser_lblEstCivil
        '
        Me.AddUser_lblEstCivil.AutoSize = True
        Me.AddUser_lblEstCivil.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblEstCivil.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblEstCivil.Location = New System.Drawing.Point(61, 313)
        Me.AddUser_lblEstCivil.Name = "AddUser_lblEstCivil"
        Me.AddUser_lblEstCivil.Size = New System.Drawing.Size(75, 17)
        Me.AddUser_lblEstCivil.TabIndex = 122
        Me.AddUser_lblEstCivil.Text = "Estado Civil:"
        '
        'AddUser_lblDireccion
        '
        Me.AddUser_lblDireccion.AutoSize = True
        Me.AddUser_lblDireccion.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblDireccion.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblDireccion.Location = New System.Drawing.Point(61, 284)
        Me.AddUser_lblDireccion.Name = "AddUser_lblDireccion"
        Me.AddUser_lblDireccion.Size = New System.Drawing.Size(63, 17)
        Me.AddUser_lblDireccion.TabIndex = 121
        Me.AddUser_lblDireccion.Text = "Dirección:"
        '
        'AddUser_lblFNacimiento
        '
        Me.AddUser_lblFNacimiento.AutoSize = True
        Me.AddUser_lblFNacimiento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblFNacimiento.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblFNacimiento.Location = New System.Drawing.Point(61, 255)
        Me.AddUser_lblFNacimiento.Name = "AddUser_lblFNacimiento"
        Me.AddUser_lblFNacimiento.Size = New System.Drawing.Size(127, 17)
        Me.AddUser_lblFNacimiento.TabIndex = 120
        Me.AddUser_lblFNacimiento.Text = "Fecha de nacimiento:"
        '
        'AddUser_lblContraseña
        '
        Me.AddUser_lblContraseña.AutoSize = True
        Me.AddUser_lblContraseña.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblContraseña.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblContraseña.Location = New System.Drawing.Point(61, 197)
        Me.AddUser_lblContraseña.Name = "AddUser_lblContraseña"
        Me.AddUser_lblContraseña.Size = New System.Drawing.Size(75, 17)
        Me.AddUser_lblContraseña.TabIndex = 119
        Me.AddUser_lblContraseña.Text = "Contraseña:"
        '
        'AddUser_lblApellido
        '
        Me.AddUser_lblApellido.AutoSize = True
        Me.AddUser_lblApellido.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblApellido.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblApellido.Location = New System.Drawing.Point(61, 168)
        Me.AddUser_lblApellido.Name = "AddUser_lblApellido"
        Me.AddUser_lblApellido.Size = New System.Drawing.Size(62, 17)
        Me.AddUser_lblApellido.TabIndex = 118
        Me.AddUser_lblApellido.Text = "Apellidos:"
        '
        'AddUser_lblNombre
        '
        Me.AddUser_lblNombre.AutoSize = True
        Me.AddUser_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblNombre.Location = New System.Drawing.Point(61, 139)
        Me.AddUser_lblNombre.Name = "AddUser_lblNombre"
        Me.AddUser_lblNombre.Size = New System.Drawing.Size(61, 17)
        Me.AddUser_lblNombre.TabIndex = 117
        Me.AddUser_lblNombre.Text = "Nombres:"
        '
        'ModUser_txtDocumento
        '
        Me.ModUser_txtDocumento.BackColor = System.Drawing.Color.White
        Me.ModUser_txtDocumento.Enabled = False
        Me.ModUser_txtDocumento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModUser_txtDocumento.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ModUser_txtDocumento.Location = New System.Drawing.Point(223, 105)
        Me.ModUser_txtDocumento.MaxLength = 8
        Me.ModUser_txtDocumento.Name = "ModUser_txtDocumento"
        Me.ModUser_txtDocumento.Size = New System.Drawing.Size(132, 20)
        Me.ModUser_txtDocumento.TabIndex = 95
        '
        'AddUser_lblDocumento
        '
        Me.AddUser_lblDocumento.AutoSize = True
        Me.AddUser_lblDocumento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUser_lblDocumento.ForeColor = System.Drawing.Color.Black
        Me.AddUser_lblDocumento.Location = New System.Drawing.Point(61, 107)
        Me.AddUser_lblDocumento.Name = "AddUser_lblDocumento"
        Me.AddUser_lblDocumento.Size = New System.Drawing.Size(76, 17)
        Me.AddUser_lblDocumento.TabIndex = 98
        Me.AddUser_lblDocumento.Text = "Documento:"
        '
        'List_btnBuscar
        '
        Me.List_btnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.List_btnBuscar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.List_btnBuscar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(143, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.List_btnBuscar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(143, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.List_btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.List_btnBuscar.ForeColor = System.Drawing.Color.White
        Me.List_btnBuscar.Location = New System.Drawing.Point(58, 69)
        Me.List_btnBuscar.Name = "List_btnBuscar"
        Me.List_btnBuscar.Size = New System.Drawing.Size(79, 23)
        Me.List_btnBuscar.TabIndex = 2
        Me.List_btnBuscar.Text = "BUSCAR"
        Me.List_btnBuscar.UseVisualStyleBackColor = False
        '
        'List_txtBuscar
        '
        Me.List_txtBuscar.ForeColor = System.Drawing.Color.LightGray
        Me.List_txtBuscar.Location = New System.Drawing.Point(18, 43)
        Me.List_txtBuscar.Name = "List_txtBuscar"
        Me.List_txtBuscar.Size = New System.Drawing.Size(158, 20)
        Me.List_txtBuscar.TabIndex = 0
        Me.List_txtBuscar.Text = "Busque por documento"
        '
        'pnlDer
        '
        Me.pnlDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlDer.Location = New System.Drawing.Point(798, 0)
        Me.pnlDer.Name = "pnlDer"
        Me.pnlDer.Size = New System.Drawing.Size(20, 443)
        Me.pnlDer.TabIndex = 0
        '
        'pnlSup
        '
        Me.pnlSup.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlSup.Location = New System.Drawing.Point(0, 0)
        Me.pnlSup.Name = "pnlSup"
        Me.pnlSup.Size = New System.Drawing.Size(798, 20)
        Me.pnlSup.TabIndex = 1
        '
        'pnlIzq
        '
        Me.pnlIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlIzq.Location = New System.Drawing.Point(0, 20)
        Me.pnlIzq.Name = "pnlIzq"
        Me.pnlIzq.Size = New System.Drawing.Size(20, 423)
        Me.pnlIzq.TabIndex = 2
        '
        'pnlInf
        '
        Me.pnlInf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlInf.Location = New System.Drawing.Point(20, 423)
        Me.pnlInf.Name = "pnlInf"
        Me.pnlInf.Size = New System.Drawing.Size(778, 20)
        Me.pnlInf.TabIndex = 3
        '
        'pnlCentral
        '
        Me.pnlCentral.BackColor = System.Drawing.Color.White
        Me.pnlCentral.Controls.Add(Me.pnlBarra)
        Me.pnlCentral.Controls.Add(Me.TabControlAgregarMod)
        Me.pnlCentral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlCentral.Location = New System.Drawing.Point(20, 20)
        Me.pnlCentral.Name = "pnlCentral"
        Me.pnlCentral.Size = New System.Drawing.Size(778, 403)
        Me.pnlCentral.TabIndex = 4
        '
        'pnlBarra
        '
        Me.pnlBarra.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBarra.Location = New System.Drawing.Point(0, 0)
        Me.pnlBarra.Name = "pnlBarra"
        Me.pnlBarra.Size = New System.Drawing.Size(778, 60)
        Me.pnlBarra.TabIndex = 1
        '
        'TabControlAgregarMod
        '
        Me.TabControlAgregarMod.Controls.Add(TabPageListar)
        Me.TabControlAgregarMod.Controls.Add(Me.TabPageAgregar)
        Me.TabControlAgregarMod.Location = New System.Drawing.Point(6, 24)
        Me.TabControlAgregarMod.Name = "TabControlAgregarMod"
        Me.TabControlAgregarMod.SelectedIndex = 0
        Me.TabControlAgregarMod.Size = New System.Drawing.Size(769, 376)
        Me.TabControlAgregarMod.TabIndex = 0
        '
        'TabPageAgregar
        '
        Me.TabPageAgregar.Location = New System.Drawing.Point(4, 22)
        Me.TabPageAgregar.Name = "TabPageAgregar"
        Me.TabPageAgregar.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageAgregar.Size = New System.Drawing.Size(761, 350)
        Me.TabPageAgregar.TabIndex = 1
        Me.TabPageAgregar.Text = "TabPage2"
        Me.TabPageAgregar.UseVisualStyleBackColor = True
        '
        'ListUser_btnCancelar
        '
        Me.ListUser_btnCancelar.FlatAppearance.BorderSize = 0
        Me.ListUser_btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ListUser_btnCancelar.Image = Global.TAX.My.Resources.Resources.close
        Me.ListUser_btnCancelar.Location = New System.Drawing.Point(291, 39)
        Me.ListUser_btnCancelar.Name = "ListUser_btnCancelar"
        Me.ListUser_btnCancelar.Size = New System.Drawing.Size(32, 32)
        Me.ListUser_btnCancelar.TabIndex = 158
        Me.ListUser_btnCancelar.UseVisualStyleBackColor = True
        Me.ListUser_btnCancelar.Visible = False
        '
        'ListUser_btnGuardar
        '
        Me.ListUser_btnGuardar.FlatAppearance.BorderSize = 0
        Me.ListUser_btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ListUser_btnGuardar.Image = Global.TAX.My.Resources.Resources.save
        Me.ListUser_btnGuardar.Location = New System.Drawing.Point(232, 39)
        Me.ListUser_btnGuardar.Name = "ListUser_btnGuardar"
        Me.ListUser_btnGuardar.Size = New System.Drawing.Size(32, 32)
        Me.ListUser_btnGuardar.TabIndex = 157
        Me.ListUser_btnGuardar.UseVisualStyleBackColor = True
        Me.ListUser_btnGuardar.Visible = False
        '
        'ListUser_btnEliminar
        '
        Me.ListUser_btnEliminar.FlatAppearance.BorderSize = 0
        Me.ListUser_btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ListUser_btnEliminar.Image = Global.TAX.My.Resources.Resources.delusers
        Me.ListUser_btnEliminar.Location = New System.Drawing.Point(291, 39)
        Me.ListUser_btnEliminar.Name = "ListUser_btnEliminar"
        Me.ListUser_btnEliminar.Size = New System.Drawing.Size(32, 32)
        Me.ListUser_btnEliminar.TabIndex = 155
        Me.ListUser_btnEliminar.UseVisualStyleBackColor = True
        Me.ListUser_btnEliminar.Visible = False
        '
        'ListUser_btnModificar
        '
        Me.ListUser_btnModificar.FlatAppearance.BorderSize = 0
        Me.ListUser_btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ListUser_btnModificar.Image = Global.TAX.My.Resources.Resources.update
        Me.ListUser_btnModificar.Location = New System.Drawing.Point(232, 39)
        Me.ListUser_btnModificar.Name = "ListUser_btnModificar"
        Me.ListUser_btnModificar.Size = New System.Drawing.Size(32, 32)
        Me.ListUser_btnModificar.TabIndex = 154
        Me.ListUser_btnModificar.UseVisualStyleBackColor = True
        Me.ListUser_btnModificar.Visible = False
        '
        'AddUser_pbFoto
        '
        Me.AddUser_pbFoto.Image = CType(resources.GetObject("AddUser_pbFoto.Image"), System.Drawing.Image)
        Me.AddUser_pbFoto.Location = New System.Drawing.Point(419, 42)
        Me.AddUser_pbFoto.Name = "AddUser_pbFoto"
        Me.AddUser_pbFoto.Size = New System.Drawing.Size(100, 94)
        Me.AddUser_pbFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.AddUser_pbFoto.TabIndex = 150
        Me.AddUser_pbFoto.TabStop = False
        '
        'List_btnLupa
        '
        Me.List_btnLupa.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.List_btnLupa.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer))
        Me.List_btnLupa.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.List_btnLupa.Image = Global.TAX.My.Resources.Resources.magnifying_glass
        Me.List_btnLupa.Location = New System.Drawing.Point(182, 42)
        Me.List_btnLupa.Name = "List_btnLupa"
        Me.List_btnLupa.Size = New System.Drawing.Size(22, 22)
        Me.List_btnLupa.TabIndex = 1
        Me.List_btnLupa.UseVisualStyleBackColor = False
        '
        'buscar_usuarios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(818, 443)
        Me.Controls.Add(Me.pnlCentral)
        Me.Controls.Add(Me.pnlInf)
        Me.Controls.Add(Me.pnlIzq)
        Me.Controls.Add(Me.pnlSup)
        Me.Controls.Add(Me.pnlDer)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "buscar_usuarios"
        Me.Text = "buscar_usuarios"
        TabPageListar.ResumeLayout(False)
        TabPageListar.PerformLayout()
        Me.pnlCentral.ResumeLayout(False)
        Me.TabControlAgregarMod.ResumeLayout(False)
        CType(Me.AddUser_pbFoto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlDer As System.Windows.Forms.Panel
    Friend WithEvents pnlSup As System.Windows.Forms.Panel
    Friend WithEvents pnlIzq As System.Windows.Forms.Panel
    Friend WithEvents pnlInf As System.Windows.Forms.Panel
    Friend WithEvents pnlCentral As System.Windows.Forms.Panel
    Friend WithEvents pnlBarra As System.Windows.Forms.Panel
    Friend WithEvents TabControlAgregarMod As System.Windows.Forms.TabControl
    Friend WithEvents List_btnBuscar As System.Windows.Forms.Button
    Friend WithEvents List_btnLupa As System.Windows.Forms.Button
    Friend WithEvents List_txtBuscar As System.Windows.Forms.TextBox
    Friend WithEvents TabPageAgregar As System.Windows.Forms.TabPage
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents AddUser_pbFoto As System.Windows.Forms.PictureBox
    Friend WithEvents ModUser_cbGrado As System.Windows.Forms.ComboBox
    Friend WithEvents ADD_ObligTipoUsuario As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligEmailEmpr As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligTelfEmpresarial As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligDepartamento As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligGrado As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligCargo As System.Windows.Forms.Label
    Friend WithEvents ADD_FIngreso As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligEmail As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligEstCivil As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligDirNumero As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligDirCalle As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligFNac As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligSexo As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligApellido As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligNombre As System.Windows.Forms.Label
    Friend WithEvents ADD_ObligDocumento As System.Windows.Forms.Label
    Friend WithEvents ModUser_txt2apellido As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txt2Nombre As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtDirCalle As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtDirNumero As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_cbEstCivil As System.Windows.Forms.ComboBox
    Friend WithEvents ModUser_cbSexo As System.Windows.Forms.ComboBox
    Friend WithEvents ModUser_dateFIngreso As System.Windows.Forms.DateTimePicker
    Friend WithEvents ModUser_dateFNacimiento As System.Windows.Forms.DateTimePicker
    Friend WithEvents ListUser_rbAdmin As System.Windows.Forms.RadioButton
    Friend WithEvents ListUser_rbUsuario As System.Windows.Forms.RadioButton
    Friend WithEvents ModUser_txtMailEmpresarial As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtTlfEmpresarial As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtDepartamento As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtCargo As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_lblEmailEmpresarial As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblTelfEmpresarial As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblDepartamento As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblGrado As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblCargo As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblFIngreso As System.Windows.Forms.Label
    Friend WithEvents ModUser_txtFijo As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtCelular As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtHijos As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtContraseña As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtApellido As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_lblFijo As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblCelular As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblEmail As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblEstCivil As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblDireccion As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblFNacimiento As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblContraseña As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblApellido As System.Windows.Forms.Label
    Friend WithEvents AddUser_lblNombre As System.Windows.Forms.Label
    Friend WithEvents ModUser_txtDocumento As System.Windows.Forms.TextBox
    Friend WithEvents AddUser_lblDocumento As System.Windows.Forms.Label
    Friend WithEvents ModUser_txtNombreCompleto As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtApellidosCompleto As System.Windows.Forms.TextBox
    Friend WithEvents ModUser_txtDireccionCompleta As System.Windows.Forms.TextBox
    Friend WithEvents ListUser_btnEliminar As System.Windows.Forms.Button
    Friend WithEvents ListUser_btnModificar As System.Windows.Forms.Button
    Friend WithEvents ListUser_btnCancelar As System.Windows.Forms.Button
    Friend WithEvents ListUser_btnGuardar As System.Windows.Forms.Button
End Class
