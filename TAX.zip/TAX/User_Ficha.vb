﻿Imports MySql.Data.MySqlClient

Public Class User_Ficha
    Dim dt As New DataTable
    Dim cnn As New MySqlConnection
    Dim sql As String
    Private Sub btnficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnficha.Click
        tabcontrolficha.SelectedTab = tabpageficha
        btnficha.ForeColor = Color.FromArgb(255, 94, 27, 168)
        btnficha.Image = My.Resources.ficha_violeta
        btnorganizacion.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnorganizacion.Image = My.Resources.enterprise_gris

        pnlSelection.Width = btnficha.Width
        pnlSelection.Location = New Point(btnficha.Location.X, pnlSelection.Location.Y)

    End Sub

    Private Sub btnorganizacion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnorganizacion.Click
        tabcontrolficha.SelectedTab = tabpageorganizacion
        btnficha.ForeColor = Color.FromArgb(255, 91, 91, 91)
        btnficha.Image = My.Resources.ficha_gris
        btnorganizacion.ForeColor = Color.FromArgb(255, 94, 27, 168)
        btnorganizacion.Image = My.Resources.enterprise_violeta
        pnlSelection.Width = btnorganizacion.Width
        pnlSelection.Location = New Point(btnorganizacion.Location.X, pnlSelection.Location.Y)

        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM empresa"
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.ORG_txtRUT.Text = rdr.Item("RUT").ToString
            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub


    
    Private Sub User_Ficha_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Dock = DockStyle.Fill
        tabcontrolficha.Dock = DockStyle.Fill
        FICHA_txtContraseña.UseSystemPasswordChar = True

        Dim cnn As New MySqlConnection
        cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
        Dim rdr As MySqlDataReader

        Try
            cnn.Open()
            Dim Query As String
            Query = "SELECT * FROM personal WHERE doc = '" & Module1.document & "' "
            Dim cmd As New MySqlCommand(Query, cnn)
            rdr = cmd.ExecuteReader
            While rdr.Read
                Me.FICHA_txtDocumento.Text = rdr.Item("doc").ToString
                Me.FICHA_txtNombre.Text = rdr.Item("nombre").ToString
                Me.FICHA_txtApellido.Text = rdr.Item("apellido").ToString
                Me.FICHA_txtContraseña.Text = rdr.Item("passwd").ToString
                Me.FICHA_txtSexo.Text = rdr.Item("sexo").ToString
                Me.FICHA_txtFNacimiento.Text = rdr.Item("f_nac").ToString
                Me.FICHA_txtCalle.Text = rdr.Item("calle").ToString
                Me.FICHA_txtDirNumero.Text = rdr.Item("numero").ToString
                Me.FICHA_txtEstCivil.Text = rdr.Item("estado_civil").ToString
                Me.FICHA_txtEmail.Text = rdr.Item("email").ToString
                Me.ORG_txtNRegistro.Text = rdr.Item("persona_id").ToString
                Me.ORG_txtFIngreso.Text = rdr.Item("f_ingreso").ToString
                Me.ORG_txtCargo.Text = rdr.Item("cargo").ToString
                Me.ORG_txtGrado.Text = rdr.Item("grado").ToString
                Me.ORG_txtDepartamento.Text = rdr.Item("dpto").ToString
                Me.ORG_txtTlfEmpresarial.Text = rdr.Item("tlf_empr").ToString
                Me.ORG_txtMailEmpresarial.Text = rdr.Item("email_empr").ToString

            End While
            cnn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FICHA_btnCambioContraseña.Click
        User_CambioContraseña.Show()
    End Sub
End Class