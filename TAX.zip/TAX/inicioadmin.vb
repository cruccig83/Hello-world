﻿Public Class inicioadmin

    Private Sub cmdficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdficha.Click
        ficharoja.Show()
        Me.Close()

    End Sub

    Private Sub cmdfichachica_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdfichachica.Click
        ficharoja.Show()
        Me.Close()
    End Sub

    Private Sub cmdempleados_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdempleados.Click
        empleados.Show()
        Me.Close()

    End Sub

    Private Sub cmdsueldos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdsueldos.Click
        sueldos.Show()
        Me.Close()

    End Sub

    Private Sub cmdsueldogrande_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdsueldogrande.Click
        sueldos.Show()
        Me.Close()

    End Sub

    Private Sub cmdempleadogrande_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdempleadogrande.Click
        empleados.Show()
        Me.Close()

    End Sub

    Private Sub cmdrecibo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdrecibo.Click
        mireciboadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdayuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdayuda.Click
        MsgBox("En Progreso")
    End Sub
End Class