﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class sueldos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(sueldos))
        Me.txtcedula = New System.Windows.Forms.TextBox
        Me.lbcedulas = New System.Windows.Forms.ListBox
        Me.txthorasextras = New System.Windows.Forms.TextBox
        Me.txtnocturnas = New System.Windows.Forms.TextBox
        Me.txtferiados = New System.Windows.Forms.TextBox
        Me.txtaguinaldos = New System.Windows.Forms.TextBox
        Me.txttickets = New System.Windows.Forms.TextBox
        Me.txtlicencia = New System.Windows.Forms.TextBox
        Me.cmdliquidar = New System.Windows.Forms.Button
        Me.cmdempleados = New System.Windows.Forms.Button
        Me.cmdrecibo = New System.Windows.Forms.Button
        Me.cmdinicio = New System.Windows.Forms.Button
        Me.cmdficha = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtfaltas = New System.Windows.Forms.TextBox
        Me.txtpresentismo = New System.Windows.Forms.TextBox
        Me.cmdayuda = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'txtcedula
        '
        Me.txtcedula.Location = New System.Drawing.Point(165, 206)
        Me.txtcedula.Name = "txtcedula"
        Me.txtcedula.Size = New System.Drawing.Size(207, 20)
        Me.txtcedula.TabIndex = 0
        '
        'lbcedulas
        '
        Me.lbcedulas.FormattingEnabled = True
        Me.lbcedulas.Location = New System.Drawing.Point(165, 238)
        Me.lbcedulas.Name = "lbcedulas"
        Me.lbcedulas.Size = New System.Drawing.Size(206, 212)
        Me.lbcedulas.TabIndex = 1
        '
        'txthorasextras
        '
        Me.txthorasextras.Location = New System.Drawing.Point(531, 168)
        Me.txthorasextras.Name = "txthorasextras"
        Me.txthorasextras.Size = New System.Drawing.Size(169, 20)
        Me.txthorasextras.TabIndex = 2
        '
        'txtnocturnas
        '
        Me.txtnocturnas.Location = New System.Drawing.Point(547, 213)
        Me.txtnocturnas.Name = "txtnocturnas"
        Me.txtnocturnas.Size = New System.Drawing.Size(169, 20)
        Me.txtnocturnas.TabIndex = 3
        '
        'txtferiados
        '
        Me.txtferiados.Location = New System.Drawing.Point(541, 254)
        Me.txtferiados.Name = "txtferiados"
        Me.txtferiados.Size = New System.Drawing.Size(169, 20)
        Me.txtferiados.TabIndex = 4
        '
        'txtaguinaldos
        '
        Me.txtaguinaldos.Location = New System.Drawing.Point(521, 297)
        Me.txtaguinaldos.Name = "txtaguinaldos"
        Me.txtaguinaldos.Size = New System.Drawing.Size(169, 20)
        Me.txtaguinaldos.TabIndex = 5
        '
        'txttickets
        '
        Me.txttickets.Location = New System.Drawing.Point(561, 332)
        Me.txttickets.Name = "txttickets"
        Me.txttickets.Size = New System.Drawing.Size(169, 20)
        Me.txttickets.TabIndex = 6
        '
        'txtlicencia
        '
        Me.txtlicencia.Location = New System.Drawing.Point(504, 371)
        Me.txtlicencia.Name = "txtlicencia"
        Me.txtlicencia.Size = New System.Drawing.Size(169, 20)
        Me.txtlicencia.TabIndex = 7
        '
        'cmdliquidar
        '
        Me.cmdliquidar.Location = New System.Drawing.Point(661, 437)
        Me.cmdliquidar.Name = "cmdliquidar"
        Me.cmdliquidar.Size = New System.Drawing.Size(69, 32)
        Me.cmdliquidar.TabIndex = 8
        Me.cmdliquidar.Text = "LIQUIDAR"
        Me.cmdliquidar.UseVisualStyleBackColor = True
        '
        'cmdempleados
        '
        Me.cmdempleados.BackColor = System.Drawing.Color.Transparent
        Me.cmdempleados.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdempleados.Location = New System.Drawing.Point(12, 260)
        Me.cmdempleados.Name = "cmdempleados"
        Me.cmdempleados.Size = New System.Drawing.Size(123, 31)
        Me.cmdempleados.TabIndex = 73
        Me.cmdempleados.UseVisualStyleBackColor = False
        '
        'cmdrecibo
        '
        Me.cmdrecibo.BackColor = System.Drawing.Color.Transparent
        Me.cmdrecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdrecibo.Location = New System.Drawing.Point(21, 218)
        Me.cmdrecibo.Name = "cmdrecibo"
        Me.cmdrecibo.Size = New System.Drawing.Size(123, 31)
        Me.cmdrecibo.TabIndex = 72
        Me.cmdrecibo.UseVisualStyleBackColor = False
        '
        'cmdinicio
        '
        Me.cmdinicio.BackColor = System.Drawing.Color.Transparent
        Me.cmdinicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdinicio.Location = New System.Drawing.Point(21, 145)
        Me.cmdinicio.Name = "cmdinicio"
        Me.cmdinicio.Size = New System.Drawing.Size(123, 30)
        Me.cmdinicio.TabIndex = 71
        Me.cmdinicio.UseVisualStyleBackColor = False
        '
        'cmdficha
        '
        Me.cmdficha.BackColor = System.Drawing.Color.Transparent
        Me.cmdficha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdficha.Location = New System.Drawing.Point(21, 181)
        Me.cmdficha.Name = "cmdficha"
        Me.cmdficha.Size = New System.Drawing.Size(123, 31)
        Me.cmdficha.TabIndex = 70
        Me.cmdficha.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(442, 401)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 74
        Me.Label1.Text = "FALTAS"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(442, 437)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 13)
        Me.Label2.TabIndex = 75
        Me.Label2.Text = "PRESENTISMO "
        '
        'txtfaltas
        '
        Me.txtfaltas.Location = New System.Drawing.Point(493, 399)
        Me.txtfaltas.Name = "txtfaltas"
        Me.txtfaltas.Size = New System.Drawing.Size(169, 20)
        Me.txtfaltas.TabIndex = 76
        '
        'txtpresentismo
        '
        Me.txtpresentismo.Location = New System.Drawing.Point(531, 434)
        Me.txtpresentismo.Name = "txtpresentismo"
        Me.txtpresentismo.Size = New System.Drawing.Size(87, 20)
        Me.txtpresentismo.TabIndex = 77
        '
        'cmdayuda
        '
        Me.cmdayuda.BackColor = System.Drawing.Color.Transparent
        Me.cmdayuda.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdayuda.Location = New System.Drawing.Point(661, 69)
        Me.cmdayuda.Name = "cmdayuda"
        Me.cmdayuda.Size = New System.Drawing.Size(93, 30)
        Me.cmdayuda.TabIndex = 78
        Me.cmdayuda.UseVisualStyleBackColor = False
        '
        'sueldos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(766, 551)
        Me.Controls.Add(Me.cmdayuda)
        Me.Controls.Add(Me.txtpresentismo)
        Me.Controls.Add(Me.txtfaltas)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmdempleados)
        Me.Controls.Add(Me.cmdrecibo)
        Me.Controls.Add(Me.cmdinicio)
        Me.Controls.Add(Me.cmdficha)
        Me.Controls.Add(Me.cmdliquidar)
        Me.Controls.Add(Me.txtlicencia)
        Me.Controls.Add(Me.txttickets)
        Me.Controls.Add(Me.txtaguinaldos)
        Me.Controls.Add(Me.txtferiados)
        Me.Controls.Add(Me.txtnocturnas)
        Me.Controls.Add(Me.txthorasextras)
        Me.Controls.Add(Me.lbcedulas)
        Me.Controls.Add(Me.txtcedula)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "sueldos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtcedula As System.Windows.Forms.TextBox
    Friend WithEvents lbcedulas As System.Windows.Forms.ListBox
    Friend WithEvents txthorasextras As System.Windows.Forms.TextBox
    Friend WithEvents txtnocturnas As System.Windows.Forms.TextBox
    Friend WithEvents txtferiados As System.Windows.Forms.TextBox
    Friend WithEvents txtaguinaldos As System.Windows.Forms.TextBox
    Friend WithEvents txttickets As System.Windows.Forms.TextBox
    Friend WithEvents txtlicencia As System.Windows.Forms.TextBox
    Friend WithEvents cmdliquidar As System.Windows.Forms.Button
    Friend WithEvents cmdempleados As System.Windows.Forms.Button
    Friend WithEvents cmdrecibo As System.Windows.Forms.Button
    Friend WithEvents cmdinicio As System.Windows.Forms.Button
    Friend WithEvents cmdficha As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtfaltas As System.Windows.Forms.TextBox
    Friend WithEvents txtpresentismo As System.Windows.Forms.TextBox
    Friend WithEvents cmdayuda As System.Windows.Forms.Button
End Class
