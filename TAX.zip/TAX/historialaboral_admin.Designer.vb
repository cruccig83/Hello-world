﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class historialaboral_admin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(historialaboral_admin))
        Me.cmdliquidar = New System.Windows.Forms.Button
        Me.cmdempleados = New System.Windows.Forms.Button
        Me.cmdrecibo = New System.Windows.Forms.Button
        Me.cmdinicio = New System.Windows.Forms.Button
        Me.cmdorganizacion = New System.Windows.Forms.Button
        Me.cmdhistorialrecibos = New System.Windows.Forms.Button
        Me.cmdficha = New System.Windows.Forms.Button
        Me.cmdayuda = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cmdliquidar
        '
        Me.cmdliquidar.BackColor = System.Drawing.Color.Transparent
        Me.cmdliquidar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdliquidar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdliquidar.Location = New System.Drawing.Point(9, 301)
        Me.cmdliquidar.Name = "cmdliquidar"
        Me.cmdliquidar.Size = New System.Drawing.Size(123, 31)
        Me.cmdliquidar.TabIndex = 19
        Me.cmdliquidar.UseVisualStyleBackColor = False
        '
        'cmdempleados
        '
        Me.cmdempleados.BackColor = System.Drawing.Color.Transparent
        Me.cmdempleados.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdempleados.Location = New System.Drawing.Point(12, 259)
        Me.cmdempleados.Name = "cmdempleados"
        Me.cmdempleados.Size = New System.Drawing.Size(123, 31)
        Me.cmdempleados.TabIndex = 18
        Me.cmdempleados.UseVisualStyleBackColor = False
        '
        'cmdrecibo
        '
        Me.cmdrecibo.BackColor = System.Drawing.Color.Transparent
        Me.cmdrecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdrecibo.Location = New System.Drawing.Point(12, 218)
        Me.cmdrecibo.Name = "cmdrecibo"
        Me.cmdrecibo.Size = New System.Drawing.Size(123, 31)
        Me.cmdrecibo.TabIndex = 17
        Me.cmdrecibo.UseVisualStyleBackColor = False
        '
        'cmdinicio
        '
        Me.cmdinicio.BackColor = System.Drawing.Color.Transparent
        Me.cmdinicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdinicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdinicio.Location = New System.Drawing.Point(12, 141)
        Me.cmdinicio.Name = "cmdinicio"
        Me.cmdinicio.Size = New System.Drawing.Size(123, 30)
        Me.cmdinicio.TabIndex = 16
        Me.cmdinicio.UseVisualStyleBackColor = False
        '
        'cmdorganizacion
        '
        Me.cmdorganizacion.BackColor = System.Drawing.Color.Transparent
        Me.cmdorganizacion.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdorganizacion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdorganizacion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdorganizacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdorganizacion.Location = New System.Drawing.Point(368, 151)
        Me.cmdorganizacion.Name = "cmdorganizacion"
        Me.cmdorganizacion.Size = New System.Drawing.Size(60, 50)
        Me.cmdorganizacion.TabIndex = 22
        Me.cmdorganizacion.UseVisualStyleBackColor = False
        '
        'cmdhistorialrecibos
        '
        Me.cmdhistorialrecibos.BackColor = System.Drawing.Color.Transparent
        Me.cmdhistorialrecibos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdhistorialrecibos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdhistorialrecibos.Location = New System.Drawing.Point(297, 151)
        Me.cmdhistorialrecibos.Name = "cmdhistorialrecibos"
        Me.cmdhistorialrecibos.Size = New System.Drawing.Size(54, 50)
        Me.cmdhistorialrecibos.TabIndex = 21
        Me.cmdhistorialrecibos.UseVisualStyleBackColor = False
        '
        'cmdficha
        '
        Me.cmdficha.BackColor = System.Drawing.Color.Transparent
        Me.cmdficha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdficha.Location = New System.Drawing.Point(150, 148)
        Me.cmdficha.Name = "cmdficha"
        Me.cmdficha.Size = New System.Drawing.Size(56, 50)
        Me.cmdficha.TabIndex = 20
        Me.cmdficha.UseVisualStyleBackColor = False
        '
        'cmdayuda
        '
        Me.cmdayuda.BackColor = System.Drawing.Color.Transparent
        Me.cmdayuda.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdayuda.Location = New System.Drawing.Point(658, 65)
        Me.cmdayuda.Name = "cmdayuda"
        Me.cmdayuda.Size = New System.Drawing.Size(93, 30)
        Me.cmdayuda.TabIndex = 79
        Me.cmdayuda.UseVisualStyleBackColor = False
        '
        'historialaboral_admin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(776, 560)
        Me.Controls.Add(Me.cmdayuda)
        Me.Controls.Add(Me.cmdorganizacion)
        Me.Controls.Add(Me.cmdhistorialrecibos)
        Me.Controls.Add(Me.cmdficha)
        Me.Controls.Add(Me.cmdliquidar)
        Me.Controls.Add(Me.cmdempleados)
        Me.Controls.Add(Me.cmdrecibo)
        Me.Controls.Add(Me.cmdinicio)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "historialaboral_admin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdliquidar As System.Windows.Forms.Button
    Friend WithEvents cmdempleados As System.Windows.Forms.Button
    Friend WithEvents cmdrecibo As System.Windows.Forms.Button
    Friend WithEvents cmdinicio As System.Windows.Forms.Button
    Friend WithEvents cmdorganizacion As System.Windows.Forms.Button
    Friend WithEvents cmdhistorialrecibos As System.Windows.Forms.Button
    Friend WithEvents cmdficha As System.Windows.Forms.Button
    Friend WithEvents cmdayuda As System.Windows.Forms.Button
End Class
