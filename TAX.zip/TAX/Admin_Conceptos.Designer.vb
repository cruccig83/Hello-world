﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Conceptos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Conceptos))
        Me.pnlSup = New System.Windows.Forms.Panel
        Me.pnlDer = New System.Windows.Forms.Panel
        Me.pnlInf = New System.Windows.Forms.Panel
        Me.pnlIzq = New System.Windows.Forms.Panel
        Me.pnlCentral = New System.Windows.Forms.Panel
        Me.pnlBotones = New System.Windows.Forms.Panel
        Me.pnlSelection = New System.Windows.Forms.Panel
        Me.pnlBotonesGris = New System.Windows.Forms.Panel
        Me.TabControl_HaberesDescuentos = New System.Windows.Forms.TabControl
        Me.TabPage_Haberes = New System.Windows.Forms.TabPage
        Me.HAB_pnlBotones = New System.Windows.Forms.Panel
        Me.HAB_pnlSelection = New System.Windows.Forms.Panel
        Me.HAB_pnlGris = New System.Windows.Forms.Panel
        Me.HAB_btnEliminar = New System.Windows.Forms.Button
        Me.HAB_btnModificar = New System.Windows.Forms.Button
        Me.HAB_btnAgregar = New System.Windows.Forms.Button
        Me.HAB_btnVer = New System.Windows.Forms.Button
        Me.TabControl_MangeHaberes = New System.Windows.Forms.TabControl
        Me.HAB_TabPage_Ver = New System.Windows.Forms.TabPage
        Me.VerHAB_txtTipo = New System.Windows.Forms.TextBox
        Me.VerHAB_txtValor = New System.Windows.Forms.TextBox
        Me.VerHAB_txtNombre = New System.Windows.Forms.TextBox
        Me.VerHAB_txtId = New System.Windows.Forms.TextBox
        Me.VerHAB_lblTipo = New System.Windows.Forms.Label
        Me.VerHAB_lblValor = New System.Windows.Forms.Label
        Me.VerHAB_lblNombre = New System.Windows.Forms.Label
        Me.VerHAB_lblId = New System.Windows.Forms.Label
        Me.VerHAB_cbHaberes = New System.Windows.Forms.ComboBox
        Me.HAB_TabPage_Agregar = New System.Windows.Forms.TabPage
        Me.AddHAB_lblPorciento = New System.Windows.Forms.Label
        Me.AddHAB_lblPesos = New System.Windows.Forms.Label
        Me.AddHAB_btnAgregar = New System.Windows.Forms.Button
        Me.AddHAB_rbPorcentaje = New System.Windows.Forms.RadioButton
        Me.AddHAB_rbValorFijo = New System.Windows.Forms.RadioButton
        Me.AddHAB_txtValor = New System.Windows.Forms.TextBox
        Me.AddHAB_txtNombre = New System.Windows.Forms.TextBox
        Me.AddHAB_lblPorcentaje = New System.Windows.Forms.Label
        Me.AddHAB_lblValor = New System.Windows.Forms.Label
        Me.AddHAB_lblNombre = New System.Windows.Forms.Label
        Me.HAB_TabPage_Modificar = New System.Windows.Forms.TabPage
        Me.ModHAB_btnModificar = New System.Windows.Forms.Button
        Me.ModHAB_cbTipo = New System.Windows.Forms.ComboBox
        Me.ModHAB_txtValor = New System.Windows.Forms.TextBox
        Me.ModHAB_txtNombre = New System.Windows.Forms.TextBox
        Me.ModHAB_txtID = New System.Windows.Forms.TextBox
        Me.ModHAB_lblTipo = New System.Windows.Forms.Label
        Me.ModHAB_lblValor = New System.Windows.Forms.Label
        Me.ModHAB_lblNombre = New System.Windows.Forms.Label
        Me.ModHAB_lblId = New System.Windows.Forms.Label
        Me.ModHAB_cbHaberes = New System.Windows.Forms.ComboBox
        Me.HAB_TabPage_Eliminar = New System.Windows.Forms.TabPage
        Me.ElimHAB_txtTipo = New System.Windows.Forms.TextBox
        Me.ElimHAB_btnEliminar = New System.Windows.Forms.Button
        Me.ElimHAB_txtValor = New System.Windows.Forms.TextBox
        Me.ElimHAB_txtNombre = New System.Windows.Forms.TextBox
        Me.ElimHAB_txtId = New System.Windows.Forms.TextBox
        Me.ElimHAB_lblTipo = New System.Windows.Forms.Label
        Me.ElimHAB_lblValor = New System.Windows.Forms.Label
        Me.ElimHAB_lblNombre = New System.Windows.Forms.Label
        Me.ElimHAB_lblId = New System.Windows.Forms.Label
        Me.ElimHAB_cbHaberes = New System.Windows.Forms.ComboBox
        Me.TabPage_Descuentos = New System.Windows.Forms.TabPage
        Me.DESC_pnlBotones = New System.Windows.Forms.Panel
        Me.DESC_pnlSelection = New System.Windows.Forms.Panel
        Me.DESC_pnlGris = New System.Windows.Forms.Panel
        Me.DESC_btnEliminar = New System.Windows.Forms.Button
        Me.DESC_btnModificar = New System.Windows.Forms.Button
        Me.DESC_btnAgregar = New System.Windows.Forms.Button
        Me.DESC_btnVer = New System.Windows.Forms.Button
        Me.TabControl_ManageDescuentos = New System.Windows.Forms.TabControl
        Me.DESC_TabPageVer = New System.Windows.Forms.TabPage
        Me.VerDesc_txtTipo = New System.Windows.Forms.TextBox
        Me.VerDesc_txtValor = New System.Windows.Forms.TextBox
        Me.VerDesc_txtNombre = New System.Windows.Forms.TextBox
        Me.VerDesc_txtID = New System.Windows.Forms.TextBox
        Me.VerDesc_lblTipo = New System.Windows.Forms.Label
        Me.VerDesc_lblValor = New System.Windows.Forms.Label
        Me.VerDesc_lblNombre = New System.Windows.Forms.Label
        Me.VerDesc_lblID = New System.Windows.Forms.Label
        Me.VerDesc_cbDescuentos = New System.Windows.Forms.ComboBox
        Me.DESC_TabPageAgregar = New System.Windows.Forms.TabPage
        Me.AddDESC_lblPorciento = New System.Windows.Forms.Label
        Me.AddDESC_lblPesos = New System.Windows.Forms.Label
        Me.AddDESC_btnAgregar = New System.Windows.Forms.Button
        Me.AddDESC_rbPorcentaje = New System.Windows.Forms.RadioButton
        Me.AddDESC_rbValorFijo = New System.Windows.Forms.RadioButton
        Me.AddDESC_txtValor = New System.Windows.Forms.TextBox
        Me.AddDESC_txtNombre = New System.Windows.Forms.TextBox
        Me.AddDESC_lblPorcentaje = New System.Windows.Forms.Label
        Me.AddDESC_lblValor = New System.Windows.Forms.Label
        Me.AddDESC_lblNombre = New System.Windows.Forms.Label
        Me.DESC_TabPageModificar = New System.Windows.Forms.TabPage
        Me.ModDesc_btnAceptar = New System.Windows.Forms.Button
        Me.ModDesc_cbTipo = New System.Windows.Forms.ComboBox
        Me.ModDesc_txtValor = New System.Windows.Forms.TextBox
        Me.ModDesc_txtNombre = New System.Windows.Forms.TextBox
        Me.ModDesc_txtID = New System.Windows.Forms.TextBox
        Me.ModDesc_lblTipo = New System.Windows.Forms.Label
        Me.ModDesc_lblValor = New System.Windows.Forms.Label
        Me.ModDesc_lblNombre = New System.Windows.Forms.Label
        Me.ModDesc_lblID = New System.Windows.Forms.Label
        Me.ModDesc_cbDescuentos = New System.Windows.Forms.ComboBox
        Me.DESC_TabPageEliminar = New System.Windows.Forms.TabPage
        Me.ElimDESC_txtTipo = New System.Windows.Forms.TextBox
        Me.ElimDESC_btnEliminar = New System.Windows.Forms.Button
        Me.ElimDESC_txtValor = New System.Windows.Forms.TextBox
        Me.ElimDESC_txtNombre = New System.Windows.Forms.TextBox
        Me.ElimDESC_txtID = New System.Windows.Forms.TextBox
        Me.ElimDESC_lblTipo = New System.Windows.Forms.Label
        Me.ElimDESC_lblValor = New System.Windows.Forms.Label
        Me.ElimDESC_lblNombre = New System.Windows.Forms.Label
        Me.ElimDESC_lblID = New System.Windows.Forms.Label
        Me.ElimDESC_cbDescuentos = New System.Windows.Forms.ComboBox
        Me.TaxDataSet = New TAX.taxDataSet
        Me.TaxDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnDescuentos = New System.Windows.Forms.Button
        Me.btnHaberes = New System.Windows.Forms.Button
        Me.VerHAB_lblVerHaberes = New System.Windows.Forms.Button
        Me.AddHAB_lblAgregarHaber = New System.Windows.Forms.Button
        Me.AddHAB_lblModificarHaberes = New System.Windows.Forms.Button
        Me.ElimHAB_lblEliminarHaberes = New System.Windows.Forms.Button
        Me.VerDESC_lblVerDescuentos = New System.Windows.Forms.Button
        Me.inftrabajador = New System.Windows.Forms.Button
        Me.ModDESC_lblModificarDescuentos = New System.Windows.Forms.Button
        Me.ElimDESC_lblEliminarDescuentos = New System.Windows.Forms.Button
        Me.pnlCentral.SuspendLayout()
        Me.pnlBotones.SuspendLayout()
        Me.TabControl_HaberesDescuentos.SuspendLayout()
        Me.TabPage_Haberes.SuspendLayout()
        Me.HAB_pnlBotones.SuspendLayout()
        Me.TabControl_MangeHaberes.SuspendLayout()
        Me.HAB_TabPage_Ver.SuspendLayout()
        Me.HAB_TabPage_Agregar.SuspendLayout()
        Me.HAB_TabPage_Modificar.SuspendLayout()
        Me.HAB_TabPage_Eliminar.SuspendLayout()
        Me.TabPage_Descuentos.SuspendLayout()
        Me.DESC_pnlBotones.SuspendLayout()
        Me.TabControl_ManageDescuentos.SuspendLayout()
        Me.DESC_TabPageVer.SuspendLayout()
        Me.DESC_TabPageAgregar.SuspendLayout()
        Me.DESC_TabPageModificar.SuspendLayout()
        Me.DESC_TabPageEliminar.SuspendLayout()
        CType(Me.TaxDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TaxDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlSup
        '
        Me.pnlSup.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlSup.Location = New System.Drawing.Point(0, 0)
        Me.pnlSup.Name = "pnlSup"
        Me.pnlSup.Size = New System.Drawing.Size(818, 20)
        Me.pnlSup.TabIndex = 0
        '
        'pnlDer
        '
        Me.pnlDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlDer.Location = New System.Drawing.Point(798, 20)
        Me.pnlDer.Name = "pnlDer"
        Me.pnlDer.Size = New System.Drawing.Size(20, 422)
        Me.pnlDer.TabIndex = 1
        '
        'pnlInf
        '
        Me.pnlInf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlInf.Location = New System.Drawing.Point(0, 422)
        Me.pnlInf.Name = "pnlInf"
        Me.pnlInf.Size = New System.Drawing.Size(798, 20)
        Me.pnlInf.TabIndex = 2
        '
        'pnlIzq
        '
        Me.pnlIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlIzq.Location = New System.Drawing.Point(0, 20)
        Me.pnlIzq.Name = "pnlIzq"
        Me.pnlIzq.Size = New System.Drawing.Size(20, 402)
        Me.pnlIzq.TabIndex = 3
        '
        'pnlCentral
        '
        Me.pnlCentral.BackColor = System.Drawing.Color.White
        Me.pnlCentral.Controls.Add(Me.pnlBotones)
        Me.pnlCentral.Controls.Add(Me.TabControl_HaberesDescuentos)
        Me.pnlCentral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlCentral.Location = New System.Drawing.Point(20, 20)
        Me.pnlCentral.Name = "pnlCentral"
        Me.pnlCentral.Size = New System.Drawing.Size(778, 402)
        Me.pnlCentral.TabIndex = 4
        '
        'pnlBotones
        '
        Me.pnlBotones.Controls.Add(Me.pnlSelection)
        Me.pnlBotones.Controls.Add(Me.pnlBotonesGris)
        Me.pnlBotones.Controls.Add(Me.btnDescuentos)
        Me.pnlBotones.Controls.Add(Me.btnHaberes)
        Me.pnlBotones.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBotones.Location = New System.Drawing.Point(0, 0)
        Me.pnlBotones.Name = "pnlBotones"
        Me.pnlBotones.Size = New System.Drawing.Size(778, 62)
        Me.pnlBotones.TabIndex = 1
        '
        'pnlSelection
        '
        Me.pnlSelection.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.pnlSelection.Location = New System.Drawing.Point(0, 59)
        Me.pnlSelection.Name = "pnlSelection"
        Me.pnlSelection.Size = New System.Drawing.Size(102, 3)
        Me.pnlSelection.TabIndex = 2
        '
        'pnlBotonesGris
        '
        Me.pnlBotonesGris.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.pnlBotonesGris.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlBotonesGris.Location = New System.Drawing.Point(0, 59)
        Me.pnlBotonesGris.Name = "pnlBotonesGris"
        Me.pnlBotonesGris.Size = New System.Drawing.Size(778, 3)
        Me.pnlBotonesGris.TabIndex = 3
        '
        'TabControl_HaberesDescuentos
        '
        Me.TabControl_HaberesDescuentos.Controls.Add(Me.TabPage_Haberes)
        Me.TabControl_HaberesDescuentos.Controls.Add(Me.TabPage_Descuentos)
        Me.TabControl_HaberesDescuentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl_HaberesDescuentos.Location = New System.Drawing.Point(0, 0)
        Me.TabControl_HaberesDescuentos.Name = "TabControl_HaberesDescuentos"
        Me.TabControl_HaberesDescuentos.Padding = New System.Drawing.Point(6, 21)
        Me.TabControl_HaberesDescuentos.SelectedIndex = 0
        Me.TabControl_HaberesDescuentos.Size = New System.Drawing.Size(778, 402)
        Me.TabControl_HaberesDescuentos.TabIndex = 0
        '
        'TabPage_Haberes
        '
        Me.TabPage_Haberes.Controls.Add(Me.HAB_pnlBotones)
        Me.TabPage_Haberes.Controls.Add(Me.TabControl_MangeHaberes)
        Me.TabPage_Haberes.Location = New System.Drawing.Point(4, 58)
        Me.TabPage_Haberes.Name = "TabPage_Haberes"
        Me.TabPage_Haberes.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Haberes.Size = New System.Drawing.Size(770, 340)
        Me.TabPage_Haberes.TabIndex = 0
        Me.TabPage_Haberes.Text = "TabPage1"
        Me.TabPage_Haberes.UseVisualStyleBackColor = True
        '
        'HAB_pnlBotones
        '
        Me.HAB_pnlBotones.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.HAB_pnlBotones.Controls.Add(Me.HAB_pnlSelection)
        Me.HAB_pnlBotones.Controls.Add(Me.HAB_pnlGris)
        Me.HAB_pnlBotones.Controls.Add(Me.HAB_btnEliminar)
        Me.HAB_pnlBotones.Controls.Add(Me.HAB_btnModificar)
        Me.HAB_pnlBotones.Controls.Add(Me.HAB_btnAgregar)
        Me.HAB_pnlBotones.Controls.Add(Me.HAB_btnVer)
        Me.HAB_pnlBotones.Dock = System.Windows.Forms.DockStyle.Top
        Me.HAB_pnlBotones.Location = New System.Drawing.Point(3, 3)
        Me.HAB_pnlBotones.Name = "HAB_pnlBotones"
        Me.HAB_pnlBotones.Size = New System.Drawing.Size(764, 30)
        Me.HAB_pnlBotones.TabIndex = 1
        '
        'HAB_pnlSelection
        '
        Me.HAB_pnlSelection.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.HAB_pnlSelection.Location = New System.Drawing.Point(0, 25)
        Me.HAB_pnlSelection.Name = "HAB_pnlSelection"
        Me.HAB_pnlSelection.Size = New System.Drawing.Size(75, 5)
        Me.HAB_pnlSelection.TabIndex = 10
        '
        'HAB_pnlGris
        '
        Me.HAB_pnlGris.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.HAB_pnlGris.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.HAB_pnlGris.Location = New System.Drawing.Point(0, 27)
        Me.HAB_pnlGris.Name = "HAB_pnlGris"
        Me.HAB_pnlGris.Size = New System.Drawing.Size(764, 3)
        Me.HAB_pnlGris.TabIndex = 9
        '
        'HAB_btnEliminar
        '
        Me.HAB_btnEliminar.FlatAppearance.BorderSize = 0
        Me.HAB_btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.HAB_btnEliminar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HAB_btnEliminar.ForeColor = System.Drawing.Color.White
        Me.HAB_btnEliminar.Location = New System.Drawing.Point(225, 0)
        Me.HAB_btnEliminar.Name = "HAB_btnEliminar"
        Me.HAB_btnEliminar.Size = New System.Drawing.Size(75, 27)
        Me.HAB_btnEliminar.TabIndex = 3
        Me.HAB_btnEliminar.Text = "ELIMINAR"
        Me.HAB_btnEliminar.UseVisualStyleBackColor = True
        '
        'HAB_btnModificar
        '
        Me.HAB_btnModificar.FlatAppearance.BorderSize = 0
        Me.HAB_btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.HAB_btnModificar.ForeColor = System.Drawing.Color.White
        Me.HAB_btnModificar.Location = New System.Drawing.Point(150, 0)
        Me.HAB_btnModificar.Name = "HAB_btnModificar"
        Me.HAB_btnModificar.Size = New System.Drawing.Size(75, 27)
        Me.HAB_btnModificar.TabIndex = 2
        Me.HAB_btnModificar.Text = "MODIFICAR"
        Me.HAB_btnModificar.UseVisualStyleBackColor = True
        '
        'HAB_btnAgregar
        '
        Me.HAB_btnAgregar.FlatAppearance.BorderSize = 0
        Me.HAB_btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.HAB_btnAgregar.ForeColor = System.Drawing.Color.White
        Me.HAB_btnAgregar.Location = New System.Drawing.Point(75, 0)
        Me.HAB_btnAgregar.Name = "HAB_btnAgregar"
        Me.HAB_btnAgregar.Size = New System.Drawing.Size(75, 27)
        Me.HAB_btnAgregar.TabIndex = 1
        Me.HAB_btnAgregar.Text = "AGREGAR"
        Me.HAB_btnAgregar.UseVisualStyleBackColor = True
        '
        'HAB_btnVer
        '
        Me.HAB_btnVer.FlatAppearance.BorderSize = 0
        Me.HAB_btnVer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.HAB_btnVer.ForeColor = System.Drawing.Color.White
        Me.HAB_btnVer.Location = New System.Drawing.Point(0, 0)
        Me.HAB_btnVer.Name = "HAB_btnVer"
        Me.HAB_btnVer.Size = New System.Drawing.Size(75, 27)
        Me.HAB_btnVer.TabIndex = 0
        Me.HAB_btnVer.Text = "VER"
        Me.HAB_btnVer.UseVisualStyleBackColor = True
        '
        'TabControl_MangeHaberes
        '
        Me.TabControl_MangeHaberes.Controls.Add(Me.HAB_TabPage_Ver)
        Me.TabControl_MangeHaberes.Controls.Add(Me.HAB_TabPage_Agregar)
        Me.TabControl_MangeHaberes.Controls.Add(Me.HAB_TabPage_Modificar)
        Me.TabControl_MangeHaberes.Controls.Add(Me.HAB_TabPage_Eliminar)
        Me.TabControl_MangeHaberes.Location = New System.Drawing.Point(0, 0)
        Me.TabControl_MangeHaberes.Name = "TabControl_MangeHaberes"
        Me.TabControl_MangeHaberes.SelectedIndex = 0
        Me.TabControl_MangeHaberes.Size = New System.Drawing.Size(767, 335)
        Me.TabControl_MangeHaberes.TabIndex = 0
        '
        'HAB_TabPage_Ver
        '
        Me.HAB_TabPage_Ver.Controls.Add(Me.VerHAB_lblVerHaberes)
        Me.HAB_TabPage_Ver.Controls.Add(Me.VerHAB_txtTipo)
        Me.HAB_TabPage_Ver.Controls.Add(Me.VerHAB_txtValor)
        Me.HAB_TabPage_Ver.Controls.Add(Me.VerHAB_txtNombre)
        Me.HAB_TabPage_Ver.Controls.Add(Me.VerHAB_txtId)
        Me.HAB_TabPage_Ver.Controls.Add(Me.VerHAB_lblTipo)
        Me.HAB_TabPage_Ver.Controls.Add(Me.VerHAB_lblValor)
        Me.HAB_TabPage_Ver.Controls.Add(Me.VerHAB_lblNombre)
        Me.HAB_TabPage_Ver.Controls.Add(Me.VerHAB_lblId)
        Me.HAB_TabPage_Ver.Controls.Add(Me.VerHAB_cbHaberes)
        Me.HAB_TabPage_Ver.Location = New System.Drawing.Point(4, 22)
        Me.HAB_TabPage_Ver.Name = "HAB_TabPage_Ver"
        Me.HAB_TabPage_Ver.Padding = New System.Windows.Forms.Padding(3)
        Me.HAB_TabPage_Ver.Size = New System.Drawing.Size(759, 309)
        Me.HAB_TabPage_Ver.TabIndex = 0
        Me.HAB_TabPage_Ver.Text = "TabPage1"
        Me.HAB_TabPage_Ver.UseVisualStyleBackColor = True
        '
        'VerHAB_txtTipo
        '
        Me.VerHAB_txtTipo.BackColor = System.Drawing.Color.White
        Me.VerHAB_txtTipo.Enabled = False
        Me.VerHAB_txtTipo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerHAB_txtTipo.ForeColor = System.Drawing.Color.Silver
        Me.VerHAB_txtTipo.Location = New System.Drawing.Point(278, 203)
        Me.VerHAB_txtTipo.Name = "VerHAB_txtTipo"
        Me.VerHAB_txtTipo.ReadOnly = True
        Me.VerHAB_txtTipo.Size = New System.Drawing.Size(132, 20)
        Me.VerHAB_txtTipo.TabIndex = 45
        '
        'VerHAB_txtValor
        '
        Me.VerHAB_txtValor.BackColor = System.Drawing.Color.White
        Me.VerHAB_txtValor.Enabled = False
        Me.VerHAB_txtValor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerHAB_txtValor.ForeColor = System.Drawing.Color.Silver
        Me.VerHAB_txtValor.Location = New System.Drawing.Point(278, 174)
        Me.VerHAB_txtValor.Name = "VerHAB_txtValor"
        Me.VerHAB_txtValor.ReadOnly = True
        Me.VerHAB_txtValor.Size = New System.Drawing.Size(132, 20)
        Me.VerHAB_txtValor.TabIndex = 44
        '
        'VerHAB_txtNombre
        '
        Me.VerHAB_txtNombre.BackColor = System.Drawing.Color.White
        Me.VerHAB_txtNombre.Enabled = False
        Me.VerHAB_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerHAB_txtNombre.Location = New System.Drawing.Point(278, 145)
        Me.VerHAB_txtNombre.Name = "VerHAB_txtNombre"
        Me.VerHAB_txtNombre.ReadOnly = True
        Me.VerHAB_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.VerHAB_txtNombre.TabIndex = 43
        '
        'VerHAB_txtId
        '
        Me.VerHAB_txtId.BackColor = System.Drawing.Color.White
        Me.VerHAB_txtId.Enabled = False
        Me.VerHAB_txtId.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerHAB_txtId.Location = New System.Drawing.Point(278, 116)
        Me.VerHAB_txtId.Name = "VerHAB_txtId"
        Me.VerHAB_txtId.ReadOnly = True
        Me.VerHAB_txtId.Size = New System.Drawing.Size(132, 20)
        Me.VerHAB_txtId.TabIndex = 42
        '
        'VerHAB_lblTipo
        '
        Me.VerHAB_lblTipo.AutoSize = True
        Me.VerHAB_lblTipo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerHAB_lblTipo.ForeColor = System.Drawing.Color.Black
        Me.VerHAB_lblTipo.Location = New System.Drawing.Point(117, 205)
        Me.VerHAB_lblTipo.Name = "VerHAB_lblTipo"
        Me.VerHAB_lblTipo.Size = New System.Drawing.Size(34, 17)
        Me.VerHAB_lblTipo.TabIndex = 41
        Me.VerHAB_lblTipo.Text = "Tipo:"
        '
        'VerHAB_lblValor
        '
        Me.VerHAB_lblValor.AutoSize = True
        Me.VerHAB_lblValor.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerHAB_lblValor.ForeColor = System.Drawing.Color.Black
        Me.VerHAB_lblValor.Location = New System.Drawing.Point(116, 176)
        Me.VerHAB_lblValor.Name = "VerHAB_lblValor"
        Me.VerHAB_lblValor.Size = New System.Drawing.Size(39, 17)
        Me.VerHAB_lblValor.TabIndex = 40
        Me.VerHAB_lblValor.Text = "Valor:"
        '
        'VerHAB_lblNombre
        '
        Me.VerHAB_lblNombre.AutoSize = True
        Me.VerHAB_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerHAB_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.VerHAB_lblNombre.Location = New System.Drawing.Point(116, 147)
        Me.VerHAB_lblNombre.Name = "VerHAB_lblNombre"
        Me.VerHAB_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.VerHAB_lblNombre.TabIndex = 39
        Me.VerHAB_lblNombre.Text = "Nombre:"
        '
        'VerHAB_lblId
        '
        Me.VerHAB_lblId.AutoSize = True
        Me.VerHAB_lblId.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerHAB_lblId.ForeColor = System.Drawing.Color.Black
        Me.VerHAB_lblId.Location = New System.Drawing.Point(116, 118)
        Me.VerHAB_lblId.Name = "VerHAB_lblId"
        Me.VerHAB_lblId.Size = New System.Drawing.Size(23, 17)
        Me.VerHAB_lblId.TabIndex = 38
        Me.VerHAB_lblId.Text = "ID:"
        '
        'VerHAB_cbHaberes
        '
        Me.VerHAB_cbHaberes.FormattingEnabled = True
        Me.VerHAB_cbHaberes.Location = New System.Drawing.Point(116, 89)
        Me.VerHAB_cbHaberes.Name = "VerHAB_cbHaberes"
        Me.VerHAB_cbHaberes.Size = New System.Drawing.Size(121, 21)
        Me.VerHAB_cbHaberes.TabIndex = 37
        '
        'HAB_TabPage_Agregar
        '
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_lblPorciento)
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_lblPesos)
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_btnAgregar)
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_rbPorcentaje)
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_rbValorFijo)
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_txtValor)
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_txtNombre)
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_lblPorcentaje)
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_lblValor)
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_lblNombre)
        Me.HAB_TabPage_Agregar.Controls.Add(Me.AddHAB_lblAgregarHaber)
        Me.HAB_TabPage_Agregar.Location = New System.Drawing.Point(4, 22)
        Me.HAB_TabPage_Agregar.Name = "HAB_TabPage_Agregar"
        Me.HAB_TabPage_Agregar.Padding = New System.Windows.Forms.Padding(3)
        Me.HAB_TabPage_Agregar.Size = New System.Drawing.Size(759, 309)
        Me.HAB_TabPage_Agregar.TabIndex = 1
        Me.HAB_TabPage_Agregar.Text = "TabPage2"
        Me.HAB_TabPage_Agregar.UseVisualStyleBackColor = True
        '
        'AddHAB_lblPorciento
        '
        Me.AddHAB_lblPorciento.AutoSize = True
        Me.AddHAB_lblPorciento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddHAB_lblPorciento.ForeColor = System.Drawing.Color.Black
        Me.AddHAB_lblPorciento.Location = New System.Drawing.Point(416, 147)
        Me.AddHAB_lblPorciento.Name = "AddHAB_lblPorciento"
        Me.AddHAB_lblPorciento.Size = New System.Drawing.Size(18, 17)
        Me.AddHAB_lblPorciento.TabIndex = 50
        Me.AddHAB_lblPorciento.Text = "%"
        Me.AddHAB_lblPorciento.Visible = False
        '
        'AddHAB_lblPesos
        '
        Me.AddHAB_lblPesos.AutoSize = True
        Me.AddHAB_lblPesos.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddHAB_lblPesos.ForeColor = System.Drawing.Color.Black
        Me.AddHAB_lblPesos.Location = New System.Drawing.Point(256, 147)
        Me.AddHAB_lblPesos.Name = "AddHAB_lblPesos"
        Me.AddHAB_lblPesos.Size = New System.Drawing.Size(16, 17)
        Me.AddHAB_lblPesos.TabIndex = 49
        Me.AddHAB_lblPesos.Text = "$"
        Me.AddHAB_lblPesos.Visible = False
        '
        'AddHAB_btnAgregar
        '
        Me.AddHAB_btnAgregar.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.AddHAB_btnAgregar.FlatAppearance.BorderSize = 0
        Me.AddHAB_btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddHAB_btnAgregar.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddHAB_btnAgregar.ForeColor = System.Drawing.Color.White
        Me.AddHAB_btnAgregar.Location = New System.Drawing.Point(201, 205)
        Me.AddHAB_btnAgregar.Name = "AddHAB_btnAgregar"
        Me.AddHAB_btnAgregar.Size = New System.Drawing.Size(114, 28)
        Me.AddHAB_btnAgregar.TabIndex = 48
        Me.AddHAB_btnAgregar.Text = "AGREGAR"
        Me.AddHAB_btnAgregar.UseVisualStyleBackColor = False
        '
        'AddHAB_rbPorcentaje
        '
        Me.AddHAB_rbPorcentaje.AutoSize = True
        Me.AddHAB_rbPorcentaje.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!)
        Me.AddHAB_rbPorcentaje.ForeColor = System.Drawing.Color.Black
        Me.AddHAB_rbPorcentaje.Location = New System.Drawing.Point(278, 87)
        Me.AddHAB_rbPorcentaje.Name = "AddHAB_rbPorcentaje"
        Me.AddHAB_rbPorcentaje.Size = New System.Drawing.Size(86, 21)
        Me.AddHAB_rbPorcentaje.TabIndex = 47
        Me.AddHAB_rbPorcentaje.TabStop = True
        Me.AddHAB_rbPorcentaje.Text = "Porcentaje"
        Me.AddHAB_rbPorcentaje.UseVisualStyleBackColor = True
        '
        'AddHAB_rbValorFijo
        '
        Me.AddHAB_rbValorFijo.AutoSize = True
        Me.AddHAB_rbValorFijo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!)
        Me.AddHAB_rbValorFijo.ForeColor = System.Drawing.Color.Black
        Me.AddHAB_rbValorFijo.Location = New System.Drawing.Point(116, 89)
        Me.AddHAB_rbValorFijo.Name = "AddHAB_rbValorFijo"
        Me.AddHAB_rbValorFijo.Size = New System.Drawing.Size(74, 21)
        Me.AddHAB_rbValorFijo.TabIndex = 46
        Me.AddHAB_rbValorFijo.TabStop = True
        Me.AddHAB_rbValorFijo.Text = "Valor fijo"
        Me.AddHAB_rbValorFijo.UseVisualStyleBackColor = True
        '
        'AddHAB_txtValor
        '
        Me.AddHAB_txtValor.BackColor = System.Drawing.Color.White
        Me.AddHAB_txtValor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddHAB_txtValor.Location = New System.Drawing.Point(278, 145)
        Me.AddHAB_txtValor.Name = "AddHAB_txtValor"
        Me.AddHAB_txtValor.Size = New System.Drawing.Size(132, 20)
        Me.AddHAB_txtValor.TabIndex = 44
        '
        'AddHAB_txtNombre
        '
        Me.AddHAB_txtNombre.BackColor = System.Drawing.Color.White
        Me.AddHAB_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddHAB_txtNombre.Location = New System.Drawing.Point(278, 116)
        Me.AddHAB_txtNombre.Name = "AddHAB_txtNombre"
        Me.AddHAB_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.AddHAB_txtNombre.TabIndex = 43
        '
        'AddHAB_lblPorcentaje
        '
        Me.AddHAB_lblPorcentaje.AutoSize = True
        Me.AddHAB_lblPorcentaje.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddHAB_lblPorcentaje.ForeColor = System.Drawing.Color.Black
        Me.AddHAB_lblPorcentaje.Location = New System.Drawing.Point(116, 147)
        Me.AddHAB_lblPorcentaje.Name = "AddHAB_lblPorcentaje"
        Me.AddHAB_lblPorcentaje.Size = New System.Drawing.Size(71, 17)
        Me.AddHAB_lblPorcentaje.TabIndex = 42
        Me.AddHAB_lblPorcentaje.Text = "Porcentaje:"
        Me.AddHAB_lblPorcentaje.Visible = False
        '
        'AddHAB_lblValor
        '
        Me.AddHAB_lblValor.AutoSize = True
        Me.AddHAB_lblValor.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddHAB_lblValor.ForeColor = System.Drawing.Color.Black
        Me.AddHAB_lblValor.Location = New System.Drawing.Point(116, 147)
        Me.AddHAB_lblValor.Name = "AddHAB_lblValor"
        Me.AddHAB_lblValor.Size = New System.Drawing.Size(39, 17)
        Me.AddHAB_lblValor.TabIndex = 41
        Me.AddHAB_lblValor.Text = "Valor:"
        '
        'AddHAB_lblNombre
        '
        Me.AddHAB_lblNombre.AutoSize = True
        Me.AddHAB_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddHAB_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.AddHAB_lblNombre.Location = New System.Drawing.Point(116, 118)
        Me.AddHAB_lblNombre.Name = "AddHAB_lblNombre"
        Me.AddHAB_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.AddHAB_lblNombre.TabIndex = 40
        Me.AddHAB_lblNombre.Text = "Nombre:"
        '
        'HAB_TabPage_Modificar
        '
        Me.HAB_TabPage_Modificar.Controls.Add(Me.ModHAB_btnModificar)
        Me.HAB_TabPage_Modificar.Controls.Add(Me.ModHAB_cbTipo)
        Me.HAB_TabPage_Modificar.Controls.Add(Me.ModHAB_txtValor)
        Me.HAB_TabPage_Modificar.Controls.Add(Me.ModHAB_txtNombre)
        Me.HAB_TabPage_Modificar.Controls.Add(Me.ModHAB_txtID)
        Me.HAB_TabPage_Modificar.Controls.Add(Me.ModHAB_lblTipo)
        Me.HAB_TabPage_Modificar.Controls.Add(Me.ModHAB_lblValor)
        Me.HAB_TabPage_Modificar.Controls.Add(Me.ModHAB_lblNombre)
        Me.HAB_TabPage_Modificar.Controls.Add(Me.ModHAB_lblId)
        Me.HAB_TabPage_Modificar.Controls.Add(Me.ModHAB_cbHaberes)
        Me.HAB_TabPage_Modificar.Controls.Add(Me.AddHAB_lblModificarHaberes)
        Me.HAB_TabPage_Modificar.Location = New System.Drawing.Point(4, 22)
        Me.HAB_TabPage_Modificar.Name = "HAB_TabPage_Modificar"
        Me.HAB_TabPage_Modificar.Size = New System.Drawing.Size(759, 309)
        Me.HAB_TabPage_Modificar.TabIndex = 2
        Me.HAB_TabPage_Modificar.Text = "TabPage1"
        Me.HAB_TabPage_Modificar.UseVisualStyleBackColor = True
        '
        'ModHAB_btnModificar
        '
        Me.ModHAB_btnModificar.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.ModHAB_btnModificar.FlatAppearance.BorderSize = 0
        Me.ModHAB_btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ModHAB_btnModificar.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModHAB_btnModificar.ForeColor = System.Drawing.Color.White
        Me.ModHAB_btnModificar.Location = New System.Drawing.Point(167, 256)
        Me.ModHAB_btnModificar.Name = "ModHAB_btnModificar"
        Me.ModHAB_btnModificar.Size = New System.Drawing.Size(132, 28)
        Me.ModHAB_btnModificar.TabIndex = 59
        Me.ModHAB_btnModificar.Text = "MODIFICAR"
        Me.ModHAB_btnModificar.UseVisualStyleBackColor = False
        '
        'ModHAB_cbTipo
        '
        Me.ModHAB_cbTipo.FormattingEnabled = True
        Me.ModHAB_cbTipo.Items.AddRange(New Object() {"Porcentaje", "Valor Fijo"})
        Me.ModHAB_cbTipo.Location = New System.Drawing.Point(275, 205)
        Me.ModHAB_cbTipo.Name = "ModHAB_cbTipo"
        Me.ModHAB_cbTipo.Size = New System.Drawing.Size(132, 21)
        Me.ModHAB_cbTipo.TabIndex = 58
        '
        'ModHAB_txtValor
        '
        Me.ModHAB_txtValor.BackColor = System.Drawing.Color.White
        Me.ModHAB_txtValor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModHAB_txtValor.Location = New System.Drawing.Point(275, 174)
        Me.ModHAB_txtValor.Name = "ModHAB_txtValor"
        Me.ModHAB_txtValor.Size = New System.Drawing.Size(132, 20)
        Me.ModHAB_txtValor.TabIndex = 56
        '
        'ModHAB_txtNombre
        '
        Me.ModHAB_txtNombre.BackColor = System.Drawing.Color.White
        Me.ModHAB_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModHAB_txtNombre.Location = New System.Drawing.Point(275, 145)
        Me.ModHAB_txtNombre.Name = "ModHAB_txtNombre"
        Me.ModHAB_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.ModHAB_txtNombre.TabIndex = 55
        '
        'ModHAB_txtID
        '
        Me.ModHAB_txtID.BackColor = System.Drawing.Color.White
        Me.ModHAB_txtID.Enabled = False
        Me.ModHAB_txtID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModHAB_txtID.Location = New System.Drawing.Point(275, 116)
        Me.ModHAB_txtID.Name = "ModHAB_txtID"
        Me.ModHAB_txtID.ReadOnly = True
        Me.ModHAB_txtID.Size = New System.Drawing.Size(132, 20)
        Me.ModHAB_txtID.TabIndex = 54
        '
        'ModHAB_lblTipo
        '
        Me.ModHAB_lblTipo.AutoSize = True
        Me.ModHAB_lblTipo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModHAB_lblTipo.ForeColor = System.Drawing.Color.Black
        Me.ModHAB_lblTipo.Location = New System.Drawing.Point(114, 205)
        Me.ModHAB_lblTipo.Name = "ModHAB_lblTipo"
        Me.ModHAB_lblTipo.Size = New System.Drawing.Size(34, 17)
        Me.ModHAB_lblTipo.TabIndex = 53
        Me.ModHAB_lblTipo.Text = "Tipo:"
        '
        'ModHAB_lblValor
        '
        Me.ModHAB_lblValor.AutoSize = True
        Me.ModHAB_lblValor.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModHAB_lblValor.ForeColor = System.Drawing.Color.Black
        Me.ModHAB_lblValor.Location = New System.Drawing.Point(113, 176)
        Me.ModHAB_lblValor.Name = "ModHAB_lblValor"
        Me.ModHAB_lblValor.Size = New System.Drawing.Size(39, 17)
        Me.ModHAB_lblValor.TabIndex = 52
        Me.ModHAB_lblValor.Text = "Valor:"
        '
        'ModHAB_lblNombre
        '
        Me.ModHAB_lblNombre.AutoSize = True
        Me.ModHAB_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModHAB_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.ModHAB_lblNombre.Location = New System.Drawing.Point(113, 147)
        Me.ModHAB_lblNombre.Name = "ModHAB_lblNombre"
        Me.ModHAB_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.ModHAB_lblNombre.TabIndex = 51
        Me.ModHAB_lblNombre.Text = "Nombre:"
        '
        'ModHAB_lblId
        '
        Me.ModHAB_lblId.AutoSize = True
        Me.ModHAB_lblId.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModHAB_lblId.ForeColor = System.Drawing.Color.Black
        Me.ModHAB_lblId.Location = New System.Drawing.Point(113, 118)
        Me.ModHAB_lblId.Name = "ModHAB_lblId"
        Me.ModHAB_lblId.Size = New System.Drawing.Size(23, 17)
        Me.ModHAB_lblId.TabIndex = 50
        Me.ModHAB_lblId.Text = "ID:"
        '
        'ModHAB_cbHaberes
        '
        Me.ModHAB_cbHaberes.FormattingEnabled = True
        Me.ModHAB_cbHaberes.Location = New System.Drawing.Point(113, 89)
        Me.ModHAB_cbHaberes.Name = "ModHAB_cbHaberes"
        Me.ModHAB_cbHaberes.Size = New System.Drawing.Size(159, 21)
        Me.ModHAB_cbHaberes.TabIndex = 49
        Me.ModHAB_cbHaberes.Text = "Seleccione un haber..."
        '
        'HAB_TabPage_Eliminar
        '
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_txtTipo)
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_btnEliminar)
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_txtValor)
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_txtNombre)
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_txtId)
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_lblTipo)
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_lblValor)
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_lblNombre)
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_lblId)
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_cbHaberes)
        Me.HAB_TabPage_Eliminar.Controls.Add(Me.ElimHAB_lblEliminarHaberes)
        Me.HAB_TabPage_Eliminar.Location = New System.Drawing.Point(4, 22)
        Me.HAB_TabPage_Eliminar.Name = "HAB_TabPage_Eliminar"
        Me.HAB_TabPage_Eliminar.Size = New System.Drawing.Size(759, 309)
        Me.HAB_TabPage_Eliminar.TabIndex = 3
        Me.HAB_TabPage_Eliminar.Text = "TabPage1"
        Me.HAB_TabPage_Eliminar.UseVisualStyleBackColor = True
        '
        'ElimHAB_txtTipo
        '
        Me.ElimHAB_txtTipo.BackColor = System.Drawing.Color.White
        Me.ElimHAB_txtTipo.Enabled = False
        Me.ElimHAB_txtTipo.Location = New System.Drawing.Point(275, 205)
        Me.ElimHAB_txtTipo.Name = "ElimHAB_txtTipo"
        Me.ElimHAB_txtTipo.Size = New System.Drawing.Size(132, 20)
        Me.ElimHAB_txtTipo.TabIndex = 71
        '
        'ElimHAB_btnEliminar
        '
        Me.ElimHAB_btnEliminar.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.ElimHAB_btnEliminar.FlatAppearance.BorderSize = 0
        Me.ElimHAB_btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ElimHAB_btnEliminar.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimHAB_btnEliminar.ForeColor = System.Drawing.Color.White
        Me.ElimHAB_btnEliminar.Location = New System.Drawing.Point(167, 256)
        Me.ElimHAB_btnEliminar.Name = "ElimHAB_btnEliminar"
        Me.ElimHAB_btnEliminar.Size = New System.Drawing.Size(132, 28)
        Me.ElimHAB_btnEliminar.TabIndex = 70
        Me.ElimHAB_btnEliminar.Text = "ELIMINAR"
        Me.ElimHAB_btnEliminar.UseVisualStyleBackColor = False
        '
        'ElimHAB_txtValor
        '
        Me.ElimHAB_txtValor.BackColor = System.Drawing.Color.White
        Me.ElimHAB_txtValor.Enabled = False
        Me.ElimHAB_txtValor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimHAB_txtValor.Location = New System.Drawing.Point(275, 174)
        Me.ElimHAB_txtValor.Name = "ElimHAB_txtValor"
        Me.ElimHAB_txtValor.Size = New System.Drawing.Size(132, 20)
        Me.ElimHAB_txtValor.TabIndex = 68
        '
        'ElimHAB_txtNombre
        '
        Me.ElimHAB_txtNombre.BackColor = System.Drawing.Color.White
        Me.ElimHAB_txtNombre.Enabled = False
        Me.ElimHAB_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimHAB_txtNombre.Location = New System.Drawing.Point(275, 145)
        Me.ElimHAB_txtNombre.Name = "ElimHAB_txtNombre"
        Me.ElimHAB_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.ElimHAB_txtNombre.TabIndex = 67
        '
        'ElimHAB_txtId
        '
        Me.ElimHAB_txtId.BackColor = System.Drawing.Color.White
        Me.ElimHAB_txtId.Enabled = False
        Me.ElimHAB_txtId.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimHAB_txtId.Location = New System.Drawing.Point(275, 116)
        Me.ElimHAB_txtId.Name = "ElimHAB_txtId"
        Me.ElimHAB_txtId.ReadOnly = True
        Me.ElimHAB_txtId.Size = New System.Drawing.Size(132, 20)
        Me.ElimHAB_txtId.TabIndex = 66
        '
        'ElimHAB_lblTipo
        '
        Me.ElimHAB_lblTipo.AutoSize = True
        Me.ElimHAB_lblTipo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimHAB_lblTipo.ForeColor = System.Drawing.Color.Black
        Me.ElimHAB_lblTipo.Location = New System.Drawing.Point(114, 205)
        Me.ElimHAB_lblTipo.Name = "ElimHAB_lblTipo"
        Me.ElimHAB_lblTipo.Size = New System.Drawing.Size(34, 17)
        Me.ElimHAB_lblTipo.TabIndex = 65
        Me.ElimHAB_lblTipo.Text = "Tipo:"
        '
        'ElimHAB_lblValor
        '
        Me.ElimHAB_lblValor.AutoSize = True
        Me.ElimHAB_lblValor.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimHAB_lblValor.ForeColor = System.Drawing.Color.Black
        Me.ElimHAB_lblValor.Location = New System.Drawing.Point(113, 176)
        Me.ElimHAB_lblValor.Name = "ElimHAB_lblValor"
        Me.ElimHAB_lblValor.Size = New System.Drawing.Size(39, 17)
        Me.ElimHAB_lblValor.TabIndex = 64
        Me.ElimHAB_lblValor.Text = "Valor:"
        '
        'ElimHAB_lblNombre
        '
        Me.ElimHAB_lblNombre.AutoSize = True
        Me.ElimHAB_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimHAB_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.ElimHAB_lblNombre.Location = New System.Drawing.Point(113, 147)
        Me.ElimHAB_lblNombre.Name = "ElimHAB_lblNombre"
        Me.ElimHAB_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.ElimHAB_lblNombre.TabIndex = 63
        Me.ElimHAB_lblNombre.Text = "Nombre:"
        '
        'ElimHAB_lblId
        '
        Me.ElimHAB_lblId.AutoSize = True
        Me.ElimHAB_lblId.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimHAB_lblId.ForeColor = System.Drawing.Color.Black
        Me.ElimHAB_lblId.Location = New System.Drawing.Point(113, 118)
        Me.ElimHAB_lblId.Name = "ElimHAB_lblId"
        Me.ElimHAB_lblId.Size = New System.Drawing.Size(23, 17)
        Me.ElimHAB_lblId.TabIndex = 62
        Me.ElimHAB_lblId.Text = "ID:"
        '
        'ElimHAB_cbHaberes
        '
        Me.ElimHAB_cbHaberes.FormattingEnabled = True
        Me.ElimHAB_cbHaberes.Location = New System.Drawing.Point(113, 89)
        Me.ElimHAB_cbHaberes.Name = "ElimHAB_cbHaberes"
        Me.ElimHAB_cbHaberes.Size = New System.Drawing.Size(159, 21)
        Me.ElimHAB_cbHaberes.TabIndex = 61
        Me.ElimHAB_cbHaberes.Text = "Seleccione un haber..."
        '
        'TabPage_Descuentos
        '
        Me.TabPage_Descuentos.Controls.Add(Me.DESC_pnlBotones)
        Me.TabPage_Descuentos.Controls.Add(Me.TabControl_ManageDescuentos)
        Me.TabPage_Descuentos.Location = New System.Drawing.Point(4, 58)
        Me.TabPage_Descuentos.Name = "TabPage_Descuentos"
        Me.TabPage_Descuentos.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Descuentos.Size = New System.Drawing.Size(770, 340)
        Me.TabPage_Descuentos.TabIndex = 1
        Me.TabPage_Descuentos.Text = "TabPage2"
        Me.TabPage_Descuentos.UseVisualStyleBackColor = True
        '
        'DESC_pnlBotones
        '
        Me.DESC_pnlBotones.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.DESC_pnlBotones.Controls.Add(Me.DESC_pnlSelection)
        Me.DESC_pnlBotones.Controls.Add(Me.DESC_pnlGris)
        Me.DESC_pnlBotones.Controls.Add(Me.DESC_btnEliminar)
        Me.DESC_pnlBotones.Controls.Add(Me.DESC_btnModificar)
        Me.DESC_pnlBotones.Controls.Add(Me.DESC_btnAgregar)
        Me.DESC_pnlBotones.Controls.Add(Me.DESC_btnVer)
        Me.DESC_pnlBotones.Dock = System.Windows.Forms.DockStyle.Top
        Me.DESC_pnlBotones.Location = New System.Drawing.Point(3, 3)
        Me.DESC_pnlBotones.Name = "DESC_pnlBotones"
        Me.DESC_pnlBotones.Size = New System.Drawing.Size(764, 30)
        Me.DESC_pnlBotones.TabIndex = 1
        '
        'DESC_pnlSelection
        '
        Me.DESC_pnlSelection.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.DESC_pnlSelection.Location = New System.Drawing.Point(0, 25)
        Me.DESC_pnlSelection.Name = "DESC_pnlSelection"
        Me.DESC_pnlSelection.Size = New System.Drawing.Size(75, 5)
        Me.DESC_pnlSelection.TabIndex = 11
        '
        'DESC_pnlGris
        '
        Me.DESC_pnlGris.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.DESC_pnlGris.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DESC_pnlGris.Location = New System.Drawing.Point(0, 27)
        Me.DESC_pnlGris.Name = "DESC_pnlGris"
        Me.DESC_pnlGris.Size = New System.Drawing.Size(764, 3)
        Me.DESC_pnlGris.TabIndex = 10
        '
        'DESC_btnEliminar
        '
        Me.DESC_btnEliminar.FlatAppearance.BorderSize = 0
        Me.DESC_btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DESC_btnEliminar.ForeColor = System.Drawing.Color.White
        Me.DESC_btnEliminar.Location = New System.Drawing.Point(225, 0)
        Me.DESC_btnEliminar.Name = "DESC_btnEliminar"
        Me.DESC_btnEliminar.Size = New System.Drawing.Size(75, 27)
        Me.DESC_btnEliminar.TabIndex = 3
        Me.DESC_btnEliminar.Text = "ELIMINAR"
        Me.DESC_btnEliminar.UseVisualStyleBackColor = True
        '
        'DESC_btnModificar
        '
        Me.DESC_btnModificar.FlatAppearance.BorderSize = 0
        Me.DESC_btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DESC_btnModificar.ForeColor = System.Drawing.Color.White
        Me.DESC_btnModificar.Location = New System.Drawing.Point(150, 0)
        Me.DESC_btnModificar.Name = "DESC_btnModificar"
        Me.DESC_btnModificar.Size = New System.Drawing.Size(75, 27)
        Me.DESC_btnModificar.TabIndex = 2
        Me.DESC_btnModificar.Text = "MODIFICAR"
        Me.DESC_btnModificar.UseVisualStyleBackColor = True
        '
        'DESC_btnAgregar
        '
        Me.DESC_btnAgregar.FlatAppearance.BorderSize = 0
        Me.DESC_btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DESC_btnAgregar.ForeColor = System.Drawing.Color.White
        Me.DESC_btnAgregar.Location = New System.Drawing.Point(75, 0)
        Me.DESC_btnAgregar.Name = "DESC_btnAgregar"
        Me.DESC_btnAgregar.Size = New System.Drawing.Size(75, 27)
        Me.DESC_btnAgregar.TabIndex = 1
        Me.DESC_btnAgregar.Text = "AGREGAR"
        Me.DESC_btnAgregar.UseVisualStyleBackColor = True
        '
        'DESC_btnVer
        '
        Me.DESC_btnVer.FlatAppearance.BorderSize = 0
        Me.DESC_btnVer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DESC_btnVer.ForeColor = System.Drawing.Color.White
        Me.DESC_btnVer.Location = New System.Drawing.Point(0, 0)
        Me.DESC_btnVer.Name = "DESC_btnVer"
        Me.DESC_btnVer.Size = New System.Drawing.Size(75, 27)
        Me.DESC_btnVer.TabIndex = 0
        Me.DESC_btnVer.Text = "VER"
        Me.DESC_btnVer.UseVisualStyleBackColor = True
        '
        'TabControl_ManageDescuentos
        '
        Me.TabControl_ManageDescuentos.Controls.Add(Me.DESC_TabPageVer)
        Me.TabControl_ManageDescuentos.Controls.Add(Me.DESC_TabPageAgregar)
        Me.TabControl_ManageDescuentos.Controls.Add(Me.DESC_TabPageModificar)
        Me.TabControl_ManageDescuentos.Controls.Add(Me.DESC_TabPageEliminar)
        Me.TabControl_ManageDescuentos.Location = New System.Drawing.Point(0, 0)
        Me.TabControl_ManageDescuentos.Name = "TabControl_ManageDescuentos"
        Me.TabControl_ManageDescuentos.Padding = New System.Drawing.Point(6, 7)
        Me.TabControl_ManageDescuentos.SelectedIndex = 0
        Me.TabControl_ManageDescuentos.Size = New System.Drawing.Size(774, 350)
        Me.TabControl_ManageDescuentos.TabIndex = 0
        '
        'DESC_TabPageVer
        '
        Me.DESC_TabPageVer.Controls.Add(Me.VerDESC_lblVerDescuentos)
        Me.DESC_TabPageVer.Controls.Add(Me.VerDesc_txtTipo)
        Me.DESC_TabPageVer.Controls.Add(Me.VerDesc_txtValor)
        Me.DESC_TabPageVer.Controls.Add(Me.VerDesc_txtNombre)
        Me.DESC_TabPageVer.Controls.Add(Me.VerDesc_txtID)
        Me.DESC_TabPageVer.Controls.Add(Me.VerDesc_lblTipo)
        Me.DESC_TabPageVer.Controls.Add(Me.VerDesc_lblValor)
        Me.DESC_TabPageVer.Controls.Add(Me.VerDesc_lblNombre)
        Me.DESC_TabPageVer.Controls.Add(Me.VerDesc_lblID)
        Me.DESC_TabPageVer.Controls.Add(Me.VerDesc_cbDescuentos)
        Me.DESC_TabPageVer.Location = New System.Drawing.Point(4, 30)
        Me.DESC_TabPageVer.Name = "DESC_TabPageVer"
        Me.DESC_TabPageVer.Padding = New System.Windows.Forms.Padding(3)
        Me.DESC_TabPageVer.Size = New System.Drawing.Size(766, 316)
        Me.DESC_TabPageVer.TabIndex = 0
        Me.DESC_TabPageVer.Text = "VER"
        Me.DESC_TabPageVer.UseVisualStyleBackColor = True
        '
        'VerDesc_txtTipo
        '
        Me.VerDesc_txtTipo.BackColor = System.Drawing.Color.White
        Me.VerDesc_txtTipo.Enabled = False
        Me.VerDesc_txtTipo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerDesc_txtTipo.Location = New System.Drawing.Point(278, 195)
        Me.VerDesc_txtTipo.Name = "VerDesc_txtTipo"
        Me.VerDesc_txtTipo.ReadOnly = True
        Me.VerDesc_txtTipo.Size = New System.Drawing.Size(132, 20)
        Me.VerDesc_txtTipo.TabIndex = 35
        '
        'VerDesc_txtValor
        '
        Me.VerDesc_txtValor.BackColor = System.Drawing.Color.White
        Me.VerDesc_txtValor.Enabled = False
        Me.VerDesc_txtValor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerDesc_txtValor.Location = New System.Drawing.Point(278, 166)
        Me.VerDesc_txtValor.Name = "VerDesc_txtValor"
        Me.VerDesc_txtValor.ReadOnly = True
        Me.VerDesc_txtValor.Size = New System.Drawing.Size(132, 20)
        Me.VerDesc_txtValor.TabIndex = 34
        '
        'VerDesc_txtNombre
        '
        Me.VerDesc_txtNombre.BackColor = System.Drawing.Color.White
        Me.VerDesc_txtNombre.Enabled = False
        Me.VerDesc_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerDesc_txtNombre.Location = New System.Drawing.Point(278, 137)
        Me.VerDesc_txtNombre.Name = "VerDesc_txtNombre"
        Me.VerDesc_txtNombre.ReadOnly = True
        Me.VerDesc_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.VerDesc_txtNombre.TabIndex = 33
        '
        'VerDesc_txtID
        '
        Me.VerDesc_txtID.BackColor = System.Drawing.Color.White
        Me.VerDesc_txtID.Enabled = False
        Me.VerDesc_txtID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerDesc_txtID.Location = New System.Drawing.Point(278, 108)
        Me.VerDesc_txtID.Name = "VerDesc_txtID"
        Me.VerDesc_txtID.ReadOnly = True
        Me.VerDesc_txtID.Size = New System.Drawing.Size(132, 20)
        Me.VerDesc_txtID.TabIndex = 32
        '
        'VerDesc_lblTipo
        '
        Me.VerDesc_lblTipo.AutoSize = True
        Me.VerDesc_lblTipo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerDesc_lblTipo.ForeColor = System.Drawing.Color.Black
        Me.VerDesc_lblTipo.Location = New System.Drawing.Point(117, 197)
        Me.VerDesc_lblTipo.Name = "VerDesc_lblTipo"
        Me.VerDesc_lblTipo.Size = New System.Drawing.Size(34, 17)
        Me.VerDesc_lblTipo.TabIndex = 31
        Me.VerDesc_lblTipo.Text = "Tipo:"
        '
        'VerDesc_lblValor
        '
        Me.VerDesc_lblValor.AutoSize = True
        Me.VerDesc_lblValor.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerDesc_lblValor.ForeColor = System.Drawing.Color.Black
        Me.VerDesc_lblValor.Location = New System.Drawing.Point(116, 168)
        Me.VerDesc_lblValor.Name = "VerDesc_lblValor"
        Me.VerDesc_lblValor.Size = New System.Drawing.Size(39, 17)
        Me.VerDesc_lblValor.TabIndex = 30
        Me.VerDesc_lblValor.Text = "Valor:"
        '
        'VerDesc_lblNombre
        '
        Me.VerDesc_lblNombre.AutoSize = True
        Me.VerDesc_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerDesc_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.VerDesc_lblNombre.Location = New System.Drawing.Point(116, 139)
        Me.VerDesc_lblNombre.Name = "VerDesc_lblNombre"
        Me.VerDesc_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.VerDesc_lblNombre.TabIndex = 29
        Me.VerDesc_lblNombre.Text = "Nombre:"
        '
        'VerDesc_lblID
        '
        Me.VerDesc_lblID.AutoSize = True
        Me.VerDesc_lblID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerDesc_lblID.ForeColor = System.Drawing.Color.Black
        Me.VerDesc_lblID.Location = New System.Drawing.Point(116, 110)
        Me.VerDesc_lblID.Name = "VerDesc_lblID"
        Me.VerDesc_lblID.Size = New System.Drawing.Size(23, 17)
        Me.VerDesc_lblID.TabIndex = 28
        Me.VerDesc_lblID.Text = "ID:"
        '
        'VerDesc_cbDescuentos
        '
        Me.VerDesc_cbDescuentos.FormattingEnabled = True
        Me.VerDesc_cbDescuentos.Location = New System.Drawing.Point(116, 81)
        Me.VerDesc_cbDescuentos.Name = "VerDesc_cbDescuentos"
        Me.VerDesc_cbDescuentos.Size = New System.Drawing.Size(121, 21)
        Me.VerDesc_cbDescuentos.TabIndex = 0
        '
        'DESC_TabPageAgregar
        '
        Me.DESC_TabPageAgregar.Controls.Add(Me.AddDESC_lblPorciento)
        Me.DESC_TabPageAgregar.Controls.Add(Me.AddDESC_lblPesos)
        Me.DESC_TabPageAgregar.Controls.Add(Me.AddDESC_btnAgregar)
        Me.DESC_TabPageAgregar.Controls.Add(Me.AddDESC_rbPorcentaje)
        Me.DESC_TabPageAgregar.Controls.Add(Me.AddDESC_rbValorFijo)
        Me.DESC_TabPageAgregar.Controls.Add(Me.AddDESC_txtValor)
        Me.DESC_TabPageAgregar.Controls.Add(Me.AddDESC_txtNombre)
        Me.DESC_TabPageAgregar.Controls.Add(Me.AddDESC_lblPorcentaje)
        Me.DESC_TabPageAgregar.Controls.Add(Me.AddDESC_lblValor)
        Me.DESC_TabPageAgregar.Controls.Add(Me.AddDESC_lblNombre)
        Me.DESC_TabPageAgregar.Controls.Add(Me.inftrabajador)
        Me.DESC_TabPageAgregar.Location = New System.Drawing.Point(4, 30)
        Me.DESC_TabPageAgregar.Name = "DESC_TabPageAgregar"
        Me.DESC_TabPageAgregar.Padding = New System.Windows.Forms.Padding(3)
        Me.DESC_TabPageAgregar.Size = New System.Drawing.Size(766, 316)
        Me.DESC_TabPageAgregar.TabIndex = 1
        Me.DESC_TabPageAgregar.Text = "AGREGAR"
        Me.DESC_TabPageAgregar.UseVisualStyleBackColor = True
        '
        'AddDESC_lblPorciento
        '
        Me.AddDESC_lblPorciento.AutoSize = True
        Me.AddDESC_lblPorciento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddDESC_lblPorciento.ForeColor = System.Drawing.Color.Black
        Me.AddDESC_lblPorciento.Location = New System.Drawing.Point(416, 139)
        Me.AddDESC_lblPorciento.Name = "AddDESC_lblPorciento"
        Me.AddDESC_lblPorciento.Size = New System.Drawing.Size(18, 17)
        Me.AddDESC_lblPorciento.TabIndex = 39
        Me.AddDESC_lblPorciento.Text = "%"
        Me.AddDESC_lblPorciento.Visible = False
        '
        'AddDESC_lblPesos
        '
        Me.AddDESC_lblPesos.AutoSize = True
        Me.AddDESC_lblPesos.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddDESC_lblPesos.ForeColor = System.Drawing.Color.Black
        Me.AddDESC_lblPesos.Location = New System.Drawing.Point(256, 139)
        Me.AddDESC_lblPesos.Name = "AddDESC_lblPesos"
        Me.AddDESC_lblPesos.Size = New System.Drawing.Size(16, 17)
        Me.AddDESC_lblPesos.TabIndex = 38
        Me.AddDESC_lblPesos.Text = "$"
        Me.AddDESC_lblPesos.Visible = False
        '
        'AddDESC_btnAgregar
        '
        Me.AddDESC_btnAgregar.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.AddDESC_btnAgregar.FlatAppearance.BorderSize = 0
        Me.AddDESC_btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddDESC_btnAgregar.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddDESC_btnAgregar.ForeColor = System.Drawing.Color.White
        Me.AddDESC_btnAgregar.Location = New System.Drawing.Point(201, 197)
        Me.AddDESC_btnAgregar.Name = "AddDESC_btnAgregar"
        Me.AddDESC_btnAgregar.Size = New System.Drawing.Size(114, 28)
        Me.AddDESC_btnAgregar.TabIndex = 37
        Me.AddDESC_btnAgregar.Text = "AGREGAR"
        Me.AddDESC_btnAgregar.UseVisualStyleBackColor = False
        '
        'AddDESC_rbPorcentaje
        '
        Me.AddDESC_rbPorcentaje.AutoSize = True
        Me.AddDESC_rbPorcentaje.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!)
        Me.AddDESC_rbPorcentaje.ForeColor = System.Drawing.Color.Black
        Me.AddDESC_rbPorcentaje.Location = New System.Drawing.Point(278, 79)
        Me.AddDESC_rbPorcentaje.Name = "AddDESC_rbPorcentaje"
        Me.AddDESC_rbPorcentaje.Size = New System.Drawing.Size(86, 21)
        Me.AddDESC_rbPorcentaje.TabIndex = 36
        Me.AddDESC_rbPorcentaje.TabStop = True
        Me.AddDESC_rbPorcentaje.Text = "Porcentaje"
        Me.AddDESC_rbPorcentaje.UseVisualStyleBackColor = True
        '
        'AddDESC_rbValorFijo
        '
        Me.AddDESC_rbValorFijo.AutoSize = True
        Me.AddDESC_rbValorFijo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!)
        Me.AddDESC_rbValorFijo.ForeColor = System.Drawing.Color.Black
        Me.AddDESC_rbValorFijo.Location = New System.Drawing.Point(116, 81)
        Me.AddDESC_rbValorFijo.Name = "AddDESC_rbValorFijo"
        Me.AddDESC_rbValorFijo.Size = New System.Drawing.Size(74, 21)
        Me.AddDESC_rbValorFijo.TabIndex = 35
        Me.AddDESC_rbValorFijo.TabStop = True
        Me.AddDESC_rbValorFijo.Text = "Valor fijo"
        Me.AddDESC_rbValorFijo.UseVisualStyleBackColor = True
        '
        'AddDESC_txtValor
        '
        Me.AddDESC_txtValor.BackColor = System.Drawing.Color.White
        Me.AddDESC_txtValor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddDESC_txtValor.Location = New System.Drawing.Point(278, 137)
        Me.AddDESC_txtValor.Name = "AddDESC_txtValor"
        Me.AddDESC_txtValor.Size = New System.Drawing.Size(132, 20)
        Me.AddDESC_txtValor.TabIndex = 32
        '
        'AddDESC_txtNombre
        '
        Me.AddDESC_txtNombre.BackColor = System.Drawing.Color.White
        Me.AddDESC_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddDESC_txtNombre.Location = New System.Drawing.Point(278, 108)
        Me.AddDESC_txtNombre.Name = "AddDESC_txtNombre"
        Me.AddDESC_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.AddDESC_txtNombre.TabIndex = 31
        '
        'AddDESC_lblPorcentaje
        '
        Me.AddDESC_lblPorcentaje.AutoSize = True
        Me.AddDESC_lblPorcentaje.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddDESC_lblPorcentaje.ForeColor = System.Drawing.Color.Black
        Me.AddDESC_lblPorcentaje.Location = New System.Drawing.Point(116, 139)
        Me.AddDESC_lblPorcentaje.Name = "AddDESC_lblPorcentaje"
        Me.AddDESC_lblPorcentaje.Size = New System.Drawing.Size(71, 17)
        Me.AddDESC_lblPorcentaje.TabIndex = 30
        Me.AddDESC_lblPorcentaje.Text = "Porcentaje:"
        Me.AddDESC_lblPorcentaje.Visible = False
        '
        'AddDESC_lblValor
        '
        Me.AddDESC_lblValor.AutoSize = True
        Me.AddDESC_lblValor.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddDESC_lblValor.ForeColor = System.Drawing.Color.Black
        Me.AddDESC_lblValor.Location = New System.Drawing.Point(116, 139)
        Me.AddDESC_lblValor.Name = "AddDESC_lblValor"
        Me.AddDESC_lblValor.Size = New System.Drawing.Size(39, 17)
        Me.AddDESC_lblValor.TabIndex = 29
        Me.AddDESC_lblValor.Text = "Valor:"
        '
        'AddDESC_lblNombre
        '
        Me.AddDESC_lblNombre.AutoSize = True
        Me.AddDESC_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddDESC_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.AddDESC_lblNombre.Location = New System.Drawing.Point(116, 110)
        Me.AddDESC_lblNombre.Name = "AddDESC_lblNombre"
        Me.AddDESC_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.AddDESC_lblNombre.TabIndex = 28
        Me.AddDESC_lblNombre.Text = "Nombre:"
        '
        'DESC_TabPageModificar
        '
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDesc_btnAceptar)
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDesc_cbTipo)
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDesc_txtValor)
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDesc_txtNombre)
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDesc_txtID)
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDesc_lblTipo)
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDesc_lblValor)
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDesc_lblNombre)
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDesc_lblID)
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDesc_cbDescuentos)
        Me.DESC_TabPageModificar.Controls.Add(Me.ModDESC_lblModificarDescuentos)
        Me.DESC_TabPageModificar.Location = New System.Drawing.Point(4, 30)
        Me.DESC_TabPageModificar.Name = "DESC_TabPageModificar"
        Me.DESC_TabPageModificar.Size = New System.Drawing.Size(766, 316)
        Me.DESC_TabPageModificar.TabIndex = 2
        Me.DESC_TabPageModificar.Text = "MODIFICAR"
        Me.DESC_TabPageModificar.UseVisualStyleBackColor = True
        '
        'ModDesc_btnAceptar
        '
        Me.ModDesc_btnAceptar.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.ModDesc_btnAceptar.FlatAppearance.BorderSize = 0
        Me.ModDesc_btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ModDesc_btnAceptar.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModDesc_btnAceptar.ForeColor = System.Drawing.Color.White
        Me.ModDesc_btnAceptar.Location = New System.Drawing.Point(167, 248)
        Me.ModDesc_btnAceptar.Name = "ModDesc_btnAceptar"
        Me.ModDesc_btnAceptar.Size = New System.Drawing.Size(132, 28)
        Me.ModDesc_btnAceptar.TabIndex = 48
        Me.ModDesc_btnAceptar.Text = "MODIFICAR"
        Me.ModDesc_btnAceptar.UseVisualStyleBackColor = False
        '
        'ModDesc_cbTipo
        '
        Me.ModDesc_cbTipo.ForeColor = System.Drawing.Color.Silver
        Me.ModDesc_cbTipo.FormattingEnabled = True
        Me.ModDesc_cbTipo.Items.AddRange(New Object() {"Porcentaje", "Valor Fijo"})
        Me.ModDesc_cbTipo.Location = New System.Drawing.Point(275, 197)
        Me.ModDesc_cbTipo.Name = "ModDesc_cbTipo"
        Me.ModDesc_cbTipo.Size = New System.Drawing.Size(132, 21)
        Me.ModDesc_cbTipo.TabIndex = 47
        '
        'ModDesc_txtValor
        '
        Me.ModDesc_txtValor.BackColor = System.Drawing.Color.White
        Me.ModDesc_txtValor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModDesc_txtValor.ForeColor = System.Drawing.Color.Silver
        Me.ModDesc_txtValor.Location = New System.Drawing.Point(275, 166)
        Me.ModDesc_txtValor.Name = "ModDesc_txtValor"
        Me.ModDesc_txtValor.Size = New System.Drawing.Size(132, 20)
        Me.ModDesc_txtValor.TabIndex = 44
        '
        'ModDesc_txtNombre
        '
        Me.ModDesc_txtNombre.BackColor = System.Drawing.Color.White
        Me.ModDesc_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModDesc_txtNombre.ForeColor = System.Drawing.Color.Silver
        Me.ModDesc_txtNombre.Location = New System.Drawing.Point(275, 137)
        Me.ModDesc_txtNombre.Name = "ModDesc_txtNombre"
        Me.ModDesc_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.ModDesc_txtNombre.TabIndex = 43
        '
        'ModDesc_txtID
        '
        Me.ModDesc_txtID.BackColor = System.Drawing.Color.White
        Me.ModDesc_txtID.Enabled = False
        Me.ModDesc_txtID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModDesc_txtID.Location = New System.Drawing.Point(275, 108)
        Me.ModDesc_txtID.Name = "ModDesc_txtID"
        Me.ModDesc_txtID.ReadOnly = True
        Me.ModDesc_txtID.Size = New System.Drawing.Size(132, 20)
        Me.ModDesc_txtID.TabIndex = 42
        '
        'ModDesc_lblTipo
        '
        Me.ModDesc_lblTipo.AutoSize = True
        Me.ModDesc_lblTipo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModDesc_lblTipo.ForeColor = System.Drawing.Color.Black
        Me.ModDesc_lblTipo.Location = New System.Drawing.Point(114, 197)
        Me.ModDesc_lblTipo.Name = "ModDesc_lblTipo"
        Me.ModDesc_lblTipo.Size = New System.Drawing.Size(34, 17)
        Me.ModDesc_lblTipo.TabIndex = 41
        Me.ModDesc_lblTipo.Text = "Tipo:"
        '
        'ModDesc_lblValor
        '
        Me.ModDesc_lblValor.AutoSize = True
        Me.ModDesc_lblValor.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModDesc_lblValor.ForeColor = System.Drawing.Color.Black
        Me.ModDesc_lblValor.Location = New System.Drawing.Point(113, 168)
        Me.ModDesc_lblValor.Name = "ModDesc_lblValor"
        Me.ModDesc_lblValor.Size = New System.Drawing.Size(39, 17)
        Me.ModDesc_lblValor.TabIndex = 40
        Me.ModDesc_lblValor.Text = "Valor:"
        '
        'ModDesc_lblNombre
        '
        Me.ModDesc_lblNombre.AutoSize = True
        Me.ModDesc_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModDesc_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.ModDesc_lblNombre.Location = New System.Drawing.Point(113, 139)
        Me.ModDesc_lblNombre.Name = "ModDesc_lblNombre"
        Me.ModDesc_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.ModDesc_lblNombre.TabIndex = 39
        Me.ModDesc_lblNombre.Text = "Nombre:"
        '
        'ModDesc_lblID
        '
        Me.ModDesc_lblID.AutoSize = True
        Me.ModDesc_lblID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModDesc_lblID.ForeColor = System.Drawing.Color.Black
        Me.ModDesc_lblID.Location = New System.Drawing.Point(113, 110)
        Me.ModDesc_lblID.Name = "ModDesc_lblID"
        Me.ModDesc_lblID.Size = New System.Drawing.Size(23, 17)
        Me.ModDesc_lblID.TabIndex = 38
        Me.ModDesc_lblID.Text = "ID:"
        '
        'ModDesc_cbDescuentos
        '
        Me.ModDesc_cbDescuentos.FormattingEnabled = True
        Me.ModDesc_cbDescuentos.Location = New System.Drawing.Point(113, 81)
        Me.ModDesc_cbDescuentos.Name = "ModDesc_cbDescuentos"
        Me.ModDesc_cbDescuentos.Size = New System.Drawing.Size(159, 21)
        Me.ModDesc_cbDescuentos.TabIndex = 35
        Me.ModDesc_cbDescuentos.Text = "Seleccione un descuento..."
        '
        'DESC_TabPageEliminar
        '
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_txtTipo)
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_btnEliminar)
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_txtValor)
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_txtNombre)
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_txtID)
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_lblTipo)
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_lblValor)
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_lblNombre)
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_lblID)
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_cbDescuentos)
        Me.DESC_TabPageEliminar.Controls.Add(Me.ElimDESC_lblEliminarDescuentos)
        Me.DESC_TabPageEliminar.Location = New System.Drawing.Point(4, 30)
        Me.DESC_TabPageEliminar.Name = "DESC_TabPageEliminar"
        Me.DESC_TabPageEliminar.Size = New System.Drawing.Size(766, 316)
        Me.DESC_TabPageEliminar.TabIndex = 3
        Me.DESC_TabPageEliminar.Text = "ELIMINAR"
        Me.DESC_TabPageEliminar.UseVisualStyleBackColor = True
        '
        'ElimDESC_txtTipo
        '
        Me.ElimDESC_txtTipo.BackColor = System.Drawing.Color.White
        Me.ElimDESC_txtTipo.Enabled = False
        Me.ElimDESC_txtTipo.Location = New System.Drawing.Point(275, 197)
        Me.ElimDESC_txtTipo.Name = "ElimDESC_txtTipo"
        Me.ElimDESC_txtTipo.Size = New System.Drawing.Size(132, 20)
        Me.ElimDESC_txtTipo.TabIndex = 71
        '
        'ElimDESC_btnEliminar
        '
        Me.ElimDESC_btnEliminar.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.ElimDESC_btnEliminar.FlatAppearance.BorderSize = 0
        Me.ElimDESC_btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ElimDESC_btnEliminar.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimDESC_btnEliminar.ForeColor = System.Drawing.Color.White
        Me.ElimDESC_btnEliminar.Location = New System.Drawing.Point(167, 248)
        Me.ElimDESC_btnEliminar.Name = "ElimDESC_btnEliminar"
        Me.ElimDESC_btnEliminar.Size = New System.Drawing.Size(132, 28)
        Me.ElimDESC_btnEliminar.TabIndex = 70
        Me.ElimDESC_btnEliminar.Text = "ELIMINAR"
        Me.ElimDESC_btnEliminar.UseVisualStyleBackColor = False
        '
        'ElimDESC_txtValor
        '
        Me.ElimDESC_txtValor.BackColor = System.Drawing.Color.White
        Me.ElimDESC_txtValor.Enabled = False
        Me.ElimDESC_txtValor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimDESC_txtValor.Location = New System.Drawing.Point(275, 166)
        Me.ElimDESC_txtValor.Name = "ElimDESC_txtValor"
        Me.ElimDESC_txtValor.Size = New System.Drawing.Size(132, 20)
        Me.ElimDESC_txtValor.TabIndex = 68
        '
        'ElimDESC_txtNombre
        '
        Me.ElimDESC_txtNombre.BackColor = System.Drawing.Color.White
        Me.ElimDESC_txtNombre.Enabled = False
        Me.ElimDESC_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimDESC_txtNombre.Location = New System.Drawing.Point(275, 137)
        Me.ElimDESC_txtNombre.Name = "ElimDESC_txtNombre"
        Me.ElimDESC_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.ElimDESC_txtNombre.TabIndex = 67
        '
        'ElimDESC_txtID
        '
        Me.ElimDESC_txtID.BackColor = System.Drawing.Color.White
        Me.ElimDESC_txtID.Enabled = False
        Me.ElimDESC_txtID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimDESC_txtID.Location = New System.Drawing.Point(275, 108)
        Me.ElimDESC_txtID.Name = "ElimDESC_txtID"
        Me.ElimDESC_txtID.ReadOnly = True
        Me.ElimDESC_txtID.Size = New System.Drawing.Size(132, 20)
        Me.ElimDESC_txtID.TabIndex = 66
        '
        'ElimDESC_lblTipo
        '
        Me.ElimDESC_lblTipo.AutoSize = True
        Me.ElimDESC_lblTipo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimDESC_lblTipo.ForeColor = System.Drawing.Color.Black
        Me.ElimDESC_lblTipo.Location = New System.Drawing.Point(114, 197)
        Me.ElimDESC_lblTipo.Name = "ElimDESC_lblTipo"
        Me.ElimDESC_lblTipo.Size = New System.Drawing.Size(34, 17)
        Me.ElimDESC_lblTipo.TabIndex = 65
        Me.ElimDESC_lblTipo.Text = "Tipo:"
        '
        'ElimDESC_lblValor
        '
        Me.ElimDESC_lblValor.AutoSize = True
        Me.ElimDESC_lblValor.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimDESC_lblValor.ForeColor = System.Drawing.Color.Black
        Me.ElimDESC_lblValor.Location = New System.Drawing.Point(113, 168)
        Me.ElimDESC_lblValor.Name = "ElimDESC_lblValor"
        Me.ElimDESC_lblValor.Size = New System.Drawing.Size(39, 17)
        Me.ElimDESC_lblValor.TabIndex = 64
        Me.ElimDESC_lblValor.Text = "Valor:"
        '
        'ElimDESC_lblNombre
        '
        Me.ElimDESC_lblNombre.AutoSize = True
        Me.ElimDESC_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimDESC_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.ElimDESC_lblNombre.Location = New System.Drawing.Point(113, 139)
        Me.ElimDESC_lblNombre.Name = "ElimDESC_lblNombre"
        Me.ElimDESC_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.ElimDESC_lblNombre.TabIndex = 63
        Me.ElimDESC_lblNombre.Text = "Nombre:"
        '
        'ElimDESC_lblID
        '
        Me.ElimDESC_lblID.AutoSize = True
        Me.ElimDESC_lblID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimDESC_lblID.ForeColor = System.Drawing.Color.Black
        Me.ElimDESC_lblID.Location = New System.Drawing.Point(113, 110)
        Me.ElimDESC_lblID.Name = "ElimDESC_lblID"
        Me.ElimDESC_lblID.Size = New System.Drawing.Size(23, 17)
        Me.ElimDESC_lblID.TabIndex = 62
        Me.ElimDESC_lblID.Text = "ID:"
        '
        'ElimDESC_cbDescuentos
        '
        Me.ElimDESC_cbDescuentos.FormattingEnabled = True
        Me.ElimDESC_cbDescuentos.Location = New System.Drawing.Point(113, 81)
        Me.ElimDESC_cbDescuentos.Name = "ElimDESC_cbDescuentos"
        Me.ElimDESC_cbDescuentos.Size = New System.Drawing.Size(159, 21)
        Me.ElimDESC_cbDescuentos.TabIndex = 61
        Me.ElimDESC_cbDescuentos.Text = "Seleccione un descuento..."
        '
        'TaxDataSet
        '
        Me.TaxDataSet.DataSetName = "taxDataSet"
        Me.TaxDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TaxDataSetBindingSource
        '
        Me.TaxDataSetBindingSource.DataSource = Me.TaxDataSet
        Me.TaxDataSetBindingSource.Position = 0
        '
        'btnDescuentos
        '
        Me.btnDescuentos.FlatAppearance.BorderSize = 0
        Me.btnDescuentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDescuentos.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDescuentos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnDescuentos.Image = Global.TAX.My.Resources.Resources.money_down
        Me.btnDescuentos.Location = New System.Drawing.Point(101, 0)
        Me.btnDescuentos.Name = "btnDescuentos"
        Me.btnDescuentos.Size = New System.Drawing.Size(102, 59)
        Me.btnDescuentos.TabIndex = 1
        Me.btnDescuentos.Text = "DESCUENTOS"
        Me.btnDescuentos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnDescuentos.UseVisualStyleBackColor = True
        '
        'btnHaberes
        '
        Me.btnHaberes.FlatAppearance.BorderSize = 0
        Me.btnHaberes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHaberes.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHaberes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.btnHaberes.Image = Global.TAX.My.Resources.Resources.money_up_red
        Me.btnHaberes.Location = New System.Drawing.Point(0, 0)
        Me.btnHaberes.Name = "btnHaberes"
        Me.btnHaberes.Size = New System.Drawing.Size(102, 59)
        Me.btnHaberes.TabIndex = 0
        Me.btnHaberes.Text = "HABERES"
        Me.btnHaberes.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnHaberes.UseVisualStyleBackColor = True
        '
        'VerHAB_lblVerHaberes
        '
        Me.VerHAB_lblVerHaberes.BackColor = System.Drawing.Color.White
        Me.VerHAB_lblVerHaberes.Enabled = False
        Me.VerHAB_lblVerHaberes.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.VerHAB_lblVerHaberes.FlatAppearance.BorderSize = 0
        Me.VerHAB_lblVerHaberes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.VerHAB_lblVerHaberes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.VerHAB_lblVerHaberes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.VerHAB_lblVerHaberes.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerHAB_lblVerHaberes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.VerHAB_lblVerHaberes.Image = CType(resources.GetObject("VerHAB_lblVerHaberes.Image"), System.Drawing.Image)
        Me.VerHAB_lblVerHaberes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.VerHAB_lblVerHaberes.Location = New System.Drawing.Point(6, 17)
        Me.VerHAB_lblVerHaberes.Name = "VerHAB_lblVerHaberes"
        Me.VerHAB_lblVerHaberes.Size = New System.Drawing.Size(239, 53)
        Me.VerHAB_lblVerHaberes.TabIndex = 46
        Me.VerHAB_lblVerHaberes.Text = "Ver haberes"
        Me.VerHAB_lblVerHaberes.UseVisualStyleBackColor = False
        '
        'AddHAB_lblAgregarHaber
        '
        Me.AddHAB_lblAgregarHaber.BackColor = System.Drawing.Color.White
        Me.AddHAB_lblAgregarHaber.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AddHAB_lblAgregarHaber.FlatAppearance.BorderSize = 0
        Me.AddHAB_lblAgregarHaber.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AddHAB_lblAgregarHaber.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AddHAB_lblAgregarHaber.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddHAB_lblAgregarHaber.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddHAB_lblAgregarHaber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.AddHAB_lblAgregarHaber.Image = CType(resources.GetObject("AddHAB_lblAgregarHaber.Image"), System.Drawing.Image)
        Me.AddHAB_lblAgregarHaber.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.AddHAB_lblAgregarHaber.Location = New System.Drawing.Point(6, 17)
        Me.AddHAB_lblAgregarHaber.Name = "AddHAB_lblAgregarHaber"
        Me.AddHAB_lblAgregarHaber.Size = New System.Drawing.Size(270, 53)
        Me.AddHAB_lblAgregarHaber.TabIndex = 45
        Me.AddHAB_lblAgregarHaber.Text = "Agregar haber"
        Me.AddHAB_lblAgregarHaber.UseVisualStyleBackColor = False
        '
        'AddHAB_lblModificarHaberes
        '
        Me.AddHAB_lblModificarHaberes.BackColor = System.Drawing.Color.White
        Me.AddHAB_lblModificarHaberes.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AddHAB_lblModificarHaberes.FlatAppearance.BorderSize = 0
        Me.AddHAB_lblModificarHaberes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AddHAB_lblModificarHaberes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AddHAB_lblModificarHaberes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddHAB_lblModificarHaberes.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddHAB_lblModificarHaberes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.AddHAB_lblModificarHaberes.Image = CType(resources.GetObject("AddHAB_lblModificarHaberes.Image"), System.Drawing.Image)
        Me.AddHAB_lblModificarHaberes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.AddHAB_lblModificarHaberes.Location = New System.Drawing.Point(3, 17)
        Me.AddHAB_lblModificarHaberes.Name = "AddHAB_lblModificarHaberes"
        Me.AddHAB_lblModificarHaberes.Size = New System.Drawing.Size(296, 53)
        Me.AddHAB_lblModificarHaberes.TabIndex = 57
        Me.AddHAB_lblModificarHaberes.Text = "Modificar haberes"
        Me.AddHAB_lblModificarHaberes.UseVisualStyleBackColor = False
        '
        'ElimHAB_lblEliminarHaberes
        '
        Me.ElimHAB_lblEliminarHaberes.BackColor = System.Drawing.Color.White
        Me.ElimHAB_lblEliminarHaberes.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ElimHAB_lblEliminarHaberes.FlatAppearance.BorderSize = 0
        Me.ElimHAB_lblEliminarHaberes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ElimHAB_lblEliminarHaberes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ElimHAB_lblEliminarHaberes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ElimHAB_lblEliminarHaberes.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimHAB_lblEliminarHaberes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.ElimHAB_lblEliminarHaberes.Image = CType(resources.GetObject("ElimHAB_lblEliminarHaberes.Image"), System.Drawing.Image)
        Me.ElimHAB_lblEliminarHaberes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ElimHAB_lblEliminarHaberes.Location = New System.Drawing.Point(3, 17)
        Me.ElimHAB_lblEliminarHaberes.Name = "ElimHAB_lblEliminarHaberes"
        Me.ElimHAB_lblEliminarHaberes.Size = New System.Drawing.Size(296, 53)
        Me.ElimHAB_lblEliminarHaberes.TabIndex = 69
        Me.ElimHAB_lblEliminarHaberes.Text = "Eliminar haberes"
        Me.ElimHAB_lblEliminarHaberes.UseVisualStyleBackColor = False
        '
        'VerDESC_lblVerDescuentos
        '
        Me.VerDESC_lblVerDescuentos.BackColor = System.Drawing.Color.White
        Me.VerDESC_lblVerDescuentos.Enabled = False
        Me.VerDESC_lblVerDescuentos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.VerDESC_lblVerDescuentos.FlatAppearance.BorderSize = 0
        Me.VerDESC_lblVerDescuentos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.VerDESC_lblVerDescuentos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.VerDESC_lblVerDescuentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.VerDESC_lblVerDescuentos.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VerDESC_lblVerDescuentos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.VerDESC_lblVerDescuentos.Image = CType(resources.GetObject("VerDESC_lblVerDescuentos.Image"), System.Drawing.Image)
        Me.VerDESC_lblVerDescuentos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.VerDESC_lblVerDescuentos.Location = New System.Drawing.Point(6, 9)
        Me.VerDESC_lblVerDescuentos.Name = "VerDESC_lblVerDescuentos"
        Me.VerDESC_lblVerDescuentos.Size = New System.Drawing.Size(239, 53)
        Me.VerDESC_lblVerDescuentos.TabIndex = 36
        Me.VerDESC_lblVerDescuentos.Text = "Ver descuentos"
        Me.VerDESC_lblVerDescuentos.UseVisualStyleBackColor = False
        '
        'inftrabajador
        '
        Me.inftrabajador.BackColor = System.Drawing.Color.White
        Me.inftrabajador.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatAppearance.BorderSize = 0
        Me.inftrabajador.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.inftrabajador.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.inftrabajador.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.inftrabajador.Image = CType(resources.GetObject("inftrabajador.Image"), System.Drawing.Image)
        Me.inftrabajador.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.inftrabajador.Location = New System.Drawing.Point(6, 9)
        Me.inftrabajador.Name = "inftrabajador"
        Me.inftrabajador.Size = New System.Drawing.Size(270, 53)
        Me.inftrabajador.TabIndex = 34
        Me.inftrabajador.Text = "Agregar descuento"
        Me.inftrabajador.UseVisualStyleBackColor = False
        '
        'ModDESC_lblModificarDescuentos
        '
        Me.ModDESC_lblModificarDescuentos.BackColor = System.Drawing.Color.White
        Me.ModDESC_lblModificarDescuentos.Enabled = False
        Me.ModDESC_lblModificarDescuentos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ModDESC_lblModificarDescuentos.FlatAppearance.BorderSize = 0
        Me.ModDESC_lblModificarDescuentos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ModDESC_lblModificarDescuentos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ModDESC_lblModificarDescuentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ModDESC_lblModificarDescuentos.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModDESC_lblModificarDescuentos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.ModDESC_lblModificarDescuentos.Image = CType(resources.GetObject("ModDESC_lblModificarDescuentos.Image"), System.Drawing.Image)
        Me.ModDESC_lblModificarDescuentos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ModDESC_lblModificarDescuentos.Location = New System.Drawing.Point(3, 9)
        Me.ModDESC_lblModificarDescuentos.Name = "ModDESC_lblModificarDescuentos"
        Me.ModDESC_lblModificarDescuentos.Size = New System.Drawing.Size(296, 53)
        Me.ModDESC_lblModificarDescuentos.TabIndex = 46
        Me.ModDESC_lblModificarDescuentos.Text = "Modificar descuentos"
        Me.ModDESC_lblModificarDescuentos.UseVisualStyleBackColor = False
        '
        'ElimDESC_lblEliminarDescuentos
        '
        Me.ElimDESC_lblEliminarDescuentos.BackColor = System.Drawing.Color.White
        Me.ElimDESC_lblEliminarDescuentos.Enabled = False
        Me.ElimDESC_lblEliminarDescuentos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ElimDESC_lblEliminarDescuentos.FlatAppearance.BorderSize = 0
        Me.ElimDESC_lblEliminarDescuentos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ElimDESC_lblEliminarDescuentos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ElimDESC_lblEliminarDescuentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ElimDESC_lblEliminarDescuentos.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElimDESC_lblEliminarDescuentos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.ElimDESC_lblEliminarDescuentos.Image = CType(resources.GetObject("ElimDESC_lblEliminarDescuentos.Image"), System.Drawing.Image)
        Me.ElimDESC_lblEliminarDescuentos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ElimDESC_lblEliminarDescuentos.Location = New System.Drawing.Point(3, 9)
        Me.ElimDESC_lblEliminarDescuentos.Name = "ElimDESC_lblEliminarDescuentos"
        Me.ElimDESC_lblEliminarDescuentos.Size = New System.Drawing.Size(296, 53)
        Me.ElimDESC_lblEliminarDescuentos.TabIndex = 69
        Me.ElimDESC_lblEliminarDescuentos.Text = "Eliminar descuentos"
        Me.ElimDESC_lblEliminarDescuentos.UseVisualStyleBackColor = False
        '
        'Admin_Conceptos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(818, 442)
        Me.Controls.Add(Me.pnlCentral)
        Me.Controls.Add(Me.pnlIzq)
        Me.Controls.Add(Me.pnlInf)
        Me.Controls.Add(Me.pnlDer)
        Me.Controls.Add(Me.pnlSup)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_Conceptos"
        Me.Text = "Admin_Conceptos"
        Me.pnlCentral.ResumeLayout(False)
        Me.pnlBotones.ResumeLayout(False)
        Me.TabControl_HaberesDescuentos.ResumeLayout(False)
        Me.TabPage_Haberes.ResumeLayout(False)
        Me.HAB_pnlBotones.ResumeLayout(False)
        Me.TabControl_MangeHaberes.ResumeLayout(False)
        Me.HAB_TabPage_Ver.ResumeLayout(False)
        Me.HAB_TabPage_Ver.PerformLayout()
        Me.HAB_TabPage_Agregar.ResumeLayout(False)
        Me.HAB_TabPage_Agregar.PerformLayout()
        Me.HAB_TabPage_Modificar.ResumeLayout(False)
        Me.HAB_TabPage_Modificar.PerformLayout()
        Me.HAB_TabPage_Eliminar.ResumeLayout(False)
        Me.HAB_TabPage_Eliminar.PerformLayout()
        Me.TabPage_Descuentos.ResumeLayout(False)
        Me.DESC_pnlBotones.ResumeLayout(False)
        Me.TabControl_ManageDescuentos.ResumeLayout(False)
        Me.DESC_TabPageVer.ResumeLayout(False)
        Me.DESC_TabPageVer.PerformLayout()
        Me.DESC_TabPageAgregar.ResumeLayout(False)
        Me.DESC_TabPageAgregar.PerformLayout()
        Me.DESC_TabPageModificar.ResumeLayout(False)
        Me.DESC_TabPageModificar.PerformLayout()
        Me.DESC_TabPageEliminar.ResumeLayout(False)
        Me.DESC_TabPageEliminar.PerformLayout()
        CType(Me.TaxDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TaxDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlSup As System.Windows.Forms.Panel
    Friend WithEvents pnlDer As System.Windows.Forms.Panel
    Friend WithEvents pnlInf As System.Windows.Forms.Panel
    Friend WithEvents pnlIzq As System.Windows.Forms.Panel
    Friend WithEvents pnlCentral As System.Windows.Forms.Panel
    Friend WithEvents TabControl_HaberesDescuentos As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_Haberes As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_Descuentos As System.Windows.Forms.TabPage
    Friend WithEvents pnlBotones As System.Windows.Forms.Panel
    Friend WithEvents HAB_pnlBotones As System.Windows.Forms.Panel
    Friend WithEvents TabControl_MangeHaberes As System.Windows.Forms.TabControl
    Friend WithEvents HAB_TabPage_Ver As System.Windows.Forms.TabPage
    Friend WithEvents HAB_TabPage_Agregar As System.Windows.Forms.TabPage
    Friend WithEvents HAB_TabPage_Modificar As System.Windows.Forms.TabPage
    Friend WithEvents HAB_TabPage_Eliminar As System.Windows.Forms.TabPage
    Friend WithEvents btnDescuentos As System.Windows.Forms.Button
    Friend WithEvents btnHaberes As System.Windows.Forms.Button
    Friend WithEvents HAB_btnEliminar As System.Windows.Forms.Button
    Friend WithEvents HAB_btnModificar As System.Windows.Forms.Button
    Friend WithEvents HAB_btnAgregar As System.Windows.Forms.Button
    Friend WithEvents HAB_btnVer As System.Windows.Forms.Button
    Friend WithEvents DESC_pnlBotones As System.Windows.Forms.Panel
    Friend WithEvents TabControl_ManageDescuentos As System.Windows.Forms.TabControl
    Friend WithEvents DESC_TabPageVer As System.Windows.Forms.TabPage
    Friend WithEvents DESC_TabPageAgregar As System.Windows.Forms.TabPage
    Friend WithEvents DESC_btnEliminar As System.Windows.Forms.Button
    Friend WithEvents DESC_btnModificar As System.Windows.Forms.Button
    Friend WithEvents DESC_btnAgregar As System.Windows.Forms.Button
    Friend WithEvents DESC_btnVer As System.Windows.Forms.Button
    Friend WithEvents DESC_TabPageModificar As System.Windows.Forms.TabPage
    Friend WithEvents DESC_TabPageEliminar As System.Windows.Forms.TabPage
    Friend WithEvents pnlSelection As System.Windows.Forms.Panel
    Friend WithEvents pnlBotonesGris As System.Windows.Forms.Panel
    Friend WithEvents HAB_pnlGris As System.Windows.Forms.Panel
    Friend WithEvents HAB_pnlSelection As System.Windows.Forms.Panel
    Friend WithEvents TaxDataSet As TAX.taxDataSet
    Friend WithEvents TaxDataSetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents AddDESC_rbValorFijo As System.Windows.Forms.RadioButton
    Friend WithEvents inftrabajador As System.Windows.Forms.Button
    Friend WithEvents AddDESC_txtValor As System.Windows.Forms.TextBox
    Friend WithEvents AddDESC_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents AddDESC_lblPorcentaje As System.Windows.Forms.Label
    Friend WithEvents AddDESC_lblValor As System.Windows.Forms.Label
    Friend WithEvents AddDESC_lblNombre As System.Windows.Forms.Label
    Friend WithEvents AddDESC_rbPorcentaje As System.Windows.Forms.RadioButton
    Friend WithEvents DESC_pnlGris As System.Windows.Forms.Panel
    Friend WithEvents DESC_pnlSelection As System.Windows.Forms.Panel
    Friend WithEvents VerDesc_cbDescuentos As System.Windows.Forms.ComboBox
    Friend WithEvents VerDESC_lblVerDescuentos As System.Windows.Forms.Button
    Friend WithEvents VerDesc_txtTipo As System.Windows.Forms.TextBox
    Friend WithEvents VerDesc_txtValor As System.Windows.Forms.TextBox
    Friend WithEvents VerDesc_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents VerDesc_txtID As System.Windows.Forms.TextBox
    Friend WithEvents VerDesc_lblTipo As System.Windows.Forms.Label
    Friend WithEvents VerDesc_lblValor As System.Windows.Forms.Label
    Friend WithEvents VerDesc_lblNombre As System.Windows.Forms.Label
    Friend WithEvents VerDesc_lblID As System.Windows.Forms.Label
    Friend WithEvents ModDesc_cbDescuentos As System.Windows.Forms.ComboBox
    Friend WithEvents ModDESC_lblModificarDescuentos As System.Windows.Forms.Button
    Friend WithEvents ModDesc_txtValor As System.Windows.Forms.TextBox
    Friend WithEvents ModDesc_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents ModDesc_txtID As System.Windows.Forms.TextBox
    Friend WithEvents ModDesc_lblTipo As System.Windows.Forms.Label
    Friend WithEvents ModDesc_lblValor As System.Windows.Forms.Label
    Friend WithEvents ModDesc_lblNombre As System.Windows.Forms.Label
    Friend WithEvents ModDesc_lblID As System.Windows.Forms.Label
    Friend WithEvents ModDesc_btnAceptar As System.Windows.Forms.Button
    Friend WithEvents ModDesc_cbTipo As System.Windows.Forms.ComboBox
    Friend WithEvents AddDESC_btnAgregar As System.Windows.Forms.Button
    Friend WithEvents AddDESC_lblPorciento As System.Windows.Forms.Label
    Friend WithEvents AddDESC_lblPesos As System.Windows.Forms.Label
    Friend WithEvents AddHAB_lblPorciento As System.Windows.Forms.Label
    Friend WithEvents AddHAB_lblPesos As System.Windows.Forms.Label
    Friend WithEvents AddHAB_btnAgregar As System.Windows.Forms.Button
    Friend WithEvents AddHAB_rbPorcentaje As System.Windows.Forms.RadioButton
    Friend WithEvents AddHAB_rbValorFijo As System.Windows.Forms.RadioButton
    Friend WithEvents AddHAB_lblAgregarHaber As System.Windows.Forms.Button
    Friend WithEvents AddHAB_txtValor As System.Windows.Forms.TextBox
    Friend WithEvents AddHAB_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents AddHAB_lblPorcentaje As System.Windows.Forms.Label
    Friend WithEvents AddHAB_lblValor As System.Windows.Forms.Label
    Friend WithEvents AddHAB_lblNombre As System.Windows.Forms.Label
    Friend WithEvents VerHAB_lblVerHaberes As System.Windows.Forms.Button
    Friend WithEvents VerHAB_txtTipo As System.Windows.Forms.TextBox
    Friend WithEvents VerHAB_txtValor As System.Windows.Forms.TextBox
    Friend WithEvents VerHAB_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents VerHAB_txtId As System.Windows.Forms.TextBox
    Friend WithEvents VerHAB_lblTipo As System.Windows.Forms.Label
    Friend WithEvents VerHAB_lblValor As System.Windows.Forms.Label
    Friend WithEvents VerHAB_lblNombre As System.Windows.Forms.Label
    Friend WithEvents VerHAB_lblId As System.Windows.Forms.Label
    Friend WithEvents VerHAB_cbHaberes As System.Windows.Forms.ComboBox
    Friend WithEvents ModHAB_btnModificar As System.Windows.Forms.Button
    Friend WithEvents ModHAB_cbTipo As System.Windows.Forms.ComboBox
    Friend WithEvents AddHAB_lblModificarHaberes As System.Windows.Forms.Button
    Friend WithEvents ModHAB_txtValor As System.Windows.Forms.TextBox
    Friend WithEvents ModHAB_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents ModHAB_txtID As System.Windows.Forms.TextBox
    Friend WithEvents ModHAB_lblTipo As System.Windows.Forms.Label
    Friend WithEvents ModHAB_lblValor As System.Windows.Forms.Label
    Friend WithEvents ModHAB_lblNombre As System.Windows.Forms.Label
    Friend WithEvents ModHAB_lblId As System.Windows.Forms.Label
    Friend WithEvents ModHAB_cbHaberes As System.Windows.Forms.ComboBox
    Friend WithEvents ElimDESC_txtTipo As System.Windows.Forms.TextBox
    Friend WithEvents ElimDESC_btnEliminar As System.Windows.Forms.Button
    Friend WithEvents ElimDESC_lblEliminarDescuentos As System.Windows.Forms.Button
    Friend WithEvents ElimDESC_txtValor As System.Windows.Forms.TextBox
    Friend WithEvents ElimDESC_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents ElimDESC_txtID As System.Windows.Forms.TextBox
    Friend WithEvents ElimDESC_lblTipo As System.Windows.Forms.Label
    Friend WithEvents ElimDESC_lblValor As System.Windows.Forms.Label
    Friend WithEvents ElimDESC_lblNombre As System.Windows.Forms.Label
    Friend WithEvents ElimDESC_lblID As System.Windows.Forms.Label
    Friend WithEvents ElimDESC_cbDescuentos As System.Windows.Forms.ComboBox
    Friend WithEvents ElimHAB_txtTipo As System.Windows.Forms.TextBox
    Friend WithEvents ElimHAB_btnEliminar As System.Windows.Forms.Button
    Friend WithEvents ElimHAB_lblEliminarHaberes As System.Windows.Forms.Button
    Friend WithEvents ElimHAB_txtValor As System.Windows.Forms.TextBox
    Friend WithEvents ElimHAB_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents ElimHAB_txtId As System.Windows.Forms.TextBox
    Friend WithEvents ElimHAB_lblTipo As System.Windows.Forms.Label
    Friend WithEvents ElimHAB_lblValor As System.Windows.Forms.Label
    Friend WithEvents ElimHAB_lblNombre As System.Windows.Forms.Label
    Friend WithEvents ElimHAB_lblId As System.Windows.Forms.Label
    Friend WithEvents ElimHAB_cbHaberes As System.Windows.Forms.ComboBox
End Class
