﻿Public Class eliminar
    Private Sub cmdinicio_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdinicio.Click
        inicioadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdficha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdficha.Click
        ficharoja.Show()
        Me.Close()

    End Sub

    Private Sub cmdrecibo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdrecibo.Click
        mireciboadmin.Show()
        Me.Close()

    End Sub

    Private Sub cmdliquidar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdliquidar.Click
        sueldos.Show()
        Me.Close()

    End Sub

    Private Sub cmdagregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdagregar.Click
        empleados.Show()
        Me.Close()

    End Sub

    Private Sub cmdmodificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdmodificar.Click
        modificar.Show()
        Me.Close()

    End Sub

    Private Sub cmdlistar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdlistar.Click
        listar.Show()
        Me.Close()

    End Sub

    Private Sub cmdayuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdayuda.Click
        MsgBox("En Progreso")
    End Sub

    Private Sub txtcedula_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcedula.TextChanged

        If Not (IsNumeric(txtcedula.Text)) Then
            MsgBox("Cedula: Solo se admiten numeros")
            txtcedula.Text = ""
            txtcedula.Focus()
        End If

        If Not (IsNumeric(txtnumeroregistro.Text)) Then
            MsgBox("Número de Registro: Solo se admiten numeros")
            txtnumeroregistro.Text = ""
            txtnumeroregistro.Focus()
        End If

    End Sub
End Class