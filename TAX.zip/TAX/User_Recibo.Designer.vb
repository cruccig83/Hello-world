﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class User_Recibo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(User_Recibo))
        Me.panelup = New System.Windows.Forms.Panel
        Me.paneldown = New System.Windows.Forms.Panel
        Me.panelder = New System.Windows.Forms.Panel
        Me.panelizq = New System.Windows.Forms.Panel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelup
        '
        Me.panelup.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.panelup.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelup.Location = New System.Drawing.Point(0, 0)
        Me.panelup.Name = "panelup"
        Me.panelup.Size = New System.Drawing.Size(842, 20)
        Me.panelup.TabIndex = 0
        '
        'paneldown
        '
        Me.paneldown.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.paneldown.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.paneldown.Location = New System.Drawing.Point(0, 489)
        Me.paneldown.Name = "paneldown"
        Me.paneldown.Size = New System.Drawing.Size(842, 20)
        Me.paneldown.TabIndex = 1
        '
        'panelder
        '
        Me.panelder.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.panelder.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelder.Location = New System.Drawing.Point(822, 20)
        Me.panelder.Name = "panelder"
        Me.panelder.Size = New System.Drawing.Size(20, 469)
        Me.panelder.TabIndex = 2
        '
        'panelizq
        '
        Me.panelizq.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.panelizq.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelizq.Location = New System.Drawing.Point(0, 20)
        Me.panelizq.Name = "panelizq"
        Me.panelizq.Size = New System.Drawing.Size(20, 469)
        Me.panelizq.TabIndex = 3
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(20, 20)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(802, 469)
        Me.Panel1.TabIndex = 4
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 134)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(528, 329)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'iniciouserrecibo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(842, 509)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.panelizq)
        Me.Controls.Add(Me.panelder)
        Me.Controls.Add(Me.paneldown)
        Me.Controls.Add(Me.panelup)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "iniciouserrecibo"
        Me.Text = "iniciouserrecibo"
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelup As System.Windows.Forms.Panel
    Friend WithEvents paneldown As System.Windows.Forms.Panel
    Friend WithEvents panelder As System.Windows.Forms.Panel
    Friend WithEvents panelizq As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
