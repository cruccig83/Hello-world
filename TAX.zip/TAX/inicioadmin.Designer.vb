﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class inicioadmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(inicioadmin))
        Me.cmdficha = New System.Windows.Forms.Button
        Me.cmdrecibo = New System.Windows.Forms.Button
        Me.cmdempleados = New System.Windows.Forms.Button
        Me.cmdsueldos = New System.Windows.Forms.Button
        Me.cmdsueldogrande = New System.Windows.Forms.Button
        Me.cmdempleadogrande = New System.Windows.Forms.Button
        Me.cmdfichachica = New System.Windows.Forms.Button
        Me.cmdayuda = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cmdficha
        '
        Me.cmdficha.BackColor = System.Drawing.Color.Transparent
        Me.cmdficha.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdficha.Location = New System.Drawing.Point(12, 178)
        Me.cmdficha.Name = "cmdficha"
        Me.cmdficha.Size = New System.Drawing.Size(118, 27)
        Me.cmdficha.TabIndex = 1
        Me.cmdficha.UseVisualStyleBackColor = False
        '
        'cmdrecibo
        '
        Me.cmdrecibo.BackColor = System.Drawing.Color.Transparent
        Me.cmdrecibo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdrecibo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdrecibo.Location = New System.Drawing.Point(12, 218)
        Me.cmdrecibo.Name = "cmdrecibo"
        Me.cmdrecibo.Size = New System.Drawing.Size(118, 27)
        Me.cmdrecibo.TabIndex = 2
        Me.cmdrecibo.UseVisualStyleBackColor = False
        '
        'cmdempleados
        '
        Me.cmdempleados.BackColor = System.Drawing.Color.Transparent
        Me.cmdempleados.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdempleados.Location = New System.Drawing.Point(17, 260)
        Me.cmdempleados.Name = "cmdempleados"
        Me.cmdempleados.Size = New System.Drawing.Size(118, 27)
        Me.cmdempleados.TabIndex = 3
        Me.cmdempleados.UseVisualStyleBackColor = False
        '
        'cmdsueldos
        '
        Me.cmdsueldos.BackColor = System.Drawing.Color.Transparent
        Me.cmdsueldos.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdsueldos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdsueldos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdsueldos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdsueldos.Location = New System.Drawing.Point(17, 302)
        Me.cmdsueldos.Name = "cmdsueldos"
        Me.cmdsueldos.Size = New System.Drawing.Size(118, 27)
        Me.cmdsueldos.TabIndex = 4
        Me.cmdsueldos.UseVisualStyleBackColor = False
        '
        'cmdsueldogrande
        '
        Me.cmdsueldogrande.BackColor = System.Drawing.Color.Transparent
        Me.cmdsueldogrande.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdsueldogrande.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdsueldogrande.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdsueldogrande.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdsueldogrande.Location = New System.Drawing.Point(153, 149)
        Me.cmdsueldogrande.Name = "cmdsueldogrande"
        Me.cmdsueldogrande.Size = New System.Drawing.Size(265, 126)
        Me.cmdsueldogrande.TabIndex = 5
        Me.cmdsueldogrande.UseVisualStyleBackColor = False
        '
        'cmdempleadogrande
        '
        Me.cmdempleadogrande.BackColor = System.Drawing.Color.Transparent
        Me.cmdempleadogrande.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleadogrande.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleadogrande.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdempleadogrande.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdempleadogrande.Location = New System.Drawing.Point(157, 299)
        Me.cmdempleadogrande.Name = "cmdempleadogrande"
        Me.cmdempleadogrande.Size = New System.Drawing.Size(265, 159)
        Me.cmdempleadogrande.TabIndex = 6
        Me.cmdempleadogrande.UseVisualStyleBackColor = False
        '
        'cmdfichachica
        '
        Me.cmdfichachica.BackColor = System.Drawing.Color.Transparent
        Me.cmdfichachica.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdfichachica.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdfichachica.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdfichachica.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdfichachica.Location = New System.Drawing.Point(545, 448)
        Me.cmdfichachica.Name = "cmdfichachica"
        Me.cmdfichachica.Size = New System.Drawing.Size(72, 10)
        Me.cmdfichachica.TabIndex = 7
        Me.cmdfichachica.UseVisualStyleBackColor = False
        '
        'cmdayuda
        '
        Me.cmdayuda.BackColor = System.Drawing.Color.Transparent
        Me.cmdayuda.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdayuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdayuda.Location = New System.Drawing.Point(660, 66)
        Me.cmdayuda.Name = "cmdayuda"
        Me.cmdayuda.Size = New System.Drawing.Size(93, 30)
        Me.cmdayuda.TabIndex = 79
        Me.cmdayuda.UseVisualStyleBackColor = False
        '
        'inicioadmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(776, 560)
        Me.Controls.Add(Me.cmdayuda)
        Me.Controls.Add(Me.cmdfichachica)
        Me.Controls.Add(Me.cmdempleadogrande)
        Me.Controls.Add(Me.cmdsueldogrande)
        Me.Controls.Add(Me.cmdsueldos)
        Me.Controls.Add(Me.cmdempleados)
        Me.Controls.Add(Me.cmdrecibo)
        Me.Controls.Add(Me.cmdficha)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "inicioadmin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TAX"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdficha As System.Windows.Forms.Button
    Friend WithEvents cmdrecibo As System.Windows.Forms.Button
    Friend WithEvents cmdempleados As System.Windows.Forms.Button
    Friend WithEvents cmdsueldos As System.Windows.Forms.Button
    Friend WithEvents cmdsueldogrande As System.Windows.Forms.Button
    Friend WithEvents cmdempleadogrande As System.Windows.Forms.Button
    Friend WithEvents cmdfichachica As System.Windows.Forms.Button
    Friend WithEvents cmdayuda As System.Windows.Forms.Button
End Class
