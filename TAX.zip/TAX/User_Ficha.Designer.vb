﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class User_Ficha
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(User_Ficha))
        Me.tabcontrolficha = New System.Windows.Forms.TabControl
        Me.tabpageficha = New System.Windows.Forms.TabPage
        Me.FICHA_txtDirNumero = New System.Windows.Forms.TextBox
        Me.Ficha_lblEspacio = New System.Windows.Forms.Label
        Me.FICHA_txtFijo = New System.Windows.Forms.TextBox
        Me.FICHA_txtCelular = New System.Windows.Forms.TextBox
        Me.FICHA_txtHijos = New System.Windows.Forms.TextBox
        Me.FICHA_txtEmail = New System.Windows.Forms.TextBox
        Me.FICHA_txtEstCivil = New System.Windows.Forms.TextBox
        Me.FICHA_txtCalle = New System.Windows.Forms.TextBox
        Me.FICHA_txtFNacimiento = New System.Windows.Forms.TextBox
        Me.FICHA_txtSexo = New System.Windows.Forms.TextBox
        Me.FICHA_txtContraseña = New System.Windows.Forms.TextBox
        Me.FICHA_txtApellido = New System.Windows.Forms.TextBox
        Me.FICHA_txtNombre = New System.Windows.Forms.TextBox
        Me.FICHA_lblFijo = New System.Windows.Forms.Label
        Me.FICHA_lblCelular = New System.Windows.Forms.Label
        Me.FICHA_lblHijos = New System.Windows.Forms.Label
        Me.FICHA_lblEmail = New System.Windows.Forms.Label
        Me.FICHA_lblEstCivil = New System.Windows.Forms.Label
        Me.FICHA_lblDireccion = New System.Windows.Forms.Label
        Me.FICHA_lblFNacimiento = New System.Windows.Forms.Label
        Me.FICHA_lblSexo = New System.Windows.Forms.Label
        Me.FICHA_lblContraseña = New System.Windows.Forms.Label
        Me.FICHA_lblApellido = New System.Windows.Forms.Label
        Me.FICHA_lblNombre = New System.Windows.Forms.Label
        Me.FICHA_txtDocumento = New System.Windows.Forms.TextBox
        Me.FICHA_lblDocumento = New System.Windows.Forms.Label
        Me.tabpageorganizacion = New System.Windows.Forms.TabPage
        Me.buttonpanel = New System.Windows.Forms.Panel
        Me.pnlBarraGris = New System.Windows.Forms.Panel
        Me.pnlSelection = New System.Windows.Forms.Panel
        Me.panel_izq = New System.Windows.Forms.Panel
        Me.panel_izq2 = New System.Windows.Forms.Panel
        Me.panel_der = New System.Windows.Forms.Panel
        Me.panel_down = New System.Windows.Forms.Panel
        Me.panel_down2 = New System.Windows.Forms.Panel
        Me.panel_up = New System.Windows.Forms.Panel
        Me.ORG_txtMailEmpresarial = New System.Windows.Forms.TextBox
        Me.ORG_txtTlfEmpresarial = New System.Windows.Forms.TextBox
        Me.ORG_txtDepartamento = New System.Windows.Forms.TextBox
        Me.ORG_txtGrado = New System.Windows.Forms.TextBox
        Me.ORG_txtCargo = New System.Windows.Forms.TextBox
        Me.ORG_txtFIngreso = New System.Windows.Forms.TextBox
        Me.ORG_txtNRegistro = New System.Windows.Forms.TextBox
        Me.ORG_lblEmailEmpresarial = New System.Windows.Forms.Label
        Me.ORG_lblTelfEmpresarial = New System.Windows.Forms.Label
        Me.ORG_lblDepartamento = New System.Windows.Forms.Label
        Me.ORG_lblGrado = New System.Windows.Forms.Label
        Me.ORG_lblCargo = New System.Windows.Forms.Label
        Me.ORG_lblFIngreso = New System.Windows.Forms.Label
        Me.ORG_lblNRegistro = New System.Windows.Forms.Label
        Me.ORG_txtRUT = New System.Windows.Forms.TextBox
        Me.ORG_lblRUT = New System.Windows.Forms.Label
        Me.btnorganizacion = New System.Windows.Forms.Button
        Me.btnficha = New System.Windows.Forms.Button
        Me.FICHA_btnCambioContraseña = New System.Windows.Forms.Button
        Me.inftrabajador = New System.Windows.Forms.Button
        Me.ORG_lblInfEmpresarial = New System.Windows.Forms.Button
        Me.tabcontrolficha.SuspendLayout()
        Me.tabpageficha.SuspendLayout()
        Me.tabpageorganizacion.SuspendLayout()
        Me.buttonpanel.SuspendLayout()
        Me.pnlBarraGris.SuspendLayout()
        Me.panel_izq.SuspendLayout()
        Me.panel_down.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabcontrolficha
        '
        Me.tabcontrolficha.Controls.Add(Me.tabpageficha)
        Me.tabcontrolficha.Controls.Add(Me.tabpageorganizacion)
        Me.tabcontrolficha.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabcontrolficha.Location = New System.Drawing.Point(13, 20)
        Me.tabcontrolficha.Margin = New System.Windows.Forms.Padding(0)
        Me.tabcontrolficha.Name = "tabcontrolficha"
        Me.tabcontrolficha.Padding = New System.Drawing.Point(6, 22)
        Me.tabcontrolficha.SelectedIndex = 0
        Me.tabcontrolficha.Size = New System.Drawing.Size(816, 469)
        Me.tabcontrolficha.TabIndex = 0
        '
        'tabpageficha
        '
        Me.tabpageficha.AutoScroll = True
        Me.tabpageficha.Controls.Add(Me.FICHA_btnCambioContraseña)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtDirNumero)
        Me.tabpageficha.Controls.Add(Me.Ficha_lblEspacio)
        Me.tabpageficha.Controls.Add(Me.inftrabajador)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtFijo)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtCelular)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtHijos)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtEmail)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtEstCivil)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtCalle)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtFNacimiento)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtSexo)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtContraseña)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtApellido)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtNombre)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblFijo)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblCelular)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblHijos)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblEmail)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblEstCivil)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblDireccion)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblFNacimiento)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblSexo)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblContraseña)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblApellido)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblNombre)
        Me.tabpageficha.Controls.Add(Me.FICHA_txtDocumento)
        Me.tabpageficha.Controls.Add(Me.FICHA_lblDocumento)
        Me.tabpageficha.Location = New System.Drawing.Point(4, 60)
        Me.tabpageficha.Name = "tabpageficha"
        Me.tabpageficha.Padding = New System.Windows.Forms.Padding(3)
        Me.tabpageficha.Size = New System.Drawing.Size(808, 405)
        Me.tabpageficha.TabIndex = 0
        Me.tabpageficha.Text = "TabPage1"
        Me.tabpageficha.UseVisualStyleBackColor = True
        '
        'FICHA_txtDirNumero
        '
        Me.FICHA_txtDirNumero.BackColor = System.Drawing.Color.White
        Me.FICHA_txtDirNumero.Enabled = False
        Me.FICHA_txtDirNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtDirNumero.Location = New System.Drawing.Point(345, 250)
        Me.FICHA_txtDirNumero.Name = "FICHA_txtDirNumero"
        Me.FICHA_txtDirNumero.ReadOnly = True
        Me.FICHA_txtDirNumero.Size = New System.Drawing.Size(65, 20)
        Me.FICHA_txtDirNumero.TabIndex = 55
        '
        'Ficha_lblEspacio
        '
        Me.Ficha_lblEspacio.AutoSize = True
        Me.Ficha_lblEspacio.Enabled = False
        Me.Ficha_lblEspacio.Location = New System.Drawing.Point(448, 412)
        Me.Ficha_lblEspacio.Name = "Ficha_lblEspacio"
        Me.Ficha_lblEspacio.Size = New System.Drawing.Size(0, 13)
        Me.Ficha_lblEspacio.TabIndex = 54
        '
        'FICHA_txtFijo
        '
        Me.FICHA_txtFijo.BackColor = System.Drawing.Color.White
        Me.FICHA_txtFijo.Enabled = False
        Me.FICHA_txtFijo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtFijo.Location = New System.Drawing.Point(278, 395)
        Me.FICHA_txtFijo.Name = "FICHA_txtFijo"
        Me.FICHA_txtFijo.ReadOnly = True
        Me.FICHA_txtFijo.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtFijo.TabIndex = 52
        '
        'FICHA_txtCelular
        '
        Me.FICHA_txtCelular.BackColor = System.Drawing.Color.White
        Me.FICHA_txtCelular.Enabled = False
        Me.FICHA_txtCelular.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtCelular.Location = New System.Drawing.Point(278, 366)
        Me.FICHA_txtCelular.Name = "FICHA_txtCelular"
        Me.FICHA_txtCelular.ReadOnly = True
        Me.FICHA_txtCelular.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtCelular.TabIndex = 51
        '
        'FICHA_txtHijos
        '
        Me.FICHA_txtHijos.BackColor = System.Drawing.Color.White
        Me.FICHA_txtHijos.Enabled = False
        Me.FICHA_txtHijos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtHijos.Location = New System.Drawing.Point(278, 337)
        Me.FICHA_txtHijos.Name = "FICHA_txtHijos"
        Me.FICHA_txtHijos.ReadOnly = True
        Me.FICHA_txtHijos.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtHijos.TabIndex = 50
        '
        'FICHA_txtEmail
        '
        Me.FICHA_txtEmail.BackColor = System.Drawing.Color.White
        Me.FICHA_txtEmail.Enabled = False
        Me.FICHA_txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtEmail.Location = New System.Drawing.Point(278, 308)
        Me.FICHA_txtEmail.Name = "FICHA_txtEmail"
        Me.FICHA_txtEmail.ReadOnly = True
        Me.FICHA_txtEmail.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtEmail.TabIndex = 49
        '
        'FICHA_txtEstCivil
        '
        Me.FICHA_txtEstCivil.BackColor = System.Drawing.Color.White
        Me.FICHA_txtEstCivil.Enabled = False
        Me.FICHA_txtEstCivil.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtEstCivil.Location = New System.Drawing.Point(278, 279)
        Me.FICHA_txtEstCivil.Name = "FICHA_txtEstCivil"
        Me.FICHA_txtEstCivil.ReadOnly = True
        Me.FICHA_txtEstCivil.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtEstCivil.TabIndex = 48
        '
        'FICHA_txtCalle
        '
        Me.FICHA_txtCalle.BackColor = System.Drawing.Color.White
        Me.FICHA_txtCalle.Enabled = False
        Me.FICHA_txtCalle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtCalle.Location = New System.Drawing.Point(278, 250)
        Me.FICHA_txtCalle.Name = "FICHA_txtCalle"
        Me.FICHA_txtCalle.ReadOnly = True
        Me.FICHA_txtCalle.Size = New System.Drawing.Size(65, 20)
        Me.FICHA_txtCalle.TabIndex = 47
        '
        'FICHA_txtFNacimiento
        '
        Me.FICHA_txtFNacimiento.BackColor = System.Drawing.Color.White
        Me.FICHA_txtFNacimiento.Enabled = False
        Me.FICHA_txtFNacimiento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtFNacimiento.Location = New System.Drawing.Point(278, 221)
        Me.FICHA_txtFNacimiento.Name = "FICHA_txtFNacimiento"
        Me.FICHA_txtFNacimiento.ReadOnly = True
        Me.FICHA_txtFNacimiento.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtFNacimiento.TabIndex = 46
        '
        'FICHA_txtSexo
        '
        Me.FICHA_txtSexo.BackColor = System.Drawing.Color.White
        Me.FICHA_txtSexo.Enabled = False
        Me.FICHA_txtSexo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtSexo.Location = New System.Drawing.Point(278, 192)
        Me.FICHA_txtSexo.Name = "FICHA_txtSexo"
        Me.FICHA_txtSexo.ReadOnly = True
        Me.FICHA_txtSexo.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtSexo.TabIndex = 45
        '
        'FICHA_txtContraseña
        '
        Me.FICHA_txtContraseña.BackColor = System.Drawing.Color.White
        Me.FICHA_txtContraseña.Enabled = False
        Me.FICHA_txtContraseña.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtContraseña.Location = New System.Drawing.Point(278, 163)
        Me.FICHA_txtContraseña.Name = "FICHA_txtContraseña"
        Me.FICHA_txtContraseña.ReadOnly = True
        Me.FICHA_txtContraseña.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtContraseña.TabIndex = 44
        '
        'FICHA_txtApellido
        '
        Me.FICHA_txtApellido.BackColor = System.Drawing.Color.White
        Me.FICHA_txtApellido.Enabled = False
        Me.FICHA_txtApellido.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtApellido.Location = New System.Drawing.Point(278, 134)
        Me.FICHA_txtApellido.Name = "FICHA_txtApellido"
        Me.FICHA_txtApellido.ReadOnly = True
        Me.FICHA_txtApellido.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtApellido.TabIndex = 43
        '
        'FICHA_txtNombre
        '
        Me.FICHA_txtNombre.BackColor = System.Drawing.Color.White
        Me.FICHA_txtNombre.Enabled = False
        Me.FICHA_txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtNombre.Location = New System.Drawing.Point(278, 105)
        Me.FICHA_txtNombre.Name = "FICHA_txtNombre"
        Me.FICHA_txtNombre.ReadOnly = True
        Me.FICHA_txtNombre.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtNombre.TabIndex = 42
        '
        'FICHA_lblFijo
        '
        Me.FICHA_lblFijo.AutoSize = True
        Me.FICHA_lblFijo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!)
        Me.FICHA_lblFijo.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblFijo.Location = New System.Drawing.Point(117, 397)
        Me.FICHA_lblFijo.Name = "FICHA_lblFijo"
        Me.FICHA_lblFijo.Size = New System.Drawing.Size(79, 17)
        Me.FICHA_lblFijo.TabIndex = 41
        Me.FICHA_lblFijo.Text = "Teléfono fijo:"
        '
        'FICHA_lblCelular
        '
        Me.FICHA_lblCelular.AutoSize = True
        Me.FICHA_lblCelular.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!)
        Me.FICHA_lblCelular.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblCelular.Location = New System.Drawing.Point(116, 368)
        Me.FICHA_lblCelular.Name = "FICHA_lblCelular"
        Me.FICHA_lblCelular.Size = New System.Drawing.Size(99, 17)
        Me.FICHA_lblCelular.TabIndex = 40
        Me.FICHA_lblCelular.Text = "Teléfono celular:"
        '
        'FICHA_lblHijos
        '
        Me.FICHA_lblHijos.AutoSize = True
        Me.FICHA_lblHijos.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblHijos.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblHijos.Location = New System.Drawing.Point(116, 339)
        Me.FICHA_lblHijos.Name = "FICHA_lblHijos"
        Me.FICHA_lblHijos.Size = New System.Drawing.Size(38, 17)
        Me.FICHA_lblHijos.TabIndex = 39
        Me.FICHA_lblHijos.Text = "Hijos:"
        '
        'FICHA_lblEmail
        '
        Me.FICHA_lblEmail.AutoSize = True
        Me.FICHA_lblEmail.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblEmail.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblEmail.Location = New System.Drawing.Point(116, 310)
        Me.FICHA_lblEmail.Name = "FICHA_lblEmail"
        Me.FICHA_lblEmail.Size = New System.Drawing.Size(42, 17)
        Me.FICHA_lblEmail.TabIndex = 38
        Me.FICHA_lblEmail.Text = "Email:"
        '
        'FICHA_lblEstCivil
        '
        Me.FICHA_lblEstCivil.AutoSize = True
        Me.FICHA_lblEstCivil.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblEstCivil.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblEstCivil.Location = New System.Drawing.Point(116, 281)
        Me.FICHA_lblEstCivil.Name = "FICHA_lblEstCivil"
        Me.FICHA_lblEstCivil.Size = New System.Drawing.Size(75, 17)
        Me.FICHA_lblEstCivil.TabIndex = 37
        Me.FICHA_lblEstCivil.Text = "Estado Civil:"
        '
        'FICHA_lblDireccion
        '
        Me.FICHA_lblDireccion.AutoSize = True
        Me.FICHA_lblDireccion.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblDireccion.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblDireccion.Location = New System.Drawing.Point(116, 252)
        Me.FICHA_lblDireccion.Name = "FICHA_lblDireccion"
        Me.FICHA_lblDireccion.Size = New System.Drawing.Size(63, 17)
        Me.FICHA_lblDireccion.TabIndex = 36
        Me.FICHA_lblDireccion.Text = "Dirección:"
        '
        'FICHA_lblFNacimiento
        '
        Me.FICHA_lblFNacimiento.AutoSize = True
        Me.FICHA_lblFNacimiento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblFNacimiento.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblFNacimiento.Location = New System.Drawing.Point(116, 223)
        Me.FICHA_lblFNacimiento.Name = "FICHA_lblFNacimiento"
        Me.FICHA_lblFNacimiento.Size = New System.Drawing.Size(127, 17)
        Me.FICHA_lblFNacimiento.TabIndex = 35
        Me.FICHA_lblFNacimiento.Text = "Fecha de nacimiento:"
        '
        'FICHA_lblSexo
        '
        Me.FICHA_lblSexo.AutoSize = True
        Me.FICHA_lblSexo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblSexo.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblSexo.Location = New System.Drawing.Point(117, 194)
        Me.FICHA_lblSexo.Name = "FICHA_lblSexo"
        Me.FICHA_lblSexo.Size = New System.Drawing.Size(37, 17)
        Me.FICHA_lblSexo.TabIndex = 34
        Me.FICHA_lblSexo.Text = "Sexo:"
        '
        'FICHA_lblContraseña
        '
        Me.FICHA_lblContraseña.AutoSize = True
        Me.FICHA_lblContraseña.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblContraseña.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblContraseña.Location = New System.Drawing.Point(116, 165)
        Me.FICHA_lblContraseña.Name = "FICHA_lblContraseña"
        Me.FICHA_lblContraseña.Size = New System.Drawing.Size(75, 17)
        Me.FICHA_lblContraseña.TabIndex = 33
        Me.FICHA_lblContraseña.Text = "Contraseña:"
        '
        'FICHA_lblApellido
        '
        Me.FICHA_lblApellido.AutoSize = True
        Me.FICHA_lblApellido.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblApellido.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblApellido.Location = New System.Drawing.Point(116, 136)
        Me.FICHA_lblApellido.Name = "FICHA_lblApellido"
        Me.FICHA_lblApellido.Size = New System.Drawing.Size(56, 17)
        Me.FICHA_lblApellido.TabIndex = 32
        Me.FICHA_lblApellido.Text = "Apellido:"
        '
        'FICHA_lblNombre
        '
        Me.FICHA_lblNombre.AutoSize = True
        Me.FICHA_lblNombre.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblNombre.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblNombre.Location = New System.Drawing.Point(116, 107)
        Me.FICHA_lblNombre.Name = "FICHA_lblNombre"
        Me.FICHA_lblNombre.Size = New System.Drawing.Size(55, 17)
        Me.FICHA_lblNombre.TabIndex = 31
        Me.FICHA_lblNombre.Text = "Nombre:"
        '
        'FICHA_txtDocumento
        '
        Me.FICHA_txtDocumento.BackColor = System.Drawing.Color.White
        Me.FICHA_txtDocumento.Enabled = False
        Me.FICHA_txtDocumento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_txtDocumento.Location = New System.Drawing.Point(278, 76)
        Me.FICHA_txtDocumento.Name = "FICHA_txtDocumento"
        Me.FICHA_txtDocumento.ReadOnly = True
        Me.FICHA_txtDocumento.Size = New System.Drawing.Size(132, 20)
        Me.FICHA_txtDocumento.TabIndex = 30
        '
        'FICHA_lblDocumento
        '
        Me.FICHA_lblDocumento.AutoSize = True
        Me.FICHA_lblDocumento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FICHA_lblDocumento.ForeColor = System.Drawing.Color.Black
        Me.FICHA_lblDocumento.Location = New System.Drawing.Point(116, 78)
        Me.FICHA_lblDocumento.Name = "FICHA_lblDocumento"
        Me.FICHA_lblDocumento.Size = New System.Drawing.Size(76, 17)
        Me.FICHA_lblDocumento.TabIndex = 29
        Me.FICHA_lblDocumento.Text = "Documento:"
        '
        'tabpageorganizacion
        '
        Me.tabpageorganizacion.Controls.Add(Me.ORG_txtMailEmpresarial)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_txtTlfEmpresarial)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_txtDepartamento)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_txtGrado)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_txtCargo)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_txtFIngreso)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_txtNRegistro)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_lblEmailEmpresarial)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_lblTelfEmpresarial)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_lblDepartamento)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_lblGrado)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_lblCargo)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_lblFIngreso)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_lblNRegistro)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_txtRUT)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_lblRUT)
        Me.tabpageorganizacion.Controls.Add(Me.ORG_lblInfEmpresarial)
        Me.tabpageorganizacion.Location = New System.Drawing.Point(4, 60)
        Me.tabpageorganizacion.Name = "tabpageorganizacion"
        Me.tabpageorganizacion.Padding = New System.Windows.Forms.Padding(3)
        Me.tabpageorganizacion.Size = New System.Drawing.Size(808, 405)
        Me.tabpageorganizacion.TabIndex = 1
        Me.tabpageorganizacion.Text = "TabPage2"
        Me.tabpageorganizacion.UseVisualStyleBackColor = True
        '
        'buttonpanel
        '
        Me.buttonpanel.BackColor = System.Drawing.Color.White
        Me.buttonpanel.Controls.Add(Me.pnlBarraGris)
        Me.buttonpanel.Controls.Add(Me.btnorganizacion)
        Me.buttonpanel.Controls.Add(Me.btnficha)
        Me.buttonpanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.buttonpanel.Location = New System.Drawing.Point(13, 20)
        Me.buttonpanel.Name = "buttonpanel"
        Me.buttonpanel.Size = New System.Drawing.Size(816, 60)
        Me.buttonpanel.TabIndex = 1
        '
        'pnlBarraGris
        '
        Me.pnlBarraGris.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.pnlBarraGris.Controls.Add(Me.pnlSelection)
        Me.pnlBarraGris.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlBarraGris.Location = New System.Drawing.Point(0, 57)
        Me.pnlBarraGris.Name = "pnlBarraGris"
        Me.pnlBarraGris.Size = New System.Drawing.Size(816, 3)
        Me.pnlBarraGris.TabIndex = 2
        '
        'pnlSelection
        '
        Me.pnlSelection.BackColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.pnlSelection.Location = New System.Drawing.Point(0, 0)
        Me.pnlSelection.Name = "pnlSelection"
        Me.pnlSelection.Size = New System.Drawing.Size(105, 3)
        Me.pnlSelection.TabIndex = 10
        '
        'panel_izq
        '
        Me.panel_izq.Controls.Add(Me.panel_izq2)
        Me.panel_izq.Dock = System.Windows.Forms.DockStyle.Left
        Me.panel_izq.Location = New System.Drawing.Point(0, 0)
        Me.panel_izq.Name = "panel_izq"
        Me.panel_izq.Size = New System.Drawing.Size(13, 509)
        Me.panel_izq.TabIndex = 2
        '
        'panel_izq2
        '
        Me.panel_izq2.Dock = System.Windows.Forms.DockStyle.Right
        Me.panel_izq2.Location = New System.Drawing.Point(0, 0)
        Me.panel_izq2.Name = "panel_izq2"
        Me.panel_izq2.Size = New System.Drawing.Size(13, 509)
        Me.panel_izq2.TabIndex = 3
        '
        'panel_der
        '
        Me.panel_der.Dock = System.Windows.Forms.DockStyle.Right
        Me.panel_der.Location = New System.Drawing.Point(829, 0)
        Me.panel_der.Name = "panel_der"
        Me.panel_der.Size = New System.Drawing.Size(13, 509)
        Me.panel_der.TabIndex = 3
        '
        'panel_down
        '
        Me.panel_down.Controls.Add(Me.panel_down2)
        Me.panel_down.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panel_down.Location = New System.Drawing.Point(13, 489)
        Me.panel_down.Name = "panel_down"
        Me.panel_down.Size = New System.Drawing.Size(816, 20)
        Me.panel_down.TabIndex = 4
        '
        'panel_down2
        '
        Me.panel_down2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panel_down2.Location = New System.Drawing.Point(0, 0)
        Me.panel_down2.Name = "panel_down2"
        Me.panel_down2.Size = New System.Drawing.Size(816, 20)
        Me.panel_down2.TabIndex = 5
        '
        'panel_up
        '
        Me.panel_up.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel_up.Location = New System.Drawing.Point(13, 0)
        Me.panel_up.Name = "panel_up"
        Me.panel_up.Size = New System.Drawing.Size(816, 20)
        Me.panel_up.TabIndex = 6
        '
        'ORG_txtMailEmpresarial
        '
        Me.ORG_txtMailEmpresarial.BackColor = System.Drawing.Color.White
        Me.ORG_txtMailEmpresarial.Enabled = False
        Me.ORG_txtMailEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtMailEmpresarial.Location = New System.Drawing.Point(278, 279)
        Me.ORG_txtMailEmpresarial.Name = "ORG_txtMailEmpresarial"
        Me.ORG_txtMailEmpresarial.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtMailEmpresarial.TabIndex = 67
        '
        'ORG_txtTlfEmpresarial
        '
        Me.ORG_txtTlfEmpresarial.BackColor = System.Drawing.Color.White
        Me.ORG_txtTlfEmpresarial.Enabled = False
        Me.ORG_txtTlfEmpresarial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtTlfEmpresarial.Location = New System.Drawing.Point(278, 250)
        Me.ORG_txtTlfEmpresarial.Name = "ORG_txtTlfEmpresarial"
        Me.ORG_txtTlfEmpresarial.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtTlfEmpresarial.TabIndex = 66
        '
        'ORG_txtDepartamento
        '
        Me.ORG_txtDepartamento.BackColor = System.Drawing.Color.White
        Me.ORG_txtDepartamento.Enabled = False
        Me.ORG_txtDepartamento.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtDepartamento.Location = New System.Drawing.Point(278, 221)
        Me.ORG_txtDepartamento.Name = "ORG_txtDepartamento"
        Me.ORG_txtDepartamento.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtDepartamento.TabIndex = 65
        '
        'ORG_txtGrado
        '
        Me.ORG_txtGrado.BackColor = System.Drawing.Color.White
        Me.ORG_txtGrado.Enabled = False
        Me.ORG_txtGrado.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtGrado.Location = New System.Drawing.Point(278, 192)
        Me.ORG_txtGrado.Name = "ORG_txtGrado"
        Me.ORG_txtGrado.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtGrado.TabIndex = 64
        '
        'ORG_txtCargo
        '
        Me.ORG_txtCargo.BackColor = System.Drawing.Color.White
        Me.ORG_txtCargo.Enabled = False
        Me.ORG_txtCargo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtCargo.Location = New System.Drawing.Point(278, 163)
        Me.ORG_txtCargo.Name = "ORG_txtCargo"
        Me.ORG_txtCargo.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtCargo.TabIndex = 63
        '
        'ORG_txtFIngreso
        '
        Me.ORG_txtFIngreso.BackColor = System.Drawing.Color.White
        Me.ORG_txtFIngreso.Enabled = False
        Me.ORG_txtFIngreso.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtFIngreso.Location = New System.Drawing.Point(278, 134)
        Me.ORG_txtFIngreso.Name = "ORG_txtFIngreso"
        Me.ORG_txtFIngreso.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtFIngreso.TabIndex = 62
        '
        'ORG_txtNRegistro
        '
        Me.ORG_txtNRegistro.BackColor = System.Drawing.Color.White
        Me.ORG_txtNRegistro.Enabled = False
        Me.ORG_txtNRegistro.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtNRegistro.Location = New System.Drawing.Point(278, 105)
        Me.ORG_txtNRegistro.Name = "ORG_txtNRegistro"
        Me.ORG_txtNRegistro.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtNRegistro.TabIndex = 61
        '
        'ORG_lblEmailEmpresarial
        '
        Me.ORG_lblEmailEmpresarial.AutoSize = True
        Me.ORG_lblEmailEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblEmailEmpresarial.Location = New System.Drawing.Point(116, 281)
        Me.ORG_lblEmailEmpresarial.Name = "ORG_lblEmailEmpresarial"
        Me.ORG_lblEmailEmpresarial.Size = New System.Drawing.Size(111, 17)
        Me.ORG_lblEmailEmpresarial.TabIndex = 60
        Me.ORG_lblEmailEmpresarial.Text = "Email empresarial:"
        '
        'ORG_lblTelfEmpresarial
        '
        Me.ORG_lblTelfEmpresarial.AutoSize = True
        Me.ORG_lblTelfEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblTelfEmpresarial.Location = New System.Drawing.Point(116, 252)
        Me.ORG_lblTelfEmpresarial.Name = "ORG_lblTelfEmpresarial"
        Me.ORG_lblTelfEmpresarial.Size = New System.Drawing.Size(128, 17)
        Me.ORG_lblTelfEmpresarial.TabIndex = 59
        Me.ORG_lblTelfEmpresarial.Text = "Telefono empresarial:"
        '
        'ORG_lblDepartamento
        '
        Me.ORG_lblDepartamento.AutoSize = True
        Me.ORG_lblDepartamento.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblDepartamento.Location = New System.Drawing.Point(116, 223)
        Me.ORG_lblDepartamento.Name = "ORG_lblDepartamento"
        Me.ORG_lblDepartamento.Size = New System.Drawing.Size(92, 17)
        Me.ORG_lblDepartamento.TabIndex = 58
        Me.ORG_lblDepartamento.Text = "Departamento:"
        '
        'ORG_lblGrado
        '
        Me.ORG_lblGrado.AutoSize = True
        Me.ORG_lblGrado.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblGrado.Location = New System.Drawing.Point(116, 194)
        Me.ORG_lblGrado.Name = "ORG_lblGrado"
        Me.ORG_lblGrado.Size = New System.Drawing.Size(44, 17)
        Me.ORG_lblGrado.TabIndex = 57
        Me.ORG_lblGrado.Text = "Grado:"
        '
        'ORG_lblCargo
        '
        Me.ORG_lblCargo.AutoSize = True
        Me.ORG_lblCargo.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblCargo.Location = New System.Drawing.Point(116, 165)
        Me.ORG_lblCargo.Name = "ORG_lblCargo"
        Me.ORG_lblCargo.Size = New System.Drawing.Size(44, 17)
        Me.ORG_lblCargo.TabIndex = 56
        Me.ORG_lblCargo.Text = "Cargo:"
        '
        'ORG_lblFIngreso
        '
        Me.ORG_lblFIngreso.AutoSize = True
        Me.ORG_lblFIngreso.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblFIngreso.Location = New System.Drawing.Point(116, 136)
        Me.ORG_lblFIngreso.Name = "ORG_lblFIngreso"
        Me.ORG_lblFIngreso.Size = New System.Drawing.Size(106, 17)
        Me.ORG_lblFIngreso.TabIndex = 55
        Me.ORG_lblFIngreso.Text = "Fecha de ingreso:"
        '
        'ORG_lblNRegistro
        '
        Me.ORG_lblNRegistro.AutoSize = True
        Me.ORG_lblNRegistro.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblNRegistro.Location = New System.Drawing.Point(116, 107)
        Me.ORG_lblNRegistro.Name = "ORG_lblNRegistro"
        Me.ORG_lblNRegistro.Size = New System.Drawing.Size(117, 17)
        Me.ORG_lblNRegistro.TabIndex = 54
        Me.ORG_lblNRegistro.Text = "Número de registro:"
        '
        'ORG_txtRUT
        '
        Me.ORG_txtRUT.BackColor = System.Drawing.Color.White
        Me.ORG_txtRUT.Enabled = False
        Me.ORG_txtRUT.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_txtRUT.Location = New System.Drawing.Point(278, 76)
        Me.ORG_txtRUT.Name = "ORG_txtRUT"
        Me.ORG_txtRUT.Size = New System.Drawing.Size(132, 20)
        Me.ORG_txtRUT.TabIndex = 53
        '
        'ORG_lblRUT
        '
        Me.ORG_lblRUT.AutoSize = True
        Me.ORG_lblRUT.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblRUT.Location = New System.Drawing.Point(116, 78)
        Me.ORG_lblRUT.Name = "ORG_lblRUT"
        Me.ORG_lblRUT.Size = New System.Drawing.Size(33, 17)
        Me.ORG_lblRUT.TabIndex = 52
        Me.ORG_lblRUT.Text = "RUT:"
        '
        'btnorganizacion
        '
        Me.btnorganizacion.BackColor = System.Drawing.Color.Transparent
        Me.btnorganizacion.FlatAppearance.BorderSize = 0
        Me.btnorganizacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnorganizacion.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnorganizacion.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnorganizacion.Image = Global.TAX.My.Resources.Resources.enterprise_gris
        Me.btnorganizacion.Location = New System.Drawing.Point(105, 0)
        Me.btnorganizacion.Name = "btnorganizacion"
        Me.btnorganizacion.Size = New System.Drawing.Size(105, 57)
        Me.btnorganizacion.TabIndex = 1
        Me.btnorganizacion.Text = "ORGANIZACION"
        Me.btnorganizacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnorganizacion.UseVisualStyleBackColor = False
        '
        'btnficha
        '
        Me.btnficha.FlatAppearance.BorderSize = 0
        Me.btnficha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnficha.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnficha.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.btnficha.Image = Global.TAX.My.Resources.Resources.ficha_violeta1
        Me.btnficha.Location = New System.Drawing.Point(1, 0)
        Me.btnficha.Name = "btnficha"
        Me.btnficha.Size = New System.Drawing.Size(105, 57)
        Me.btnficha.TabIndex = 0
        Me.btnficha.Text = "FICHA"
        Me.btnficha.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnficha.UseVisualStyleBackColor = True
        '
        'FICHA_btnCambioContraseña
        '
        Me.FICHA_btnCambioContraseña.BackColor = System.Drawing.Color.Transparent
        Me.FICHA_btnCambioContraseña.FlatAppearance.BorderSize = 0
        Me.FICHA_btnCambioContraseña.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.FICHA_btnCambioContraseña.Image = Global.TAX.My.Resources.Resources.edit__2_
        Me.FICHA_btnCambioContraseña.Location = New System.Drawing.Point(416, 161)
        Me.FICHA_btnCambioContraseña.Name = "FICHA_btnCambioContraseña"
        Me.FICHA_btnCambioContraseña.Size = New System.Drawing.Size(25, 25)
        Me.FICHA_btnCambioContraseña.TabIndex = 56
        Me.FICHA_btnCambioContraseña.UseVisualStyleBackColor = False
        '
        'inftrabajador
        '
        Me.inftrabajador.BackColor = System.Drawing.Color.White
        Me.inftrabajador.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatAppearance.BorderSize = 0
        Me.inftrabajador.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.inftrabajador.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.inftrabajador.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.inftrabajador.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.inftrabajador.Image = CType(resources.GetObject("inftrabajador.Image"), System.Drawing.Image)
        Me.inftrabajador.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.inftrabajador.Location = New System.Drawing.Point(6, 6)
        Me.inftrabajador.Name = "inftrabajador"
        Me.inftrabajador.Size = New System.Drawing.Size(354, 53)
        Me.inftrabajador.TabIndex = 53
        Me.inftrabajador.Text = "Información del Trabajador"
        Me.inftrabajador.UseVisualStyleBackColor = False
        '
        'ORG_lblInfEmpresarial
        '
        Me.ORG_lblInfEmpresarial.BackColor = System.Drawing.Color.White
        Me.ORG_lblInfEmpresarial.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ORG_lblInfEmpresarial.FlatAppearance.BorderSize = 0
        Me.ORG_lblInfEmpresarial.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ORG_lblInfEmpresarial.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ORG_lblInfEmpresarial.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ORG_lblInfEmpresarial.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORG_lblInfEmpresarial.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.ORG_lblInfEmpresarial.Image = CType(resources.GetObject("ORG_lblInfEmpresarial.Image"), System.Drawing.Image)
        Me.ORG_lblInfEmpresarial.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ORG_lblInfEmpresarial.Location = New System.Drawing.Point(6, 6)
        Me.ORG_lblInfEmpresarial.Name = "ORG_lblInfEmpresarial"
        Me.ORG_lblInfEmpresarial.Size = New System.Drawing.Size(354, 53)
        Me.ORG_lblInfEmpresarial.TabIndex = 68
        Me.ORG_lblInfEmpresarial.Text = "Información Empresarial"
        Me.ORG_lblInfEmpresarial.UseVisualStyleBackColor = False
        '
        'User_Ficha
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(842, 509)
        Me.Controls.Add(Me.buttonpanel)
        Me.Controls.Add(Me.tabcontrolficha)
        Me.Controls.Add(Me.panel_up)
        Me.Controls.Add(Me.panel_down)
        Me.Controls.Add(Me.panel_der)
        Me.Controls.Add(Me.panel_izq)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "User_Ficha"
        Me.Text = "fichauserinicio"
        Me.tabcontrolficha.ResumeLayout(False)
        Me.tabpageficha.ResumeLayout(False)
        Me.tabpageficha.PerformLayout()
        Me.tabpageorganizacion.ResumeLayout(False)
        Me.tabpageorganizacion.PerformLayout()
        Me.buttonpanel.ResumeLayout(False)
        Me.pnlBarraGris.ResumeLayout(False)
        Me.panel_izq.ResumeLayout(False)
        Me.panel_down.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tabcontrolficha As System.Windows.Forms.TabControl
    Friend WithEvents tabpageficha As System.Windows.Forms.TabPage
    Friend WithEvents tabpageorganizacion As System.Windows.Forms.TabPage
    Friend WithEvents buttonpanel As System.Windows.Forms.Panel
    Friend WithEvents btnorganizacion As System.Windows.Forms.Button
    Friend WithEvents btnficha As System.Windows.Forms.Button
    Friend WithEvents panel_izq As System.Windows.Forms.Panel
    Friend WithEvents panel_izq2 As System.Windows.Forms.Panel
    Friend WithEvents panel_der As System.Windows.Forms.Panel
    Friend WithEvents panel_down As System.Windows.Forms.Panel
    Friend WithEvents panel_down2 As System.Windows.Forms.Panel
    Friend WithEvents panel_up As System.Windows.Forms.Panel
    Friend WithEvents pnlBarraGris As System.Windows.Forms.Panel
    Friend WithEvents pnlSelection As System.Windows.Forms.Panel
    Friend WithEvents FICHA_btnCambioContraseña As System.Windows.Forms.Button
    Friend WithEvents FICHA_txtDirNumero As System.Windows.Forms.TextBox
    Friend WithEvents Ficha_lblEspacio As System.Windows.Forms.Label
    Friend WithEvents inftrabajador As System.Windows.Forms.Button
    Friend WithEvents FICHA_txtFijo As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtCelular As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtHijos As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtEstCivil As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtCalle As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtFNacimiento As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtSexo As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtContraseña As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtApellido As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_txtNombre As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_lblFijo As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblCelular As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblHijos As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblEmail As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblEstCivil As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblDireccion As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblFNacimiento As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblSexo As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblContraseña As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblApellido As System.Windows.Forms.Label
    Friend WithEvents FICHA_lblNombre As System.Windows.Forms.Label
    Friend WithEvents FICHA_txtDocumento As System.Windows.Forms.TextBox
    Friend WithEvents FICHA_lblDocumento As System.Windows.Forms.Label
    Friend WithEvents ORG_txtMailEmpresarial As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtTlfEmpresarial As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtDepartamento As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtGrado As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtCargo As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtFIngreso As System.Windows.Forms.TextBox
    Friend WithEvents ORG_txtNRegistro As System.Windows.Forms.TextBox
    Friend WithEvents ORG_lblEmailEmpresarial As System.Windows.Forms.Label
    Friend WithEvents ORG_lblTelfEmpresarial As System.Windows.Forms.Label
    Friend WithEvents ORG_lblDepartamento As System.Windows.Forms.Label
    Friend WithEvents ORG_lblGrado As System.Windows.Forms.Label
    Friend WithEvents ORG_lblCargo As System.Windows.Forms.Label
    Friend WithEvents ORG_lblFIngreso As System.Windows.Forms.Label
    Friend WithEvents ORG_lblNRegistro As System.Windows.Forms.Label
    Friend WithEvents ORG_txtRUT As System.Windows.Forms.TextBox
    Friend WithEvents ORG_lblRUT As System.Windows.Forms.Label
    Friend WithEvents ORG_lblInfEmpresarial As System.Windows.Forms.Button
End Class
