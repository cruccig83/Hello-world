﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_LiquidarSueldos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlSup = New System.Windows.Forms.Panel
        Me.pnlDer = New System.Windows.Forms.Panel
        Me.pnlIzq = New System.Windows.Forms.Panel
        Me.pnlInf = New System.Windows.Forms.Panel
        Me.pnlCentral = New System.Windows.Forms.Panel
        Me.TabControl_FormadeTrabajo = New System.Windows.Forms.TabControl
        Me.TabPage_Mensual = New System.Windows.Forms.TabPage
        Me.TabPage_Semanal = New System.Windows.Forms.TabPage
        Me.TabPage_Jornalero = New System.Windows.Forms.TabPage
        Me.pnlBotones = New System.Windows.Forms.Panel
        Me.btnMensual = New System.Windows.Forms.Button
        Me.btnJornalero = New System.Windows.Forms.Button
        Me.btnHorario = New System.Windows.Forms.Button
        Me.pnlCentral.SuspendLayout()
        Me.TabControl_FormadeTrabajo.SuspendLayout()
        Me.pnlBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlSup
        '
        Me.pnlSup.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlSup.Location = New System.Drawing.Point(0, 0)
        Me.pnlSup.Name = "pnlSup"
        Me.pnlSup.Size = New System.Drawing.Size(802, 20)
        Me.pnlSup.TabIndex = 0
        '
        'pnlDer
        '
        Me.pnlDer.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlDer.Location = New System.Drawing.Point(782, 20)
        Me.pnlDer.Name = "pnlDer"
        Me.pnlDer.Size = New System.Drawing.Size(20, 383)
        Me.pnlDer.TabIndex = 1
        '
        'pnlIzq
        '
        Me.pnlIzq.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlIzq.Location = New System.Drawing.Point(0, 20)
        Me.pnlIzq.Name = "pnlIzq"
        Me.pnlIzq.Size = New System.Drawing.Size(20, 383)
        Me.pnlIzq.TabIndex = 2
        '
        'pnlInf
        '
        Me.pnlInf.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlInf.Location = New System.Drawing.Point(20, 383)
        Me.pnlInf.Name = "pnlInf"
        Me.pnlInf.Size = New System.Drawing.Size(762, 20)
        Me.pnlInf.TabIndex = 3
        '
        'pnlCentral
        '
        Me.pnlCentral.BackColor = System.Drawing.Color.White
        Me.pnlCentral.Controls.Add(Me.pnlBotones)
        Me.pnlCentral.Controls.Add(Me.TabControl_FormadeTrabajo)
        Me.pnlCentral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlCentral.Location = New System.Drawing.Point(20, 20)
        Me.pnlCentral.Name = "pnlCentral"
        Me.pnlCentral.Size = New System.Drawing.Size(762, 363)
        Me.pnlCentral.TabIndex = 4
        '
        'TabControl_FormadeTrabajo
        '
        Me.TabControl_FormadeTrabajo.Controls.Add(Me.TabPage_Mensual)
        Me.TabControl_FormadeTrabajo.Controls.Add(Me.TabPage_Jornalero)
        Me.TabControl_FormadeTrabajo.Controls.Add(Me.TabPage_Semanal)
        Me.TabControl_FormadeTrabajo.Location = New System.Drawing.Point(0, 0)
        Me.TabControl_FormadeTrabajo.Name = "TabControl_FormadeTrabajo"
        Me.TabControl_FormadeTrabajo.Padding = New System.Drawing.Point(6, 22)
        Me.TabControl_FormadeTrabajo.SelectedIndex = 0
        Me.TabControl_FormadeTrabajo.Size = New System.Drawing.Size(762, 360)
        Me.TabControl_FormadeTrabajo.TabIndex = 0
        '
        'TabPage_Mensual
        '
        Me.TabPage_Mensual.Location = New System.Drawing.Point(4, 60)
        Me.TabPage_Mensual.Name = "TabPage_Mensual"
        Me.TabPage_Mensual.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Mensual.Size = New System.Drawing.Size(754, 296)
        Me.TabPage_Mensual.TabIndex = 0
        Me.TabPage_Mensual.Text = "TabPage_Mensual"
        Me.TabPage_Mensual.UseVisualStyleBackColor = True
        '
        'TabPage_Semanal
        '
        Me.TabPage_Semanal.Location = New System.Drawing.Point(4, 60)
        Me.TabPage_Semanal.Name = "TabPage_Semanal"
        Me.TabPage_Semanal.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Semanal.Size = New System.Drawing.Size(754, 296)
        Me.TabPage_Semanal.TabIndex = 1
        Me.TabPage_Semanal.Text = "TabPage_Jornalero"
        Me.TabPage_Semanal.UseVisualStyleBackColor = True
        '
        'TabPage_Jornalero
        '
        Me.TabPage_Jornalero.Location = New System.Drawing.Point(4, 60)
        Me.TabPage_Jornalero.Name = "TabPage_Jornalero"
        Me.TabPage_Jornalero.Size = New System.Drawing.Size(754, 296)
        Me.TabPage_Jornalero.TabIndex = 2
        Me.TabPage_Jornalero.Text = "TabPage_Horal"
        Me.TabPage_Jornalero.UseVisualStyleBackColor = True
        '
        'pnlBotones
        '
        Me.pnlBotones.Controls.Add(Me.btnHorario)
        Me.pnlBotones.Controls.Add(Me.btnJornalero)
        Me.pnlBotones.Controls.Add(Me.btnMensual)
        Me.pnlBotones.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBotones.Location = New System.Drawing.Point(0, 0)
        Me.pnlBotones.Name = "pnlBotones"
        Me.pnlBotones.Size = New System.Drawing.Size(762, 60)
        Me.pnlBotones.TabIndex = 1
        '
        'btnMensual
        '
        Me.btnMensual.FlatAppearance.BorderSize = 0
        Me.btnMensual.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMensual.Location = New System.Drawing.Point(0, 0)
        Me.btnMensual.Name = "btnMensual"
        Me.btnMensual.Size = New System.Drawing.Size(93, 57)
        Me.btnMensual.TabIndex = 0
        Me.btnMensual.Text = "MENSUAL"
        Me.btnMensual.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnMensual.UseVisualStyleBackColor = True
        '
        'btnJornalero
        '
        Me.btnJornalero.FlatAppearance.BorderSize = 0
        Me.btnJornalero.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnJornalero.Location = New System.Drawing.Point(93, 0)
        Me.btnJornalero.Name = "btnJornalero"
        Me.btnJornalero.Size = New System.Drawing.Size(93, 57)
        Me.btnJornalero.TabIndex = 1
        Me.btnJornalero.Text = "JORNALERO"
        Me.btnJornalero.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnJornalero.UseVisualStyleBackColor = True
        '
        'btnHorario
        '
        Me.btnHorario.FlatAppearance.BorderSize = 0
        Me.btnHorario.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHorario.Location = New System.Drawing.Point(186, 0)
        Me.btnHorario.Name = "btnHorario"
        Me.btnHorario.Size = New System.Drawing.Size(93, 57)
        Me.btnHorario.TabIndex = 2
        Me.btnHorario.Text = "HORARIO"
        Me.btnHorario.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnHorario.UseVisualStyleBackColor = True
        '
        'Admin_LiquidarSueldos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(802, 403)
        Me.Controls.Add(Me.pnlCentral)
        Me.Controls.Add(Me.pnlInf)
        Me.Controls.Add(Me.pnlIzq)
        Me.Controls.Add(Me.pnlDer)
        Me.Controls.Add(Me.pnlSup)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_LiquidarSueldos"
        Me.Text = "Admin_LiquidarSueldos"
        Me.pnlCentral.ResumeLayout(False)
        Me.TabControl_FormadeTrabajo.ResumeLayout(False)
        Me.pnlBotones.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlSup As System.Windows.Forms.Panel
    Friend WithEvents pnlDer As System.Windows.Forms.Panel
    Friend WithEvents pnlIzq As System.Windows.Forms.Panel
    Friend WithEvents pnlInf As System.Windows.Forms.Panel
    Friend WithEvents pnlCentral As System.Windows.Forms.Panel
    Friend WithEvents pnlBotones As System.Windows.Forms.Panel
    Friend WithEvents btnHorario As System.Windows.Forms.Button
    Friend WithEvents btnJornalero As System.Windows.Forms.Button
    Friend WithEvents btnMensual As System.Windows.Forms.Button
    Friend WithEvents TabControl_FormadeTrabajo As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_Mensual As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_Jornalero As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_Semanal As System.Windows.Forms.TabPage
End Class
