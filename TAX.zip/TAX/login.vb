﻿Imports MySql.Data.MySqlClient
Public Class login
    Dim cnn As New MySqlConnection
    Dim dataadapter As MySqlDataAdapter
    Dim dataset As New DataSet
    Dim comma As MySqlCommand
    Dim da As MySqlDataAdapter
    Dim cmd As New MySqlCommand
    Dim sql As String
    Dim sw As Boolean = False
    Dim variable As Integer



    Private Sub txtcorreo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdoc.TextChanged

    End Sub

   
    Private Sub cmdentrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdentrar.Click
        Module1.document = txtdoc.Text


        If (personaexists(txtdoc.Text, txtpasswd.Text)) Then
            MsgBox("Bienvenido")
        Else
            MsgBox("Documento y/o contraseña incorrectos")
        End If

        If variable = 2 Then
            User_Principal.Show()
            Me.Close()
        ElseIf variable = 1 Then
            Admin_Principal.Show()
            Me.Close()
        End If

    End Sub
    Function personaexists(ByVal document As Integer, ByVal password As String) As Boolean
        Try
            cnn.ConnectionString = ("data source=localhost;user id=root; password='1234';database=tax")
            sql = "SELECT * FROM personal WHERE doc= '" & document & "' and passwd= '" & password & "'  "
            cnn.Open()
            dataadapter = New MySqlDataAdapter(sql, cnn)
            dataset.Clear()
            dataadapter.Fill(dataset, "personal")
            Dim DA As New MySqlDataAdapter(sql, cnn)
            Dim DS As New DataSet
            DA.Fill(DS, "personal")


            If (dataset.Tables("personal").Rows.Count() <> 0) Then
                MsgBox("Bienvenido al sistema")
                sw = True
            Else
                MsgBox("Usuario y/o contraseña incorrectos")

            End If
            If DS.Tables("personal").Columns.Count > 0 Then
                variable = DS.Tables("personal").Rows(0)("rol")

                MessageBox.Show(variable)

            End If


        Catch ex As Exception
            MsgBox(ex.ToString)


        End Try
        Return (sw)
    End Function

    Private Sub login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtpasswd.UseSystemPasswordChar = True
    End Sub


    
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If txtpasswd.UseSystemPasswordChar = False Then
            txtpasswd.UseSystemPasswordChar = True
            Button1.Image = My.Resources.ver_16
        Else
            txtpasswd.UseSystemPasswordChar = False
            Button1.Image = My.Resources.ocultar

        End If


    End Sub
End Class
